package com.suzai.suzaiflowersystem;

import org.junit.Test;
import static org.junit.Assert.*;

import java.lang.reflect.Method;

/**
 * 测试时间戳解析修复（Bug #3）
 * 验证 isoToMs() 方法对各种时间格式的兼容性
 */
public class TimestampParseTest {
    
    // 使用反射调用私有方法 isoToMs
    private long callIsoToMs(String timeStr) throws Exception {
        Class<?> clazz = Class.forName("com.suzai.suzaiflowersystem.SupabaseSyncManager");
        Method method = clazz.getDeclaredMethod("isoToMs", String.class);
        method.setAccessible(true);
        return (long) method.invoke(null, timeStr);
    }
    
    @Test
    public void testStandardIsoFormat() throws Exception {
        // 标准ISO格式：2025-12-30T16:05:36.762Z
        long result = callIsoToMs("2025-12-30T16:05:36.762Z");
        assertTrue("标准ISO格式应能解析", result > 0);
    }
    
    @Test
    public void testSupabaseFormatWithSpace() throws Exception {
        // Supabase常见格式：2025-12-30 16:05:36.762495+00
        long result = callIsoToMs("2025-12-30 16:05:36.762495+00");
        assertTrue("空格分隔格式应能解析", result > 0);
    }
    
    @Test
    public void testShortTimezone() throws Exception {
        // 短时区格式：2025-12-30T16:05:36+00
        long result = callIsoToMs("2025-12-30T16:05:36+00");
        assertTrue("短时区格式应能解析", result > 0);
    }
    
    @Test
    public void testLongMilliseconds() throws Exception {
        // 长毫秒格式：2025-12-30T16:05:36.123456+00:00
        long result = callIsoToMs("2025-12-30T16:05:36.123456+00:00");
        assertTrue("长毫秒格式应能解析", result > 0);
    }
    
    @Test
    public void testSimpleFormat() throws Exception {
        // 简单格式：2025-12-30 16:05:36
        long result = callIsoToMs("2025-12-30 16:05:36");
        assertTrue("简单格式应能解析", result > 0);
    }
    
    @Test
    public void testNullInput() throws Exception {
        // 空输入
        long result = callIsoToMs(null);
        assertEquals("null输入应返回0", 0, result);
    }
    
    @Test
    public void testEmptyInput() throws Exception {
        // 空字符串
        long result = callIsoToMs("");
        assertEquals("空字符串应返回0", 0, result);
    }
    
    @Test
    public void testInvalidFormat() throws Exception {
        // 无效格式
        long result = callIsoToMs("invalid-date-format");
        assertEquals("无效格式应返回0", 0, result);
    }
}