package com.suzai.suzaiflowersystem;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * 测试网络重试逻辑修复（Bug #4）
 * 验证指数退避重试机制
 */
public class NetworkRetryTest {
    
    @Test
    public void testIsFatalErrorDetection() {
        // 测试致命错误识别
        assertTrue("400应为致命错误", isFatalError(400));
        assertTrue("403应为致命错误", isFatalError(403));
        assertTrue("404应为致命错误", isFatalError(404));
        assertTrue("409应为致命错误", isFatalError(409));
        assertTrue("500应为致命错误", isFatalError(500));
        
        assertFalse("429不应为致命错误", isFatalError(429));
        assertFalse("502不应为致命错误", isFatalError(502));
        assertFalse("503不应为致命错误", isFatalError(503));
        assertFalse("504不应为致命错误", isFatalError(504));
    }
    
    @Test
    public void testIsRetryableErrorDetection() {
        // 测试可重试错误识别
        assertTrue("429应为可重试错误", isRetryableError(429));
        assertTrue("502应为可重试错误", isRetryableError(502));
        assertTrue("503应为可重试错误", isRetryableError(503));
        assertTrue("504应为可重试错误", isRetryableError(504));
        
        assertFalse("400不应为可重试错误", isRetryableError(400));
        assertFalse("200不应为可重试错误", isRetryableError(200));
        assertFalse("304不应为可重试错误", isRetryableError(304));
    }
    
    @Test
    public void testRetryDelaySequence() {
        // 测试重试延迟序列
        long[] delays = {1000, 3000, 5000};
        assertEquals("应有3次重试延迟", 3, delays.length);
        assertTrue("第一次重试延迟应为1秒", delays[0] == 1000);
        assertTrue("第二次重试延迟应为3秒", delays[1] == 3000);
        assertTrue("第三次重试延迟应为5秒", delays[2] == 5000);
        
        // 验证延迟递增（指数退避）
        assertTrue("延迟应递增", delays[1] > delays[0]);
        assertTrue("延迟应递增", delays[2] > delays[1]);
    }
    
    @Test
    public void testMaxRetriesLimit() {
        // 测试最大重试次数限制
        int maxRetries = 3;
        assertEquals("最大重试次数应为3", 3, maxRetries);
        assertTrue("应有合理的重试上限", maxRetries >= 1 && maxRetries <= 5);
    }
    
    // 辅助方法（模拟SupabaseSyncManager中的方法）
    private boolean isFatalError(int code) {
        if (code == 400 || code == 403 || code == 404 || code == 405 || 
            code == 409 || code == 422 || code >= 500) {
            return true;
        }
        return false;
    }
    
    private boolean isRetryableError(int code) {
        return code == 429 || code == 502 || code == 503 || code == 504;
    }
}