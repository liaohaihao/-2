package com.suzai.suzaiflowersystem;

import android.os.Bundle;
import android.widget.TextView;

public class SyncLogActivity extends BaseDrawerActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("同步日志");
        TextView tv = new TextView(this);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        tv.setPadding(p, p, p, p);
        tv.setText("为降低数据泄露风险，正式版已关闭同步日志查看与诊断包导出功能。");
        setContentView(tv);
    }
}
