package com.suzai.suzaiflowersystem;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * SupabaseSyncManager（可覆盖版）
 *
 * 目标（保持你当前功能不变）：
 * 1) 登录后：从云端拉取 customers / products / inventory_items / print_templates / orders 等恢复本地
 * 2) 本地变更后：把本地快照上传到云端（写入 Supabase 表）
 *
 * P0-2 改动：
 * - orders 的 pull：优先增量（updated_at > last_pull），失败/首次/周期性回退全量
 * - 仍由 DatabaseHelper.replaceMasterDataFromCloud(md) 落库；你P0-1的DB逻辑会对 orders 做 upsert/merge，保留 printed/synced
 */
public class SupabaseSyncManager {

    private static final String TAG = "SupabaseSync";

    // --- P1-1: persist sync logs inside app (so users can view/copy without Logcat) ---
    private static void logD(Context ctx, String msg) {
        Log.d(TAG, msg);
        // 兼容本项目内的 SyncLogStore 接口（append 而不是 appendLine）
        try { SyncLogStore.append(ctx, "D", TAG, msg); } catch (Exception ignored) {}
    }
    private static void logW(Context ctx, String msg) {
        Log.w(TAG, msg);
        // 兼容本项目内的 SyncLogStore 接口（append 而不是 appendLine）
        try { SyncLogStore.append(ctx, "W", TAG, msg); } catch (Exception ignored) {}
    }
    private static void logE(Context ctx, String msg) {
        Log.e(TAG, msg);
        // 兼容本项目内的 SyncLogStore 接口（append 而不是 appendLine）
        try { SyncLogStore.append(ctx, "E", TAG, msg); } catch (Exception ignored) {}
    }

    private static final String SP_CFG = "supabase_cfg";
    private static final String KEY_URL = "supabase_url";
    private static final String KEY_ANON = "supabase_anon_key";

    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    // ✅ 组织共享：customers/products/print_templates 使用 org_id 过滤与写入
    private static final String KEY_ORG_ID = "org_id"; // stored in auth_prefs

    // ✅ 增量订单推送：避免每次都 INSERT 全量 orders 造成云端重复
    private static final String SP_STATE_PREFIX = "sync_state_";
    // ✅ 按账号隔离同步状态：避免 A 账号的 last_pull/last_push 影响 B 账号
    private static SharedPreferences spState(Context ctx) {
        String uid = AuthManager.getUserId(ctx);
        if (uid == null || uid.trim().isEmpty()) uid = "anon";
        return ctx.getSharedPreferences(SP_STATE_PREFIX + uid, Context.MODE_PRIVATE);
    }
    private static final String KEY_LAST_PUSHED_ORDER_ID = "last_pushed_order_id";
    private static final String KEY_LAST_PUSHED_LOGISTICS_ID = "last_pushed_logistics_id";

    // ===== P1：主数据增量/dirty push 状态（按 updated_at）=====
    private static final String KEY_LAST_PUSH_CUSTOMERS_TS = "last_push_customers_ts";
    private static final String KEY_LAST_PUSH_PRODUCTS_TS = "last_push_products_ts";
    private static final String KEY_LAST_PUSH_TEMPLATES_TS = "last_push_print_templates_ts";
    private static final String KEY_LAST_PUSH_INVENTORY_TS = "last_push_inventory_items_ts";


    // ✅ P0-2：orders 增量 pull 状态
    private static final String SP_PULL_PREFIX = "sync_pull_state_";
    // ✅ 按账号隔离订单/明细拉取状态：避免切换账号后只做增量导致"拉不回历史订单"
    private static SharedPreferences spPull(Context ctx) {
        String uid = AuthManager.getUserId(ctx);
        if (uid == null || uid.trim().isEmpty()) uid = "anon";
        return ctx.getSharedPreferences(SP_PULL_PREFIX + uid, Context.MODE_PRIVATE);
    }
    private static final String KEY_ORDERS_LAST_PULL_MS = "orders_last_pull_ms";
    private static final String KEY_ORDERS_LAST_FULL_PULL_MS = "orders_last_full_pull_ms";
    private static final String KEY_ORDER_ITEMS_LAST_PULL_MS = "order_items_last_pull_ms";
    private static final String KEY_ORDER_ITEMS_LAST_FULL_PULL_MS = "order_items_last_full_pull_ms";
    private static final String KEY_CUSTOMERS_LAST_PULL_MS = "customers_last_pull_ms";
    private static final String KEY_PRODUCTS_LAST_PULL_MS = "products_last_pull_ms";
    private static final String KEY_TEMPLATES_LAST_PULL_MS = "print_templates_last_pull_ms";
    private static final String KEY_INVENTORY_LAST_PULL_MS = "inventory_items_last_pull_ms";
    private static final String KEY_LOGISTICS_FORMS_LAST_PULL_MS = "logistics_forms_last_pull_ms";
    private static final String KEY_LOGISTICS_SIZES_LAST_PULL_MS = "logistics_sizes_last_pull_ms";
    private static final String KEY_BOOTSTRAP_DONE = "bootstrap_done";

    // 手动恢复范围
    public static final String SCOPE_CUSTOMERS = "customers";
    public static final String SCOPE_PRODUCTS = "products";
    public static final String SCOPE_TEMPLATES = "print_templates";
    public static final String SCOPE_INVENTORY = "inventory_items";
    public static final String SCOPE_ORDERS = "orders";
    public static final String SCOPE_LOGISTICS = "logistics";
    public static final String SCOPE_FINANCE = "finance";

    private static final long ORDERS_FORCE_FULL_PULL_INTERVAL_MS = 7L * 24 * 3600 * 1000;

    // ✅ P1：orders 拉取分页/时间窗（防止订单量大时全量拉取性能塌）
    private static final int ORDERS_PAGE_SIZE = 300;
    // 修复：移除最大页数限制，实现持续分页直到获取所有数据
    private static final int ORDERS_MAX_PAGES_PER_QUERY = 0; // 0表示无限制，持续分页直到获取所有数据
    private static final int ORDERS_FULL_PULL_MAX_MONTHS = 2;  // 全量回退时最多拉取近 2 个自然月热数据
 // 7天强制全量一次

    private static final OkHttpClient http = new OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(40, TimeUnit.SECONDS)
            .writeTimeout(40, TimeUnit.SECONDS)
            .build();



    private static boolean isRetryableConnectError(IOException e) {
        if (e == null) return false;
        if (e instanceof java.net.ConnectException) return true;
        if (e instanceof java.net.SocketTimeoutException) {
            String m = e.getMessage();
            return m == null || m.contains("failed to connect") || m.contains("timeout");
        }
        return false;
    }

    private static Response executeWithRetry(Request request) throws IOException {
        IOException last = null;
        for (int attempt = 1; attempt <= 3; attempt++) {
            try {
                return http.newCall(request).execute();
            } catch (IOException e) {
                last = e;
                if (!isRetryableConnectError(e) || attempt >= 3) throw e;
                try { Thread.sleep(1200L * attempt); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); throw e; }
            }
        }
        throw last != null ? last : new IOException("request failed");
    }

    // v4 防抖：避免同一时刻多线程重复 push/DELETE/UPSERT
    private static final Object PUSH_LOCK = new Object();
    private static volatile boolean pushRunning = false;
    private static volatile boolean pushPending = false;
    private static volatile long lastPushStartTime = 0L;
    private static volatile long lastPushFinishTime = 0L;
    private static final long MIN_PUSH_INTERVAL_MS = 5000L; // 5秒内不重复push
    private static final long POST_PUSH_COOLDOWN_MS = 8000L; // push刚结束8秒内忽略重复后台触发

    public interface SyncCallback {
        void onDone(boolean ok, String msg);
    }

    /**
     * 统一 UI 轻提示：不改变任何同步逻辑，仅广播"同步结果"给前台页面。
     * BaseDrawerActivity 会接收并显示 Toast。
     */
    private static void broadcastSyncEvent(Context ctx, boolean ok, String msg) {
        try {
            Intent i = new Intent(BaseDrawerActivity.ACTION_SYNC_EVENT);
            i.setPackage(ctx.getPackageName());
            i.putExtra(BaseDrawerActivity.EXTRA_SYNC_OK, ok);
            i.putExtra(BaseDrawerActivity.EXTRA_SYNC_MSG, msg);
            ctx.sendBroadcast(i);
        } catch (Exception ignored) {}
    }

    /**
     * 登录成功后调用：从云端恢复数据到本地。
     */
    public static void pullThenRestoreLocal(Context ctx, SyncCallback cb) {
        pullThenRestoreLocal(ctx, null, cb);
    }

    public static void pullThenRestoreLocal(Context ctx, java.util.Set<String> scopes, SyncCallback cb) {
        new Thread(() -> {
            try {
                JSONObject md = fetchMasterData(ctx, true, scopes);
                if (md == null) {
                    String m = "云端无数据或拉取失败（请看日志）";
                    logD(ctx, m);
                    post(cb, false, m);
                    return;
                }
                DatabaseHelper db = new DatabaseHelper(ctx);
                String base = getBaseUrl(ctx);

                try {
                    if (base != null) processCloudDeletes(ctx, base, db);
                } catch (Exception e) {
                    Log.e(TAG, "processCloudDeletes(pull) error", e);
                }

                db.replaceMasterDataFromCloud(md);
                syncDirtyBaselineFromPulledData(ctx, md);
                try {
                    long nowPull = System.currentTimeMillis();
                    android.content.SharedPreferences.Editor ed = spPull(ctx).edit();
                    if (md.has("customers")) ed.putLong(KEY_CUSTOMERS_LAST_PULL_MS, nowPull);
                    if (md.has("products")) ed.putLong(KEY_PRODUCTS_LAST_PULL_MS, nowPull);
                    if (md.has("print_templates")) ed.putLong(KEY_TEMPLATES_LAST_PULL_MS, nowPull);
                    if (md.has("inventory_items")) ed.putLong(KEY_INVENTORY_LAST_PULL_MS, nowPull);
                    if (md.has("logistics_forms")) ed.putLong(KEY_LOGISTICS_FORMS_LAST_PULL_MS, nowPull);
                    if (md.has("logistics_sizes")) ed.putLong(KEY_LOGISTICS_SIZES_LAST_PULL_MS, nowPull);
                    if (md.has("orders")) ed.putLong(KEY_ORDERS_LAST_PULL_MS, nowPull).putLong(KEY_ORDERS_LAST_FULL_PULL_MS, nowPull);
                    if (md.has("order_items")) ed.putLong(KEY_ORDER_ITEMS_LAST_PULL_MS, nowPull).putLong(KEY_ORDER_ITEMS_LAST_FULL_PULL_MS, nowPull);
                    ed.apply();
                    try { spState(ctx).edit().putBoolean(KEY_BOOTSTRAP_DONE, true).apply(); } catch (Exception ignored) {}
                } catch (Exception ignored) {}

                try {
                    if (md.has("inventory_items")) {
                        int localInv = getLocalInventoryCount(ctx);
                        if (localInv == 0 && base != null) {
                            String uid2 = getUserId(ctx);
                            String uidEnc2 = java.net.URLEncoder.encode(uid2, java.nio.charset.StandardCharsets.UTF_8.name());
                            org.json.JSONArray cloudInv = fetchInventoryItemsCloudSafe(ctx, base, uidEnc2);
                            if (cloudInv != null && cloudInv.length() > 0) {
                                org.json.JSONObject onlyInv = new org.json.JSONObject();
                                onlyInv.put("inventory_items", cloudInv);
                                db.replaceMasterDataFromCloud(onlyInv);
                                bumpLastPushTs(ctx, KEY_LAST_PUSH_INVENTORY_TS, cloudInv);
                                Log.w(TAG, "inventory_items restored from cloud, count=" + cloudInv.length());
                            }
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "inventory restore guard error", e);
                }

                try {
                    int maxId = db.getMaxOrderId();
                    spState(ctx).edit().putInt(KEY_LAST_PUSHED_ORDER_ID, maxId).apply();
                } catch (Exception ignored) { }

                try {
                    logD(ctx, "云端热数据窗口起点: " + getDateTwoYearsAgo() + "（仅同步近2个自然月）");
                } catch (Exception ignored) {}

                String m = buildRestoreResultMessage(md, scopes);
                logD(ctx, m);
                post(cb, true, m);

            } catch (Exception e) {
                Log.e(TAG, "pullThenRestoreLocal error", e);
                String m = "拉取失败：" + e.getMessage();
                logD(ctx, m);
                post(cb, false, m);
            }
        }).start();
    }

    public static boolean shouldBootstrapAfterLogin(Context ctx) {
        try {
            if (!ready(ctx)) return false;
            SharedPreferences st = spState(ctx);
            if (st.getBoolean(KEY_BOOTSTRAP_DONE, false)) return false;
            SharedPreferences pull = spPull(ctx);
            boolean neverPulled = pull.getLong(KEY_ORDERS_LAST_PULL_MS, 0L) <= 0L
                    && pull.getLong(KEY_CUSTOMERS_LAST_PULL_MS, 0L) <= 0L
                    && pull.getLong(KEY_PRODUCTS_LAST_PULL_MS, 0L) <= 0L
                    && pull.getLong(KEY_TEMPLATES_LAST_PULL_MS, 0L) <= 0L
                    && pull.getLong(KEY_INVENTORY_LAST_PULL_MS, 0L) <= 0L
                    && pull.getLong(KEY_LOGISTICS_FORMS_LAST_PULL_MS, 0L) <= 0L;
            if (!neverPulled) return false;
            // 新装/卸载重装后，优先自动恢复；不再要求本地六张表都严格为空
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean isBootstrapLocalEmpty(Context ctx) {
        return getLocalTableCount(ctx, "orders") <= 0
                && getLocalTableCount(ctx, "customers") <= 0
                && getLocalTableCount(ctx, "products") <= 0
                && getLocalTableCount(ctx, "inventory_items") <= 0
                && getLocalTableCount(ctx, "print_templates") <= 0
                && getLocalTableCount(ctx, "logistics_forms") <= 0;
    }

    private static String buildRestoreResultMessage(JSONObject md, java.util.Set<String> scopes) {
        if (md == null) return "云端数据已恢复到本地";
        java.util.List<String> parts = new java.util.ArrayList<>();
        appendRestoreCount(parts, "客户", md.optJSONArray("customers"));
        appendRestoreCount(parts, "产品", md.optJSONArray("products"));
        appendRestoreCount(parts, "打印模板", md.optJSONArray("print_templates"));
        appendRestoreCount(parts, "库存", md.optJSONArray("inventory_items"));
        int orders = arrLen(md, "orders");
        int items = arrLen(md, "order_items");
        if (orders > 0 || items > 0 || wants(scopes, SCOPE_ORDERS) && (md.has("orders") || md.has("order_items"))) {
            parts.add("订单/明细 " + orders + "/" + items + " 条");
        }
        int forms = arrLen(md, "logistics_forms");
        int sizes = arrLen(md, "logistics_sizes");
        if (forms > 0 || sizes > 0 || wants(scopes, SCOPE_LOGISTICS) && (md.has("logistics_forms") || md.has("logistics_sizes"))) {
            parts.add("物流/尺寸 " + forms + "/" + sizes + " 条");
        }
        int invs = arrLen(md, "ar_invoices");
        int pays = arrLen(md, "ar_payments");
        int allocs = arrLen(md, "ar_allocations");
        if (invs > 0 || pays > 0 || allocs > 0 || wants(scopes, SCOPE_FINANCE) && (md.has("ar_invoices") || md.has("ar_payments") || md.has("ar_allocations"))) {
            parts.add("财务 发票/回款/核销 " + invs + "/" + pays + "/" + allocs + " 条");
        }
        if (parts.isEmpty()) return "云端数据已恢复到本地";
        return "恢复完成：\n" + android.text.TextUtils.join("\n", parts);
    }

    private static void appendRestoreCount(java.util.List<String> parts, String label, JSONArray arr) {
        if (arr != null) parts.add(label + " " + arr.length() + " 条");
    }

    private static int arrLen(JSONObject md, String key) {
        try {
            JSONArray arr = md.optJSONArray(key);
            return arr == null ? 0 : arr.length();
        } catch (Exception ignored) {
            return 0;
        }
    }

    private static int getLocalTableCount(Context ctx, String table) {
        int cnt = 0;
        DatabaseHelper dbh = null;
        SQLiteDatabase db = null;
        Cursor c = null;
        try {
            dbh = new DatabaseHelper(ctx);
            db = dbh.getReadableDatabase();
            c = db.rawQuery("SELECT COUNT(*) FROM " + table, null);
            if (c.moveToFirst()) cnt = c.getInt(0);
        } catch (Exception ignored) {
        } finally {
            try { if (c != null) c.close(); } catch (Exception ignored) {}
            try { if (db != null && db.isOpen()) db.close(); } catch (Exception ignored) {}
            try { if (dbh != null) dbh.close(); } catch (Exception ignored) {}
        }
        return cnt;
    }

    /**
     * 主动上传快照
     */
    public static void pushSnapshot(Context ctx, SyncCallback cb) {
        requestPush(ctx, cb);
    }

    /**
     * 本地写入后调用
     */
    public static void schedulePush(Context ctx) {
        requestPush(ctx, null);
    }

    // ----------------- internal -----------------


    // =========================
    // Inventory safety-restore (防止库存"空覆盖/误清空")
    // =========================

    /** 本地 inventory_items 行数（SQLite） */
    private static int getLocalInventoryCount(Context ctx) {
        int cnt = 0;
        DatabaseHelper dbh = null;
        SQLiteDatabase db = null;
        Cursor c = null;
        try {
            dbh = new DatabaseHelper(ctx);
            db = dbh.getReadableDatabase();
            c = db.rawQuery("SELECT COUNT(*) FROM inventory_items", null);
            if (c.moveToFirst()) cnt = c.getInt(0);
        } catch (Exception ignored) {
        } finally {
            try { if (c != null) c.close(); } catch (Exception ignored) {}
            try { if (db != null && db.isOpen()) db.close(); } catch (Exception ignored) {}
            try { if (dbh != null) dbh.close(); } catch (Exception ignored) {}
        }
        return cnt;
    }

    /**
     * 云端拉取库存（双策略）：
     * 1) 先按 owner_uid=eq.uid 拉取（快且明确）
     * 2) 若返回空数组，额外再拉一次不加 where（让 RLS 自行过滤）
     */
    private static JSONArray fetchInventoryItemsCloudSafe(Context ctx, String base, String uidEnc) {
        try {
            JSONArray a = getArray(ctx, base + "/rest/v1/inventory_items?select=*&owner_uid=eq." + uidEnc);
            if (a != null && a.length() > 0) return a;

            // 返回空：可能是 where 过滤不匹配 / RLS 策略变化 / 临时异常
            JSONArray b = getArray(ctx, base + "/rest/v1/inventory_items?select=*");
            if (b != null) return b;
            return a; // 可能是空数组或 null
        } catch (Exception e) {
            return null;
        }
    }

private static void post(SyncCallback cb, boolean ok, String msg) {
        if (cb == null) return;
        cb.onDone(ok, msg);
    }

    private static void requestPush(Context ctx, SyncCallback cb) {
        boolean shouldStart;
        synchronized (PUSH_LOCK) {
            long now = System.currentTimeMillis();
            if (!pushRunning && cb == null && lastPushFinishTime > 0L && (now - lastPushFinishTime < POST_PUSH_COOLDOWN_MS)) {
                shouldStart = false;
                logD(ctx, "Push suppressed: cooldown " + (now - lastPushFinishTime) + "ms after previous sync");
            } else if (pushRunning && (now - lastPushStartTime < MIN_PUSH_INTERVAL_MS)) {
                pushPending = true;
                shouldStart = false;
                logD(ctx, "Push throttled: too frequent, last started " + (now - lastPushStartTime) + "ms ago");
            } else if (pushRunning) {
                pushPending = true;
                shouldStart = false;
            } else {
                pushRunning = true;
                lastPushStartTime = now;
                shouldStart = true;
            }
        }
        if (!shouldStart) {
            post(cb, true, "同步节流中");
            return;
        }

        new Thread(() -> {
            try {
                int[] result = pushAllWithCount(ctx);
                boolean ok = result[0] == 1;
                int changeCount = result[1];
                boolean isFirstSync = result[2] == 1;
                
                // 完全移除广播提示功能，只记录日志
                if (changeCount > 0) {
                    String logMsg;
                    if (isFirstSync) {
                        logMsg = "同步完成：" + changeCount + "条数据（首次同步）";
                    } else {
                        logMsg = "同步完成：" + changeCount + "条数据（增量同步）";
                    }
                    logD(ctx, logMsg);
                    post(cb, ok, logMsg);
                } else {
                    // 无实际变更内容
                    String logMsg = "无新数据需要同步";
                    logD(ctx, logMsg);
                    post(cb, true, logMsg);
                }
            } catch (Exception e) {
                Log.e(TAG, "pushSnapshot error", e);
                String logMsg = "上传失败：" + e.getMessage();
                logD(ctx, logMsg);
                post(cb, false, logMsg);
            }

            while (true) {
                boolean doAgain;
                synchronized (PUSH_LOCK) {
                    if (pushPending) {
                        pushPending = false;
                        doAgain = true;
                    } else {
                        pushRunning = false;
                        lastPushFinishTime = System.currentTimeMillis();
                        doAgain = false;
                    }
                }
                if (!doAgain) break;
                try {
                    pushAllWithCount(ctx); // 只执行同步，不处理提示（已经在第一次处理过了）
                } catch (Exception e) {
                    Log.e(TAG, "pushSnapshot(pending) error", e);
                }
            }
        }).start();
    }

    private static String getBaseUrl(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(SP_CFG, Context.MODE_PRIVATE);

        String u = sp.getString(KEY_URL, null);
        if (TextUtils.isEmpty(u)) u = sp.getString("base_url", null);
        if (TextUtils.isEmpty(u)) u = sp.getString("baseUrl", null);

        if (TextUtils.isEmpty(u)) return null;

        u = normalizeBaseUrl(u);
        return TextUtils.isEmpty(u) ? null : u;
    }

    private static String normalizeBaseUrl(String raw) {
        if (raw == null) return null;
        String u = raw.trim();

        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);

        u = stripSuffix(u, "/rest/v1");
        u = stripSuffix(u, "/functions/v1");
        u = stripSuffix(u, "/api");
        u = stripSuffix(u, "/api/sync");
        u = stripSuffix(u, "/api/master-data");

        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);

        return u;
    }

    private static String stripSuffix(String s, String suffix) {
        if (s == null || suffix == null) return s;
        if (s.endsWith(suffix)) return s.substring(0, s.length() - suffix.length());
        return s;
    }

    private static String getAnonKey(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(SP_CFG, Context.MODE_PRIVATE);

        String k = sp.getString(KEY_ANON, null);
        if (TextUtils.isEmpty(k)) k = sp.getString("anon_key", null);
        if (TextUtils.isEmpty(k)) k = sp.getString("anonKey", null);

        return TextUtils.isEmpty(k) ? null : k;
    }

    private static String getAccessToken(Context ctx) {
        return AuthManager.getToken(ctx);
    }

    private static String getUserId(Context ctx) {
        return AuthManager.getUserId(ctx);
    }

    private static String getOrgId(Context ctx) {
        return AuthManager.getOrgId(ctx);
    }

    private static String ensureOrgId(Context ctx) {
        String cached = getOrgId(ctx);
        if (cached != null && !cached.trim().isEmpty()) return cached.trim();
        try {
            String base = getBaseUrl(ctx);
            if (base == null || base.trim().isEmpty()) return null;

            String url = base + "/rest/v1/rpc/my_org_id";
            RequestBody rb = RequestBody.create("{}", JSON);
            Request req = withHeaders(ctx, url)
                    .post(rb)
                    .build();

            try (Response resp = executeWithRetry(req)) {
                String raw = resp.body() != null ? resp.body().string() : "";
                if (!resp.isSuccessful()) {
                    if (resp.code() == 401) {
                        String newToken = refreshAccessToken(ctx);
                        if (newToken != null) {
                            Request req2 = withHeaders(ctx, url).post(rb).build();
                            try (Response resp2 = executeWithRetry(req2)) {
                                String raw2 = resp2.body() != null ? resp2.body().string() : "";
                                String org = parseOrgIdFromRpc(raw2);
                                if (org != null) {
                                    AuthManager.setOrgId(ctx, org);
                                    return org;
                                }
                            }
                        }
                    }
                    return null;
                }

                String org = parseOrgIdFromRpc(raw);
                if (org != null) {
                    AuthManager.setOrgId(ctx, org);
                    return org;
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private static String parseOrgIdFromRpc(String raw) {
        if (raw == null) return null;
        String s = raw.trim();
        if (s.isEmpty() || "null".equalsIgnoreCase(s)) return null;
        try {
            if (s.startsWith("\"") && s.endsWith("\"")) {
                s = s.substring(1, s.length() - 1);
                return s.trim().isEmpty() ? null : s.trim();
            }
            if (s.startsWith("[")) {
                org.json.JSONArray arr = new org.json.JSONArray(s);
                if (arr.length() > 0) {
                    org.json.JSONObject o = arr.optJSONObject(0);
                    if (o != null) {
                        String v = o.optString("org_id", null);
                        if (v == null || v.trim().isEmpty()) v = o.optString("org", null);
                        return (v == null || v.trim().isEmpty()) ? null : v.trim();
                    }
                }
                return null;
            }
            if (s.startsWith("{")) {
                org.json.JSONObject o = new org.json.JSONObject(s);
                String v = o.optString("org_id", null);
                if (v == null || v.trim().isEmpty()) v = o.optString("org", null);
                return (v == null || v.trim().isEmpty()) ? null : v.trim();
            }
            return s;
        } catch (Exception ignored) {
            return null;
        }
    }

    private static boolean ready(Context ctx) {
        String base = getBaseUrl(ctx);
        String anon = getAnonKey(ctx);
        String token = getAccessToken(ctx);
        String uid = getUserId(ctx);

        if (TextUtils.isEmpty(token)) {
            try {
                String newToken = refreshAccessToken(ctx);
                if (!TextUtils.isEmpty(newToken)) {
                    token = newToken;
                    try {
                        ctx.getSharedPreferences("auth_prefs", Context.MODE_PRIVATE)
                                .edit()
                                .putString("auth_token", newToken)
                                .commit();
                    } catch (Exception ignored) { }
                }
            } catch (Exception ignored) { }
        }

        boolean ok = !TextUtils.isEmpty(base)
                && !TextUtils.isEmpty(anon)
                && !TextUtils.isEmpty(token)
                && !TextUtils.isEmpty(uid);

        if (!ok) {
            Log.w(TAG, "not ready: base=" + safe(base) + ", anon=" + (TextUtils.isEmpty(anon) ? "EMPTY" : "OK")
                    + ", token=" + (TextUtils.isEmpty(token) ? "EMPTY" : "OK")
                    + ", uid=" + (TextUtils.isEmpty(uid) ? "EMPTY" : uid));
        }
        return ok;
    }

    private static String safe(String s) {
        if (s == null) return "null";
        return s;
    }

    private static String nvl(String s) {
        if (s == null) return "";
        String v = s.trim();
        if ("null".equalsIgnoreCase(v) || "(null)".equalsIgnoreCase(v)) return "";
        return s;
    }

    private static Request.Builder withHeaders(Context ctx, String url) {
        String anon = getAnonKey(ctx);
        String token = getAccessToken(ctx);
        // 商用稳定性：若 token 为空，先尝试用 refresh_token 换新 token（避免第一次请求就 401）
        if (TextUtils.isEmpty(token)) {
            try {
                String nt = refreshAccessToken(ctx);
                if (!TextUtils.isEmpty(nt)) token = nt;
            } catch (Exception ignored) {}
        }
        return new Request.Builder()
                .url(url)
                .addHeader("apikey", anon == null ? "" : anon)
                .addHeader("Authorization", "Bearer " + (token == null ? "" : token))
                .addHeader("Accept", "application/json");
    }

    // ===== P0-2 helper: ms -> ISO-8601 UTC =====
    private static String msToIsoUtc(long ms) {
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US);
            sdf.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            return sdf.format(new java.util.Date(ms));
        } catch (Exception e) {
            return String.valueOf(ms);
        }
    }


    // ===== P1：ISO时间解析（兼容 Supabase timestamptz / 数字时间戳）=====
    private static long isoToMs(String s) {
        if (s == null) return 0L;
        String t = s.trim();
        if (t.isEmpty()) return 0L;

        try {
            if (t.matches("^\\d{10,17}$")) {
                long v = Long.parseLong(t);
                return (t.length() <= 10) ? (v * 1000L) : v;
            }
        } catch (Exception ignored) {}

        try {
            // 兼容：2025-12-30 16:05:36.762495+00  -> 2025-12-30T16:05:36.762495+00:00
            if (t.contains(" ") && t.contains("+") && !t.contains("T")) {
                t = t.replace(" ", "T");
                int p = t.lastIndexOf('+');
                if (p > 0 && t.length() - p == 3) t = t + ":00";
            }
            if (t.endsWith("+00")) t = t + ":00";
            if (t.endsWith("-00")) t = t + ":00";

            if (t.contains(".")) {
                int dotIndex = t.indexOf('.');
                int zIndex = t.indexOf('Z', dotIndex);
                int plusIndex = t.indexOf('+', dotIndex);
                int minusIndex = t.indexOf('-', dotIndex + 1);

                int endIndex = t.length();
                if (zIndex > dotIndex) endIndex = zIndex;
                else if (plusIndex > dotIndex) endIndex = plusIndex;
                else if (minusIndex > dotIndex) endIndex = minusIndex;

                if (endIndex - dotIndex > 4) {
                    String millis = t.substring(dotIndex + 1, endIndex);
                    if (millis.length() > 3) {
                        millis = millis.substring(0, 3);
                        t = t.substring(0, dotIndex + 1) + millis + t.substring(endIndex);
                    }
                }
            }

            String[] fmts = new String[] {
                    "yyyy-MM-dd'T'HH:mm:ss.SSSX",
                    "yyyy-MM-dd'T'HH:mm:ss.SSSSSSX",
                    "yyyy-MM-dd'T'HH:mm:ssX",
                    "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                    "yyyy-MM-dd'T'HH:mm:ss'Z'",
                    "yyyy-MM-dd HH:mm:ss.SSS",
                    "yyyy-MM-dd HH:mm:ss",
                    "yyyy-MM-dd"
            };
            for (String f : fmts) {
                try {
                    java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(f, java.util.Locale.US);
                    sdf.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
                    java.util.Date d = sdf.parse(t);
                    if (d != null) return d.getTime();
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
        return 0L;
    }

    // ===== P1：按 updated_at 过滤"脏数据"（仅上传变更行）=====
    private static JSONArray filterDirtyByUpdatedAt(Context ctx, JSONArray arr, String spKey) {
        if (arr == null) return null;
        long last = 0L;
        try { last = spState(ctx).getLong(spKey, 0L); } catch (Exception ignored) {}

        // 没有增量基准：返回原数组（等同全量一次）
        if (last <= 0L) return arr;

        JSONArray out = new JSONArray();
        boolean hasUpdatedAt = false;
        for (int i = 0; i < arr.length(); i++) {
            try {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String u = o.optString("updated_at", null);
                if (u == null || u.trim().isEmpty()) {
                    // 有些表可能叫 updatedAt
                    u = o.optString("updatedAt", null);
                }
                if (u != null && !u.trim().isEmpty()) {
                    hasUpdatedAt = true;
                    long ts = isoToMs(u);
                    if (ts > last) out.put(o);
                } else {
                    // 没有 updated_at 的行：为安全起见加入（避免漏推）
                    out.put(o);
                }
            } catch (Exception ignored) {}
        }
        // 如果整个表都没有 updated_at 字段，则无法做增量，退化为全量
        if (!hasUpdatedAt) return arr;
        return out;
    }

    private static void bumpLastPushTs(Context ctx, String spKey, JSONArray pushed) {
        if (pushed == null || pushed.length() == 0) return;
        long max = 0L;
        for (int i = 0; i < pushed.length(); i++) {
            try {
                JSONObject o = pushed.optJSONObject(i);
                if (o == null) continue;
                String u = o.optString("updated_at", null);
                if (u == null || u.trim().isEmpty()) u = o.optString("updatedAt", null);
                long ts = isoToMs(u);
                if (ts > max) max = ts;
            } catch (Exception ignored) {}
        }
        if (max <= 0L) max = System.currentTimeMillis();
        try { spState(ctx).edit().putLong(spKey, max).apply(); } catch (Exception ignored) {}
    }

    // P1 final: after pull-after-push, reset incremental baseline to cloud's latest updated_at
    // so freshly pulled server timestamps won't be re-uploaded as dirty on the next sync.
    private static void syncDirtyBaselineFromPulledData(Context ctx, JSONObject merged) {
        if (ctx == null || merged == null) return;
        try {
            bumpLastPushTs(ctx, KEY_LAST_PUSH_CUSTOMERS_TS, merged.optJSONArray("customers"));
        } catch (Exception ignored) {}
        try {
            bumpLastPushTs(ctx, KEY_LAST_PUSH_PRODUCTS_TS, merged.optJSONArray("products"));
        } catch (Exception ignored) {}
        try {
            bumpLastPushTs(ctx, KEY_LAST_PUSH_TEMPLATES_TS, merged.optJSONArray("print_templates"));
        } catch (Exception ignored) {}
        try {
            bumpLastPushTs(ctx, KEY_LAST_PUSH_INVENTORY_TS, merged.optJSONArray("inventory_items"));
        } catch (Exception ignored) {}
    }


    // ===== P1 helper: URL 加分页参数 =====
    private static String withLimitOffset(String urlBase, int limit, int offset) {
        if (urlBase == null) return null;
        String u = urlBase;
        String sep = u.contains("?") ? "&" : "?";
        if (!u.contains("limit=")) u += sep + "limit=" + limit;
        else u = u.replaceAll("([&?])limit=\\d+", "$1limit=" + limit);
        // offset 可能重复，统一替换/追加
        if (u.contains("offset=")) {
            u = u.replaceAll("([&?])offset=\\d+", "$1offset=" + offset);
        } else {
            u += (u.contains("?") ? "&" : "?") + "offset=" + offset;
        }
        return u;
    }

    // ===== P1 helper: 分页拉取数组（返回合并后的 JSONArray；失败返回 null）=====
    private static JSONArray getArrayPaged(Context ctx, String urlBase, int pageSize, int maxPages) throws IOException {
        if (urlBase == null) return null;
        JSONArray all = new JSONArray();
        int offset = 0;
        int pageCount = 0;
        
        // 修复：支持无限制分页（maxPages=0表示无限制）
        boolean unlimited = (maxPages == 0);
        int maxIterations = unlimited ? Integer.MAX_VALUE : maxPages;
        
        while (pageCount < maxIterations) {
            String u = withLimitOffset(urlBase, pageSize, offset);
            JSONArray one = getArray(ctx, u);
            if (one == null) {
                // 若第一页就失败，直接失败；若后续页失败，返回已拿到的数据
                return (pageCount == 0) ? null : all;
            }
            if (one.length() == 0) {
                break;
            }
            for (int i = 0; i < one.length(); i++) {
                all.put(one.opt(i));
            }
            if (one.length() < pageSize) break;
            offset += pageSize;
            pageCount++;
            
            // 添加日志，便于调试
            if (pageCount % 10 == 0) {
                logD(ctx, "分页拉取进度：已获取" + pageCount + "页，" + all.length() + "条记录");
            }
        }
        
        if (unlimited && pageCount > 0) {
            logD(ctx, "无限制分页完成：共获取" + pageCount + "页，" + all.length() + "条记录");
        }
        
        return all;
    }

    private static JSONArray getArrayIncremental(Context ctx, String urlBase, String spKey, boolean forceFull) {
        try {
            SharedPreferences sp = spPull(ctx);
            long last = sp.getLong(spKey, 0L);
            String url = urlBase;
            if (!forceFull && last > 0L) {
                url += "&updated_at=gt." + URLEncoder.encode(toIso8601(last), StandardCharsets.UTF_8.name()) + "&order=updated_at.asc";
            }
            JSONArray arr = getArrayPaged(ctx, url, 500, 0);
            if (arr != null) {
                sp.edit().putLong(spKey, System.currentTimeMillis()).apply();
            }
            return arr;
        } catch (Exception e) {
            logW(ctx, "incremental pull failed for " + spKey + ": " + e.getMessage());
            return null;
        }
    }

    private static JSONArray fetchInventoryItemsCloudIncrementalSafe(Context ctx, String base, String uidEnc, boolean forceFull) {
        JSONArray a = getArrayIncremental(ctx, base + "/rest/v1/inventory_items?select=*&owner_uid=eq." + uidEnc, KEY_INVENTORY_LAST_PULL_MS, forceFull);
        if (a != null && (a.length() > 0 || !forceFull)) return a;
        return getArrayIncremental(ctx, base + "/rest/v1/inventory_items?select=*", KEY_INVENTORY_LAST_PULL_MS, forceFull);
    }

    private static JSONArray fetchLogisticsSizesForForms(Context ctx, String base, JSONArray forms, boolean forceFull) {
        if (forms == null) return null;
        java.util.LinkedHashSet<String> formIds = new java.util.LinkedHashSet<>();
        for (int i = 0; i < forms.length(); i++) {
            try {
                JSONObject o = forms.optJSONObject(i);
                if (o == null) continue;
                String id = o.optString("id", null);
                if (id != null && !id.trim().isEmpty() && !"null".equalsIgnoreCase(id)) formIds.add(id.trim());
            } catch (Exception ignored) {}
        }
        JSONArray merged = new JSONArray();
        if (formIds.isEmpty()) {
            try { if (forceFull) spPull(ctx).edit().putLong(KEY_LOGISTICS_SIZES_LAST_PULL_MS, System.currentTimeMillis()).apply(); } catch (Exception ignored) {}
            return merged;
        }
        java.util.List<String> ids = new java.util.ArrayList<>(formIds);
        for (int i = 0; i < ids.size(); i += 100) {
            int end = Math.min(i + 100, ids.size());
            StringBuilder inClause = new StringBuilder();
            for (int j = i; j < end; j++) {
                if (j > i) inClause.append(',');
                inClause.append(ids.get(j));
            }
            String url = base + "/rest/v1/logistics_sizes?select=*&form_id=in.(" + inClause + ")";
            try {
                JSONArray part = getArrayPaged(ctx, url, 1000, 5);
                if (part != null) {
                    for (int k = 0; k < part.length(); k++) merged.put(part.opt(k));
                }
            } catch (IOException ioe) {
                logW(ctx, "fetch logistics_sizes by form batch failed: " + ioe.getMessage());
            }
        }
        try { spPull(ctx).edit().putLong(KEY_LOGISTICS_SIZES_LAST_PULL_MS, System.currentTimeMillis()).apply(); } catch (Exception ignored) {}
        return merged;
    }


    // ===== Orders pull helper: try different user-key columns (owner_uid / tenant_id) =====
    private static JSONArray pullOrdersWindowed(Context ctx, String base, String uidEnc, String userCol, String extraQuery) throws IOException {
        // ✅ 回退全量：按月份窗口（最近 N 个月），每个月分页拉取，避免一次性拉取全部历史订单
        JSONArray all = new JSONArray();
        int total = 0;

        // 额外包含“下个月”窗口，支持提前一天录入下月订单（如 4/1 订单在 3/31 录入）
        for (int m = -1; m < ORDERS_FULL_PULL_MAX_MONTHS; m++) {
            String[] range = monthRange(m);
            String start = range[0];
            String end = range[1];

            StringBuilder monthUrlB = new StringBuilder();
            monthUrlB.append(base).append("/rest/v1/orders?select=*");
            if (userCol != null && uidEnc != null) {
                monthUrlB.append("&").append(userCol).append("=eq.").append(uidEnc);
            }
            if (extraQuery != null && !extraQuery.trim().isEmpty()) {
                if (extraQuery.startsWith("&")) monthUrlB.append(extraQuery);
                else monthUrlB.append("&").append(extraQuery);
            }
            monthUrlB.append("&date=gte.").append(URLEncoder.encode(start, StandardCharsets.UTF_8.name()))
                    .append("&date=lt.").append(URLEncoder.encode(end, StandardCharsets.UTF_8.name()))
                    .append("&order=date.desc");
            String monthUrl = monthUrlB.toString();

            JSONArray part = getArrayPaged(ctx, monthUrl, ORDERS_PAGE_SIZE, ORDERS_MAX_PAGES_PER_QUERY);
            if (part == null) {
                // 如果 date 过滤不被支持（字段类型不匹配等），再兜底：不加 date 窗口但仍分页（只取前几页）
                logW(ctx, "orders monthly window failed (" + userCol + "), fallback to paged full (no date filter)");
                StringBuilder fullUrlB = new StringBuilder();
                fullUrlB.append(base).append("/rest/v1/orders?select=*");
                if (userCol != null && uidEnc != null) {
                    fullUrlB.append("&").append(userCol).append("=eq.").append(uidEnc);
                }
                if (extraQuery != null && !extraQuery.trim().isEmpty()) {
                    if (extraQuery.startsWith("&")) fullUrlB.append(extraQuery);
                    else fullUrlB.append("&").append(extraQuery);
                }
                fullUrlB.append("&order=date.desc");
                String fullUrl = fullUrlB.toString();
                return getArrayPaged(ctx, fullUrl, ORDERS_PAGE_SIZE, ORDERS_MAX_PAGES_PER_QUERY);
            }

            if (part.length() == 0) {
                continue;
            }

            for (int i = 0; i < part.length(); i++) {
                all.put(part.opt(i));
            }
            total += part.length();

            // 修复：移除单次恢复限制，实现持续分页直到获取所有数据
            // 添加日志记录恢复进度
            if (total % 1000 == 0) {
                logD(ctx, "订单恢复进度：已获取" + total + "条订单记录");
            }
        }

        logD(ctx, "订单恢复完成：共获取" + total + "条订单记录");
        return all;
    }

    private static JSONArray pullOrdersIncremental(Context ctx, String base, String uidEnc, String userCol, long lastPull, String extraQuery) throws IOException {
        String iso = msToIsoUtc(lastPull);
        StringBuilder incUrlB = new StringBuilder();
        incUrlB.append(base).append("/rest/v1/orders?select=*");
        if (userCol != null && uidEnc != null) {
            incUrlB.append("&").append(userCol).append("=eq.").append(uidEnc);
        }
        if (extraQuery != null && !extraQuery.trim().isEmpty()) {
            if (extraQuery.startsWith("&")) incUrlB.append(extraQuery);
            else incUrlB.append("&").append(extraQuery);
        }
        incUrlB.append("&updated_at=gt.").append(URLEncoder.encode(iso, StandardCharsets.UTF_8.name()));
        
        // ✅ 添加2年时间限制：只拉取最近24个月的数据
        String twoYearsAgo = getDateTwoYearsAgo();
        incUrlB.append("&date=gte.").append(URLEncoder.encode(twoYearsAgo, StandardCharsets.UTF_8.name()));
        
        incUrlB.append("&order=updated_at.asc");
        String incUrl = incUrlB.toString();
        return getArrayPaged(ctx, incUrl, ORDERS_PAGE_SIZE, ORDERS_MAX_PAGES_PER_QUERY);
    }

    private static JSONArray pullOrdersSmart(Context ctx, String base, String uidEnc, long lastPull, boolean forceFull, String extraQuery, boolean allowCrossUser) throws IOException {
        // 先试 owner_uid，再试 tenant_id（兼容历史版本/字段差异）
        String[] cols = allowCrossUser ? new String[]{null} : new String[]{"owner_uid", "tenant_id"};
        JSONArray best = null;

        for (String col : cols) {
            JSONArray arr;
            if (!forceFull) {
                arr = pullOrdersIncremental(ctx, base, uidEnc, col, lastPull, extraQuery);
                if (arr != null) return arr; // 增量成功直接返回
                logW(ctx, "orders incremental pull failed on " + col + ", try next / fallback to full");
            }

            arr = pullOrdersWindowed(ctx, base, uidEnc, col, extraQuery);
            if (arr != null && arr.length() > 0) return arr;

            // 记录一个"成功但为空"的结果，避免最后返回 null
            if (arr != null && best == null) best = arr;
        }

        return best; // 可能为空数组，但不为 null
    }
// ===== P1 helper: 计算某个月份窗口的 [start, end)（格式 yyyy-MM-dd）；m=-1 表示下个月，0 表示本月，1 表示上个月 =====
    private static String[] monthRange(int monthsOffsetFromCurrent) {
        java.util.Calendar cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));
        cal.set(java.util.Calendar.DAY_OF_MONTH, 1);
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0);
        cal.set(java.util.Calendar.MINUTE, 0);
        cal.set(java.util.Calendar.SECOND, 0);
        cal.set(java.util.Calendar.MILLISECOND, 0);

        cal.add(java.util.Calendar.MONTH, -monthsOffsetFromCurrent);
        java.util.Date startDate = cal.getTime();

        cal.add(java.util.Calendar.MONTH, 1);
        java.util.Date endDate = cal.getTime();

        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
        sdf.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        return new String[]{sdf.format(startDate), sdf.format(endDate)};
    }

    // ===== 近2个自然月云端窗口：取“上一个自然月的第一天”（格式 yyyy-MM-dd）=====
    private static String getDateTwoYearsAgo() {
        java.util.Calendar cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));
        cal.set(java.util.Calendar.DAY_OF_MONTH, 1);
        cal.add(java.util.Calendar.MONTH, -1);
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0);
        cal.set(java.util.Calendar.MINUTE, 0);
        cal.set(java.util.Calendar.SECOND, 0);
        cal.set(java.util.Calendar.MILLISECOND, 0);

        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
        sdf.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        return sdf.format(cal.getTime());
    }

    private static boolean isOnOrAfterWindowStart(String value) {
        String boundary = getDateTwoYearsAgo();
        if (value == null) return false;
        String v = value.trim();
        if (v.isEmpty()) return false;
        if (v.length() >= 10) v = v.substring(0, 10);
        return v.compareTo(boundary) >= 0;
    }

    private static JSONArray filterRowsByDateWindow(JSONArray src, String... keys) {
        if (src == null || src.length() == 0) return src;
        JSONArray out = new JSONArray();
        for (int i = 0; i < src.length(); i++) {
            JSONObject o = src.optJSONObject(i);
            if (o == null) continue;
            boolean keep = false;
            for (String key : keys) {
                String v = o.optString(key, null);
                if (isOnOrAfterWindowStart(v)) { keep = true; break; }
            }
            if (keep) out.put(o);
        }
        return out;
    }

    private static java.util.HashSet<String> collectStringSet(JSONArray arr, String key) {
        java.util.HashSet<String> set = new java.util.HashSet<>();
        if (arr == null) return set;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String v = o.optString(key, "");
            if (v != null && !v.trim().isEmpty()) set.add(v.trim());
        }
        return set;
    }

    private static JSONArray filterRowsByRefSet(JSONArray src, String key, java.util.Set<String> refs) {
        if (src == null || src.length() == 0) return src;
        if (refs == null || refs.isEmpty()) return new JSONArray();
        JSONArray out = new JSONArray();
        for (int i = 0; i < src.length(); i++) {
            JSONObject o = src.optJSONObject(i);
            if (o == null) continue;
            String v = o.optString(key, "");
            if (v != null && refs.contains(v.trim())) out.put(o);
        }
        return out;
    }

    private static JSONObject fetchMasterData(Context ctx) throws IOException {
        return fetchMasterData(ctx, false, null);
    }

    private static JSONObject fetchMasterData(Context ctx, boolean forceFullRestore) throws IOException {
        return fetchMasterData(ctx, forceFullRestore, null);
    }

    private static boolean wants(java.util.Set<String> scopes, String scope) {
        return scopes == null || scopes.isEmpty() || scopes.contains(scope);
    }

    private static JSONObject fetchMasterData(Context ctx, boolean forceFullRestore, java.util.Set<String> scopes) throws IOException {
        if (!ready(ctx)) return null;

        String base = getBaseUrl(ctx);
        String uid = getUserId(ctx);

        String uidEnc = URLEncoder.encode(uid, StandardCharsets.UTF_8.name());

        // ✅ 组织共享：customers/products/print_templates 走 org_id；没有组织则回退到 owner_uid
        String orgId = null;
        String orgEnc = null;
        try {
            orgId = ensureOrgId(ctx);
            if (orgId != null) orgEnc = URLEncoder.encode(orgId, StandardCharsets.UTF_8.name());
        } catch (Exception ignored) {}

        JSONObject md = new JSONObject();

        // customers
        boolean forceMasterFull = forceFullRestore;
        if (wants(scopes, SCOPE_CUSTOMERS)) {
            String customersUrl = (orgEnc != null)
                    ? (base + "/rest/v1/customers?select=*&org_id=eq." + orgEnc)
                    : (base + "/rest/v1/customers?select=*");
            JSONArray customers = getArrayIncremental(ctx, customersUrl, KEY_CUSTOMERS_LAST_PULL_MS, forceMasterFull);
            if (customers != null) {
                try { md.put("customers", customers); } catch (Exception e) { Log.e(TAG, "md.put customers failed", e); }
            }
        }

        // products
        if (wants(scopes, SCOPE_PRODUCTS)) {
            String productsUrl = (orgEnc != null)
                    ? (base + "/rest/v1/products?select=*&org_id=eq." + orgEnc)
                    : (base + "/rest/v1/products?select=*");
            JSONArray products = getArrayIncremental(ctx, productsUrl, KEY_PRODUCTS_LAST_PULL_MS, forceMasterFull);
            if (products != null) {
                try { md.put("products", products); } catch (Exception e) { Log.e(TAG, "md.put products failed", e); }
            }
        }

        // inventory_items
        if (wants(scopes, SCOPE_INVENTORY)) {
            JSONArray inv = fetchInventoryItemsCloudIncrementalSafe(ctx, base, uidEnc, forceMasterFull);
            if (inv != null) {
                if (inv.length() == 0) {
                    int localCnt = getLocalInventoryCount(ctx);
                    if (localCnt > 0) {
                        Log.w(TAG, "inventory_items cloud empty but localCnt=" + localCnt + " -> skip md.put(inventory_items) to prevent wipe");
                    } else {
                        try { md.put("inventory_items", inv); } catch (Exception e) { Log.e(TAG, "md.put inventory_items failed", e); }
                    }
                } else {
                    try { md.put("inventory_items", inv); } catch (Exception e) { Log.e(TAG, "md.put inventory_items failed", e); }
                }
            }
        }

        // print_templates
        if (wants(scopes, SCOPE_TEMPLATES)) {
            String tplsUrl = (orgEnc != null)
                    ? (base + "/rest/v1/print_templates?select=*&org_id=eq." + orgEnc)
                    : (base + "/rest/v1/print_templates?select=*");
            JSONArray tpls = getArrayIncremental(ctx, tplsUrl, KEY_TEMPLATES_LAST_PULL_MS, forceMasterFull);
            if (tpls != null) {
                try { md.put("print_templates", tpls); } catch (Exception e) { Log.e(TAG, "md.put print_templates failed", e); }
            }
        }

        // 财务
        if (wants(scopes, SCOPE_FINANCE)) {
        try {
            JSONArray arInvoices = getArray(ctx, base + "/rest/v1/ar_invoices?select=*&created_by=eq." + uidEnc + "&created_at=gte." + URLEncoder.encode(getDateTwoYearsAgo(), StandardCharsets.UTF_8.name()) + "&order=updated_at.desc");
            if (arInvoices != null) md.put("ar_invoices", arInvoices);
        } catch (Exception ignored) {}
        try {
            JSONArray arPayments = getArray(ctx, base + "/rest/v1/ar_payments?select=*&created_by=eq." + uidEnc + "&created_at=gte." + URLEncoder.encode(getDateTwoYearsAgo(), StandardCharsets.UTF_8.name()) + "&order=updated_at.desc");
            if (arPayments != null) md.put("ar_payments", arPayments);
        } catch (Exception ignored) {}
        try {
            JSONArray arAllocations = getArray(ctx, base + "/rest/v1/ar_allocations?select=*&created_by=eq." + uidEnc + "&created_at=gte." + URLEncoder.encode(getDateTwoYearsAgo(), StandardCharsets.UTF_8.name()) + "&order=created_at.desc");
            if (arAllocations != null) md.put("ar_allocations", arAllocations);
        } catch (Exception ignored) {}
        }

        // =========================
        // P0-2 + P1：orders 增量 pull（优先）+ 分页/按月窗口（防止订单量大时全量拉取性能塌）
        // - 优先按 updated_at 增量拉取（需要云端有 updated_at 字段）
        // - 若增量失败（云端没 updated_at / 语法不支持），回退：按月份窗口分页拉取最近 N 个月
        // - 不在这里 delete 本地；落库由 DatabaseHelper.replaceMasterDataFromCloud(md) 处理（你P0-1已做 orders upsert/merge/保留 printed/synced）
        // =========================
        JSONArray orders = null;
        if (wants(scopes, SCOPE_ORDERS)) {
        try {
            SharedPreferences sp = spPull(ctx);
            long now = System.currentTimeMillis();
            long lastPull = sp.getLong(KEY_ORDERS_LAST_PULL_MS, 0);
            long lastFull = sp.getLong(KEY_ORDERS_LAST_FULL_PULL_MS, 0);

            // suzai2 / suzai1 允许跨账号查看订单（按场地过滤，最终由 RLS 控制可见范围）
            String email = "";
            try {
                String e = AuthManager.getEmail(ctx);
                if (e != null) email = e.toLowerCase(java.util.Locale.ROOT);
            } catch (Exception ignored) {}
            boolean allowCrossUser = (email.contains("suzai2@") || email.contains("suzai1@"));

            // 额外过滤：跨账号拉取时按场地 in(...) 限制；普通账号按默认场地 eq 限制
            String extraQuery = "";
            try {
                if (allowCrossUser) {
                    String inExpr = "(佛山,广州,鹤山)";
                    extraQuery = "&location=in." + URLEncoder.encode(inExpr, StandardCharsets.UTF_8.name());
                } else {
                    String def = AuthManager.getDefaultLocationForCurrentUser(ctx);
                    if (def != null && !def.trim().isEmpty()) {
                        extraQuery = "&location=eq." + URLEncoder.encode(def.trim(), StandardCharsets.UTF_8.name());
                    }
                }
            } catch (Exception ignored) {}
            boolean forceFull = forceFullRestore || (lastPull == 0) || (now - lastFull > ORDERS_FORCE_FULL_PULL_INTERVAL_MS);

            boolean usedFull = false;

            if (!forceFull) {
                // ✅ 增量：updated_at > lastPull（分页）
                JSONArray inc;
                if (allowCrossUser) {
                    // 不加 owner_uid/tenant_id 限制，否则会把其他账号订单过滤掉
                    inc = pullOrdersIncremental(ctx, base, null, null, lastPull, extraQuery);
                } else {
                    inc = pullOrdersIncremental(ctx, base, uidEnc, "owner_uid", lastPull, extraQuery);
                    if (inc == null) {
                        // 兼容：部分历史表用 tenant_id 作为私有隔离键
                        inc = pullOrdersIncremental(ctx, base, uidEnc, "tenant_id", lastPull, extraQuery);
                    }
                }

                if (inc != null) {
                    orders = inc;
                    sp.edit().putLong(KEY_ORDERS_LAST_PULL_MS, now).apply();
                } else {
                    // 增量失败则回退全量（比如云端没 updated_at / 过滤列不同）
                    logW(ctx, "orders incremental pull failed, fallback to monthly window");
                }
            }

            if (orders == null) {
                // ✅ 回退全量：按月份窗口（最近 N 个月），每个月分页拉取，避免一次性拉取全部历史订单
                usedFull = true;

                JSONArray full;
                if (allowCrossUser) {
                    full = pullOrdersWindowed(ctx, base, null, null, extraQuery);
                } else {
                    full = pullOrdersWindowed(ctx, base, uidEnc, "owner_uid", extraQuery);

                    // 如果 owner_uid 方式"成功但为空"，再试 tenant_id（清数据首次恢复最常见的兼容问题）
                    if (full != null && full.length() == 0) {
                        JSONArray full2 = pullOrdersWindowed(ctx, base, uidEnc, "tenant_id", extraQuery);
                        if (full2 != null && full2.length() > 0) {
                            full = full2;
                        } else if (full2 != null && full == null) {
                            full = full2;
                        }
                    } else if (full == null) {
                        // owner_uid 方式失败（比如列不存在/权限拒绝），尝试 tenant_id
                        full = pullOrdersWindowed(ctx, base, uidEnc, "tenant_id", extraQuery);
                    }
                }

                orders = full;

                if (orders != null) {
                    sp.edit()
                            .putLong(KEY_ORDERS_LAST_PULL_MS, now)
                            .putLong(KEY_ORDERS_LAST_FULL_PULL_MS, now)
                            .apply();
                }
            }
} catch (Exception e) {
            Log.e(TAG, "orders pull error", e);
        }

        // ✅ 把 orders 拉取结果放入 master-data，供 replaceMasterDataFromCloud() 恢复到本地
        if (orders != null) {
            try { md.put("orders", orders); } catch (Exception e) { Log.e(TAG, "md.put orders failed", e); }
        }

        // =========================
        // P1：order_items 增量 pull（优先）+ 回退全量
        // - owner_uid 私有订单：按 owner_uid=auth.uid() 拉取
        // - 优先 updated_at 增量：updated_at > last_pull
        // =========================
        JSONArray orderItems = null;
        try {
            String email = "";
            try {
                String e = AuthManager.getEmail(ctx);
                if (e != null) email = e.toLowerCase(java.util.Locale.ROOT);
            } catch (Exception ignored) {}
            boolean allowCrossUser = (email.contains("suzai2@") || email.contains("suzai1@"));
            String ownerFilter = allowCrossUser ? "" : ("&owner_uid=eq." + uidEnc);

            SharedPreferences sp = spPull(ctx);
            long last = sp.getLong(KEY_ORDER_ITEMS_LAST_PULL_MS, 0L);
            long lastFull = sp.getLong(KEY_ORDER_ITEMS_LAST_FULL_PULL_MS, 0L);
            long now = System.currentTimeMillis();

            // 优先增量（updated_at）- 修复：也需要限制只拉取2年内订单的order_items
            if (last > 0) {
                String iso = toIso8601(last);
                String twoYearsAgo = getDateTwoYearsAgo();
                
                // 增量拉取也需要过滤：先获取2年内有更新的订单，再拉取对应的order_items
                String updatedOrdersUrl = base + "/rest/v1/orders?select=cloud_id" + ownerFilter
                        + "&date=gte." + URLEncoder.encode(twoYearsAgo, StandardCharsets.UTF_8.name())
                        + "&updated_at=gt." + URLEncoder.encode(iso, StandardCharsets.UTF_8.name())
                        + "&order=cloud_id.asc";
                
                JSONArray updatedOrders = getArrayPaged(ctx, updatedOrdersUrl, 500, 5);
                if (updatedOrders != null && updatedOrders.length() > 0) {
                    logD(ctx, "找到" + updatedOrders.length() + "个近2年有更新的订单，拉取对应的order_items增量");
                    
                    // 分批处理
                    List<String> updatedOrderIds = new ArrayList<>();
                    for (int i = 0; i < updatedOrders.length(); i++) {
                        try {
                            JSONObject order = updatedOrders.getJSONObject(i);
                            String cloudId = order.optString("cloud_id");
                            if (cloudId != null && !cloudId.isEmpty()) {
                                updatedOrderIds.add(cloudId);
                            }
                        } catch (Exception ignored) {}
                    }
                    
                    // 分批拉取增量order_items
                    List<JSONArray> incrementalItems = new ArrayList<>();
                    int batchSize = 100;
                    for (int i = 0; i < updatedOrderIds.size(); i += batchSize) {
                        int end = Math.min(i + batchSize, updatedOrderIds.size());
                        List<String> batchIds = updatedOrderIds.subList(i, end);
                        
                        StringBuilder inClause = new StringBuilder();
                        for (int j = 0; j < batchIds.size(); j++) {
                            if (j > 0) inClause.append(",");
                            inClause.append(batchIds.get(j));
                        }
                        
                        String batchUrl = base + "/rest/v1/order_items?select=*" + ownerFilter
                                + "&order_cloud_id=in.(" + inClause.toString() + ")"
                                + "&updated_at=gt." + URLEncoder.encode(iso, StandardCharsets.UTF_8.name())
                                + "&order=updated_at.asc";
                        
                        JSONArray batchItems = getArrayPaged(ctx, batchUrl, 1000, 5);
                        if (batchItems != null && batchItems.length() > 0) {
                            incrementalItems.add(batchItems);
                        }
                    }
                    
                    // 合并增量数据
                    if (!incrementalItems.isEmpty()) {
                        JSONArray mergedItems = new JSONArray();
                        int totalIncremental = 0;
                        for (JSONArray batch : incrementalItems) {
                            totalIncremental += batch.length();
                            for (int j = 0; j < batch.length(); j++) {
                                try {
                                    mergedItems.put(batch.get(j));
                                } catch (Exception ignored) {}
                            }
                        }
                        orderItems = mergedItems;
                        logD(ctx, "order_items增量拉取完成：共" + totalIncremental + "条记录，来自" + updatedOrderIds.size() + "个有更新的订单");
                    }
                } else {
                    logD(ctx, "没有近2年有更新的订单，order_items增量拉取跳过");
                }
            }

            // 回退：全量（首次 / 周期性）
            if (orderItems == null || orderItems.length() == 0) {
                boolean needFull = forceFullRestore || (last == 0) || (now - lastFull > ORDERS_FORCE_FULL_PULL_INTERVAL_MS);
                if (needFull) {
                    // ✅ 修复：2年热数据 - 只拉取与2年内订单相关的order_items
                    // 客户端稳妥方案：先拉取2年内订单的cloud_id列表，然后分批拉取对应的order_items
                    String twoYearsAgo = getDateTwoYearsAgo();
                    
                    // 1. 先拉取2年内订单的cloud_id列表
                    String ordersUrl = base + "/rest/v1/orders?select=cloud_id" + ownerFilter
                            + "&date=gte." + URLEncoder.encode(twoYearsAgo, StandardCharsets.UTF_8.name())
                            + "&order=cloud_id.asc";
                    
                    JSONArray recentOrders = getArrayPaged(ctx, ordersUrl, 500, 20); // 最多10000个订单
                    if (recentOrders != null && recentOrders.length() > 0) {
                        logD(ctx, "找到" + recentOrders.length() + "个近2年订单，开始拉取对应的order_items");
                        
                        // 2. 分批处理订单cloud_id，避免URL过长
                        List<String> orderCloudIds = new ArrayList<>();
                        for (int i = 0; i < recentOrders.length(); i++) {
                            try {
                                JSONObject order = recentOrders.getJSONObject(i);
                                String cloudId = order.optString("cloud_id");
                                if (cloudId != null && !cloudId.isEmpty()) {
                                    orderCloudIds.add(cloudId);
                                }
                            } catch (Exception ignored) {}
                        }
                        
                        // 3. 分批拉取order_items（每批最多100个订单）
                        List<JSONArray> allOrderItems = new ArrayList<>();
                        int batchSize = 100;
                        for (int i = 0; i < orderCloudIds.size(); i += batchSize) {
                            int end = Math.min(i + batchSize, orderCloudIds.size());
                            List<String> batchIds = orderCloudIds.subList(i, end);
                            
                            // 构建IN查询条件
                            StringBuilder inClause = new StringBuilder();
                            for (int j = 0; j < batchIds.size(); j++) {
                                if (j > 0) inClause.append(",");
                                inClause.append(batchIds.get(j));
                            }
                            
                            String batchUrl = base + "/rest/v1/order_items?select=*" + ownerFilter
                                    + "&order_cloud_id=in.(" + inClause.toString() + ")"
                                    + "&order=updated_at.desc";
                            
                            JSONArray batchItems = getArrayPaged(ctx, batchUrl, 1000, 5); // 每批最多5000条
                            if (batchItems != null && batchItems.length() > 0) {
                                allOrderItems.add(batchItems);
                                logD(ctx, "第" + ((i/batchSize)+1) + "批拉取到" + batchItems.length() + "条order_items");
                            }
                        }
                        
                        // 4. 合并所有批次的order_items
                        if (!allOrderItems.isEmpty()) {
                            int totalItems = 0;
                            JSONArray mergedItems = new JSONArray();
                            for (JSONArray batch : allOrderItems) {
                                totalItems += batch.length();
                                for (int j = 0; j < batch.length(); j++) {
                                    try {
                                        mergedItems.put(batch.get(j));
                                    } catch (Exception ignored) {}
                                }
                            }
                            
                            orderItems = mergedItems;
                            logD(ctx, "order_items全量拉取（2年热数据）完成：共" + totalItems + "条记录，来自" + orderCloudIds.size() + "个订单");
                        } else {
                            logD(ctx, "近2年订单没有对应的order_items");
                            orderItems = new JSONArray(); // 返回空数组而不是null
                        }
                    } else {
                        logD(ctx, "没有找到近2年的订单，order_items拉取跳过");
                        orderItems = new JSONArray(); // 返回空数组而不是null
                    }
                    
                    if (orderItems != null) {
                        sp.edit().putLong(KEY_ORDER_ITEMS_LAST_FULL_PULL_MS, now).apply();
                    }
                }
            }

            if (orderItems != null) {
                sp.edit().putLong(KEY_ORDER_ITEMS_LAST_PULL_MS, now).apply();
                try { md.put("order_items", orderItems); } catch (Exception e) { Log.e(TAG, "md.put order_items failed", e); }
            }
        } catch (Exception e) {
            Log.e(TAG, "order_items pull error", e);
        }
        }

        // logistics_forms
        if (wants(scopes, SCOPE_LOGISTICS)) {
            String twoYearsAgo = getDateTwoYearsAgo();
            JSONArray lfs = getArrayIncremental(ctx, base + "/rest/v1/logistics_forms?select=*&tenant_id=eq." + uidEnc 
                    + "&date=gte." + URLEncoder.encode(twoYearsAgo, StandardCharsets.UTF_8.name()), KEY_LOGISTICS_FORMS_LAST_PULL_MS, forceMasterFull);
            if (lfs != null) {
                try { md.put("logistics_forms", lfs); } catch (Exception e) { Log.e(TAG, "md.put logistics_forms failed", e); }
            }
            JSONArray lss = fetchLogisticsSizesForForms(ctx, base, lfs, false);
            if (lss != null) {
                try { md.put("logistics_sizes", lss); } catch (Exception e) { Log.e(TAG, "md.put logistics_sizes failed", e); }
            }
        }

        if (md.length() == 0) return null;
        return md;
    }

    private static JSONArray getArray(Context ctx, String url) throws IOException {
        Request req = withHeaders(ctx, url).get().build();
        try (Response resp = executeWithRetry(req)) {
            String raw = resp.body() != null ? resp.body().string() : "";
            logD(ctx, "GET " + url + " code=" + resp.code() + " raw=" + raw);

            if (resp.code() == 401) {
                String newToken = refreshAccessToken(ctx);
                if (newToken != null) {
                    Request req2 = withHeaders(ctx, url).get().build();
                    try (Response resp2 = executeWithRetry(req2)) {
                        String raw2 = resp2.body() != null ? resp2.body().string() : "";
                        logD(ctx, "GET(retry) " + url + " code=" + resp2.code() + " raw=" + raw2);
                        if (!resp2.isSuccessful()) return null;
                        try { return new JSONArray(raw2); } catch (Exception e) { Log.e(TAG, "parse JSONArray failed: " + url, e); return null; }
                    }
                }
            }

            if (!resp.isSuccessful()) return null;

            try {
                return new JSONArray(raw);
            } catch (Exception e) {
                Log.e(TAG, "parse JSONArray failed: " + url, e);
                return null;
            }
        }
    }

    // ===== pushAll 以下保持你原文件不变（未做P0-3） =====

    // 原始pushAll方法，保持向后兼容
    private static boolean pushAll(Context ctx) throws Exception {
        int[] result = pushAllWithCount(ctx);
        return result[0] == 1; // 只返回成功状态
    }

    private static int[] pushAllWithCount(Context ctx) throws Exception {
        // 返回值: [0] = 成功状态 (0失败, 1成功), [1] = 总变更计数
        if (!ready(ctx)) return new int[]{0, 0, 0};

        String base = getBaseUrl(ctx);
        String uid = getUserId(ctx);

        int totalChanges = 0; // 总变更计数
        boolean isFirstSync = false; // 是否是首次同步

        // ✅ 组织共享：customers/products/print_templates
        String orgId = null;
        try { orgId = ensureOrgId(ctx); } catch (Exception ignored) {}

        DatabaseHelper db = new DatabaseHelper(ctx);

        // ✅ 修复历史遗留：旧版本本地已删除(VOID/is_deleted=1)的订单，没有入队 cloud_delete_queue，导致云端残留。
        // 这里以"本地为准"，在每次 push 前自动补齐 orders & order_items 的精确 DELETE 入队。
        try {
            int fixed = db.enqueueCloudDeletesForLocallyDeletedOrders();
            if (fixed > 0) {
                logD(ctx, "CLOUD_DELETE backfill enqueued (orders/order_items) count=" + fixed);
            }
        } catch (Exception e) {
            logW(ctx, "CLOUD_DELETE backfill failed: " + e);
        }

        // ✅ 先处理云端删除队列
        try {
            if (base != null) {
                int pending = 0;
                try { pending = db.getPendingCloudDeletes(1).size(); } catch (Exception ignored) {}
                if (pending == 0) {
                    logD(ctx, "DELETE skip (empty): cloud_delete_queue");
                }
                processCloudDeletes(ctx, base, db);
            }
        } catch (Exception e) {
            Log.e(TAG, "processCloudDeletes(push) error", e);
        }

        JSONObject snapshot = db.exportMasterDataForCloud(uid, orgId);

        JSONArray customers = snapshot != null ? snapshot.optJSONArray("customers") : null;
        JSONArray products = snapshot != null ? snapshot.optJSONArray("products") : null;
        JSONArray inv = snapshot != null ? snapshot.optJSONArray("inventory_items") : null;
        JSONArray movs = snapshot != null ? snapshot.optJSONArray("inventory_movements") : null;
        JSONArray templates = snapshot != null ? snapshot.optJSONArray("print_templates") : null;

        String seed = (orgId != null && !orgId.trim().isEmpty()) ? orgId.trim() : uid;
        customers = ensureStableIds(customers, seed, "customers");
        products = ensureStableIds(products, seed, "products");

        // =========================
        // P1：主数据增量/dirty push（按 updated_at）
        // - 只上传 updated_at > last_push_ts 的行
        // - 若表缺少 updated_at，则退化为全量（不影响正确性）
        // - 成功后更新 last_push_ts（取本次推送行的最大 updated_at）
        // =========================
        JSONArray customersDirty = filterDirtyByUpdatedAt(ctx, customers, KEY_LAST_PUSH_CUSTOMERS_TS);
        JSONArray productsDirty  = filterDirtyByUpdatedAt(ctx, products,  KEY_LAST_PUSH_PRODUCTS_TS);
        JSONArray invDirty       = filterDirtyByUpdatedAt(ctx, inv,       KEY_LAST_PUSH_INVENTORY_TS);
        JSONArray tplDirty       = filterDirtyByUpdatedAt(ctx, templates, KEY_LAST_PUSH_TEMPLATES_TS);

        try {
            SharedPreferences st = spState(ctx);
            boolean bootstrapDone = st.getBoolean(KEY_BOOTSTRAP_DONE, false);
            isFirstSync = !bootstrapDone
                    && st.getLong(KEY_LAST_PUSH_CUSTOMERS_TS, 0L) <= 0L
                    && st.getLong(KEY_LAST_PUSH_PRODUCTS_TS, 0L) <= 0L
                    && st.getLong(KEY_LAST_PUSH_INVENTORY_TS, 0L) <= 0L
                    && st.getLong(KEY_LAST_PUSH_TEMPLATES_TS, 0L) <= 0L;
            if (isFirstSync) logD(ctx, "检测到首次同步");
        } catch (Exception ignored) {}

        boolean ok1 = upsertTable(ctx, base, "customers", customersDirty);
        if (ok1) {
            bumpLastPushTs(ctx, KEY_LAST_PUSH_CUSTOMERS_TS, customersDirty);
            if (customersDirty != null) totalChanges += customersDirty.length();
        }

        boolean ok2 = upsertTable(ctx, base, "products", productsDirty);
        if (ok2) {
            bumpLastPushTs(ctx, KEY_LAST_PUSH_PRODUCTS_TS, productsDirty);
            if (productsDirty != null) totalChanges += productsDirty.length();
        }

        boolean ok3 = upsertTable(ctx, base, "inventory_items", invDirty);
        if (ok3) {
            bumpLastPushTs(ctx, KEY_LAST_PUSH_INVENTORY_TS, invDirty);
            if (invDirty != null) totalChanges += invDirty.length();
        }

        boolean okTpl = upsertTable(ctx, base, "print_templates", tplDirty);
        if (okTpl) {
            bumpLastPushTs(ctx, KEY_LAST_PUSH_TEMPLATES_TS, tplDirty);
            if (tplDirty != null) totalChanges += tplDirty.length();
        }

        // =========================
        // P0-3：orders push 改为 upsert（支持更新/打印状态同步）
        // - 本地以 orders.synced=0 作为"待同步"标记
        // - 走 on_conflict=cloud_id + merge-duplicates
        // =========================
        JSONArray pendingOrders = db.exportOrdersPendingForCloud(uid, 500);
        pendingOrders = filterRowsByDateWindow(pendingOrders, "date", "created_at", "updated_at");
        boolean ok4 = upsertOrders(ctx, base, pendingOrders);
        if (ok4) {
            try {
                // 从订单对象数组中提取cloud_id列表
                JSONArray cloudIdArray = new JSONArray();
                if (pendingOrders != null) {
                    for (int i = 0; i < pendingOrders.length(); i++) {
                        JSONObject order = pendingOrders.optJSONObject(i);
                        if (order != null) {
                            String cloudId = order.optString("cloud_id", null);
                            if (cloudId != null && !cloudId.equals("null") && !cloudId.isEmpty()) {
                                cloudIdArray.put(cloudId);
                            }
                        }
                    }
                }
                db.markOrdersSyncedByCloudIds(cloudIdArray);
            } catch (Exception ignored) {}
            // 兼容保留：更新 last_pushed_order_id 为当前最大 id（不再作为判断依据）
            try {
                int maxId = db.getMaxOrderId();
                spState(ctx)
                        .edit()
                        .putInt(KEY_LAST_PUSHED_ORDER_ID, maxId)
                        .apply();
            } catch (Exception ignored) { }
            if (pendingOrders != null) totalChanges += pendingOrders.length();
        }


        // =========================
        // P1：order_items push（多品订单明细）
        // - 本地以 order_items.synced=0 标记待同步
        // - 云端走 on_conflict=cloud_id + merge-duplicates
        // =========================
        JSONArray pendingItems = db.exportOrderItemsPendingForCloud(uid, 800);
        // Fallback: if order_items table isn't populated/marked dirty, derive minimal order_items from pending orders.
        if ((pendingItems == null || pendingItems.length() == 0) && pendingOrders != null && pendingOrders.length() > 0) {
            try {
                pendingItems = buildOrderItemsFromPendingOrders(ctx, pendingOrders, uid);
                logD(ctx, "ORDER_ITEMS fallback built from pendingOrders, count=" + (pendingItems == null ? 0 : pendingItems.length()));
            } catch (Exception e) {
                logW(ctx, "ORDER_ITEMS fallback failed: " + e);
            }
        }
        pendingItems = filterRowsByRefSet(pendingItems, "order_cloud_id", collectStringSet(pendingOrders, "cloud_id"));
        boolean okItems = upsertTable(ctx, base, "order_items", pendingItems);
        if (okItems) {
            try {
                // 从订单明细对象数组中提取cloud_id列表
                JSONArray cloudIdArray = new JSONArray();
                if (pendingItems != null) {
                    for (int i = 0; i < pendingItems.length(); i++) {
                        JSONObject item = pendingItems.optJSONObject(i);
                        if (item != null) {
                            String cloudId = item.optString("cloud_id", null);
                            if (cloudId != null && !cloudId.equals("null") && !cloudId.isEmpty()) {
                                cloudIdArray.put(cloudId);
                            }
                        }
                    }
                }
                db.markOrderItemsSyncedByCloudIds(cloudIdArray);
            } catch (Exception ignored) {}
            if (pendingItems != null) totalChanges += pendingItems.length();
        }

        // =========================
        // v15：财务/对账（AR）push
        // - 先实现最核心的：新增/修改能上传，卸载重装能恢复
        // - 删除/冲突后续再增强
        // =========================
        JSONArray pendingArInvoices = db.exportArInvoicesPendingForCloud(uid, 500);
        pendingArInvoices = filterRowsByDateWindow(pendingArInvoices, "invoice_month", "created_at", "updated_at");
        boolean okAr1 = upsertTable(ctx, base, "ar_invoices", pendingArInvoices);
        if (okAr1) {
            try {
                // 从AR发票对象数组中提取cloud_id列表
                JSONArray cloudIdArray = new JSONArray();
                if (pendingArInvoices != null) {
                    for (int i = 0; i < pendingArInvoices.length(); i++) {
                        JSONObject invoice = pendingArInvoices.optJSONObject(i);
                        if (invoice != null) {
                            String cloudId = invoice.optString("cloud_id", null);
                            if (cloudId != null && !cloudId.equals("null") && !cloudId.isEmpty()) {
                                cloudIdArray.put(cloudId);
                            }
                        }
                    }
                }
                db.markArInvoicesSyncedByCloudIds(cloudIdArray);
            } catch (Exception ignored) {}
            if (pendingArInvoices != null) totalChanges += pendingArInvoices.length();
        }

        JSONArray pendingArPayments = db.exportArPaymentsPendingForCloud(uid, 500);
        pendingArPayments = filterRowsByDateWindow(pendingArPayments, "pay_date", "created_at", "updated_at");
        boolean okAr2 = upsertTable(ctx, base, "ar_payments", pendingArPayments);
        if (okAr2) {
            try {
                // 从AR付款对象数组中提取cloud_id列表
                JSONArray cloudIdArray = new JSONArray();
                if (pendingArPayments != null) {
                    for (int i = 0; i < pendingArPayments.length(); i++) {
                        JSONObject payment = pendingArPayments.optJSONObject(i);
                        if (payment != null) {
                            String cloudId = payment.optString("cloud_id", null);
                            if (cloudId != null && !cloudId.equals("null") && !cloudId.isEmpty()) {
                                cloudIdArray.put(cloudId);
                            }
                        }
                    }
                }
                db.markArPaymentsSyncedByCloudIds(cloudIdArray);
            } catch (Exception ignored) {}
            if (pendingArPayments != null) totalChanges += pendingArPayments.length();
        }

        JSONArray pendingArAlloc = db.exportArAllocationsPendingForCloud(uid, 500);
        pendingArAlloc = filterRowsByDateWindow(pendingArAlloc, "created_at", "updated_at");
        boolean okAr3 = upsertTable(ctx, base, "ar_allocations", pendingArAlloc);
        if (okAr3) {
            try {
                // 从AR分配对象数组中提取cloud_id列表
                JSONArray cloudIdArray = new JSONArray();
                if (pendingArAlloc != null) {
                    for (int i = 0; i < pendingArAlloc.length(); i++) {
                        JSONObject allocation = pendingArAlloc.optJSONObject(i);
                        if (allocation != null) {
                            String cloudId = allocation.optString("cloud_id", null);
                            if (cloudId != null && !cloudId.equals("null") && !cloudId.isEmpty()) {
                                cloudIdArray.put(cloudId);
                            }
                        }
                    }
                }
                db.markArAllocationsSyncedByCloudIds(cloudIdArray);
            } catch (Exception ignored) {}
            if (pendingArAlloc != null) totalChanges += pendingArAlloc.length();
        }

int lastPushedLogisticsId = spState(ctx)
                .getInt(KEY_LAST_PUSHED_LOGISTICS_ID, 0);
        JSONArray newLogistics = db.exportLogisticsFormsForCloudSince(uid, lastPushedLogisticsId);
        newLogistics = filterRowsByDateWindow(newLogistics, "date", "created_at", "updated_at");
        JSONArray newSizes = db.exportLogisticsSizesForCloudSince(uid, lastPushedLogisticsId);
        newSizes = filterRowsByRefSet(newSizes, "form_id", collectStringSet(newLogistics, "id"));

        boolean okL1 = upsertTable(ctx, base, "logistics_forms", newLogistics);
        boolean okL2 = upsertTable(ctx, base, "logistics_sizes", newSizes);
        if (okL1 && okL2) {
            try {
                int maxLid = db.getMaxLogisticsFormId();
                db.markLogisticsSyncedUpTo(maxLid);
                spState(ctx)
                        .edit()
                        .putInt(KEY_LAST_PUSHED_LOGISTICS_ID, maxLid)
                        .apply();
            } catch (Exception ignored) { }
            if (newLogistics != null) totalChanges += newLogistics.length();
            if (newSizes != null) totalChanges += newSizes.length();
        }

        if (movs != null && movs.length() > 0) {
            logW(ctx, "inventory_movements sync disabled (Plan A). Keep local only.");
        }
        boolean ok5 = true;

        boolean ok = ok1 && ok2 && ok3 && okTpl && ok4 && okItems && okAr1 && okAr2 && okAr3 && ok5 && okL1 && okL2;
        // 严谨同步规则：普通 push 后不再自动执行整表恢复。
        // 避免 customers/products/inventory/logistics 在每次订单变更后被整轮回拉。
        if (ok) {
            try {
                spState(ctx).edit().putBoolean(KEY_BOOTSTRAP_DONE, true).apply();
            } catch (Exception ignored) {}
            try { cleanupCloudHistoricalData(ctx, base); } catch (Exception e) { logW(ctx, "云端历史裁剪失败: " + e.getMessage()); }
            try { logD(ctx, "PULL AFTER PUSH skipped: strict mode"); } catch (Exception ignored) {}
        }

        // 返回值: [0] = 成功状态, [1] = 变更计数, [2] = 是否首次同步 (1是, 0否)
        return new int[]{ok ? 1 : 0, totalChanges, isFirstSync ? 1 : 0};
    }


    /**
     * ✅ push 完成后拉取共享主数据（customers/products/print_templates）并用于覆盖本地，
     * 避免多设备之间"删了/改名了，本机不刷新"的问题。
     *
     * 注意：这里只拉共享主数据，不触碰 orders/order_items 的增量与删除逻辑，避免改变你现有功能。
     */
    private static JSONObject fetchSharedMastersAfterPush(Context ctx, String base, String orgId) throws IOException {
        if (!ready(ctx) || base == null) return null;

        String orgEnc = null;
        try {
            if (orgId != null && !orgId.trim().isEmpty()) {
                orgEnc = URLEncoder.encode(orgId.trim(), StandardCharsets.UTF_8.name());
            }
        } catch (Exception ignored) {}

        JSONObject md = new JSONObject();

        // customers（共享表：优先按 org_id；拿不到 org_id 则不加 where 交给 RLS）
        boolean forceMasterFull = false;
        String customersUrl = (orgEnc != null)
                ? (base + "/rest/v1/customers?select=*&org_id=eq." + orgEnc)
                : (base + "/rest/v1/customers?select=*");
        JSONArray customers = getArrayIncremental(ctx, customersUrl, KEY_CUSTOMERS_LAST_PULL_MS, forceMasterFull);
        if (customers != null) {
            try { md.put("customers", customers); } catch (Exception ignored) {}
        }

        // products
        String productsUrl = (orgEnc != null)
                ? (base + "/rest/v1/products?select=*&org_id=eq." + orgEnc)
                : (base + "/rest/v1/products?select=*");
        JSONArray products = getArrayIncremental(ctx, productsUrl, KEY_PRODUCTS_LAST_PULL_MS, forceMasterFull);
        if (products != null) {
            try { md.put("products", products); } catch (Exception ignored) {}
        }

        // print_templates（模板中心）
        String tplsUrl = (orgEnc != null)
                ? (base + "/rest/v1/print_templates?select=*&org_id=eq." + orgEnc)
                : (base + "/rest/v1/print_templates?select=*");
        JSONArray tpls = getArrayIncremental(ctx, tplsUrl, KEY_TEMPLATES_LAST_PULL_MS, forceMasterFull);
        if (tpls != null) {
            try { md.put("print_templates", tpls); } catch (Exception ignored) {}
        }

        return md;
    }

    /**
     * ✅ push 完成后拉取关键私有数据（inventory_items / logistics_forms / logistics_sizes），
     * 让"另一台设备删除后，本机点同步即可对齐"。
     *
     * 注意：这里不触碰 orders/order_items（它们有更复杂的增量/精确删除/避免复活逻辑）。
     */
    private static JSONObject fetchPrivateAfterPush(Context ctx, String base, String uid) throws IOException {
        if (!ready(ctx) || base == null || uid == null || uid.trim().isEmpty()) return null;
        String uidEnc;
        try { uidEnc = URLEncoder.encode(uid.trim(), StandardCharsets.UTF_8.name()); }
        catch (Exception e) { uidEnc = uid.trim(); }

        JSONObject md = new JSONObject();

        // inventory_items：按 owner_uid 全量拉取（体量可控，且需要用于删除对齐）
        JSONArray inv = fetchInventoryItemsCloudIncrementalSafe(ctx, base, uidEnc, false);
        if (inv != null) {
            try { md.put("inventory_items", inv); } catch (Exception ignored) {}
        }

        // logistics_forms / logistics_sizes：按 tenant_id 全量拉取（用于多设备删除对齐）
        String twoYearsAgo2 = getDateTwoYearsAgo();
        JSONArray lfs = getArrayPaged(ctx, base + "/rest/v1/logistics_forms?select=*&tenant_id=eq." + uidEnc + "&date=gte." + URLEncoder.encode(twoYearsAgo2, StandardCharsets.UTF_8.name()) + "&order=date.desc", 500, 10);
        if (lfs != null) {
            try { md.put("logistics_forms", lfs); } catch (Exception ignored) {}
        }
        JSONArray lss = fetchLogisticsSizesForForms(ctx, base, lfs, false);
        if (lss != null) {
            try { md.put("logistics_sizes", lss); } catch (Exception ignored) {}
        }

        return md;
    }

// ================== 下面所有函数保持你原文件内容（未改） ==================

    private static boolean postTableInsertNoUpsert(Context ctx, String base, String table, JSONArray rows) throws IOException {
        if (rows == null || rows.length() == 0) {
            logD(ctx, "INSERT skip (empty): " + table);
            return true;
        }

        String url = base + "/rest/v1/" + table;
        String prefer = "return=minimal";

        if ("orders".equals(table)) {
            url = base + "/rest/v1/orders?on_conflict=cloud_id";
            rows = sanitizeOrdersForCloud(ctx, rows);
            if (rows == null || rows.length() == 0) {
                Log.d(TAG, "INSERT skip (empty after sanitize): " + table);
                return true;
            }
            prefer = "return=minimal,resolution=ignore-duplicates";
        }

        RequestBody rb = RequestBody.create(rows.toString(), JSON);

        Request req = withHeaders(ctx, url)
                .addHeader("Prefer", prefer)
                .post(rb)
                .build();

        try (Response resp = executeWithRetry(req)) {
            String raw = resp.body() != null ? resp.body().string() : "";
            logD(ctx, "INSERT POST " + url + " code=" + resp.code() + " raw=" + raw);

            if (resp.code() == 401) {
                String newToken = refreshAccessToken(ctx);
                if (newToken != null) {
                    Request req2 = withHeaders(ctx, url)
                            .addHeader("Prefer", prefer)
                            .post(rb)
                            .build();
                    try (Response resp2 = executeWithRetry(req2)) {
                        String raw2 = resp2.body() != null ? resp2.body().string() : "";
                        logD(ctx, "INSERT POST(retry) " + url + " code=" + resp2.code() + " raw=" + raw2);
                        if (resp2.code() == 404) return true;
                        return resp2.isSuccessful();
                    }
                }
            }
            if (resp.code() == 404) return true;
            return resp.isSuccessful();
        }
    }

    private static JSONArray sanitizeOrdersForCloud(Context ctx, JSONArray orders) {
        if (orders == null) return null;
        String uid = getUserId(ctx);
        JSONArray out = new JSONArray();

        for (int i = 0; i < orders.length(); i++) {
            JSONObject o = orders.optJSONObject(i);
            if (o == null) continue;

            // ✅ 本地已删除/作废的订单不再参与 upsert，避免"云端删除后又被 upsert 复活"
            try {
                String st = o.optString("status", "");
                int isDelInt = 0;
                if (o.has("is_deleted")) {
                    Object v = o.opt("is_deleted");
                    if (v instanceof Boolean) isDelInt = ((Boolean) v) ? 1 : 0;
                    else isDelInt = o.optInt("is_deleted", 0);
                }
                if (isDelInt == 1) continue;
                if (st != null && st.trim().length() > 0 && st.trim().equalsIgnoreCase("VOID")) continue;
            } catch (Exception ignored) {}

            // ✅ PostgREST 批量 upsert 要求：数组内每个对象的 key 集合必须完全一致（否则 PGRST102）
            // 所以这里固定输出完整字段集合；缺失的用默认值/NULL 填充。
            JSONObject n = new JSONObject();
            try {
                // --- 必填 ---
                n.put("owner_uid", (o.optString("owner_uid", "").trim().length() > 0) ? o.optString("owner_uid") : uid);

                String cloudId = o.optString("cloud_id", "").trim();
                if (cloudId.isEmpty()) {
                    String maybe = o.optString("id", "").trim();
                    if (maybe.contains("-") && maybe.length() >= 32) cloudId = maybe;
                }
                if (cloudId.isEmpty()) continue;
                n.put("cloud_id", cloudId);

                // --- 业务字段：全部固定输出 ---
                n.put("date", o.optString("date", ""));
                n.put("customer", o.optString("customer", ""));
                n.put("product", o.optString("product", ""));
                n.put("quantity", o.optInt("quantity", 0));
                n.put("pieces", o.optInt("pieces", 0));
                // numeric：用 optDouble；无则 0
                n.put("price", o.has("price") ? o.optDouble("price", 0.0) : 0.0);
                n.put("location", o.optString("location", ""));
                n.put("remark", o.optString("remark", ""));

                // 打印/统计字段（保持与云端列一致，不存在就默认 0/空）
                n.put("printed", o.optInt("printed", 0));
                n.put("tenant", o.optString("tenant", ""));
                n.put("print_count", o.optInt("print_count", 0));
                n.put("status", o.optString("status", ""));
                n.put("total_quantity", o.optInt("total_quantity", 0));
                n.put("total_amount", o.has("total_amount") ? o.optDouble("total_amount", 0.0) : 0.0);

                // 删除相关：固定输出（未删除则 false / null）
                Object isDel = o.has("is_deleted") ? o.opt("is_deleted") : null;
                if (isDel instanceof Boolean) n.put("is_deleted", (Boolean) isDel);
                else n.put("is_deleted", o.optInt("is_deleted", 0) == 1);

                // 时间戳：统一用 NULL/字符串（避免空字符串导致解析问题）
                putNullableTs(n, "created_at", o.optString("created_at", null));
                putNullableTs(n, "updated_at", o.optString("updated_at", null));
                putNullableTs(n, "deleted_at", o.optString("deleted_at", null));
                putNullableTs(n, "print_last_at", o.optString("print_last_at", null));

                out.put(n);
            } catch (Exception ignored) {}
        }
        return out;
    }


    private static JSONArray sanitizeInventoryItemsForCloud(Context ctx, JSONArray rows) {
        if (rows == null) return null;
        JSONArray out = new JSONArray();
        for (int i = 0; i < rows.length(); i++) {
            JSONObject o = rows.optJSONObject(i);
            if (o == null) continue;
            String cloudId = o.optString("cloud_id", "").trim();
            if (cloudId.isEmpty()) continue;
            out.put(o);
        }
        return out;
    }
    private static void putString(JSONObject obj, String key, String val) {
        try { obj.put(key, val == null ? "" : val); } catch (Exception ignored) {}
    }

    private static void putNullableTs(JSONObject obj, String key, String ts) {
        try {
            if (ts == null) { obj.put(key, JSONObject.NULL); return; }
            String t = ts.trim();
            obj.put(key, t.isEmpty() ? JSONObject.NULL : t);
        } catch (Exception ignored) {}
    }

    /** PostgREST 批量 upsert 要求：数组内每个对象的 key 集合必须完全一致，否则会报 PGRST102 */

    /**
     * Build a minimal order_items payload from pending orders.
     * This is used when local order_items are not stored or not marked dirty, but we still want Step3 to be runnable.
     * It generates ONE item row per order using product fields on the order row.
     *
     * IMPORTANT: This does NOT touch local DB and will NOT affect printing/UI.
     */
    private static JSONArray buildOrderItemsFromPendingOrders(Context ctx, JSONArray pendingOrders, String uid) throws Exception {
        JSONArray out = new JSONArray();
        String nowIso = isoNowUtc();
        for (int i = 0; i < pendingOrders.length(); i++) {
            JSONObject o = pendingOrders.optJSONObject(i);
            if (o == null) continue;

            String orderCloudId = nvl(o.optString("cloud_id"));
            if (orderCloudId.isEmpty()) {
                // If order doesn't have cloud_id, it will not be accepted by cloud FK anyway.
                continue;
            }

            String product = firstNonEmpty(
                    nvl(o.optString("product")),
                    nvl(o.optString("product_name")),
                    nvl(o.optString("productName")),
                    nvl(o.optString("name"))
            );
            if (product.isEmpty()) product = "(未命名产品)";

            int pieces = optInt(o, "pieces", optInt(o, "piece", 1));
            int quantity = optInt(o, "quantity", optInt(o, "qty", 0));
            double price = optDouble(o, "price", optDouble(o, "unit_price", 0.0));
            String remark = nvl(o.optString("remark"));

            JSONObject it = new JSONObject();
            it.put("cloud_id", stableItemCloudId(orderCloudId, product));
            it.put("owner_uid", uid);
            it.put("order_cloud_id", orderCloudId);
            it.put("product", product);
            it.put("pieces", pieces);
            it.put("quantity", quantity);
            it.put("price", price);
            it.put("remark", remark);
            it.put("is_deleted", false);
            it.put("deleted_at", JSONObject.NULL);
            it.put("created_at", nowIso);
            it.put("updated_at", nowIso);

            out.put(it);
        }
        // Ensure keys match (safety)
        return sanitizeOrderItemsForCloud(ctx, out);
    }

    private static int optInt(JSONObject o, String k, int def) {
        try {
            if (!o.has(k) || o.isNull(k)) return def;
            return o.optInt(k, def);
        } catch (Exception ignored) { return def; }
    }

    private static double optDouble(JSONObject o, String k, double def) {
        try {
            if (!o.has(k) || o.isNull(k)) return def;
            return o.optDouble(k, def);
        } catch (Exception ignored) { return def; }
    }

    private static String firstNonEmpty(String... ss) {
        if (ss == null) return "";
        for (String s : ss) {
            if (s != null) {
                s = s.trim();
                if (!s.isEmpty()) return s;
            }
        }
        return "";
    }

    private static String stableItemCloudId(String orderCloudId, String product) {
        try {
            String base = "item:" + orderCloudId + ":" + product;
            return java.util.UUID.nameUUIDFromBytes(base.getBytes("UTF-8")).toString();
        } catch (Exception e) {
            return java.util.UUID.randomUUID().toString();
        }
    }

    private static String isoNowUtc() {
        // 2026-01-31T14:14:30.456Z
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US);
        sdf.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        return sdf.format(new java.util.Date());
    }

private static JSONArray sanitizeOrderItemsForCloud(Context ctx, JSONArray rows) {
        // PostgREST batch upsert requires: every object in the JSON array has EXACTLY the same keys.
        // Keep keys aligned with cloud table columns (order_items: product, not product_name).
        final String[] KEYS = new String[]{
                "cloud_id",
                "owner_uid",
                "order_cloud_id",
                "product",
                "pieces",
                "quantity",
                "price",
                "remark",
                "is_deleted",
                "deleted_at",
                "created_at",
                "updated_at"
        };

        JSONArray out = new JSONArray();
        if (rows == null) return out;

        String nowIso = toIso8601(System.currentTimeMillis());

        for (int i = 0; i < rows.length(); i++) {
            try {
                JSONObject o = rows.optJSONObject(i);
                if (o == null) continue;

                JSONObject n = new JSONObject();

                // ids
                String cloudId = firstNonEmpty(
                        nvl(o.optString("cloud_id", "")),
                        nvl(o.optString("cloudId", "")),
                        nvl(o.optString("id", ""))
                );
                String orderCloudId = firstNonEmpty(
                        nvl(o.optString("order_cloud_id", "")),
                        nvl(o.optString("orderCloudId", ""))
                );
                n.put("owner_uid", nvl(o.optString("owner_uid", o.optString("ownerUid", ""))));
                n.put("order_cloud_id", orderCloudId);

                // product (cloud column is "product")
                String pn = o.optString("product", "");
                if (pn == null || pn.length() == 0) pn = o.optString("product_name", "");
                if (pn == null || pn.length() == 0) pn = o.optString("productName", "");
                String productName = nvl(pn);
                n.put("product", productName); // ✅ not-null on cloud

                // 兜底：兼容本地导出把 cloud_id 放在 id 字段，或历史脏数据 cloud_id 为空串。
                // 这里在真正上云前补一个稳定 UUID，避免 Supabase 报 uuid: ""。
                if (cloudId.length() == 0) {
                    cloudId = stableItemCloudId(
                            orderCloudId.length() == 0 ? ("no_order_" + i) : orderCloudId,
                            productName.length() == 0 ? ("no_product_" + i) : productName
                    );
                }
                n.put("cloud_id", cloudId);

                // numbers
                n.put("pieces", o.optInt("pieces", 0));
                n.put("quantity", o.optInt("quantity", 0));

                double price = 0d;
                try {
                    price = o.has("price") ? o.optDouble("price", 0d) : 0d;
                    if (Double.isNaN(price) || Double.isInfinite(price)) price = 0d;
                } catch (Exception ignored) { price = 0d; }
                n.put("price", price);

                // text / flags
                n.put("remark", nvl(o.optString("remark", "")));
                boolean isDel = false;
                try {
                    if (o.has("is_deleted")) isDel = o.optBoolean("is_deleted", false);
                    else if (o.has("deleted")) isDel = o.optBoolean("deleted", false);
                    else if (o.has("isDeleted")) isDel = o.optBoolean("isDeleted", false);
                } catch (Exception ignored) {}
                n.put("is_deleted", isDel);

                // ✅ 精确删除策略：已删除的明细不再 upsert，避免云端 DELETE 后复活
                if (isDel) continue;

                // timestamps: keep ISO strings if provided; otherwise set now to satisfy NOT NULL.
                // NOTE: deleted_at can be null.
                Object delObj = o.opt("deleted_at");
if (delObj == null || delObj == JSONObject.NULL) delObj = o.opt("deletedAt");
if (delObj == null || delObj == JSONObject.NULL) {
    n.put("deleted_at", JSONObject.NULL);
} else {
    String delAt = nvl(String.valueOf(delObj));
    if (delAt.length() == 0 || "null".equalsIgnoreCase(delAt)) n.put("deleted_at", JSONObject.NULL);
    else n.put("deleted_at", delAt);
}

Object cObj = o.opt("created_at");
if (cObj == null || cObj == JSONObject.NULL) cObj = o.opt("createdAt");
String createdAt = (cObj == null || cObj == JSONObject.NULL) ? "" : nvl(String.valueOf(cObj));

Object uObj = o.opt("updated_at");
if (uObj == null || uObj == JSONObject.NULL) uObj = o.opt("updatedAt");
String updatedAt = (uObj == null || uObj == JSONObject.NULL) ? "" : nvl(String.valueOf(uObj));

if (createdAt.length() == 0 || "null".equalsIgnoreCase(createdAt)) createdAt = nowIso;
if (updatedAt.length() == 0 || "null".equalsIgnoreCase(updatedAt)) updatedAt = nowIso;

n.put("created_at", createdAt);
n.put("updated_at", updatedAt);

// Ensure exact key set
                JSONObject fixed = new JSONObject();
                for (String k : KEYS) fixed.put(k, n.get(k));
                out.put(fixed);
            } catch (Exception e) {
                Log.w(TAG, "sanitizeOrderItemsForCloud err: " + e.getMessage());
            }
        }
        return out;
    }

    /**
     * P0-3：orders 专用 upsert（on_conflict=cloud_id）。
     * - 优先携带 printed 字段；若云端无 printed 列，则自动移除 printed 再重试。
     */
    private static boolean upsertOrders(Context ctx, String base, JSONArray rows) throws IOException {
        // =======================
        //  ORDERS UPLOAD LOCKED
        // =======================
        // ⚠️ 商用核心：订单上云逻辑"锁死"，后续不要再随意改动这里。
        // 设计目标：
        // 1) 永不因为本地新增字段导致云端 400（PGRST204 schema cache / unknown column）。
        // 2) 永不因为批量 JSON key 不一致导致 400（PGRST102 All object keys must match）。
        // 做法：
        // - 先统一 key 集合（缺失字段补 null）
        // - 如遇 PGRST204 提示某列不存在：自动移除该列并重试（最多 3 次）
        // 这样即使未来本地表加字段，也不会影响订单同步。

        if (rows == null || rows.length() == 0) return true;
        String url = base + "/rest/v1/orders?on_conflict=cloud_id";

        java.util.HashSet<String> dropKeys = new java.util.HashSet<>();
        // 云端 orders 表没有的字段：历史遗留/误加字段，必须永远过滤
        dropKeys.add("voided_at");

        JSONArray payload = normalizeJsonArrayKeys(rows, dropKeys);

        for (int attempt = 0; attempt < 3; attempt++) {
            PostResult pr = postJsonWithRaw(ctx, url, payload, "return=minimal,resolution=merge-duplicates");
            logD(ctx, "ORDERS UPSERT POST " + url + " code=" + pr.code + " raw=" + pr.raw);
            if (pr.ok) return true;

            // 401 已在 postJsonWithRaw 内部处理刷新并重试过，这里就不再额外处理

            // 若云端 schema cache 提示某列不存在，则自动移除该列再试一次
            String missingCol = parseMissingColumn(pr.raw);
            if (missingCol != null && missingCol.length() > 0) {
                if (!dropKeys.contains(missingCol)) {
                    dropKeys.add(missingCol);
                    logW(ctx, "orders upsert retry after dropping missing column: " + missingCol);
                    payload = normalizeJsonArrayKeys(rows, dropKeys);
                    continue;
                }
            }

            // 若仍提示 key 不一致（PGRST102），再次做一次 key 归一化即可
            if (pr.raw != null && pr.raw.contains("PGRST102")) {
                logW(ctx, "orders upsert retry after normalizing keys (PGRST102)");
                payload = normalizeJsonArrayKeys(rows, dropKeys);
                continue;
            }

            // 其他 400/500：不再盲目重试，避免死循环
            break;
        }
        return false;
    }

    /** Small struct for HTTP results */
    private static class PostResult {
        final boolean ok;
        final int code;
        final String raw;
        PostResult(boolean ok, int code, String raw) { this.ok = ok; this.code = code; this.raw = raw; }
    }

    /**
     * Post JSON with token-refresh retry; returns raw body so we can detect schema errors.
     * IMPORTANT: do NOT use for other tables unless you really need raw.
     */
    private static PostResult postJsonWithRaw(Context ctx, String url, JSONArray rows, String prefer) throws IOException {
        if (rows == null || rows.length() == 0) return new PostResult(true, 200, "");

        // 指数退避重试配置
        int maxRetries = 3;
        long[] retryDelays = {1000, 3000, 5000}; // 1秒, 3秒, 5秒

        for (int attempt = 0; attempt < maxRetries; attempt++) {
            if (attempt > 0) {
                try {
                    Thread.sleep(retryDelays[attempt - 1]);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return new PostResult(false, 0, "Interrupted");
                }
            }

            Request req = withHeaders(ctx, url)
                    .addHeader("Prefer", prefer)
                    .post(RequestBody.create(rows.toString(), JSON))
                    .build();

            try (Response resp = executeWithRetry(req)) {
                String raw = resp.body() != null ? resp.body().string() : "";

                // 401: token刷新重试
                if (resp.code() == 401) {
                    String newToken = refreshAccessToken(ctx);
                    if (newToken != null) {
                        Request req2 = withHeaders(ctx, url)
                                .addHeader("Prefer", prefer)
                                .post(RequestBody.create(rows.toString(), JSON))
                                .build();
                        try (Response resp2 = executeWithRetry(req2)) {
                            String raw2 = resp2.body() != null ? resp2.body().string() : "";
                            return new PostResult(resp2.isSuccessful(), resp2.code(), raw2);
                        }
                    }
                }

                // 成功或致命错误：不重试
                if (resp.isSuccessful() || isFatalError(resp.code())) {
                    return new PostResult(resp.isSuccessful(), resp.code(), raw);
                }

                // 可重试错误：继续循环
                if (isRetryableError(resp.code()) && attempt < maxRetries - 1) {
                    logW(ctx, "HTTP " + resp.code() + " retryable, attempt " + (attempt + 1) + "/" + maxRetries);
                    continue;
                }

                return new PostResult(resp.isSuccessful(), resp.code(), raw);
            } catch (IOException e) {
                // 网络异常：可重试
                if (attempt < maxRetries - 1) {
                    logW(ctx, "IO error, retry " + (attempt + 1) + "/" + maxRetries + ": " + e.getMessage());
                    continue;
                }
                throw e;
            }
        }

        return new PostResult(false, 0, "Max retries exceeded");
    }

    private static boolean isFatalError(int code) {
        // 4xx客户端错误（除了429）和5xx服务器错误（除了502,503,504）
        if (code == 400 || code == 403 || code == 404 || code == 405 ||
            code == 409 || code == 422 || code >= 500) {
            return true;
        }
        return false;
    }

    private static boolean isRetryableError(int code) {
        // 可重试的错误：429（太多请求）、502（错误网关）、503（服务不可用）、504（网关超时）
        return code == 429 || code == 502 || code == 503 || code == 504;
    }

    /** Extract missing column name from PostgREST error (PGRST204). */
    private static String parseMissingColumn(String raw) {
        if (raw == null) return null;
        // Example: Could not find the 'voided_at' column of 'orders' in the schema cache
        int p = raw.indexOf("Could not find the '");
        if (p < 0) return null;
        int s = p + len("Could not find the '");
        int e = raw.indexOf("' column", s);
        if (e < 0) return null;
        return raw.substring(s, e);
    }

    private static int len(String s) { return s == null ? 0 : s.length(); }

    /**
     * Make every object in array have EXACT same key set to satisfy PostgREST batch rules.
     * Also drops any keys in dropKeys (e.g., voided_at).
     */
    private static JSONArray normalizeJsonArrayKeys(JSONArray in, java.util.Set<String> dropKeys) {
        if (in == null) return new JSONArray();
        java.util.LinkedHashSet<String> keys = new java.util.LinkedHashSet<>();

        // 1) collect union keys
        for (int i = 0; i < in.length(); i++) {
            JSONObject o = in.optJSONObject(i);
            if (o == null) continue;
            java.util.Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String k = it.next();
                if (dropKeys != null && dropKeys.contains(k)) continue;
                keys.add(k);
            }
        }

        // 2) rebuild each object with same keys
        JSONArray out = new JSONArray();
        for (int i = 0; i < in.length(); i++) {
            JSONObject o = in.optJSONObject(i);
            if (o == null) continue;
            JSONObject n = new JSONObject();
            try {
                for (String k : keys) {
                    if (o.has(k)) {
                        Object v = o.opt(k);
                        // org.json: explicit null should be JSONObject.NULL
                        if (v == null) v = JSONObject.NULL;
                        n.put(k, v);
                    } else {
                        n.put(k, JSONObject.NULL);
                    }
                }
            } catch (Exception ignored) { /* never crash orders sync */ }
            out.put(n);
        }
        return out;
    }

    private static JSONArray removeKeyFromAll(JSONArray in, String key) {
        if (in == null) return null;
        JSONArray out = new JSONArray();
        for (int i = 0; i < in.length(); i++) {
            JSONObject o = in.optJSONObject(i);
            if (o == null) continue;
            JSONObject n = new JSONObject();
            try {
                java.util.Iterator<String> it = o.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    if (key != null && key.equals(k)) continue;
                    n.put(k, o.opt(k));
                }
            } catch (Exception ignored) {}
            out.put(n);
        }
        return out;
    }

    /** POST/UPSERT helper: uses existing headers/token refresh logic */
    private static boolean postJson(Context ctx, String url, JSONArray rows, String prefer) throws IOException {
        if (rows == null || rows.length() == 0) return true;

        Request req = withHeaders(ctx, url)
                .addHeader("Prefer", prefer)
                .post(RequestBody.create(rows.toString(), JSON))
                .build();

        try (Response resp = executeWithRetry(req)) {
            String raw = resp.body() != null ? resp.body().string() : "";
            logD(ctx, "ORDERS UPSERT POST " + url + " code=" + resp.code() + " raw=" + raw);
            if (resp.code() == 401) {
                String newToken = refreshAccessToken(ctx);
                if (newToken != null) {
                    Request req2 = withHeaders(ctx, url)
                            .addHeader("Prefer", prefer)
                            .post(RequestBody.create(rows.toString(), JSON))
                            .build();

                    try (Response resp2 = executeWithRetry(req2)) {
                        String raw2 = resp2.body() != null ? resp2.body().string() : "";
                        logD(ctx, "ORDERS UPSERT POST(retry) " + url + " code=" + resp2.code() + " raw=" + raw2);
                        return resp2.isSuccessful();
                    }
                }
            }
            return resp.isSuccessful();
        }
    }

    private static boolean upsertTable(Context ctx, String base, String table, JSONArray rows) throws IOException {
        if ("inventory_movements".equals(table)) {
            if (rows != null && rows.length() > 0) {
                Log.w(TAG, "UPSERT skip (disabled): inventory_movements len=" + rows.length());
            } else {
                Log.d(TAG, "UPSERT skip (empty/disabled): inventory_movements");
            }
            return true;
        }

        if (rows == null || rows.length() == 0) {
            logD(ctx, "UPSERT skip (empty): " + table);
            return true;
        }

        String prefer = "return=minimal,resolution=merge-duplicates";

        // Default endpoint
        String url = base + "/rest/v1/" + table;

        // Table-specific on_conflict + sanitize
        if ("customers".equals(table)) {
            // ✅ 新策略：优先用 cloud_id 精确对齐（支持改名不产生新云端行）
            // 若云端暂未创建 unique(cloud_id)，则会自动回退到旧策略 org_id,name。
            url = base + "/rest/v1/customers?on_conflict=id";
        } else if ("products".equals(table)) {
            url = base + "/rest/v1/products?on_conflict=id";
        } else if ("inventory_items".equals(table)) {
            url = base + "/rest/v1/inventory_items?on_conflict=cloud_id";
            rows = sanitizeInventoryItemsForCloud(ctx, rows);
            if (rows == null || rows.length() == 0) {
                Log.d(TAG, "UPSERT skip (empty after sanitize): " + table);
                return true;
            }
        } else if ("orders".equals(table)) {
            url = base + "/rest/v1/orders?on_conflict=cloud_id";
        } else if ("order_items".equals(table)) {
            url = base + "/rest/v1/order_items?on_conflict=cloud_id";
            rows = sanitizeOrderItemsForCloud(ctx, rows);
            if (rows == null || rows.length() == 0) {
                Log.d(TAG, "UPSERT skip (empty after sanitize): " + table);
                return true;
            }
            // helpful debug (truncated)
            try { Log.d(TAG, "ORDER_ITEMS UPSERT body=" + rows.toString().substring(0, Math.min(rows.toString().length(), 2000))); } catch (Exception ignored) {}
        } else if ("ar_invoices".equals(table) || "ar_payments".equals(table) || "ar_allocations".equals(table)) {
            // v15：财务/对账表：按 cloud_id 做 upsert
            url = base + "/rest/v1/" + table + "?on_conflict=cloud_id";
        } else if ("print_templates".equals(table)) {
            // ✅ 关键修复：云端唯一约束是 uq_templates_org_type_name(org_id,type,name)
            // 必须用 on_conflict=org_id,type,name，避免不同设备同名模板触发 409
            url = base + "/rest/v1/print_templates?on_conflict=org_id,type,name";
            rows = sanitizePrintTemplatesForCloud(rows);
            if (rows == null || rows.length() == 0) {
                Log.d(TAG, "UPSERT skip (empty after sanitize): " + table);
                return true;
            }
        }

        // ✅ logistics：显式指定 on_conflict=id，避免重复
        if ("logistics_forms".equals(table) || "logistics_sizes".equals(table)) {
            url = base + "/rest/v1/" + table + "?on_conflict=id";
        }

        RequestBody rb = RequestBody.create(rows.toString(), JSON);

        Request req = withHeaders(ctx, url)
                .addHeader("Prefer", prefer)
                .post(rb)
                .build();

        try (Response resp = executeWithRetry(req)) {
            String raw = resp.body() != null ? resp.body().string() : "";
            logD(ctx, "UPSERT POST " + url + " code=" + resp.code() + " raw=" + raw);

            // ✅ 修复：print_templates 可能出现 409（同 org_id/type/name 但云端 id 不同）
            // 典型报错：duplicate key value violates unique constraint "uq_templates_org_type_name"
            // 原因：本地计算出的 id(stableId) 与云端既有记录 id 不一致。处理方式：
            // 1) 逐条查询云端真实 id；2) 写回本地 cloud_id；3) 用真实 id 重新 upsert。
            if ("print_templates".equals(table) && resp.code() == 409 && raw != null && raw.contains("uq_templates_org_type_name")) {
                try {
                    JSONArray fixed = new JSONArray();
                    DatabaseHelper db = new DatabaseHelper(ctx);
                    for (int i = 0; i < rows.length(); i++) {
                        JSONObject o = rows.optJSONObject(i);
                        if (o == null) continue;
                        String orgId = o.optString("org_id", null);
                        String type = o.optString("type", "");
                        String name = o.optString("name", "");
                        if (type.trim().isEmpty() || name.trim().isEmpty() || orgId == null || orgId.trim().isEmpty()) {
                            fixed.put(o);
                            continue;
                        }
                        String resolvedId = resolvePrintTemplateId(ctx, base, orgId, type, name);
                        if (resolvedId != null && !resolvedId.trim().isEmpty()) {
                            JSONObject n = new JSONObject(o.toString());
                            n.put("id", resolvedId);
                            // 修复：1) 将修复后的对象加入fixed数组
                            fixed.put(n);
                            
                            // 修复：2) 将resolvedId写回本地数据库，避免后续每次都409
                            try {
                                String stableId = o.optString("id", "");
                                if (!stableId.trim().isEmpty()) {
                                    db.updatePrintTemplateCloudId(stableId, resolvedId);
                                    logD(ctx, "print_templates 409修复：将本地id " + stableId + " 映射到云端id " + resolvedId);
                                }
                            } catch (Exception e) {
                                logW(ctx, "写回本地print_templates cloud_id失败: " + e.getMessage());
                            }
                        } else {
                            fixed.put(o);
                        }
                    }

                    RequestBody rbFix = RequestBody.create(fixed.toString(), JSON);
                    String retryUrl = base + "/rest/v1/print_templates?on_conflict=id";
                    Request reqFix = withHeaders(ctx, retryUrl)
                            .addHeader("Prefer", prefer)
                            .post(rbFix)
                            .build();
                    try (Response respFix = executeWithRetry(reqFix)) {
                        String rawFix = respFix.body() != null ? respFix.body().string() : "";
                        logW(ctx, "UPSERT retry (resolve uq_templates_org_type_name): print_templates code=" + respFix.code() + " raw=" + rawFix);
                        return respFix.isSuccessful();
                    }
                } catch (Exception e) {
                    logW(ctx, "print_templates 409 resolve failed: " + e);
                }
            }

            if (resp.code() == 404 && "print_templates".equals(table)) {
                Log.d(TAG, "UPSERT skip (missing table): " + table);
                return true;
            }

            // ✅ 兼容回退：若云端没有为 cloud_id 建 unique 约束（或 PostgREST 提示 ON CONFLICT 无匹配约束），
            // 则自动回退到旧的 on_conflict 组合键，避免同步失败。
            if (!resp.isSuccessful() && ("customers".equals(table) || "products".equals(table) || "print_templates".equals(table))) {
                if (shouldFallbackLegacyOnConflict(resp.code(), raw)) {
                    String legacyUrl = url;
                    if ("customers".equals(table)) legacyUrl = base + "/rest/v1/customers?on_conflict=org_id,name";
                    else if ("products".equals(table)) legacyUrl = base + "/rest/v1/products?on_conflict=org_id,name";
                    else if ("print_templates".equals(table)) legacyUrl = base + "/rest/v1/print_templates?on_conflict=org_id,type,name";

                    Request reqLegacy = withHeaders(ctx, legacyUrl)
                            .addHeader("Prefer", prefer)
                            .post(rb)
                            .build();
                    try (Response respLegacy = executeWithRetry(reqLegacy)) {
                        String rawLegacy = respLegacy.body() != null ? respLegacy.body().string() : "";
                        logW(ctx, "UPSERT fallback legacy on_conflict: " + table + " url=" + legacyUrl + " code=" + respLegacy.code() + " raw=" + rawLegacy);
                        return respLegacy.isSuccessful();
                    }
                }
            }

            if (resp.code() == 401) {
                String newToken = refreshAccessToken(ctx);
                if (newToken != null) {
                    Request req2 = withHeaders(ctx, url)
                            .addHeader("Prefer", prefer)
                            .post(rb)
                            .build();
                    try (Response resp2 = executeWithRetry(req2)) {
                        String raw2 = resp2.body() != null ? resp2.body().string() : "";
                        logD(ctx, "UPSERT POST(retry) " + url + " code=" + resp2.code() + " raw=" + raw2);
                        return resp2.isSuccessful();
                    }
                }
            }
            return resp.isSuccessful();
        }
    }

    /**
     * 查询云端是否已存在同(org_id,type,name)的模板，返回云端主键 id。
     */
    private static String resolvePrintTemplateId(Context ctx, String base, String orgId, String type, String name) {
        try {
            String url = base + "/rest/v1/print_templates?select=id&org_id=eq."
                    + URLEncoder.encode(orgId, StandardCharsets.UTF_8.name())
                    + "&type=eq." + URLEncoder.encode(type, StandardCharsets.UTF_8.name())
                    + "&name=eq." + URLEncoder.encode(name, StandardCharsets.UTF_8.name())
                    + "&limit=1";
            Request req = withHeaders(ctx, url).get().build();
            try (Response resp = executeWithRetry(req)) {
                String raw = resp.body() != null ? resp.body().string() : "";
                if (!resp.isSuccessful()) return null;
                JSONArray arr = new JSONArray(raw);
                if (arr.length() == 0) return null;
                JSONObject o = arr.optJSONObject(0);
                if (o == null) return null;
                return o.optString("id", null);
            }
        } catch (Exception ignored) {
            return null;
        }
    }

    /**
     * When PostgREST doesn't have a unique/exclusion constraint matching the ON CONFLICT spec,
     * it returns 400 with message like:
     * "there is no unique or exclusion constraint matching the ON CONFLICT specification".
     *
     * Some environments may also return constraint-related text under "details".
     */
    private static boolean shouldFallbackLegacyOnConflict(int httpCode, String rawBody) {
        if (httpCode != 400 && httpCode != 409) return false;
        if (rawBody == null) return false;
        String s = rawBody.toLowerCase(java.util.Locale.US);

        // 1) 云端没有对应的 unique/exclusion 约束
        boolean noConstraint = (s.contains("on conflict") && (s.contains("no unique") || s.contains("no unique or exclusion") || s.contains("constraint")))
                || s.contains("there is no unique")
                || s.contains("no unique or exclusion constraint");

        // 2) 云端根本没有该列（常见：试图使用 on_conflict=cloud_id，但表里只有 id）
        boolean missingColumn = s.contains("pgrst204") && s.contains("could not find") && s.contains("cloud_id");

        return noConstraint || missingColumn;
    }

    private static String refreshAccessToken(Context ctx) {
        try {
            String baseUrl = getBaseUrl(ctx);
            String anon = getAnonKey(ctx);
            String refreshToken = AuthManager.getRefreshToken(ctx);
            if (baseUrl == null || anon == null || refreshToken == null) return null;

            String url = baseUrl + "/auth/v1/token?grant_type=refresh_token";
            JSONObject body = new JSONObject();
            body.put("refresh_token", refreshToken);

            Request req = new Request.Builder()
                    .url(url)
                    .post(RequestBody.create(body.toString(), JSON))
                    .addHeader("apikey", anon)
                    .addHeader("Content-Type", "application/json")
                    .build();

            Response resp = http.newCall(req).execute();
            String respBody = resp.body() == null ? "" : resp.body().string();
            if (!resp.isSuccessful()) {
                Log.w(TAG, "refresh token failed code=" + resp.code() + " body=" + respBody);
                return null;
            }

            JSONObject json = new JSONObject(respBody);
            String newAccess = json.optString("access_token", null);
            String newRefresh = json.optString("refresh_token", null);
            if (newAccess == null || newAccess.trim().isEmpty()) return null;

            AuthManager.saveTokensToSupabaseCfg(ctx, newAccess, (newRefresh == null ? refreshToken : newRefresh));
            try {
                ctx.getSharedPreferences("auth_prefs", Context.MODE_PRIVATE)
                        .edit()
                        .putString("auth_token", newAccess)
                        .commit();
            } catch (Exception ignored) { }
            return newAccess;
        } catch (Exception e) {
            Log.w(TAG, "refreshAccessToken error: " + e.getMessage());
            return null;
        }
    }

    private static String stableUuid(String uid, String kind, String name) {
        try {
            String raw = (uid == null ? "" : uid.trim()) + "|" + kind + "|" + (name == null ? "" : name.trim());
            java.util.UUID u = java.util.UUID.nameUUIDFromBytes(raw.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            return u.toString();
        } catch (Exception e) {
            return java.util.UUID.randomUUID().toString();
        }
    }

    private static JSONArray ensureStableIds(JSONArray arr, String seed, String kind) {
        if (arr == null) return null;
        JSONArray out = new JSONArray();
        for (int i = 0; i < arr.length(); i++) {
            try {
                JSONObject r = arr.optJSONObject(i);
                if (r == null) continue;
                String name = r.optString("name", "");
                if (TextUtils.isEmpty(name)) continue;

                String id = r.optString("id", "");
                if (TextUtils.isEmpty(id) || "null".equalsIgnoreCase(id)) {
                    id = stableUuid(seed, kind, name);
                }
                r.put("id", id);
                out.put(r);
            } catch (Exception ignored) {}
        }
        return out;
    }

    private static void processCloudDeletes(Context ctx, String base, DatabaseHelper db) throws Exception {
        if (db == null || TextUtils.isEmpty(base)) return;
        java.util.List<DatabaseHelper.CloudDeleteItem> items = db.getPendingCloudDeletes(50);
        if (items == null || items.isEmpty()) return;

        final String uid = getUserId(ctx);
        String orgId = null;
        try { orgId = ensureOrgId(ctx); } catch (Exception ignored) {}

        for (DatabaseHelper.CloudDeleteItem it : items) {
            if (it == null) continue;
            String table = it.tableName == null ? "" : it.tableName.trim();
            if (table.isEmpty()) { db.markCloudDeleteDone(it.id); continue; }
            JSONObject w = it.where == null ? new JSONObject() : it.where;

            boolean shared = "customers".equals(table) || "products".equals(table) || "print_templates".equals(table);
            if (shared) {
                if (!TextUtils.isEmpty(orgId) && !w.has("org_id")) {
                    try { w.put("org_id", orgId); } catch (Exception ignored) {}
                }
            } else {
                if (!TextUtils.isEmpty(uid) && !w.has("owner_uid")) {
                    try { w.put("owner_uid", uid); } catch (Exception ignored) {}
                }
            }

            boolean allowNullLoc = w.optBoolean("__location_allow_null", false);

            java.util.ArrayList<String> urls = new java.util.ArrayList<>();
            urls.add(buildDeleteUrl(base, table, w, false));
            if (allowNullLoc) {
                urls.add(buildDeleteUrl(base, table, w, true));
            }

            boolean okAny = false;
            for (String url : urls) {
                if (TextUtils.isEmpty(url)) continue;
                Request req = withHeaders(ctx, url).delete().build();
                try (Response resp = executeWithRetry(req)) {
                    String raw = resp.body() != null ? resp.body().string() : "";
                    Log.d(TAG, "DELETE " + url + " code=" + resp.code() + " raw=" + raw);
                    if (resp.isSuccessful() || resp.code() == 404) {
                        okAny = true;
                        continue;
                    }
                    if (resp.code() == 401) {
                        String newToken = refreshAccessToken(ctx);
                        if (newToken != null) {
                            Request req2 = withHeaders(ctx, url).delete().build();
                            try (Response resp2 = executeWithRetry(req2)) {
                                String raw2 = resp2.body() != null ? resp2.body().string() : "";
                                Log.d(TAG, "DELETE(retry) " + url + " code=" + resp2.code() + " raw=" + raw2);
                                if (resp2.isSuccessful() || resp2.code() == 404) okAny = true;
                            }
                        }
                    }
                }
            }

            if (okAny) {
                db.markCloudDeleteDone(it.id);
                try {
                    String trackedCid = null;
                    if ("orders".equals(table)) trackedCid = w.optString("cloud_id", "");
                    else if ("order_items".equals(table)) trackedCid = w.optString("order_cloud_id", "");
                    if (trackedCid != null && !trackedCid.trim().isEmpty()) {
                        db.markOrderCloudDeleteTrackedByCloudId(trackedCid.trim());
                    }
                } catch (Exception ignored) {}
            } else {
                break;
            }
        }
    }


    private static boolean deleteUrl(Context ctx, String url) throws IOException {
        Request req = withHeaders(ctx, url).delete().build();
        try (Response resp = executeWithRetry(req)) {
            String raw = resp.body() != null ? resp.body().string() : "";
            logD(ctx, "DELETE " + url + " code=" + resp.code() + " raw=" + raw);
            if (resp.isSuccessful() || resp.code() == 404) return true;
            if (resp.code() == 401) {
                String newToken = refreshAccessToken(ctx);
                if (newToken != null) {
                    Request req2 = withHeaders(ctx, url).delete().build();
                    try (Response resp2 = executeWithRetry(req2)) {
                        String raw2 = resp2.body() != null ? resp2.body().string() : "";
                        logD(ctx, "DELETE(retry) " + url + " code=" + resp2.code() + " raw=" + raw2);
                        return resp2.isSuccessful() || resp2.code() == 404;
                    }
                }
            }
            return false;
        }
    }

    private static void cleanupCloudHistoricalData(Context ctx, String base) throws Exception {
        if (TextUtils.isEmpty(base) || !ready(ctx)) return;
        String boundary = getDateTwoYearsAgo();
        String uid = getUserId(ctx);
        if (TextUtils.isEmpty(uid)) return;
        String uidEnc = URLEncoder.encode(uid, StandardCharsets.UTF_8.name());

        // 1) orders/order_items：删除边界之前的云端历史数据
        java.util.LinkedHashSet<String> oldOrderCloudIds = new java.util.LinkedHashSet<>();
        String[] orderCols = new String[]{"owner_uid", "tenant_id"};
        for (String col : orderCols) {
            JSONArray olds = getArrayPaged(ctx,
                    base + "/rest/v1/orders?select=cloud_id&" + col + "=eq." + uidEnc
                            + "&date=lt." + URLEncoder.encode(boundary, StandardCharsets.UTF_8.name())
                            + "&order=date.asc",
                    500,
                    20);
            if (olds == null) continue;
            for (int i = 0; i < olds.length(); i++) {
                JSONObject o = olds.optJSONObject(i);
                if (o == null) continue;
                String cid = o.optString("cloud_id", "");
                if (!TextUtils.isEmpty(cid)) oldOrderCloudIds.add(cid);
            }
        }
        if (!oldOrderCloudIds.isEmpty()) {
            java.util.ArrayList<String> batch = new java.util.ArrayList<>();
            for (String cid : oldOrderCloudIds) {
                batch.add(cid);
                if (batch.size() >= 100) {
                    deleteOrderItemsBatch(ctx, base, batch);
                    batch.clear();
                }
            }
            if (!batch.isEmpty()) deleteOrderItemsBatch(ctx, base, batch);
        }
        for (String col : orderCols) {
            deleteUrl(ctx,
                    base + "/rest/v1/orders?" + col + "=eq." + uidEnc
                            + "&date=lt." + URLEncoder.encode(boundary, StandardCharsets.UTF_8.name()));
        }

        // 2) logistics/logistics_sizes
        JSONArray oldForms = getArrayPaged(ctx,
                base + "/rest/v1/logistics_forms?select=id&tenant_id=eq." + uidEnc
                        + "&date=lt." + URLEncoder.encode(boundary, StandardCharsets.UTF_8.name())
                        + "&order=date.asc",
                500,
                20);
        if (oldForms != null && oldForms.length() > 0) {
            java.util.ArrayList<String> formIds = new java.util.ArrayList<>();
            for (int i = 0; i < oldForms.length(); i++) {
                JSONObject o = oldForms.optJSONObject(i);
                if (o == null) continue;
                String id = o.optString("id", "");
                if (!TextUtils.isEmpty(id)) formIds.add(id);
            }
            for (int i = 0; i < formIds.size(); i += 100) {
                int end = Math.min(i + 100, formIds.size());
                String inClause = android.text.TextUtils.join(",", formIds.subList(i, end));
                deleteUrl(ctx, base + "/rest/v1/logistics_sizes?form_id=in.(" + inClause + ")");
            }
        }
        deleteUrl(ctx,
                base + "/rest/v1/logistics_forms?tenant_id=eq." + uidEnc
                        + "&date=lt." + URLEncoder.encode(boundary, StandardCharsets.UTF_8.name()));

        // 3) finance（仅保留近2个自然月）
        deleteUrl(ctx, base + "/rest/v1/ar_allocations?created_by=eq." + uidEnc + "&created_at=lt." + URLEncoder.encode(boundary, StandardCharsets.UTF_8.name()));
        deleteUrl(ctx, base + "/rest/v1/ar_payments?created_by=eq." + uidEnc + "&created_at=lt." + URLEncoder.encode(boundary, StandardCharsets.UTF_8.name()));
        deleteUrl(ctx, base + "/rest/v1/ar_invoices?created_by=eq." + uidEnc + "&created_at=lt." + URLEncoder.encode(boundary, StandardCharsets.UTF_8.name()));

        logD(ctx, "云端历史裁剪完成，边界=" + boundary);
    }

    private static void deleteOrderItemsBatch(Context ctx, String base, java.util.List<String> cloudIds) throws Exception {
        if (cloudIds == null || cloudIds.isEmpty()) return;
        String inClause = android.text.TextUtils.join(",", cloudIds);
        deleteUrl(ctx, base + "/rest/v1/order_items?order_cloud_id=in.(" + inClause + ")");
    }

    private static String buildDeleteUrl(String base, String table, JSONObject where, boolean useNullLocation) throws Exception {
        StringBuilder sb = new StringBuilder();
        sb.append(base).append("/rest/v1/").append(table).append("?");

        boolean first = true;
        java.util.Iterator<String> it = where.keys();
        while (it.hasNext()) {
            String k = it.next();
            if (k == null) continue;
            if (k.startsWith("__")) continue;
            if ("orders".equals(table) && "tenant_id".equals(k)) continue;

            final String originalK = k;

            String key = originalK;
            if ("orders".equals(table)) {
                if ("customer_name".equals(originalK)) key = "customer";
                else if ("product_name".equals(originalK)) key = "product";
            }

            if (useNullLocation && "location".equals(originalK)) continue;
            Object v = where.opt(originalK);
            if (v == null) continue;
            String val = String.valueOf(v);

            if (!first) sb.append("&");
            first = false;
            sb.append(URLEncoder.encode(key, StandardCharsets.UTF_8.name())).append("=eq.");
            sb.append(URLEncoder.encode(val, StandardCharsets.UTF_8.name()));
        }

        if (useNullLocation) {
            if (!first) sb.append("&");
            sb.append("location=is.null");
        }
        return sb.toString();
    }
    // ===== print_templates timestamp sanitize =====
    // Remove bad created_at/updated_at values before pushing to cloud, letting DB triggers fill timestamptz.
    private static JSONArray sanitizePrintTemplatesForCloud(JSONArray rows) {
        if (rows == null || rows.length() == 0) return rows;
        JSONArray out = new JSONArray();
        for (int i = 0; i < rows.length(); i++) {
            JSONObject o = rows.optJSONObject(i);
            if (o == null) continue;
            try {
                JSONObject n = new JSONObject(o.toString());

                String ca = n.optString("created_at", null);
                if (isBadTimestampValue(ca)) n.remove("created_at");

                String ua = n.optString("updated_at", null);
                if (isBadTimestampValue(ua)) n.remove("updated_at");

                out.put(n);
            } catch (Exception e) {
                out.put(o);
            }
        }
        return out;
    }

    // Treat numeric placeholders / timestamps that Postgres timestamptz can't parse (e.g. "0", all-zeros, 10+/13+ digits)
    private static boolean isBadTimestampValue(String s) {
        if (s == null) return false;
        s = s.trim();
        if (s.isEmpty()) return false;

        // Pure digits?
        if (!s.matches("^\\d+$")) return false;

        // 10+ digits are seconds/millis timestamps (e.g., 1769142316337)
        if (s.length() >= 10) return true;

        // "0" or all-zeros are bad placeholders for timestamptz
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) != '0') return false;
        }
        return true;
    }


    // === helper: millis -> ISO-8601 (UTC) ===
    private static String toIso8601(long millis) {
        try {
            // 使用兼容的SimpleDateFormat替代java.time API
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US);
            sdf.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            return sdf.format(new java.util.Date(millis));
        } catch (Exception e) {
            return null;
        }

    }
    // ===== 占位：模板 cloud_id 回写（当前版本不启用，避免影响同步）=====
    public void updatePrintTemplateCloudIdByTypeName(String type, String name, String cloudId) {
        // intentionally left blank
    }

}