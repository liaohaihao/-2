package com.suzai.suzaiflowersystem;

public class ProductInfo {
    private final String name;
    private final int packingUnits;
    private final double price;

    public ProductInfo(String name, int packingUnits, double price) {
        this.name = name;
        this.packingUnits = packingUnits;
        this.price = price;
    }

    public String getName() { return name; }

    public int getPackingUnits() { return packingUnits; }

    public double getPrice() { return price; }
}
