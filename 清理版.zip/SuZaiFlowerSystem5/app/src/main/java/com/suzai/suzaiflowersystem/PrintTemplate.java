package com.suzai.suzaiflowersystem;

public class PrintTemplate {
    private long id;
    private String type;   // LABEL / DELIVERY / LOGISTICS
    private String name;
    private String content;
    private long updatedAt;
    private int isDefault; // 0/1

    public PrintTemplate() {}

    public PrintTemplate(long id, String type, String name, String content, long updatedAt, int isDefault) {
        this.id = id;
        this.type = type;
        this.name = name;
        this.content = content;
        this.updatedAt = updatedAt;
        this.isDefault = isDefault;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public long getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(long updatedAt) { this.updatedAt = updatedAt; }
    public int getIsDefault() { return isDefault; }
    public void setIsDefault(int isDefault) { this.isDefault = isDefault; }
}
