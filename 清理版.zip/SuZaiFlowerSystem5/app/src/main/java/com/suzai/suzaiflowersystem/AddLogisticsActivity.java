package com.suzai.suzaiflowersystem;

import android.app.DatePickerDialog;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.Locale;

public class AddLogisticsActivity extends BaseDrawerActivity {

    private EditText dateEdit;
    private Spinner locationSpinner;
    private EditText totalPiecesEdit;
    private EditText actualQtyEdit;
    private EditText totalCbmEdit;
    private EditText remarkEdit;

    private Button addSizeBtn, saveSizesBtn, submitBtn;
    private Button autoGenerateBtn;
    private Button cartonRuleBtn;
    private Button printBtn;
    private Button deleteBtn;
    private LinearLayout sizeContainer;

    private DatabaseHelper db;

    // ✅ 编辑模式 id（从 LogisticsManagementActivity 传入）
    private long editId = -1;

    private final ArrayList<SizeItem> sizeItems = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentLayout(R.layout.activity_add_logistics);

        db = new DatabaseHelper(this);

        bindViews();

        // ✅ 判断是否编辑（先取 id，方便后续初始化 UI）
        editId = getIntent().getLongExtra("id", -1);

        setupDate();
        setupLocation();

        addSizeBtn.setOnClickListener(v -> addSize());
        if (saveSizesBtn != null) saveSizesBtn.setOnClickListener(v -> saveAllSizeRows(true));
        if (autoGenerateBtn != null) autoGenerateBtn.setOnClickListener(v -> autoGenerateCartons(true));
        if (cartonRuleBtn != null) cartonRuleBtn.setOnClickListener(v -> showCartonRuleDialog());
        submitBtn.setOnClickListener(v -> submit());
        if (printBtn != null) {
            printBtn.setOnClickListener(v -> {
                if (editId > 0) {
                    LogisticsPrinter.printById(this, editId);
                } else {
                    Toast.makeText(this, "请先保存后再打印", Toast.LENGTH_SHORT).show();
                }
            });
        }

        if (deleteBtn != null) {
            deleteBtn.setOnClickListener(v -> {
                if (editId <= 0) {
                    Toast.makeText(this, "请先保存后再删除", Toast.LENGTH_SHORT).show();
                    return;
                }
                new AlertDialog.Builder(this)
                        .setTitle("删除物流单")
                        .setMessage("确定删除此物流单？删除后不可恢复。")
                        .setPositiveButton("删除", (d, w) -> {
                            int rows = db.deleteLogisticsForm(editId);
                            if (rows > 0) {
                                Toast.makeText(this, "已删除", Toast.LENGTH_SHORT).show();
                                finish();
                            } else {
                                Toast.makeText(this, "删除失败", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("取消", null)
                        .show();
            });
        }
        if (editId > 0) {
            setTitle("编辑物流单");
            loadForEdit(editId);
            if (printBtn != null) printBtn.setVisibility(View.VISIBLE);
            if (deleteBtn != null) deleteBtn.setVisibility(View.VISIBLE);
        } else {
            setTitle("新增物流单");
            refreshFromDate();
            if (sizeContainer != null && sizeContainer.getChildCount() == 0) addSize();
            if (printBtn != null) printBtn.setVisibility(View.GONE);
            if (deleteBtn != null) deleteBtn.setVisibility(View.GONE);
        }
    }

    private void bindViews() {
        dateEdit = findViewById(R.id.logDateEditText);
        locationSpinner = findViewById(R.id.logLocationSpinner);
        totalPiecesEdit = findViewById(R.id.logTotalPiecesEditText);
        totalCbmEdit = findViewById(R.id.logTotalCbmEditText);
        remarkEdit = findViewById(R.id.logRemarkEditText);

        actualQtyEdit = findViewById(R.id.logActualQtyEditText);
        addSizeBtn = findViewById(R.id.addSizeButton);
        saveSizesBtn = findViewById(R.id.saveSizesButton);
        autoGenerateBtn = findViewById(R.id.autoGenerateCartonButton);
        cartonRuleBtn = findViewById(R.id.manageCartonRulesButton);
        submitBtn = findViewById(R.id.submitLogisticsButton);
        printBtn = findViewById(R.id.printLogisticsButton);
        deleteBtn = findViewById(R.id.deleteLogisticsButton);
        sizeContainer = findViewById(R.id.sizeContainer);

        dateEdit.setInputType(InputType.TYPE_NULL);
        totalPiecesEdit.setEnabled(false);
        if (actualQtyEdit != null) actualQtyEdit.setEnabled(false);
        totalCbmEdit.setEnabled(false);
        if (remarkEdit != null) {
            remarkEdit.setVerticalScrollBarEnabled(true);
            remarkEdit.setMovementMethod(new ScrollingMovementMethod());
            remarkEdit.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        }
    }

    private void setupDate() {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        dateEdit.setText(today);
        dateEdit.setOnClickListener(v -> showDatePicker());
    }

    private void showDatePicker() {
        Calendar cal = Calendar.getInstance();
        String[] parts = dateEdit.getText().toString().split("-");
        if (parts.length == 3) {
            try {
                cal.set(Calendar.YEAR, Integer.parseInt(parts[0]));
                cal.set(Calendar.MONTH, Integer.parseInt(parts[1]) - 1);
                cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(parts[2]));
            } catch (Exception ignored) {}
        }
        new DatePickerDialog(this, (view, y, m, d) -> {
            String v = String.format(Locale.getDefault(), "%04d-%02d-%02d", y, m + 1, d);
            dateEdit.setText(v);

            // ✅ 新增模式：日期改变时自动刷新“各档口件数”
            if (editId <= 0) {
                refreshFromDate();
            }
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void setupLocation() {
        List<String> locations = db.getAllLocationNames();
        if (!locations.contains("全部")) locations.add(0, "全部");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, locations);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        locationSpinner.setAdapter(adapter);

        // ✅ 新增物流单：场地默认与账号场地一致，不需要手动选择
        if (editId <= 0) {
            String defLoc = AuthManager.getDefaultLocation(this);
            boolean matched = false;
            if (defLoc != null && !defLoc.trim().isEmpty()) {
                for (int i = 0; i < locationSpinner.getCount(); i++) {
                    String item = String.valueOf(locationSpinner.getItemAtPosition(i));
                    if (defLoc.equals(item)) {
                        locationSpinner.setSelection(i);
                        matched = true;
                        break;
                    }
                }
            }
            // 如果匹配到了默认场地，则禁用选择；否则仍允许用户手动选
            locationSpinner.setEnabled(!matched);
        } else {
            // 编辑模式允许修改
            locationSpinner.setEnabled(true);
        }

        // ✅ 新增模式：切换场地时也刷新“各档口件数/总件数”
        locationSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (editId <= 0) {
                    refreshFromDate();
                }
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
    }

    /**
     * ✅ 新增模式：根据日期自动生成“总件数/各档口件数备注”
     */
    private void refreshFromDate() {
        String date = dateEdit.getText().toString().trim();
        String loc = String.valueOf(locationSpinner.getSelectedItem());
        int totalPieces = db.getTotalPiecesByDate(date, loc);
        totalPiecesEdit.setText(String.valueOf(totalPieces));
        if (actualQtyEdit != null) {
            actualQtyEdit.setText(String.valueOf(db.getTotalPiecesByDate(date, loc)));
        }

        StringBuilder sb = new StringBuilder();
        for (CustomerPiecesSummary cs : db.getCustomerPiecesSummaryByDate(date, loc)) {
            sb.append(cs.getCustomerName())
                    .append(cs.getTotalPieces())
                    .append("件\n");
        }
        remarkEdit.setText(sb.toString().trim());

        recalcTotals();
    }


    private void autoGenerateCartons(boolean fromButton) {
        String date = dateEdit.getText().toString().trim();
        String location = String.valueOf(locationSpinner.getSelectedItem());
        if (date.isEmpty() || location == null || location.trim().isEmpty() || "全部".equals(location)) {
            if (fromButton) Toast.makeText(this, "请先选择具体日期和场地", Toast.LENGTH_SHORT).show();
            return;
        }
        saveAllSizeRows(false);
        List<LogisticsSize> autos = db.buildAutoCartonSizesForDate(date, location);
        if (autos == null || autos.isEmpty()) {
            if (fromButton) Toast.makeText(this, "未找到可自动生成的纸箱规则，请先设置产品纸箱规则", Toast.LENGTH_SHORT).show();
            recalcTotals();
            return;
        }
        sizeItems.clear();
        sizeContainer.removeAllViews();
        for (LogisticsSize s : autos) {
            SizeItem si = new SizeItem(s.getLen(), s.getWid(), s.getHei(), s.getPieces());
            sizeItems.add(si);
            addSizeRow(si);
        }
        recalcTotals();
        if (fromButton) Toast.makeText(this, "已按当天订单自动生成纸箱尺寸", Toast.LENGTH_SHORT).show();
    }

    private void showCartonRuleDialog() {
        List<DatabaseHelper.CartonRuleGroup> groups = db.getCartonRuleGroups();
        final java.util.ArrayList<String> labels = new java.util.ArrayList<>();
        labels.add("新增尺寸规则");
        if (groups != null) {
            for (DatabaseHelper.CartonRuleGroup g : groups) {
                labels.add(String.format(Locale.getDefault(), "%.0f×%.0f×%.0f（%d个产品）", g.len, g.wid, g.hei, g.products.size()));
            }
        }
        new AlertDialog.Builder(this)
                .setTitle("纸箱规则")
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    if (which == 0) showGroupedCartonRuleEditor(null);
                    else showGroupedCartonRuleEditor(groups.get(which - 1));
                })
                .setNegativeButton("查看规则", (d, w) -> showCartonRuleList())
                .setNeutralButton("关闭", null)
                .show();
    }

    private void showGroupedCartonRuleEditor(@Nullable DatabaseHelper.CartonRuleGroup group) {
        List<String> allProducts = db.getAllProductNames();
        if (allProducts == null) allProducts = new ArrayList<>();

        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        wrap.setPadding(pad, pad, pad, pad);

        final EditText lenEt = new EditText(this);
        final EditText widEt = new EditText(this);
        final EditText heiEt = new EditText(this);
        lenEt.setHint("长(cm)");
        widEt.setHint("宽(cm)");
        heiEt.setHint("高(cm)");
        lenEt.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        widEt.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        heiEt.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        if (group != null) {
            lenEt.setText(String.format(Locale.getDefault(), "%.0f", group.len));
            widEt.setText(String.format(Locale.getDefault(), "%.0f", group.wid));
            heiEt.setText(String.format(Locale.getDefault(), "%.0f", group.hei));
        }
        wrap.addView(lenEt);
        wrap.addView(widEt);
        wrap.addView(heiEt);

        final String[] names = allProducts.toArray(new String[0]);
        final boolean[] checked = new boolean[names.length];
        if (group != null) {
            for (int i = 0; i < names.length; i++) checked[i] = group.products.contains(names[i]);
        }

        TextView tip = new TextView(this);
        tip.setText("选择适用该纸箱尺寸的产品");
        tip.setPadding(0, pad / 2, 0, pad / 2);
        wrap.addView(tip);

        final android.widget.ScrollView sv = new android.widget.ScrollView(this);
        LinearLayout prodWrap = new LinearLayout(this);
        prodWrap.setOrientation(LinearLayout.VERTICAL);
        for (int i = 0; i < names.length; i++) {
            android.widget.CheckBox cb = new android.widget.CheckBox(this);
            cb.setText(names[i]);
            cb.setChecked(checked[i]);
            final int idx = i;
            cb.setOnCheckedChangeListener((buttonView, isChecked) -> checked[idx] = isChecked);
            prodWrap.addView(cb);
        }
        sv.addView(prodWrap);
        wrap.addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (int)(220 * getResources().getDisplayMetrics().density)));

        new AlertDialog.Builder(this)
                .setTitle(group == null ? "新增纸箱规则" : "编辑纸箱规则")
                .setView(wrap)
                .setNegativeButton("取消", null)
                .setNeutralButton(group == null ? "清空选择" : "删除此尺寸", (d, w) -> {
                    if (group == null) return;
                    db.deleteCartonRulesBySize(group.len, group.wid, group.hei);
                    Toast.makeText(this, "已删除该尺寸规则", Toast.LENGTH_SHORT).show();
                })
                .setPositiveButton("保存", (d, w) -> {
                    try {
                        double len = Double.parseDouble(lenEt.getText().toString().trim());
                        double wid = Double.parseDouble(widEt.getText().toString().trim());
                        double hei = Double.parseDouble(heiEt.getText().toString().trim());
                        ArrayList<String> selected = new ArrayList<>();
                        for (int i = 0; i < names.length; i++) if (checked[i]) selected.add(names[i]);
                        if (selected.isEmpty()) {
                            Toast.makeText(this, "请至少勾选一个产品", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        boolean ok = db.saveCartonRulesForSize(group == null ? null : group, len, wid, hei, selected);
                        Toast.makeText(this, ok ? "规则已保存" : "保存失败", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(this, "请输入正确的尺寸", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private void showCartonRuleList() {
        List<DatabaseHelper.CartonRuleGroup> groups = db.getCartonRuleGroups();
        if (groups == null || groups.isEmpty()) {
            Toast.makeText(this, "当前还没有纸箱规则", Toast.LENGTH_SHORT).show();
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (DatabaseHelper.CartonRuleGroup g : groups) {
            sb.append(String.format(Locale.getDefault(), "%.0f×%.0f×%.0f → ", g.len, g.wid, g.hei))
                    .append(android.text.TextUtils.join("、", g.products))
                    .append("\n");
        }
        new AlertDialog.Builder(this)
                .setTitle("纸箱规则总览")
                .setMessage(sb.toString().trim())
                .setPositiveButton("确定", null)
                .show();
    }

    private void addSize() {
        SizeItem item = new SizeItem(0, 0, 0, 0);
        sizeItems.add(item);
        addSizeRow(item);
    }

    private void bindSizeRow(View row, SizeItem item) {
        EditText lenEt = row.findViewById(R.id.sizeLenEditText);
        EditText widEt = row.findViewById(R.id.sizeWidEditText);
        EditText heiEt = row.findViewById(R.id.sizeHeiEditText);
        EditText pcsEt = row.findViewById(R.id.sizePiecesEditText);
        TextView cbm = row.findViewById(R.id.sizeCbmTextView);

        lenEt.setText(item.len > 0 ? String.format(Locale.getDefault(), "%.0f", item.len) : "");
        widEt.setText(item.wid > 0 ? String.format(Locale.getDefault(), "%.0f", item.wid) : "");
        heiEt.setText(item.hei > 0 ? String.format(Locale.getDefault(), "%.0f", item.hei) : "");
        pcsEt.setText(item.pieces > 0 ? String.valueOf(item.pieces) : "");
        cbm.setText(item.pieces > 0 ? String.format(Locale.getDefault(), "%.4f m³", item.getCbm()) : "未保存");

        row.setTag(item);
    }

    private void addSizeRow(SizeItem item) {
        View row = getLayoutInflater().inflate(R.layout.item_size_row, sizeContainer, false);
        Button del = row.findViewById(R.id.deleteSizeButton);
        bindSizeRow(row, item);
        del.setOnClickListener(v -> {
            sizeContainer.removeView(row);
            Object tag = row.getTag();
            if (tag instanceof SizeItem) sizeItems.remove((SizeItem) tag);
            recalcTotals();
        });
        sizeContainer.addView(row);
    }

    private boolean saveAllSizeRows(boolean showToast) {
        ArrayList<SizeItem> collected = new ArrayList<>();
        for (int i = 0; i < sizeContainer.getChildCount(); i++) {
            View row = sizeContainer.getChildAt(i);
            EditText lenEt = row.findViewById(R.id.sizeLenEditText);
            EditText widEt = row.findViewById(R.id.sizeWidEditText);
            EditText heiEt = row.findViewById(R.id.sizeHeiEditText);
            EditText pcsEt = row.findViewById(R.id.sizePiecesEditText);
            TextView cbmTv = row.findViewById(R.id.sizeCbmTextView);
            String ls = lenEt.getText().toString().trim();
            String ws = widEt.getText().toString().trim();
            String hs = heiEt.getText().toString().trim();
            String ps = pcsEt.getText().toString().trim();
            if (ls.isEmpty() && ws.isEmpty() && hs.isEmpty() && ps.isEmpty()) {
                cbmTv.setText("未填写");
                continue;
            }
            try {
                double len = Double.parseDouble(ls);
                double wid = Double.parseDouble(ws);
                double hei = Double.parseDouble(hs);
                int pcs = Integer.parseInt(ps);
                if (len <= 0 || wid <= 0 || hei <= 0 || pcs <= 0) throw new RuntimeException();
                SizeItem item = (row.getTag() instanceof SizeItem) ? (SizeItem) row.getTag() : new SizeItem(0,0,0,0);
                item.len = len; item.wid = wid; item.hei = hei; item.pieces = pcs;
                row.setTag(item);
                cbmTv.setText(String.format(Locale.getDefault(), "%.4f m³", item.getCbm()));
                collected.add(item);
            } catch (Exception e) {
                if (showToast) Toast.makeText(this, "请把每一条尺寸的长、宽、高、件数填写完整且大于0", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        sizeItems.clear();
        sizeItems.addAll(collected);
        recalcTotals();
        if (showToast) Toast.makeText(this, "尺寸已保存", Toast.LENGTH_SHORT).show();
        return true;
    }

    /**
     * ✅ 重新计算：总件数 + 总方数
     */
    private void recalcTotals() {
        int piecesSum = 0;
        double cbmSum = 0.0;
        for (SizeItem s : sizeItems) {
            piecesSum += s.pieces;
            cbmSum += s.getCbm();
        }
        totalPiecesEdit.setText(String.valueOf(piecesSum));
        totalCbmEdit.setText(String.format(Locale.getDefault(), "%.4f", cbmSum));
    }

    /**
     * ✅ 编辑：加载主表 + 子表尺寸
     */
    private void loadForEdit(long id) {
        LogisticsForm f = db.getLogisticsFormById(id);
        if (f == null) {
            Toast.makeText(this, "未找到该物流单", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        dateEdit.setText(f.getDate());

        // 场地选择
        for (int i = 0; i < locationSpinner.getCount(); i++) {
            String item = String.valueOf(locationSpinner.getItemAtPosition(i));
            if (item.equals(f.getLocation())) {
                locationSpinner.setSelection(i);
                break;
            }
        }

        remarkEdit.setText(f.getRemark() == null ? "" : f.getRemark());
        if (actualQtyEdit != null) {
            actualQtyEdit.setText(String.valueOf(db.getTotalPiecesByDate(f.getDate(), f.getLocation())));
        }

        // 尺寸明细
        sizeItems.clear();
        sizeContainer.removeAllViews();
        List<LogisticsSize> sizes = db.getLogisticsSizes(id);
        if (sizes != null) {
            for (LogisticsSize s : sizes) {
                SizeItem si = new SizeItem(s.getLen(), s.getWid(), s.getHei(), s.getPieces());
                sizeItems.add(si);
                addSizeRow(si);
            }
        }

        recalcTotals();
    }

    /**
     * ✅ 保存：新增 or 更新
     */
    private void submit() {
        String date = dateEdit.getText().toString().trim();
        String location = String.valueOf(locationSpinner.getSelectedItem());
        String remark = remarkEdit.getText().toString();

        if (date.isEmpty()) {
            Toast.makeText(this, "请选择日期", Toast.LENGTH_SHORT).show();
            return;
        }
        if (location == null || location.trim().isEmpty() || "全部".equals(location)) {
            Toast.makeText(this, "请选择具体场地（不要选“全部”）", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!saveAllSizeRows(false)) {
            Toast.makeText(this, "请先保存尺寸明细", Toast.LENGTH_SHORT).show();
            return;
        }
        if (sizeItems.isEmpty()) {
            Toast.makeText(this, "请至少添加一条尺寸明细", Toast.LENGTH_SHORT).show();
            return;
        }

        int totalPieces;
        double totalCbm;
        try {
            totalPieces = Integer.parseInt(totalPiecesEdit.getText().toString().trim());
        } catch (Exception e) {
            totalPieces = 0;
        }
        try {
            totalCbm = Double.parseDouble(totalCbmEdit.getText().toString().trim());
        } catch (Exception e) {
            totalCbm = 0.0;
        }

        LogisticsForm form = new LogisticsForm(
                editId > 0 ? editId : 0,
                date,
                location,
                totalPieces,
                totalCbm,
                remark
        );

        List<LogisticsSize> sizes = new ArrayList<>();
        for (SizeItem s : sizeItems) {
            sizes.add(new LogisticsSize(
                    0,
                    editId > 0 ? editId : 0,
                    s.len,
                    s.wid,
                    s.hei,
                    s.pieces,
                    s.getCbm()
            ));
        }

        boolean wasNew = (editId <= 0);

        long id;
        if (editId > 0) {
            boolean ok = db.updateLogisticsForm(editId, form, sizes);
            id = ok ? editId : -1;
        } else {
            id = db.addLogisticsForm(form, sizes);
        }

        if (id <= 0) {
            Toast.makeText(this, "保存失败（数据库插入/更新失败）", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, editId > 0 ? "物流单已更新" : "物流单已保存", Toast.LENGTH_SHORT).show();
        // ✅ 保存后立即尝试推送到云端（异步，不影响本地使用）
        SupabaseSyncManager.schedulePush(getApplicationContext());

        // ✅ 新增物流单后弹窗提醒是否立即打印
        if (wasNew) {
            final long savedId = id;
            new AlertDialog.Builder(this)
                    .setTitle("打印提醒")
                    .setMessage("是否立即打印该物流单？")
                    .setPositiveButton("打印", (d, w) -> {
                        LogisticsPrinter.printById(this, savedId);
                        finish();
                    })
                    .setNegativeButton("不打印", (d, w) -> finish())
                    .setCancelable(false)
                    .show();
        } else {
            finish(); // 返回物流管理界面，onResume 会刷新列表
        }
    }

    static class SizeItem {
        double len, wid, hei;
        int pieces;

        SizeItem(double len, double wid, double hei, int pieces) {
            this.len = len;
            this.wid = wid;
            this.hei = hei;
            this.pieces = pieces;
        }

        double getCbm() {
            // cm^3 -> m^3
            return (len * wid * hei * pieces) / 1_000_000.0;
        }
    }


private void printLogisticsForm(LogisticsForm form, List<LogisticsSize> sizes) {
    if (form == null) {
        Toast.makeText(this, "物流单不存在", Toast.LENGTH_SHORT).show();
        return;
    }
    // ✅ 默认模板：LOGISTICS
    try {
        String tpl = db.getDefaultTemplateContent(TemplateCenterActivity.TYPE_LOGISTICS);
        if (tpl != null && !tpl.trim().isEmpty()) {
            StringBuilder sizeLines = new StringBuilder();
            if (sizes != null) {
                for (LogisticsSize s : sizes) {
                    sizeLines.append(String.format(java.util.Locale.getDefault(),
                            "%.0f×%.0f×%.0f  %d件  %.3fm³",
                            s.getLen(), s.getWid(), s.getHei(), s.getPieces(), s.getCbm()))
                            .append("\n");
                }
            }
            java.util.Map<String, String> vars = new java.util.HashMap<>();
            vars.put("date", form.getDate() == null ? "" : form.getDate());
            vars.put("total_pieces", String.valueOf(form.getTotalPieces()));
            vars.put("cubic", String.format(java.util.Locale.getDefault(), "%.3f", form.getTotalCbm()));
            vars.put("remark", form.getRemark() == null ? "" : form.getRemark());
            vars.put("serial_no", String.valueOf(form.getId()));
            vars.put("size_lines", sizeLines.toString());

            String rendered = TemplateEngine.render(tpl, vars);
            PrinterManager.printDoc(this, rendered);
            Toast.makeText(this, "物流单已按默认模板发送到打印机", Toast.LENGTH_SHORT).show();
            return;
        }
    } catch (Exception ignore) {}

    // fallback：简单文本
    StringBuilder sb = new StringBuilder();
    sb.append("物流单\n");
    sb.append("日期：").append(form.getDate() == null ? "" : form.getDate()).append("\n");
    sb.append("合计件数：").append(form.getTotalPieces()).append("\n");
    sb.append("合计方数：").append(form.getTotalCbm()).append("\n");
    if (sizes != null) {
        sb.append("尺寸明细：\n");
        for (LogisticsSize s : sizes) {
            sb.append(String.format(java.util.Locale.getDefault(),
                    "%.0f×%.0f×%.0f  %d件  %.3fm³",
                    s.getLen(), s.getWid(), s.getHei(), s.getPieces(), s.getCbm())).append("\n");
        }
    }
    sb.append("备注：").append(form.getRemark() == null ? "" : form.getRemark()).append("\n");
    PrinterManager.printDoc(this, sb.toString());
    Toast.makeText(this, "物流单已发送到打印机", Toast.LENGTH_SHORT).show();
}

}
