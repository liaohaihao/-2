package com.suzai.suzaiflowersystem;

public class ProductSummary {
    private String productName;
    private int pieces;

    public ProductSummary(String productName, int pieces) {
        this.productName = productName;
        this.pieces = pieces;
    }

    public String getProductName() {
        return productName;
    }

    public int getPieces() {
        return pieces;
    }
}
