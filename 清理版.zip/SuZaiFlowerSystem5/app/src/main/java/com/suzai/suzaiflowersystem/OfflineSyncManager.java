package com.suzai.suzaiflowersystem;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Handler;
import android.os.Looper;

/**
 * 离线同步管理器
 *
 * 目标：
 * 1) 不修改现有 SupabaseSyncManager 上传逻辑
 * 2) 只在“网络恢复”时自动触发一次 schedulePush()
 * 3) 兼容旧调用：保留 trySync(Context)
 * 4) 避免频繁网络抖动导致重复触发
 */
public class OfflineSyncManager {

    private static final long DEBOUNCE_MS = 6000L;
    private static volatile long lastAutoSyncAt = 0L;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private OfflineSyncManager() {}

    public static boolean isNetworkAvailable(Context ctx) {
        try {
            ConnectivityManager cm =
                    (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;

            Network network = cm.getActiveNetwork();
            if (network == null) return false;

            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            return caps != null
                    && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 兼容旧版 NetworkStateReceiver 的调用。
     */
    public static void trySync(Context ctx) {
        onNetworkRestored(ctx);
    }

    /**
     * 网络恢复时调用：
     * - 仅触发现有 schedulePush()
     * - 不改你原来的上传链路
     */
    public static void onNetworkRestored(Context ctx) {
        if (ctx == null) return;

        Context appCtx = ctx.getApplicationContext();
        if (!isNetworkAvailable(appCtx)) {
            try {
                SyncLogStore.append(appCtx, "D", "OfflineSync", "network unavailable, skip auto sync");
            } catch (Exception ignored) {}
            return;
        }

        long now = System.currentTimeMillis();
        if (now - lastAutoSyncAt < DEBOUNCE_MS) {
            try {
                SyncLogStore.append(appCtx, "D", "OfflineSync", "debounced auto sync");
            } catch (Exception ignored) {}
            return;
        }
        lastAutoSyncAt = now;

        try {
            SyncLogStore.append(appCtx, "D", "OfflineSync", "network restored, schedule push");
        } catch (Exception ignored) {}

        MAIN.post(() -> {
            try {
                SupabaseSyncManager.schedulePush(appCtx);
            } catch (Exception e) {
                try {
                    SyncLogStore.append(appCtx, "E", "OfflineSync",
                            "auto sync error: " + e.getMessage());
                } catch (Exception ignored) {}
            }
        });
    }

    /**
     * APP 启动/回到前台时也可顺手检查一次网络，
     * 防止系统没有派发网络变化事件。
     */
    public static void trySyncWhenForeground(Context ctx) {
        if (ctx == null) return;
        if (!isNetworkAvailable(ctx.getApplicationContext())) return;
        onNetworkRestored(ctx.getApplicationContext());
    }
}
