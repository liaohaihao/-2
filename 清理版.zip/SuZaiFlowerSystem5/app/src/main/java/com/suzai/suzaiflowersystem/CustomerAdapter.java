package com.suzai.suzaiflowersystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CustomerAdapter extends RecyclerView.Adapter<CustomerAdapter.CustomerViewHolder> {

    public interface OnCustomerClickListener {
        void onCustomerClick(String customerName);
    }

    public interface OnCustomerDeleteListener {
        void onCustomerDelete(String customerName);
    }

    private List<String> customerList;
    private final OnCustomerClickListener clickListener;
    private final OnCustomerDeleteListener deleteListener;

    public CustomerAdapter(List<String> customerList,
                           OnCustomerClickListener clickListener,
                           OnCustomerDeleteListener deleteListener) {
        this.customerList = customerList;
        this.clickListener = clickListener;
        this.deleteListener = deleteListener;
    }

    @NonNull
    @Override
    public CustomerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_customer, parent, false);
        return new CustomerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomerViewHolder holder, int position) {
        String customer = customerList.get(position);
        holder.nameTextView.setText(customer);

        holder.itemView.setOnClickListener(v -> {
            if (clickListener != null) clickListener.onCustomerClick(customer);
        });

        if (holder.deleteButton != null) {
            holder.deleteButton.setOnClickListener(v -> {
                if (deleteListener != null) deleteListener.onCustomerDelete(customer);
            });
        }
    }

    @Override
    public int getItemCount() {
        return customerList == null ? 0 : customerList.size();
    }

    public void updateCustomerList(List<String> newCustomerList) {
        this.customerList = newCustomerList;
        notifyDataSetChanged();
    }

    static class CustomerViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView;
        ImageButton deleteButton;

        CustomerViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.nameTextView);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
