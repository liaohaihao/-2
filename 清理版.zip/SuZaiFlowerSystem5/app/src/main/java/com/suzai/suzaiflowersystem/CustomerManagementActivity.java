package com.suzai.suzaiflowersystem;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.app.AlertDialog;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CustomerManagementActivity extends BaseDrawerActivity {

    private RecyclerView recyclerView;
    private Button addCustomerButton;
    private Button importCustomersButton;
    private CustomerAdapter adapter;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("客户管理");
        setContentLayout(R.layout.activity_customer_management);

        initializeViews();
        databaseHelper = new DatabaseHelper(this);
        setupRecyclerView();
        setupAddCustomerButton();
    }

    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerView);
        addCustomerButton = findViewById(R.id.addCustomerButton);
        importCustomersButton = findViewById(R.id.importCustomersButton);
    }

    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        List<String> customerList = databaseHelper.getAllCustomerNames();
        adapter = new CustomerAdapter(
                customerList,
                this::showEditCustomerDialog,
                this::confirmDeleteCustomer
        );
        recyclerView.setAdapter(adapter);
    }

    private void showEditCustomerDialog(String oldName) {
        View view = getLayoutInflater().inflate(R.layout.dialog_edit_customer, null);
        EditText nameEdit = view.findViewById(R.id.editCustomerName);
        EditText contactEdit = view.findViewById(R.id.editCustomerContact);

        nameEdit.setText(oldName);
        contactEdit.setText(databaseHelper.getCustomerContactByName(oldName));
        nameEdit.setInputType(InputType.TYPE_CLASS_TEXT);
        contactEdit.setInputType(InputType.TYPE_CLASS_TEXT);

        new AlertDialog.Builder(this)
                .setTitle("修改客户")
                .setView(view)
                .setPositiveButton("保存", (d, w) -> {
                    String newName = nameEdit.getText().toString().trim();
                    String newContact = contactEdit.getText().toString().trim();
                    if (newName.isEmpty()) {
                        Toast.makeText(this, "客户名称不能为空", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    int rows = databaseHelper.updateCustomerByName(oldName, newName, newContact);
                    Toast.makeText(this, rows > 0 ? "已保存" : "保存失败", Toast.LENGTH_SHORT).show();
                    refreshCustomerList();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void confirmDeleteCustomer(String customerName) {
        if (customerName == null || customerName.trim().isEmpty()) return;
        new AlertDialog.Builder(this)
                .setTitle("删除客户")
                .setMessage("确认删除客户：" + customerName + " ？\n\n删除后会同步到云端。")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", (d, w) -> {
                    boolean ok = databaseHelper.deleteCustomerByName(customerName);
                    Toast.makeText(this, ok ? "客户已删除" : "删除失败", Toast.LENGTH_SHORT).show();
                    if (ok) refreshCustomerList();
                })
                .show();
    }

    private void setupAddCustomerButton() {
        addCustomerButton.setOnClickListener(v ->
                startActivity(new Intent(CustomerManagementActivity.this, AddCustomerActivity.class)));

        if (importCustomersButton != null) {
            importCustomersButton.setOnClickListener(v -> confirmAndImportCustomers());
        }
    }

    private void confirmAndImportCustomers() {
        new AlertDialog.Builder(this)
                .setTitle("一键导入客户")
                .setMessage("将内置的客户清单导入到本机数据库。\n\n重复的客户名称会自动跳过。")
                .setNegativeButton("取消", null)
                .setPositiveButton("开始导入", (d, w) -> {
                    int[] result = importCustomersFromAssets();
                    Toast.makeText(this,
                            "导入完成：新增 " + result[0] + " 个，跳过 " + result[1] + " 个",
                            Toast.LENGTH_LONG).show();
                    refreshCustomerList();
                })
                .show();
    }

    private int[] importCustomersFromAssets() {
        int inserted = 0;
        int skipped = 0;
        try {
            java.io.InputStream is = getAssets().open("customers_import_with_owner_uid.csv");
            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(is, java.nio.charset.StandardCharsets.UTF_8));
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first) {
                    line = stripBom(line);
                    first = false;
                    if (line.toLowerCase().contains("name")) continue;
                }
                line = line.trim();
                if (line.isEmpty()) continue;

                String[] parts;
                if (line.contains(";")) parts = line.split(";", -1);
                else if (line.contains(",")) parts = line.split(",", -1);
                else parts = line.split("\\t", -1);

                String name = "";
                if (parts.length >= 2) name = parts[1].trim();
                else if (parts.length == 1) name = parts[0].trim();
                if (name.isEmpty()) continue;

                long id = databaseHelper.addCustomer(name, "");
                if (id > 0) inserted++;
                else skipped++;
            }
            br.close();
        } catch (Exception e) {
            Toast.makeText(this, "导入失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        return new int[]{inserted, skipped};
    }

    private String stripBom(String s) {
        if (s == null) return "";
        return s.replace("\uFEFF", "");
    }

    private void refreshCustomerList() {
        List<String> customerList = databaseHelper.getAllCustomerNames();
        if (adapter != null) {
            adapter.updateCustomerList(customerList);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshCustomerList();
    }
}
