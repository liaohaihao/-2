
package com.suzai.suzaiflowersystem;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * 监听网络恢复
 * 恢复网络时自动触发同步
 */
public class NetworkStateReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        if (intent == null) return;

        try {
            SyncLogStore.append(context,"D","NetworkReceiver","network change detected");
        } catch (Exception ignored) {}

        OfflineSyncManager.trySync(context);
    }
}
