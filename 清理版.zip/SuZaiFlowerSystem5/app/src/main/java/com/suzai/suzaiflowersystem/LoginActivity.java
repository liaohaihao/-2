package com.suzai.suzaiflowersystem;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import java.util.concurrent.TimeUnit;

public class LoginActivity extends AppCompatActivity {

    // ✅ 写死 Supabase 配置
    private static final String FIXED_BASE_URL = "https://ohvgzpwaqecjwnbdujkq.supabase.co";
    private static final String FIXED_ANON_KEY = "sb_publishable_yjywKgVmOM05bNsXqDlrgQ_zLJO_Hb_";

    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    private EditText etBaseUrl;
    private EditText etEmail;
    private EditText etPassword;
    private Button btnLogin;
    private CheckBox cbRemember;

    // UX-only widgets (do NOT change auth/sync logic)
    private ProgressBar loginProgress;
    private TextView tvLoginStatus;

    // ✅ 设置超时，避免“点了登录一直卡住”
    private final OkHttpClient http = new OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .writeTimeout(12, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .callTimeout(25, TimeUnit.SECONDS)
            .build();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ✅ 存配置给其他模块（baseUrl/anonKey 固定）
        saveSupabaseCfg(this, FIXED_BASE_URL, FIXED_ANON_KEY);

        // ✅ 已登录：直接进入首页（无需每次输入密码）
        // 只有用户在“退出账号”后（AuthManager.clear）才会回到登录页。
        if (AuthManager.isLoggedIn(this)) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_login);

        etBaseUrl = findViewById(R.id.etBaseUrl);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);

        // UX-only widgets (may not exist in some older layouts)
        int pbId = getResources().getIdentifier("loginProgress", "id", getPackageName());
        if (pbId != 0) loginProgress = findViewById(pbId);
        int stId = getResources().getIdentifier("tvLoginStatus", "id", getPackageName());
        if (stId != 0) tvLoginStatus = findViewById(stId);
        if (loginProgress != null) loginProgress.setVisibility(View.GONE);
        if (tvLoginStatus != null) tvLoginStatus.setText("");

        int cbId = getResources().getIdentifier("cbRemember", "id", getPackageName());
        if (cbId != 0) cbRemember = findViewById(cbId);

        // ✅ baseUrl 写死 + 禁止编辑
        etBaseUrl.setText(FIXED_BASE_URL);
        etBaseUrl.setEnabled(false);

        // ✅ 读取“记住账号”
        loadRememberedEmail();

        btnLogin.setOnClickListener(v -> doLogin());
    }

    private void setUiLoggingIn(String statusText) {
        btnLogin.setEnabled(false);
        btnLogin.setText("正在登录…");
        if (loginProgress != null) loginProgress.setVisibility(View.VISIBLE);
        if (tvLoginStatus != null) tvLoginStatus.setText(statusText == null ? "" : statusText);
    }

    private void setUiLoggedInSyncing() {
        btnLogin.setEnabled(false);
        btnLogin.setText("登录成功，正在同步…");
        if (loginProgress != null) loginProgress.setVisibility(View.VISIBLE);
        if (tvLoginStatus != null) tvLoginStatus.setText("登录成功，正在同步数据…");
    }

    private void restoreUiIdle(String statusText) {
        btnLogin.setEnabled(true);
        btnLogin.setText("登录");
        if (loginProgress != null) loginProgress.setVisibility(View.GONE);
        if (tvLoginStatus != null) tvLoginStatus.setText(statusText == null ? "" : statusText);
    }

    private static boolean looksLikeInvalidCredentials(String raw) {
        if (raw == null) return false;
        String s = raw.toLowerCase();
        return s.contains("invalid") || s.contains("credentials") || s.contains("invalid login") || s.contains("invalid_grant");
    }

    private static void saveSupabaseCfg(Context ctx, String baseUrl, String anonKey) {
        SharedPreferences sp = ctx.getSharedPreferences("supabase_cfg", MODE_PRIVATE);
        sp.edit()
                .putString("supabase_url", baseUrl)
                .putString("supabase_anon_key", anonKey)
                .putString("base_url", baseUrl)
                .putString("anon_key", anonKey)
                .putString("baseUrl", baseUrl)
                .putString("anonKey", anonKey)
                .apply();
    }

    private void loadRememberedEmail() {
        SharedPreferences sp = getSharedPreferences("login_prefs", MODE_PRIVATE);
        boolean remember = sp.getBoolean("remember", false);
        String email = sp.getString("email", "");
        if (remember && !TextUtils.isEmpty(email)) etEmail.setText(email);
        if (cbRemember != null) cbRemember.setChecked(remember);
    }

    private void saveRememberedEmail(String email) {
        boolean remember = cbRemember != null && cbRemember.isChecked();
        SharedPreferences sp = getSharedPreferences("login_prefs", MODE_PRIVATE);
        sp.edit()
                .putBoolean("remember", remember)
                .putString("email", remember ? email : "")
                .apply();
    }

    private static String jsonEscape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private void doLogin() {
        final String email = etEmail.getText().toString().trim();
        final String password = etPassword.getText().toString().trim();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "请输入账号和密码", Toast.LENGTH_SHORT).show();
            return;
        }

        // UX: show deterministic state to user
        setLoginUiState(true, "正在验证账号…", "正在登录…");

        final String url = FIXED_BASE_URL + "/auth/v1/token?grant_type=password";
        final String json = "{\"email\":\"" + jsonEscape(email) + "\",\"password\":\"" + jsonEscape(password) + "\"}";
        RequestBody body = RequestBody.create(JSON, json);

        Request req = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("apikey", FIXED_ANON_KEY)
                .addHeader("Authorization", "Bearer " + FIXED_ANON_KEY)
                .addHeader("Content-Type", "application/json")
                .addHeader("Accept", "application/json")
                .build();

        http.newCall(req).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        setLoginUiState(false, "网络异常，请检查网络", "登录");
                        Toast.makeText(LoginActivity.this, "网络异常，请检查网络", Toast.LENGTH_LONG).show();
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String raw = response.body() != null ? response.body().string() : "";

                if (!response.isSuccessful()) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            String msg = "登录失败";
                            String lower = raw != null ? raw.toLowerCase() : "";
                            if (lower.contains("invalid login") || lower.contains("invalid") || lower.contains("credentials")) {
                                msg = "账号或密码错误";
                            } else if (lower.contains("timeout") || lower.contains("timed out") || lower.contains("unable to resolve") || lower.contains("failed to connect")) {
                                msg = "网络异常，请检查网络";
                            }
                            setLoginUiState(false, msg, "登录");
                            Toast.makeText(LoginActivity.this, msg, Toast.LENGTH_LONG).show();
                        }
                    });
                    return;
                }

                try {
                    org.json.JSONObject obj = new org.json.JSONObject(raw);
                    String accessToken = obj.optString("access_token", "");
                    String refreshToken = obj.optString("refresh_token", "");
                    org.json.JSONObject user = obj.optJSONObject("user");
                    String userId = user != null ? user.optString("id", "") : "";
                    String userEmail = user != null ? user.optString("email", email) : email;

                    // ✅ 关键兜底：有些情况下会返回 200 但没有 access_token（或字段名异常）
                    // 这种情况会导致“看起来登录了但马上又回到登录页”。
                    if (TextUtils.isEmpty(accessToken)) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                setLoginUiState(false, "登录失败：未获取到凭证", "登录");
                                Toast.makeText(LoginActivity.this, "登录失败：未获取到 access_token", Toast.LENGTH_LONG).show();
                            }
                        });
                        return;
                    }

                    saveRememberedEmail(email);

                    AuthManager.saveSession(LoginActivity.this, accessToken, "", userId, userEmail);
                    AuthManager.saveTokensToSupabaseCfg(LoginActivity.this, accessToken, refreshToken);

                    getSharedPreferences("auth_prefs", MODE_PRIVATE).edit()
                            .putString("auth_token", accessToken)
                            .putString("refresh_token", refreshToken)
                            .apply();

                    // ✅ 登录成功：先进入主界面（不阻塞），再在后台拉取云端恢复本地。
                    // 这样可显著减少“登录很久才进去”的体验问题。
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // UX: let user know what's happening. Do not block entering MainActivity.
                            setLoginUiState(true, "登录成功，正在同步数据…", "登录成功");
                            startActivity(new Intent(LoginActivity.this, MainActivity.class));
                            finish();
                        }
                    });

                    // 首次登录/本地空库时，后台执行一次云端恢复；其余情况只做轻量 push 调度。
                    try {
                        if (SupabaseSyncManager.shouldBootstrapAfterLogin(getApplicationContext())) {
                            SupabaseSyncManager.pullThenRestoreLocal(getApplicationContext(), new SupabaseSyncManager.SyncCallback() {
                                @Override public void onDone(boolean ok, String msg) { }
                            });
                        } else {
                            SupabaseSyncManager.schedulePush(getApplicationContext());
                        }
                    } catch (Exception ignored) {}

                } catch (Exception ex) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            setLoginUiState(false, "登录失败：返回解析异常", "登录");
                            Toast.makeText(LoginActivity.this, "解析登录结果失败：" + ex.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        });
    }

    private void setLoginUiState(boolean busy, String statusText, String buttonText) {
        try {
            if (btnLogin != null) {
                btnLogin.setEnabled(!busy);
                if (!TextUtils.isEmpty(buttonText)) btnLogin.setText(buttonText);
            }
            if (loginProgress != null) {
                loginProgress.setVisibility(busy ? View.VISIBLE : View.GONE);
            }
            if (tvLoginStatus != null) {
                tvLoginStatus.setText(statusText == null ? "" : statusText);
            }
        } catch (Exception ignored) {
        }
    }
}
