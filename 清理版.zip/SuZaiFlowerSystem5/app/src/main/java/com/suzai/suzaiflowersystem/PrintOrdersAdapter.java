package com.suzai.suzaiflowersystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * 打印管理页列表（仅展示今日待打印的合并结果）。
 */
public class PrintOrdersAdapter extends RecyclerView.Adapter<PrintOrdersAdapter.VH> {

    public static class Row {
        public final String customer;
        public final String product;
        public final int pieces;
        public final String remark;
        public final String location;

        public Row(String customer, String product, int pieces, String remark, String location) {
            this.customer = customer;
            this.product = product;
            this.pieces = pieces;
            this.remark = remark;
            this.location = location;
        }
    }

    private final List<Row> rows;

    public PrintOrdersAdapter(List<Row> rows) {
        this.rows = rows;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_print_order, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Row r = rows.get(position);
        h.tv1.setText((r.customer == null ? "" : r.customer) + "  |  " + (r.location == null ? "" : r.location));
        h.tv2.setText((r.product == null ? "" : r.product) + "  —  " + r.pieces + "件");
        if (r.remark != null && !r.remark.trim().isEmpty()) {
            h.tv3.setVisibility(View.VISIBLE);
            h.tv3.setText("备注：" + r.remark);
        } else {
            h.tv3.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return rows == null ? 0 : rows.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tv1, tv2, tv3;
        VH(@NonNull View itemView) {
            super(itemView);
            tv1 = itemView.findViewById(R.id.poLine1);
            tv2 = itemView.findViewById(R.id.poLine2);
            tv3 = itemView.findViewById(R.id.poLine3);
        }
    }
}
