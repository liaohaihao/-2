package com.suzai.suzaiflowersystem;

public class LogisticsForm {

    private long id;
    private String date;
    private String location;
    private int totalPieces;
    private double totalCbm;
    private String remark;

    public LogisticsForm() {
    }

    public LogisticsForm(long id, String date, String location, int totalPieces, double totalCbm, String remark) {
        this.id = id;
        this.date = date;
        this.location = location;
        this.totalPieces = totalPieces;
        this.totalCbm = totalCbm;
        this.remark = remark;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getTotalPieces() {
        return totalPieces;
    }

    public void setTotalPieces(int totalPieces) {
        this.totalPieces = totalPieces;
    }

    public double getTotalCbm() {
        return totalCbm;
    }

    public void setTotalCbm(double totalCbm) {
        this.totalCbm = totalCbm;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
