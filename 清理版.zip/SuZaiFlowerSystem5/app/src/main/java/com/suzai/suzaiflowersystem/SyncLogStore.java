package com.suzai.suzaiflowersystem;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;

/**
 * A tiny file-based log buffer used to show "latest sync log" inside the app.
 *
 * 改进：
 * 1) 保留最近 5000 行，避免日志无限增长
 * 2) 同时保留 MAX_BYTES 限制，双保险
 * 3) 对外接口保持不变，低风险可直接覆盖
 *
 * NOTE: Keep this minimal and safe. If anything fails, we silently ignore.
 */
public final class SyncLogStore {

    private static final String FILE_NAME = "sync_log.txt";
    private static final long MAX_BYTES = 512 * 1024; // 512KB
    private static final int MAX_LINES = 5000;

    private SyncLogStore() {}

    private static File file(Context ctx) {
        return new File(ctx.getFilesDir(), FILE_NAME);
    }

    /** Returns the internal sync log file. Useful for exporting diagnostics. */
    public static File getLogFile(Context ctx) {
        if (ctx == null) return null;
        return file(ctx);
    }

    public static void append(Context ctx, String level, String tag, String msg) {
        if (ctx == null) return;
        try {
            String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
                    .format(new Date());
            String safeLevel = level == null ? "D" : level;
            String safeTag = tag == null ? "SyncLog" : tag;
            String safeMsg = msg == null ? "" : msg.replace('\r', ' ').replace('\n', ' ');
            String line = ts + " " + safeLevel + "/" + safeTag + ": " + safeMsg + "\n";

            File f = file(ctx);

            // 先做裁剪，再追加，避免文件无限变大
            if (f.exists() && (f.length() > MAX_BYTES || countLinesFast(ctx, f) > MAX_LINES)) {
                trimToRecentLines(ctx, f, MAX_LINES);
            }

            FileOutputStream fos = new FileOutputStream(f, true);
            fos.write(line.getBytes(StandardCharsets.UTF_8));
            fos.close();

            // 追加后再检查一次，防止单行过长把文件顶爆
            if (f.exists() && (f.length() > MAX_BYTES || countLinesFast(ctx, f) > MAX_LINES)) {
                trimToRecentLines(ctx, f, MAX_LINES);
            }
        } catch (Exception ignored) {
        }
    }

    /** Read the whole file (may be large, but capped by MAX_BYTES). */
    public static String readAll(Context ctx) {
        if (ctx == null) return "";
        try {
            File f = file(ctx);
            if (!f.exists()) return "";
            StringBuilder sb = new StringBuilder();
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8));
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append('\n');
            }
            br.close();
            return sb.toString();
        } catch (Exception ignored) {
            return "";
        }
    }

    /** Read last N bytes from file (best-effort). */
    public static String readTail(Context ctx, int bytes) {
        if (ctx == null) return "";
        try {
            File f = file(ctx);
            if (!f.exists()) return "";
            long len = f.length();
            long start = Math.max(0, len - Math.max(0, bytes));
            FileInputStream fis = new FileInputStream(f);
            if (start > 0) {
                //noinspection ResultOfMethodCallIgnored
                fis.skip(start);
            }
            byte[] buf = new byte[(int) (len - start)];
            int read = fis.read(buf);
            fis.close();
            if (read <= 0) return "";
            return new String(buf, 0, read, StandardCharsets.UTF_8);
        } catch (Exception ignored) {
            return "";
        }
    }

    public static void clear(Context ctx) {
        if (ctx == null) return;
        try {
            File f = file(ctx);
            if (f.exists()) {
                //noinspection ResultOfMethodCallIgnored
                f.delete();
            }
        } catch (Exception ignored) {
        }
    }

    /** 快速统计行数，失败则返回 0（由调用方继续容错） */
    private static int countLinesFast(Context ctx, File f) {
        try {
            if (f == null || !f.exists()) return 0;
            int count = 0;
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8));
            while (br.readLine() != null) count++;
            br.close();
            return count;
        } catch (Exception ignored) {
            return 0;
        }
    }

    /** 裁剪为最近 N 行；若仍超过 MAX_BYTES，再保留最后半段字节 */
    private static void trimToRecentLines(Context ctx, File f, int maxLines) {
        try {
            if (f == null || !f.exists()) return;

            ArrayDeque<String> deque = new ArrayDeque<>(Math.max(16, maxLines));
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8));
            String line;
            while ((line = br.readLine()) != null) {
                deque.addLast(line);
                while (deque.size() > maxLines) {
                    deque.removeFirst();
                }
            }
            br.close();

            StringBuilder sb = new StringBuilder();
            for (String s : deque) {
                sb.append(s).append('\n');
            }

            String content = sb.toString();

            // 若按行裁剪后仍太大，再按字节保留最后半段
            byte[] all = content.getBytes(StandardCharsets.UTF_8);
            if (all.length > MAX_BYTES) {
                int keep = (int) (MAX_BYTES / 2);
                int start = Math.max(0, all.length - keep);
                content = new String(all, start, all.length - start, StandardCharsets.UTF_8);
            }

            FileOutputStream fos = new FileOutputStream(f, false);
            fos.write(content.getBytes(StandardCharsets.UTF_8));
            fos.close();
        } catch (Exception ignored) {
        }
    }
}
