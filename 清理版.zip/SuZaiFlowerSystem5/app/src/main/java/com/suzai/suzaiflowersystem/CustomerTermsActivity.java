package com.suzai.suzaiflowersystem;

import android.app.AlertDialog;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Step3：客户账期
 * - 每个客户设置：账期天数、信用额度（可选）
 * - 导出 Excel：客户账期清单
 */
public class CustomerTermsActivity extends BaseDrawerActivity {

    // 月结设置：本月货款下月结清（不按“天数”滚动）
    // 为避免改动数据库结构，这里用 SharedPreferences 持久化：key=settle_mode_<customer>
    private static final String PREFS = "finance_terms_prefs";
    private static final String KEY_PREFIX = "settle_mode_"; // value: "monthly" or "days"

    private DatabaseHelper db;
    private CustomerTermsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("客户账期");
        setContentLayout(R.layout.activity_customer_terms);

        db = new DatabaseHelper(this);

        Button btnExport = findViewById(R.id.btn_export);
        Button btnRefresh = findViewById(R.id.btn_refresh);

        RecyclerView rv = findViewById(R.id.recycler_terms);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CustomerTermsAdapter(p -> showEditDialog(p.customerName, p.creditDays, p.creditLimit));
        rv.setAdapter(adapter);

        btnRefresh.setOnClickListener(v -> refresh());
        btnExport.setOnClickListener(v -> exportExcel());

        refresh();
    }

    private void refresh() {
        List<CustomerFinanceProfile> list = db.getAllCustomerFinanceProfiles();
        adapter.setData(list);
    }

    private void showEditDialog(String customer, int days, double limit) {
        if (TextUtils.isEmpty(customer)) return;

        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (getResources().getDisplayMetrics().density * 12);
        wrap.setPadding(pad, pad, pad, pad);

        final EditText etDays = new EditText(this);
        etDays.setHint("账期天数（仅当选择‘按天数’时生效）");
        etDays.setInputType(InputType.TYPE_CLASS_NUMBER);
        etDays.setText(String.valueOf(days));
        wrap.addView(etDays);

        // 月结/按天数 选择
        final CheckBox cbMonthly = new CheckBox(this);
        cbMonthly.setText("月结（本月货款下月结清）");
        boolean isMonthly = isMonthlyMode(customer);
        cbMonthly.setChecked(isMonthly);
        wrap.addView(cbMonthly);

        // 初始状态
        etDays.setEnabled(!isMonthly);
        cbMonthly.setOnCheckedChangeListener((buttonView, checked) -> etDays.setEnabled(!checked));

        final EditText etLimit = new EditText(this);
        etLimit.setHint("信用额度（可选）");
        etLimit.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        etLimit.setText(String.format(Locale.getDefault(), "%.2f", limit));
        wrap.addView(etLimit);

        new AlertDialog.Builder(this)
                .setTitle("设置账期：" + customer)
                .setView(wrap)
                .setPositiveButton("保存", (d, w) -> {
                    try {
                        int nd = parseIntSafe(etDays.getText().toString());
                        double nl = parseDoubleSafe(etLimit.getText().toString());
                        db.upsertCustomerFinanceProfile(customer, nd, nl);

                        // 保存结算模式
                        saveMonthlyMode(customer, cbMonthly.isChecked());

                        refresh();
                        Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(this, "保存失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void exportExcel() {
        try {
            List<CustomerFinanceProfile> list = db.getAllCustomerFinanceProfiles();
            String[] headers = new String[]{"客户", "结算方式", "账期(天)", "额度"};
            List<List<String>> rows = new ArrayList<>();
            if (list != null) {
                for (CustomerFinanceProfile p : list) {
                    List<String> r = new ArrayList<>();
                    r.add(nvl(p.customerName));
                    r.add(isMonthlyMode(p.customerName) ? "月结" : "按天数");
                    r.add(String.valueOf(p.creditDays));
                    r.add(String.format(Locale.getDefault(), "%.2f", p.creditLimit));
                    rows.add(r);
                }
            }
            String xml = SpreadsheetXml.buildWorkbookSingle("客户账期", "", headers, rows);
            String month = new SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(new Date());
            String fileName = "客户账期_" + month + ".xls";
            Uri uri = ExportUtils.saveTextToDownloads(this, "SuZaiExports/Finance/" + month, fileName,
                    "application/vnd.ms-excel", xml);
            Toast.makeText(this, uri == null ? "导出失败" : "已导出：" + fileName, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "导出失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private static int parseIntSafe(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; }
    }
    private static double parseDoubleSafe(String s) {
        try { return Double.parseDouble(s.trim()); } catch (Exception e) { return 0; }
    }
    private static String nvl(String s) { return s == null ? "" : s; }

    private boolean isMonthlyMode(String customer) {
        if (TextUtils.isEmpty(customer)) return true; // 默认月结
        String v = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_PREFIX + customer, "monthly");
        return "monthly".equalsIgnoreCase(v);
    }

    private void saveMonthlyMode(String customer, boolean monthly) {
        if (TextUtils.isEmpty(customer)) return;
        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit()
                .putString(KEY_PREFIX + customer, monthly ? "monthly" : "days")
                .apply();
    }
}
