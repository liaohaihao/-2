package com.suzai.suzaiflowersystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ReceivableAdapter extends RecyclerView.Adapter<ReceivableAdapter.VH> {

    public interface OnItemClickListener {
        void onClick(ReceivableRow row);
    }

    private final List<ReceivableRow> data = new ArrayList<>();
    private final OnItemClickListener listener;

    public ReceivableAdapter(OnItemClickListener listener) {
        this.listener = listener;
    }

    public void setData(List<ReceivableRow> rows) {
        data.clear();
        if (rows != null) data.addAll(rows);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_receivable, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        final ReceivableRow r = data.get(position);
        h.tvCustomer.setText(r.customerName == null ? "" : r.customerName);
        h.tvBalance.setText(String.format("应收：%.2f", r.balance));
        h.tvTerms.setText(String.format("账期：%d天", r.creditDays));
        h.tvDetail.setText(String.format("出货累计：%.2f  收款累计：%.2f", r.totalShip, r.totalPaid));

        h.itemView.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (listener != null) listener.onClick(r);
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvCustomer, tvBalance, tvTerms, tvDetail;
        VH(@NonNull View itemView) {
            super(itemView);
            tvCustomer = itemView.findViewById(R.id.tv_customer);
            tvBalance = itemView.findViewById(R.id.tv_balance);
            tvTerms = itemView.findViewById(R.id.tv_terms);
            tvDetail = itemView.findViewById(R.id.tv_detail);
        }
    }
}
