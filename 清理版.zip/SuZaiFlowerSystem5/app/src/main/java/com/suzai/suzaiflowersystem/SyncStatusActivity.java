package com.suzai.suzaiflowersystem;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import java.util.LinkedHashSet;
import java.util.Set;

public class SyncStatusActivity extends BaseDrawerActivity {

    private static final int REQ_EXPORT_FULL_BACKUP = 7101;
    private static final int REQ_IMPORT_FULL_BACKUP = 7102;

    private static final String RESTORE_SCOPE_TEXT =
            "恢复范围说明\n"
                    + "• 客户、产品、打印模板：恢复当前公司/组织下可见的云端数据\n"
                    + "• 库存：恢复当前账号可见的云端库存数据\n"
                    + "• 订单、订单明细、物流单、物流尺寸：恢复云端近2个自然月数据\n"
                    + "• 财务数据（应收/回款/核销）：恢复当前账号下的云端数据\n\n"
                    + "注意事项\n"
                    + "• 此操作用于换机、重装、首次初始化本机数据\n"
                    + "• 执行后会以云端数据恢复本机，不会删除云端数据\n"
                    + "• 如本机存在未上传的新数据，请先点击“上传本地变更”";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("账号/同步");
        setContentLayout(R.layout.activity_sync_status);

        TextView tv = findViewById(R.id.tvAccountInfo);
        if (tv != null) {
            tv.setText("当前账号：" + AuthManager.getEmail(this) + "\n公司ID：" + AuthManager.getTenantId(this));
        }

        TextView tvRestoreScope = findViewById(R.id.tvRestoreScope);
        if (tvRestoreScope != null) tvRestoreScope.setText(RESTORE_SCOPE_TEXT);

        Button btnSync = findViewById(R.id.btnSyncNow);
        if (btnSync != null) {
            btnSync.setText("上传本地变更");
            btnSync.setOnClickListener(v -> {
                showLoading("正在上传同步…");
                SupabaseSyncManager.schedulePush(getApplicationContext());
                btnSync.postDelayed(() -> {
                    hideLoading();
                    toastOk("已发起上传同步");
                }, 800);
            });
        }

        Button btnRestore = findViewById(R.id.btnRestoreFromCloud);
        if (btnRestore != null) {
            btnRestore.setOnClickListener(v -> showRestoreScopeDialog());
        }

        Button btnExportFullBackup = findViewById(R.id.btnExportFullBackup);
        if (btnExportFullBackup != null) {
            btnExportFullBackup.setOnClickListener(v -> startCreateFullBackupDocument());
        }

        Button btnImportFullBackup = findViewById(R.id.btnImportFullBackup);
        if (btnImportFullBackup != null) {
            btnImportFullBackup.setOnClickListener(v -> confirmImportFullBackup());
        }

        Button btnLogout = findViewById(R.id.btnLogout);
        if (btnLogout != null) {
            btnLogout.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("退出登录")
                    .setMessage("确定退出当前账号？")
                    .setPositiveButton("退出", (d, w) -> {
                        AuthManager.clear(this);
                        toastOk("已退出");
                        try {
                            android.content.Intent it = new android.content.Intent(this, LoginActivity.class);
                            it.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP | android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(it);
                        } catch (Exception ignored) {}
                        finish();
                    })
                    .setNegativeButton("取消", null)
                    .show());
        }
    }

    private void showRestoreScopeDialog() {
        final String[] labels = new String[]{"客户", "产品", "打印模板", "库存", "订单/订单明细", "物流单/物流尺寸", "财务数据"};
        final String[] keys = new String[]{
                SupabaseSyncManager.SCOPE_CUSTOMERS,
                SupabaseSyncManager.SCOPE_PRODUCTS,
                SupabaseSyncManager.SCOPE_TEMPLATES,
                SupabaseSyncManager.SCOPE_INVENTORY,
                SupabaseSyncManager.SCOPE_ORDERS,
                SupabaseSyncManager.SCOPE_LOGISTICS,
                SupabaseSyncManager.SCOPE_FINANCE
        };
        final boolean[] checked = new boolean[]{true, true, true, true, true, true, true};

        new AlertDialog.Builder(this)
                .setTitle("选择恢复范围")
                .setMultiChoiceItems(labels, checked, (d, which, isChecked) -> checked[which] = isChecked)
                .setNegativeButton("取消", null)
                .setPositiveButton("下一步", (d, which) -> {
                    Set<String> scopes = new LinkedHashSet<>();
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < labels.length; i++) {
                        if (checked[i]) {
                            scopes.add(keys[i]);
                            if (sb.length() > 0) sb.append("、");
                            sb.append(labels[i]);
                        }
                    }
                    if (scopes.isEmpty()) {
                        toastErr("请至少选择一个恢复范围");
                        return;
                    }
                    new AlertDialog.Builder(this)
                            .setTitle("确认恢复范围")
                            .setMessage("本次将从云端恢复到本机：\n" + sb + "\n\n只影响本机，不删除云端数据。")
                            .setNegativeButton("取消", null)
                            .setPositiveButton("开始恢复", (d2, w2) -> {
                                showLoading("正在从云端恢复…");
                                SupabaseSyncManager.pullThenRestoreLocal(this, scopes, (ok, msg) -> runOnUiThread(() -> {
                                    hideLoading();
                                    if (ok) toastOk(msg); else toastErr(msg);
                                }));
                            })
                            .show();
                })
                .show();
    }


    private void startCreateFullBackupDocument() {
        try {
            Intent it = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            it.addCategory(Intent.CATEGORY_OPENABLE);
            it.setType("application/zip");
            it.putExtra(Intent.EXTRA_TITLE, BackupManager.buildDefaultBackupFileName());
            startActivityForResult(it, REQ_EXPORT_FULL_BACKUP);
        } catch (Exception e) {
            toastErr("无法打开导出位置：" + e.getMessage());
        }
    }

    private void confirmImportFullBackup() {
        new AlertDialog.Builder(this)
                .setTitle("一键恢复完整备份")
                .setMessage("恢复会把当前本机数据替换为备份包中的数据。\n\n恢复完成后，APP 会自动重启，数据状态将与备份时一致。")
                .setNegativeButton("取消", null)
                .setPositiveButton("选择备份包", (d, w) -> {
                    try {
                        Intent it = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        it.addCategory(Intent.CATEGORY_OPENABLE);
                        it.setType("application/zip");
                        startActivityForResult(it, REQ_IMPORT_FULL_BACKUP);
                    } catch (Exception e) {
                        toastErr("无法打开备份文件：" + e.getMessage());
                    }
                })
                .show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;

        if (requestCode == REQ_EXPORT_FULL_BACKUP) {
            doExportFullBackup(uri);
        } else if (requestCode == REQ_IMPORT_FULL_BACKUP) {
            doImportFullBackup(uri);
        }
    }

    private void doExportFullBackup(Uri uri) {
        showLoading("正在导出完整备份…");
        new Thread(() -> {
            try {
                BackupManager.exportFullBackup(getApplicationContext(), uri);
                runOnUiThread(() -> {
                    hideLoading();
                    toastOk("完整备份导出成功");
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    hideLoading();
                    toastErr("导出失败：" + e.getMessage());
                });
            }
        }).start();
    }

    private void doImportFullBackup(Uri uri) {
        showLoading("正在恢复完整备份…");
        new Thread(() -> {
            try {
                BackupManager.restoreFullBackup(getApplicationContext(), uri);
                runOnUiThread(() -> {
                    hideLoading();
                    new AlertDialog.Builder(this)
                            .setTitle("恢复完成")
                            .setMessage("完整备份已恢复，本机数据已回到备份时状态。\n\nAPP 将自动重启。")
                            .setCancelable(false)
                            .setPositiveButton("确定", (d, w) -> {
                                BackupManager.scheduleAppRestart(getApplicationContext());
                                finishAffinity();
                                System.exit(0);
                            })
                            .show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    hideLoading();
                    toastErr("恢复失败：" + e.getMessage());
                });
            }
        }).start();
    }

}
