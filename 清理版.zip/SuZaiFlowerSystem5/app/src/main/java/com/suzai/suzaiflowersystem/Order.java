package com.suzai.suzaiflowersystem;

public class Order {
    private int id;
    private String date;
    private String customerName;
    private String productName;
    private int pieces; // 件数（箱数）
    private int quantity;
    private double price;
    private String location;
    private String remark; // 备注
    private String createdAt; // 创建时间（用于稳定排序）

    public Order() {
    }

    public Order(String date, String customerName, String productName, int pieces, int quantity, double price, String location) {
        this.date = date;
        this.customerName = customerName;
        this.productName = productName;
        this.pieces = pieces;
        this.quantity = quantity;
        this.price = price;
        this.location = location;
    }

    /**
     * 新增：带备注的构造（用于新增订单页面填写备注）
     */
    public Order(String date, String customerName, String productName, int pieces, int quantity, double price, String location, String remark) {
        this(date, customerName, productName, pieces, quantity, price, location);
        this.remark = remark;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    
    public int getPieces() {
        return pieces;
    }

    public void setPieces(int pieces) {
        this.pieces = pieces;
    }

public double getTotalPrice() {
        return quantity * price;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}