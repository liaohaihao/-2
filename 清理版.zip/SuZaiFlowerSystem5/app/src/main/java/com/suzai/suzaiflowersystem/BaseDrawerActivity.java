package com.suzai.suzaiflowersystem;

import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

/**
 * 所有“功能页”统一抽屉（侧滑菜单）基类：
 * - 顶部汉堡按钮
 * - 左侧导航菜单
 * - 内容区由子类通过 setContentLayout(...) 注入
 *
 * 同时在此处做“统一操作反馈”：
 * - 统一 toast 文案风格
 * - 统一 Loading 提示（非阻塞业务逻辑）
 * - 统一接收同步广播（SupabaseSyncManager）
 */
public abstract class BaseDrawerActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    // SupabaseSyncManager will broadcast these so any foreground page can show a consistent toast.
    public static final String ACTION_SYNC_EVENT = "com.suzai.suzaiflowersystem.SYNC_EVENT";
    public static final String EXTRA_SYNC_OK = "ok";
    public static final String EXTRA_SYNC_MSG = "msg";
    // When true, UI should prompt user to re-login (token expired / refresh failed)
    public static final String EXTRA_SYNC_AUTH_EXPIRED = "sync_auth_expired";

    protected DrawerLayout drawerLayout;
    protected NavigationView navigationView;
    protected Toolbar toolbar;

    private AlertDialog authExpiredDialog;
    private long lastAuthExpiredAt = 0L;

    private Dialog loadingDialog;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private final BroadcastReceiver syncEventReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null || !ACTION_SYNC_EVENT.equals(intent.getAction())) return;
            boolean ok = intent.getBooleanExtra(EXTRA_SYNC_OK, true);
            String msg = intent.getStringExtra(EXTRA_SYNC_MSG);
            boolean authExpired = intent.getBooleanExtra(EXTRA_SYNC_AUTH_EXPIRED, false);

            if (msg == null || msg.trim().isEmpty()) msg = ok ? "同步完成" : "同步失败";

            // 401 / refresh failed: show a blocking dialog to guide user to re-login.
            if (authExpired) {
                final String finalMsg = msg;
                ui.post(() -> showAuthExpiredDialog(finalMsg));
                return;
            }

            // 移除同步提示Toast，保持静默同步
            // if (ok) toastOk(msg); else toastErr(msg);
        }
    };

    // ===== Unified toasts =====
    protected void toastInfo(String msg) { toast("ℹ️ " + safe(msg), Toast.LENGTH_SHORT); }
    protected void toastOk(String msg)   { toast("✅ " + safe(msg), Toast.LENGTH_SHORT); }
    protected void toastWarn(String msg) { toast("⚠️ " + safe(msg), Toast.LENGTH_SHORT); }
    protected void toastErr(String msg)  { toast("❌ " + safe(msg), Toast.LENGTH_LONG); }

    protected void toast(String msg, int len) {
        ui.post(() -> {
            try { Toast.makeText(BaseDrawerActivity.this, safe(msg), len).show(); } catch (Exception ignored) {}
        });
    }

    // ===== Unified loading =====
    protected void showLoading(String message) {
        ui.post(() -> {
            try {
                if (loadingDialog == null) {
                    View v = getLayoutInflater().inflate(R.layout.dialog_loading, null);
                    TextView tv = v.findViewById(R.id.loading_message);
                    tv.setText(message == null ? "处理中…" : message);
                    loadingDialog = new AlertDialog.Builder(this)
                            .setView(v)
                            .setCancelable(false)
                            .create();
                } else {
                    try {
                        TextView tv = loadingDialog.findViewById(R.id.loading_message);
                        if (tv != null) tv.setText(message == null ? "处理中…" : message);
                    } catch (Exception ignored) {}
                }
                if (!isFinishing() && !loadingDialog.isShowing()) loadingDialog.show();
            } catch (Exception ignored) {}
        });
    }

    protected void hideLoading() {
        ui.post(() -> {
            try {
                if (loadingDialog != null && loadingDialog.isShowing()) loadingDialog.dismiss();
            } catch (Exception ignored) {}
        });
    }

    /**
     * 401/refresh 失败统一弹窗（全APP只弹一次，避免多个页面重复弹窗）
     */
    private void showAuthExpiredDialog(String msg) {
        try {
            // 防止短时间重复弹窗（例如多个页面同时前台 or 同一页面连收多条广播）
            long now = System.currentTimeMillis();
            if (authExpiredDialog != null && authExpiredDialog.isShowing()) return;
            if (now - lastAuthExpiredAt < 8000) return; // 8秒内不重复弹
            lastAuthExpiredAt = now;

            String safeMsg = (msg == null || msg.trim().isEmpty())
                    ? "登录状态已失效，请重新登录。"
                    : msg;

            authExpiredDialog = new AlertDialog.Builder(this)
                    .setTitle("登录已过期")
                    .setMessage(safeMsg)
                    .setCancelable(false)
                    .setPositiveButton("重新登录", (dialog, which) -> {
                        try {
                            // 清除本地token
                            getSharedPreferences("supabase_cfg", MODE_PRIVATE)
                                    .edit()
                                    .remove("access_token")
                                    .remove("refresh_token")
                                    .apply();
                        } catch (Exception ignored) {}

                        try {
                            Intent intent = new Intent(BaseDrawerActivity.this, LoginActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        } catch (Exception ignored) {}
                    })
                    .setNegativeButton("取消", (dialog, which) -> {
                        try { dialog.dismiss(); } catch (Exception ignored) {}
                    })
                    .create();

            if (!isFinishing()) authExpiredDialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String safe(String s) { return s == null ? "" : s; }

    @Override
    protected void onStart() {
        super.onStart();
        // 前台监听同步事件（用于全局轻提示）
        try {
            IntentFilter filter = new IntentFilter(ACTION_SYNC_EVENT);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(syncEventReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                // 对于Android 13及以下版本，使用兼容的方式
                registerReceiver(syncEventReceiver, filter);
            }
        } catch (Exception ignored) {}
        // 前台监听剪贴板（检测到“客户+产品+件数”则弹窗询问是否自动新增订单）
        try { ClipboardOrderAssistant.get().attach(this); } catch (Exception ignored) {}
    }

    @Override
    protected void onStop() {
        // 取消监听，避免泄露
        try { ClipboardOrderAssistant.get().detach(); } catch (Exception ignored) {}
        try { unregisterReceiver(syncEventReceiver); } catch (Exception ignored) {}
        super.onStop();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 登录校验：未登录先去登录页（MVP）
        if (!AuthManager.isLoggedIn(this)) {
            startActivity(new Intent(this, LoginActivity.class));
        }
        setContentView(R.layout.activity_drawer_base);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close
        );
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);
    }

    /**
     * 子类在 super.onCreate(...) 之后调用，把自己的布局注入到抽屉内容区。
     */
    protected void setContentLayout(@LayoutRes int layoutResId) {
        FrameLayout contentFrame = findViewById(R.id.content_frame);
        contentFrame.removeAllViews();
        View child = getLayoutInflater().inflate(layoutResId, contentFrame, false);
        contentFrame.addView(child);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            startActivity(new Intent(this, MainActivity.class));
        } else if (id == R.id.nav_sales) {
            startActivity(new Intent(this, SalesManagementActivity.class));
        } else if (id == R.id.nav_reports) {
            startActivity(new Intent(this, ReportsActivity.class));
        } else if (id == R.id.nav_finance) {
            startActivity(new Intent(this, FinanceCenterActivity.class));
        } else if (id == R.id.nav_inventory) {
            startActivity(new Intent(this, InventoryManagementActivity.class));
        } else if (id == R.id.nav_customer) {
            startActivity(new Intent(this, CustomerManagementActivity.class));
        } else if (id == R.id.nav_product) {
            startActivity(new Intent(this, ProductManagementActivity.class));
        } else if (id == R.id.nav_worker) {
            startActivity(new Intent(this, WorkerAllocationActivity.class));
        } else if (id == R.id.nav_logistics) {
            startActivity(new Intent(this, LogisticsManagementActivity.class));
        } else if (id == R.id.nav_print) {
            startActivity(new Intent(this, PrintManagementActivity.class));
        } else if (id == R.id.nav_templates) {
            startActivity(new Intent(this, TemplateCenterActivity.class));
        } else if (id == R.id.nav_printer_settings) {
            startActivity(new Intent(this, PrinterSettingsActivity.class));
        } else if (id == R.id.nav_account) {
            startActivity(new Intent(this, SyncStatusActivity.class));
        }

        if (drawerLayout != null) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout != null && drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
