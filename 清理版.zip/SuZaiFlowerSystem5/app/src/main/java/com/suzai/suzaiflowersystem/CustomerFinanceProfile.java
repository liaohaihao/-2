package com.suzai.suzaiflowersystem;

public class CustomerFinanceProfile {
    public String customerName;
    public int creditDays;
    public double creditLimit;

    public CustomerFinanceProfile() {}

    public CustomerFinanceProfile(String customerName, int creditDays, double creditLimit) {
        this.customerName = customerName;
        this.creditDays = creditDays;
        this.creditLimit = creditLimit;
    }
}
