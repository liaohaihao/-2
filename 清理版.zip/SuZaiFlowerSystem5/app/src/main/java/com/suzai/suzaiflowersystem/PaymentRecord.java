package com.suzai.suzaiflowersystem;

public class PaymentRecord {
    public long id;
    public String customerName;
    public double amount;
    public String payDate; // yyyy-MM-dd
    public String method;
    public String remark;
}
