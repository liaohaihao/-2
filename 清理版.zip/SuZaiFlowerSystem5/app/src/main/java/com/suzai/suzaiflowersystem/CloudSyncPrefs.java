package com.suzai.suzaiflowersystem;

import android.content.Context;
import android.content.SharedPreferences;

public class CloudSyncPrefs {
    private static final String PREFS = "cloud_sync_prefs";
    private static final String KEY_MASTER_LAST_PULL = "master_last_pull";
    private static final String KEY_TPL_LAST_PULL = "tpl_last_pull";

    public static long getMasterLastPull(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_MASTER_LAST_PULL, 0L);
    }

    public static void setMasterLastPull(Context ctx, long v) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(KEY_MASTER_LAST_PULL, v).apply();
    }

    public static long getTplLastPull(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_TPL_LAST_PULL, 0L);
    }

    public static void setTplLastPull(Context ctx, long v) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(KEY_TPL_LAST_PULL, v).apply();
    }
}
