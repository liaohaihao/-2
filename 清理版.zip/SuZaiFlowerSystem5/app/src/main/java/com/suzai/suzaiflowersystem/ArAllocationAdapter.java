package com.suzai.suzaiflowersystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ArAllocationAdapter extends RecyclerView.Adapter<ArAllocationAdapter.VH> {

    public interface OnClick { void onItem(ArAllocationRow row); }

    private final List<ArAllocationRow> data = new ArrayList<>();
    private final OnClick onClick;

    public ArAllocationAdapter(OnClick onClick) {
        this.onClick = onClick;
    }

    public void setData(List<ArAllocationRow> list) {
        data.clear();
        if (list != null) data.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_ar_allocation, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        ArAllocationRow r = data.get(position);
        h.tvTitle.setText(String.format(Locale.getDefault(), "%s  核销：%.2f", nvl(r.siteName), r.amount));
        h.tvSub.setText("账单：" + shortId(r.invoiceCloudId) + "   收款：" + shortId(r.paymentCloudId) +
                ((r.note == null || r.note.trim().isEmpty()) ? "" : ("   备注：" + r.note)));
        h.itemView.setOnClickListener(v -> { if (onClick != null) onClick.onItem(r); });
    }

    @Override
    public int getItemCount() { return data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvTitle, tvSub;
        VH(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvSub = itemView.findViewById(R.id.tv_sub);
        }
    }

    private static String nvl(String s) { return s == null ? "" : s; }
    private static String shortId(String s) {
        if (s == null) return "";
        if (s.length() <= 8) return s;
        return s.substring(0, 8) + "...";
    }
}
