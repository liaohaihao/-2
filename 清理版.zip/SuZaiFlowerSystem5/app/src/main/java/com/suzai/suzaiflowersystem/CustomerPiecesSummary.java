package com.suzai.suzaiflowersystem;

public class CustomerPiecesSummary {
    private final String customerName;
    private final int totalPieces;

    public CustomerPiecesSummary(String customerName, int totalPieces) {
        this.customerName = customerName;
        this.totalPieces = totalPieces;
    }

    public String getCustomerName() {
        return customerName;
    }

    public int getTotalPieces() {
        return totalPieces;
    }
}
