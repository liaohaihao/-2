package com.suzai.suzaiflowersystem;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import java.nio.charset.StandardCharsets;

public class PrinterSettingsActivity extends BaseDrawerActivity {

    private Spinner labelModeSpinner, docModeSpinner;

    private EditText labelCloudUserEt, labelCloudUrlEt, labelCloudDeviceEt, labelCloudTokenEt;
    private EditText docCloudUserEt, docCloudUrlEt, docCloudDeviceEt, docCloudTokenEt;

    private Button labelTestBtn, docTestBtn, saveBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_printer_settings);

        bindViews();
        initSpinnerCloudOnly();
        loadToUi();

        labelTestBtn.setOnClickListener(v -> testPrintWithDialog(PrinterPrefs.Role.LABEL));
        docTestBtn.setOnClickListener(v -> testPrintWithDialog(PrinterPrefs.Role.DOC));

        saveBtn.setOnClickListener(v -> {
            saveFromUi();
            Toast.makeText(this, "已保存设置", Toast.LENGTH_SHORT).show();
        });
    }

    private void bindViews() {
        labelModeSpinner = findViewById(R.id.labelModeSpinner);
        docModeSpinner = findViewById(R.id.docModeSpinner);

        labelCloudUserEt = findViewById(R.id.labelCloudUserEt);
        labelCloudUrlEt = findViewById(R.id.labelCloudUrlEt);
        labelCloudDeviceEt = findViewById(R.id.labelCloudDeviceEt);
        labelCloudTokenEt = findViewById(R.id.labelCloudTokenEt);

        docCloudUserEt = findViewById(R.id.docCloudUserEt);
        docCloudUrlEt = findViewById(R.id.docCloudUrlEt);
        docCloudDeviceEt = findViewById(R.id.docCloudDeviceEt);
        docCloudTokenEt = findViewById(R.id.docCloudTokenEt);

        labelTestBtn = findViewById(R.id.labelTestBtn);
        docTestBtn = findViewById(R.id.docTestBtn);
        saveBtn = findViewById(R.id.savePrinterSettingsBtn);
    }

    /** 强制云打印 */
    private void initSpinnerCloudOnly() {
        String[] modes = {"蓝牙", "网络", "云打印"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, modes
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        labelModeSpinner.setAdapter(adapter);
        docModeSpinner.setAdapter(adapter);

        labelModeSpinner.setSelection(2);
        docModeSpinner.setSelection(2);

        labelModeSpinner.setEnabled(false);
        docModeSpinner.setEnabled(false);
    }

    private void loadToUi() {
        labelCloudUserEt.setText(PrinterPrefs.getCloudUser(this, PrinterPrefs.Role.LABEL));
        labelCloudUrlEt.setText(PrinterPrefs.getCloudUrl(this, PrinterPrefs.Role.LABEL));
        labelCloudDeviceEt.setText(PrinterPrefs.getCloudDevice(this, PrinterPrefs.Role.LABEL));
        labelCloudTokenEt.setText(PrinterPrefs.getCloudToken(this, PrinterPrefs.Role.LABEL));

        docCloudUserEt.setText(PrinterPrefs.getCloudUser(this, PrinterPrefs.Role.DOC));
        docCloudUrlEt.setText(PrinterPrefs.getCloudUrl(this, PrinterPrefs.Role.DOC));
        docCloudDeviceEt.setText(PrinterPrefs.getCloudDevice(this, PrinterPrefs.Role.DOC));
        docCloudTokenEt.setText(PrinterPrefs.getCloudToken(this, PrinterPrefs.Role.DOC));

        if (TextUtils.isEmpty(str(labelCloudUrlEt))) labelCloudUrlEt.setText("http://api.feieyun.cn/Api/Open/");
        if (TextUtils.isEmpty(str(docCloudUrlEt))) docCloudUrlEt.setText("http://api.feieyun.cn/Api/Open/");
    }

    private void saveFromUi() {
        PrinterPrefs.setMode(this, PrinterPrefs.Role.LABEL, PrinterPrefs.Mode.CLOUD);
        PrinterPrefs.setMode(this, PrinterPrefs.Role.DOC, PrinterPrefs.Mode.CLOUD);

        PrinterPrefs.setCloudUser(this, PrinterPrefs.Role.LABEL, str(labelCloudUserEt));
        PrinterPrefs.setCloudUser(this, PrinterPrefs.Role.DOC, str(docCloudUserEt));

        PrinterPrefs.setCloud(this, PrinterPrefs.Role.LABEL,
                str(labelCloudUrlEt),
                str(labelCloudDeviceEt),
                str(labelCloudTokenEt)
        );

        PrinterPrefs.setCloud(this, PrinterPrefs.Role.DOC,
                str(docCloudUrlEt),
                str(docCloudDeviceEt),
                str(docCloudTokenEt)
        );
    }

    private String str(EditText et) {
        return et == null ? "" : et.getText().toString().trim();
    }

    /** 异步测试打印 + 弹窗可复制 */
    private void testPrintWithDialog(PrinterPrefs.Role role) {
        saveFromUi();

        final String user = PrinterPrefs.getCloudUser(this, role);
        final String url = PrinterPrefs.getCloudUrl(this, role);
        final String sn = PrinterPrefs.getCloudDevice(this, role);
        final String token = PrinterPrefs.getCloudToken(this, role);

        if (TextUtils.isEmpty(user) || TextUtils.isEmpty(url) || TextUtils.isEmpty(sn) || TextUtils.isEmpty(token)) {
            String detail =
                    "请填写完整：\n" +
                            "USER / URL / SN / 密钥(UKEY)\n\n" +
                            "当前：\n" +
                            "USER=" + safe(user) + "\n" +
                            "URL=" + safe(url) + "\n" +
                            "SN=" + safe(sn) + "\n" +
                            "KEY=" + (TextUtils.isEmpty(token) ? "" : "********");
            showCopyDialog("配置不完整", detail);
            return;
        }

        // ✅ 生成“真正可用”的测试内容：
        // - LABEL：必须是飞鹅云的标签排版控制标签（<SIZE>、<TEXT>...），否则会 ret=1001
        // - DOC：纯文本即可
        final String content = (role == PrinterPrefs.Role.LABEL)
                ? PrinterManager.buildLabelFeie50x80(
                        "测试客户",
                        "标签测试(50x80)",
                        1,
                        "SN:" + sn,
                        1,
                        1,
                        "#TEST"
                )
                : "【测试单据】\nSN:" + sn + "\n苏再园艺管理\n\n（纸张：80mm热敏纸）\n";

        try { CloudPrinterClient.resetLast(); } catch (Throwable ignore) {}

        new Thread(() -> {
            try {
                // ✅ 后台线程执行，避免 NetworkOnMainThreadException
                PrinterManager.printRaw(PrinterSettingsActivity.this, role,
                        content.getBytes(StandardCharsets.UTF_8));

                String detail =
                        "结果：已发送（未抛异常）\n\n" +
                                "role=" + role + "\n" +
                                "SN=" + sn + "\n" +
                                "USER=" + user + "\n" +
                                "URL=" + url + "\n\n" +
                                "【飞鹅云返回】\n" +
                                "ret=" + safeInt(getLastRet()) + "\n" +
                                "msg=" + safe(getLastMsg()) + "\n" +
                                "data=" + safe(getLastData()) + "\n\n" +
                                "raw=\n" + safe(getLastRaw());

                runOnUiThread(() -> showCopyDialog("测试打印结果（可复制）", detail));

            } catch (Exception e) {
                String emsg = (e.getMessage() == null || e.getMessage().trim().isEmpty())
                        ? e.getClass().getSimpleName()
                        : e.getMessage();

                String detail =
                        "结果：失败（抛异常）\n\n" +
                                "role=" + role + "\n" +
                                "SN=" + sn + "\n" +
                                "USER=" + user + "\n" +
                                "URL=" + url + "\n\n" +
                                "异常=" + emsg + "\n\n" +
                                "【飞鹅云返回】\n" +
                                "ret=" + safeInt(getLastRet()) + "\n" +
                                "msg=" + safe(getLastMsg()) + "\n" +
                                "data=" + safe(getLastData()) + "\n\n" +
                                "raw=\n" + safe(getLastRaw());

                runOnUiThread(() -> showCopyDialog("测试打印失败（可复制）", detail));
            }
        }).start();
    }

    private Integer getLastRet() {
        try { return CloudPrinterClient.LAST_FEIEYUN_RET; } catch (Throwable t) { return null; }
    }
    private String getLastMsg() {
        try { return CloudPrinterClient.LAST_FEIEYUN_MSG; } catch (Throwable t) { return ""; }
    }
    private String getLastData() {
        try { return CloudPrinterClient.LAST_FEIEYUN_DATA; } catch (Throwable t) { return ""; }
    }
    private String getLastRaw() {
        try { return CloudPrinterClient.LAST_FEIEYUN_RAW_RESPONSE; } catch (Throwable t) { return ""; }
    }

    private String safe(String s) { return s == null ? "" : s; }
    private String safeInt(Integer i) { return i == null ? "" : String.valueOf(i); }

    /** 可滚动 + 可长按复制 */
    private void showCopyDialog(String title, String message) {
        TextView tv = new TextView(this);
        tv.setTextIsSelectable(true);
        tv.setText(message);
        tv.setPadding(40, 30, 40, 30);
        tv.setTextSize(14f);

        ScrollView sv = new ScrollView(this);
        sv.addView(tv);

        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(sv)
                .setPositiveButton("关闭", null)
                .setNegativeButton("复制提示", (d, w) ->
                        Toast.makeText(this, "长按文字即可全选复制", Toast.LENGTH_LONG).show()
                )
                .show();
    }
}
