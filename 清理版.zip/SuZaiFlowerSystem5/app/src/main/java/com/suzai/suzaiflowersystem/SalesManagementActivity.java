package com.suzai.suzaiflowersystem;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.app.AlertDialog;
import android.widget.Toast;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.app.DatePickerDialog;
import java.util.Calendar;

public class SalesManagementActivity extends BaseDrawerActivity {


    // --- Cloud pull visibility (Step 1) ---
    private static long sLastCloudPullMs = 0;
    private static boolean sPulling = false;
    private static final long CLOUD_PULL_THROTTLE_MS = 12_000;

    private static final String PREF_LAST_SAVED_ORDER_DATE = "last_saved_order_date";
    private static final String PREF_LAST_SAVED_ORDER_DATE_CONSUMED = "last_saved_order_date_consumed";
private RecyclerView recyclerView;
    private Button addOrderButton;
    private Button searchButton;
    // 明细模式（不合并）
    private OrderAdapter detailAdapter;
    // 汇总模式（合并同日同客户）
    private SalesSummaryAdapter summaryAdapter;
    private DatabaseHelper databaseHelper;

    // 表头（仅汇总模式显示）
    private View headerRow;

    private String currentDate;
    private String currentCustomer = "全部";
    // 默认显示当前账号默认场地（suzai1=佛山, suzai2=广州, suzai3=鹤山；仍可在筛选里切换）
    private String currentLocation = "全部";
    /**
     * 是否在销售管理中按"明细"展示（不合并当天同客户订单）。
     * - true: 显示原始订单明细
     * - false: 按 客户+产品+场地+单价 合并显示
     */
    // ✅ 默认：合并（汇总）显示，符合你截图2的需求
    private boolean currentNoMerge = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("销售管理");
        setContentLayout(R.layout.activity_sales_management);

        initializeViews();
        databaseHelper = new DatabaseHelper(this);

        // 默认场地：避免每次进入都显示"全部"导致跨场地数据过多
        try {
            currentLocation = AuthManager.getDefaultLocationForCurrentUser(this);
        } catch (Exception ignored) {
            // keep default
        }
        setupRecyclerView();
        setupAddOrderButton();
        setupSearchButton();
    }

    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerView);
        addOrderButton = findViewById(R.id.addOrderButton);
        searchButton = findViewById(R.id.searchButton);
        headerRow = findViewById(R.id.salesHeaderRow);
    }

    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        // 1) 明细适配器
        List<Order> orderList = getOrderListByCurrentFilter();
        detailAdapter = new OrderAdapter(orderList, new OrderAdapter.OnOrderClickListener() {
            @Override
            public void onOrderClick(Order order) {
                // 点击订单进入"订单打印"界面
                Intent it = new Intent(SalesManagementActivity.this, OrderPrintActivity.class);
                it.putExtra(OrderPrintActivity.EXTRA_DATE, order.getDate());
                it.putExtra(OrderPrintActivity.EXTRA_CUSTOMER, order.getCustomerName());
                it.putExtra(OrderPrintActivity.EXTRA_ORDER_ID, order.getId());
                startActivity(it);
            }

            @Override
            public void onOrderEdit(Order order) {
                showEditOrderDialog(order);
            }

            @Override
            public void onOrderCancel(Order order) {
                showCancelConfirm(order);
            }
        });

        // 2) 汇总适配器（同日同客户合并显示，带表头）
        summaryAdapter = new SalesSummaryAdapter(getSummaryListByCurrentFilter(), summary -> {
            // 点击某客户，进入"订单打印"界面（按日期+客户展示）
            Intent it = new Intent(SalesManagementActivity.this, OrderPrintActivity.class);
            it.putExtra(OrderPrintActivity.EXTRA_DATE, summary.date);
            it.putExtra(OrderPrintActivity.EXTRA_CUSTOMER, summary.customer);
            // 不传 orderId，进入后按日期+客户加载
            startActivity(it);
        });

        applyModeAdapter();
    }

    private void applyModeAdapter() {
        if (headerRow != null) {
            headerRow.setVisibility(currentNoMerge ? View.GONE : View.VISIBLE);
        }
        recyclerView.setAdapter(currentNoMerge ? detailAdapter : summaryAdapter);
    }

    private void setupAddOrderButton() {
        addOrderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SalesManagementActivity.this, AddOrderActivity.class));
            }
        });
    }

    private void setupSearchButton() {
        if (searchButton == null) return;
        searchButton.setOnClickListener(v -> showFilterDialog());
    }

    private void showFilterDialog() {
        View view = getLayoutInflater().inflate(R.layout.dialog_sales_filter, null);
        EditText dateEdit = view.findViewById(R.id.filterDateEditText);
        Spinner customerSpinner = view.findViewById(R.id.filterCustomerSpinner);
        Spinner locationSpinner = view.findViewById(R.id.filterLocationSpinner);
        android.widget.CheckBox noMergeCheckBox = view.findViewById(R.id.filterNoMergeCheckBox);

        dateEdit.setInputType(InputType.TYPE_NULL);
        dateEdit.setText(currentDate);
        dateEdit.setOnClickListener(v -> showDatePicker(dateEdit));

        List<String> customers = databaseHelper.getAllCustomerNames();
        customers.add(0, "全部");
        ArrayAdapter<String> customerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, customers);
        customerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        customerSpinner.setAdapter(customerAdapter);
        customerSpinner.setSelection(Math.max(0, customers.indexOf(currentCustomer)));

        // 场地选项：避免因为本地暂时没有某场地订单而不显示
        String email = "";
        try {
            String e = AuthManager.getEmail(this);
            if (e != null) email = e.toLowerCase(Locale.ROOT);
        } catch (Exception ignored) {}
        List<String> locations = new java.util.ArrayList<>();
        locations.add("全部");
        if (email.contains("suzai2@") || email.contains("suzai1@")) {
            locations.add("佛山");
            locations.add("广州");
            locations.add("鹤山");
        } else {
            String def = AuthManager.getDefaultLocationForCurrentUser(this);
            if (!android.text.TextUtils.isEmpty(def)) locations.add(def);
        }
        try {
            List<String> extra = databaseHelper.getAllLocationNames();
            for (String s : extra) {
                if (android.text.TextUtils.isEmpty(s)) continue;
                if (!locations.contains(s)) locations.add(s);
            }
        } catch (Exception ignored) {}
        ArrayAdapter<String> locationAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, locations);
        locationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        locationSpinner.setAdapter(locationAdapter);

        int idx = locations.indexOf(currentLocation);
        if (idx >= 0) locationSpinner.setSelection(idx);
        locationSpinner.setSelection(Math.max(0, locations.indexOf(currentLocation)));

        if (noMergeCheckBox != null) {
            noMergeCheckBox.setChecked(currentNoMerge);
        }

        new AlertDialog.Builder(this)
                .setTitle("筛选")
                .setView(view)
                .setPositiveButton("确定", (d, w) -> {
                    currentDate = dateEdit.getText().toString().trim();
                    currentCustomer = (String) customerSpinner.getSelectedItem();
                    currentLocation = (String) locationSpinner.getSelectedItem();
                    if (noMergeCheckBox != null) {
                        currentNoMerge = noMergeCheckBox.isChecked();
                    }
                    refreshList();
                })
                .setNeutralButton("重置", (d, w) -> {
                    currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                    currentCustomer = "全部";
                    currentLocation = "全部";
                    currentNoMerge = true;
                    refreshList();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showDatePicker(EditText target) {
        Calendar cal = Calendar.getInstance();
        String[] parts = target.getText().toString().split("-");
        if (parts.length == 3) {
            try {
                cal.set(Calendar.YEAR, Integer.parseInt(parts[0]));
                cal.set(Calendar.MONTH, Integer.parseInt(parts[1]) - 1);
                cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(parts[2]));
            } catch (Exception ignored) {}
        }
        new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            String v = String.format(Locale.getDefault(), "%04d-%02d-%02d", year, month + 1, dayOfMonth);
            target.setText(v);
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void showCancelConfirm(Order order) {
        final boolean isNoMerge = currentNoMerge;
        new AlertDialog.Builder(this)
                .setTitle("取消订单")
                .setMessage("确定取消该订单吗？\n" + order.getCustomerName() + " - " + order.getProductName() + " - 数量:" + order.getQuantity() + " / 件数(箱):" + order.getPieces())
                .setPositiveButton("确定", (d, w) -> {
                    int rows;
                    if (isNoMerge) {
                        rows = databaseHelper.deleteOrderById(order.getId());
                    } else {
                        rows = databaseHelper.deleteOrderGroup(order.getDate(), order.getCustomerName(), order.getProductName(), order.getLocation(), order.getPrice());
                    }
                    Toast.makeText(this, rows > 0 ? "已取消" : "取消失败", Toast.LENGTH_SHORT).show();
                    refreshList();
                })
                .setNegativeButton("返回", null)
                .show();
    }

    private void showEditOrderDialog(Order order) {
        final boolean isNoMerge = currentNoMerge;

        View view = getLayoutInflater().inflate(R.layout.dialog_edit_order, null);
        EditText piecesEdit = view.findViewById(R.id.editPiecesEditText);
        TextView computedQtyText = view.findViewById(R.id.computedQuantityTextView);
        EditText priceEdit = view.findViewById(R.id.editPriceEditText);
        EditText remarkEdit = view.findViewById(R.id.editRemarkEditText);
        Spinner locationSpinner = view.findViewById(R.id.editLocationSpinner);

        piecesEdit.setInputType(InputType.TYPE_CLASS_NUMBER);
        piecesEdit.setText(String.valueOf(order.getPieces()));

        priceEdit.setInputType(InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_CLASS_NUMBER);
        priceEdit.setText(String.valueOf(order.getPrice()));

        remarkEdit.setText(order.getRemark() == null ? "" : order.getRemark());

        // 计算数量：件数(箱) * 装箱数
        int pu = databaseHelper.getProductPackingUnitsByName(order.getProductName());
        if (pu <= 1 && order.getPieces() > 0 && order.getQuantity() > order.getPieces()) {
            pu = Math.max(1, order.getQuantity() / Math.max(1, order.getPieces()));
        }
        final int packingUnits = Math.max(1, pu);
        final Runnable refreshComputedQty = () -> {
            int piecesVal = 0;
            try {
                piecesVal = Integer.parseInt(piecesEdit.getText().toString().trim());
            } catch (Exception ignore) {
            }
            int qty = Math.max(0, piecesVal) * Math.max(1, packingUnits);
            computedQtyText.setText("数量：" + qty + "（装箱数：" + Math.max(1, packingUnits) + "）");
        };
        refreshComputedQty.run();
        piecesEdit.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override public void afterTextChanged(android.text.Editable s) { refreshComputedQty.run(); }
        });

        List<String> locations = databaseHelper.getAllLocationNames();
        if (order.getLocation() != null && order.getLocation().length() > 0 && !locations.contains(order.getLocation())) {
            locations.add(0, order.getLocation());
        }
        ArrayAdapter<String> locationAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, locations);
        locationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        locationSpinner.setAdapter(locationAdapter);
        locationSpinner.setSelection(Math.max(0, locations.indexOf(order.getLocation())));

        new AlertDialog.Builder(this)
                .setTitle("修改订单")
                .setView(view)
                .setPositiveButton("保存", (d, w) -> {
                    int newPieces = order.getPieces();
                    double newPrice = order.getPrice();

                    try {
                        newPieces = Integer.parseInt(piecesEdit.getText().toString().trim());
                    } catch (Exception ignore) {
                    }
                    try {
                        newPrice = Double.parseDouble(priceEdit.getText().toString().trim());
                    } catch (Exception ignore) {
                    }

                    String newLocation = (String) locationSpinner.getSelectedItem();
                    String newRemark = remarkEdit.getText().toString().trim();

                    int newQty = Math.max(0, newPieces) * Math.max(1, packingUnits);

                    int rows;
                    if (isNoMerge) {
                        rows = databaseHelper.updateOrderById(order.getId(), newPieces, newQty, newLocation, newPrice, newRemark);
                    } else {
                        rows = databaseHelper.updateOrderGroup(order.getDate(), order.getCustomerName(), order.getProductName(),
                                order.getLocation(), order.getPrice(), newPieces, newQty, newLocation, newPrice, newRemark);
                    }

                    Toast.makeText(this, rows > 0 ? "已保存" : "保存失败", Toast.LENGTH_SHORT).show();
                    refreshList();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void refreshList() {
        if (currentNoMerge) {
            List<Order> orderList = getOrderListByCurrentFilter();
            detailAdapter.updateOrderList(orderList);
        } else {
            summaryAdapter.updateList(getSummaryListByCurrentFilter());
        }
        applyModeAdapter();
    }

    /**
     * ✅ 汇总：同日同客户合并（件数合计、金额合计）
     * 规则：
     * - date 固定为 currentDate
     * - customer 若筛选为"全部"，则按客户分组；否则只返回该客户一行
     * - location 若筛选不为"全部"，只统计该场地
     */
    private List<SalesSummary> getSummaryListByCurrentFilter() {
        List<Order> raw = databaseHelper.getOrdersByDateFiltered(currentDate, currentCustomer, currentLocation);

        java.util.HashMap<String, SalesSummary> map = new java.util.HashMap<>();
        if (raw != null) {
            for (Order o : raw) {
                if (o == null) continue;
                String c = o.getCustomerName() == null ? "" : o.getCustomerName();
                SalesSummary s = map.get(c);
                if (s == null) {
                    s = new SalesSummary(currentDate, c, 0, 0.0);
                    s.anchorCreatedAt = normalizeCreatedAt(o.getCreatedAt());
                    s.anchorId = o.getId();
                    map.put(c, s);
                } else {
                    String cur = normalizeCreatedAt(o.getCreatedAt());
                    if (isEarlierCreatedAt(cur, s.anchorCreatedAt, o.getId(), s.anchorId)) {
                        s.anchorCreatedAt = cur;
                        s.anchorId = o.getId();
                    }
                }
                s.totalPieces += Math.max(0, o.getPieces());
                s.totalAmount += o.getTotalPrice();
            }
        }

        java.util.ArrayList<SalesSummary> out = new java.util.ArrayList<>(map.values());
        java.util.Collections.sort(out, (a, b) -> {
            int cmp = compareCreatedAtDesc(a.anchorCreatedAt, b.anchorCreatedAt);
            if (cmp != 0) return cmp;
            return Integer.compare(b.anchorId, a.anchorId);
        });
        return out;
    }

    private String normalizeCreatedAt(String s) {
        return s == null ? "" : s.trim();
    }

    private boolean isEarlierCreatedAt(String candidate, String baseline, int candidateId, int baselineId) {
        String c = normalizeCreatedAt(candidate);
        String b = normalizeCreatedAt(baseline);
        if (c.isEmpty() && b.isEmpty()) return candidateId < baselineId;
        if (c.isEmpty()) return false;
        if (b.isEmpty()) return true;
        int cmp = c.compareTo(b);
        if (cmp != 0) return cmp < 0;
        return candidateId < baselineId;
    }

    private int compareCreatedAtDesc(String a, String b) {
        String aa = normalizeCreatedAt(a);
        String bb = normalizeCreatedAt(b);
        if (aa.isEmpty() && bb.isEmpty()) return 0;
        if (aa.isEmpty()) return 1;
        if (bb.isEmpty()) return -1;
        return bb.compareTo(aa);
    }

    private List<Order> getOrderListByCurrentFilter() {
        return databaseHelper.getOrdersByDateFiltered(currentDate, currentCustomer, currentLocation);
    }

    private void consumePendingSavedOrderDateIfAny() {
        try {
            android.content.SharedPreferences sp = getSharedPreferences("sales_management_state", MODE_PRIVATE);
            String pendingDate = sp.getString(PREF_LAST_SAVED_ORDER_DATE, "");
            boolean consumed = sp.getBoolean(PREF_LAST_SAVED_ORDER_DATE_CONSUMED, true);
            if (pendingDate != null && !pendingDate.trim().isEmpty() && !consumed) {
                currentDate = pendingDate.trim();
                currentCustomer = "全部";
                if (currentLocation == null || currentLocation.trim().isEmpty()) {
                    currentLocation = AuthManager.getDefaultLocationForCurrentUser(this);
                }
                sp.edit().putBoolean(PREF_LAST_SAVED_ORDER_DATE_CONSUMED, true).apply();
            }
        } catch (Exception ignored) {}
    }

    private void maybeAutoJumpToToday() {
        try {
            android.content.SharedPreferences sp = getSharedPreferences("sales_management_state", MODE_PRIVATE);
            boolean consumed = sp.getBoolean(PREF_LAST_SAVED_ORDER_DATE_CONSUMED, true);
            if (consumed) {
                String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                if (currentDate == null || currentDate.trim().isEmpty()) currentDate = today;
            }
        } catch (Exception ignored) {}
    }

    @Override
    protected void onResume() {
        super.onResume();
        consumePendingSavedOrderDateIfAny();
        maybeAutoJumpToToday();
        refreshList();
        try { SupabaseSyncManager.schedulePush(getApplicationContext()); } catch (Exception ignored) {}
    }

    @Override
    protected void onStart() {
        super.onStart();
        setupSearchButton();
    }

    // -----------------------------
    //  汇总（同日同客户合并）显示
    // -----------------------------

    static class SalesSummary {
        String date;
        String customer;
        int totalPieces;
        double totalAmount;
        String anchorCreatedAt;
        int anchorId;

        SalesSummary(String date, String customer, int totalPieces, double totalAmount) {
            this.date = date;
            this.customer = customer;
            this.totalPieces = totalPieces;
            this.totalAmount = totalAmount;
            this.anchorCreatedAt = "";
            this.anchorId = 0;
        }
    }

    interface OnSummaryClickListener {
        void onClick(SalesSummary summary);
    }

    static class SalesSummaryAdapter extends RecyclerView.Adapter<SalesSummaryAdapter.VH> {

        private final List<SalesSummary> list;
        private final OnSummaryClickListener listener;

        SalesSummaryAdapter(List<SalesSummary> list, OnSummaryClickListener listener) {
            this.list = (list == null) ? new java.util.ArrayList<>() : list;
            this.listener = listener;
        }

        void updateList(List<SalesSummary> newList) {
            this.list.clear();
            if (newList != null) this.list.addAll(newList);
            notifyDataSetChanged();
        }

        @Override
        public VH onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            android.view.View v = android.view.LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_sales_summary_row, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(VH h, int position) {
            SalesSummary s = list.get(position);
            h.tvDate.setText(s.date);
            h.tvCustomer.setText(s.customer);
            h.tvPieces.setText(String.valueOf(s.totalPieces));
            h.tvAmount.setText(String.format(java.util.Locale.getDefault(), "%.2f", s.totalAmount));

            h.itemView.setOnClickListener(v -> {
                if (listener != null) listener.onClick(s);
            });
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        static class VH extends RecyclerView.ViewHolder {
            TextView tvDate;
            TextView tvCustomer;
            TextView tvPieces;
            TextView tvAmount;

            VH(android.view.View itemView) {
                super(itemView);
                tvDate = itemView.findViewById(R.id.rowDate);
                tvCustomer = itemView.findViewById(R.id.rowCustomer);
                tvPieces = itemView.findViewById(R.id.rowPieces);
                tvAmount = itemView.findViewById(R.id.rowAmount);
            }
        }
    }
}
