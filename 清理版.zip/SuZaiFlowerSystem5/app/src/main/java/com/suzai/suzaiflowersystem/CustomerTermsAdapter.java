package com.suzai.suzaiflowersystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CustomerTermsAdapter extends RecyclerView.Adapter<CustomerTermsAdapter.VH> {

    public interface OnItemClickListener {
        void onClick(CustomerFinanceProfile p);
    }

    private final List<CustomerFinanceProfile> data = new ArrayList<>();
    private final OnItemClickListener listener;

    public CustomerTermsAdapter(OnItemClickListener listener) {
        this.listener = listener;
    }

    public void setData(List<CustomerFinanceProfile> list) {
        data.clear();
        if (list != null) data.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_customer_term, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        final CustomerFinanceProfile p = data.get(position);
        h.tvCustomer.setText(p.customerName == null ? "" : p.customerName);
        h.tvTerms.setText(String.format("账期：%d天  额度：%.2f", p.creditDays, p.creditLimit));
        h.itemView.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (listener != null) listener.onClick(p);
            }
        });
    }

    @Override
    public int getItemCount() { return data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvCustomer, tvTerms;
        VH(@NonNull View itemView) {
            super(itemView);
            tvCustomer = itemView.findViewById(R.id.tv_customer);
            tvTerms = itemView.findViewById(R.id.tv_terms);
        }
    }
}
