package com.suzai.suzaiflowersystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {

    private List<Order> orderList;
    private OnOrderClickListener listener;

    /**
     * 当 listener 为 null 时，该 Adapter 仅用于展示，不提供点击/编辑/取消事件，也会隐藏操作按钮。
     */

    public interface OnOrderClickListener {
        void onOrderClick(Order order);
        void onOrderEdit(Order order);
        void onOrderCancel(Order order);
    }

    public OrderAdapter(List<Order> orderList, OnOrderClickListener listener) {
        this.orderList = orderList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_order, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order order = orderList.get(position);
        holder.bind(order);
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    public void updateOrderList(List<Order> newOrderList) {
        this.orderList = newOrderList;
        notifyDataSetChanged();
    }

    class OrderViewHolder extends RecyclerView.ViewHolder {
        private TextView customerNameTextView;
        private TextView productNameTextView;
        private TextView piecesTextView;
        private TextView quantityTextView;
        private TextView amountTextView;
        private TextView dateTextView;
        private Button editButton;
        private Button cancelButton;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            customerNameTextView = itemView.findViewById(R.id.customerNameTextView);
            productNameTextView = itemView.findViewById(R.id.productNameTextView);
            piecesTextView = itemView.findViewById(R.id.piecesTextView);
            quantityTextView = itemView.findViewById(R.id.quantityTextView);
            amountTextView = itemView.findViewById(R.id.amountTextView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
            editButton = itemView.findViewById(R.id.editButton);
            cancelButton = itemView.findViewById(R.id.cancelButton);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener == null) return;
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onOrderClick(orderList.get(position));
                    }
                }
            });

            editButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener == null) return;
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION && listener != null) {
                        listener.onOrderEdit(orderList.get(position));
                    }
                }
            });

            cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener == null) return;
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION && listener != null) {
                        listener.onOrderCancel(orderList.get(position));
                    }
                }
            });
        }

        public void bind(Order order) {
            customerNameTextView.setText(order.getCustomerName());
            productNameTextView.setText(order.getProductName());
            if (piecesTextView != null) {
                piecesTextView.setText("件数(箱): " + order.getPieces());
            }
            quantityTextView.setText("数量: " + order.getQuantity());if (amountTextView != null) {
                amountTextView.setText("金额: ¥" + String.format(java.util.Locale.getDefault(), "%.2f", order.getTotalPrice()));
            }
            dateTextView.setText(order.getDate());

            // 仅展示模式：隐藏按钮
            if (listener == null) {
                if (editButton != null) editButton.setVisibility(View.GONE);
                if (cancelButton != null) cancelButton.setVisibility(View.GONE);
            } else {
                if (editButton != null) editButton.setVisibility(View.VISIBLE);
                if (cancelButton != null) cancelButton.setVisibility(View.VISIBLE);
            }
        }
    }
}