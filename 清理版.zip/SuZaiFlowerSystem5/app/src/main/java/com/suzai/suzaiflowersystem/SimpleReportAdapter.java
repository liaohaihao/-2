package com.suzai.suzaiflowersystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** 简单四列报表列表适配器（Step2） */
public class SimpleReportAdapter extends RecyclerView.Adapter<SimpleReportAdapter.VH> {

    private String[] headers = new String[]{"列1","列2","列3","列4"};
    private final List<ReportsActivity.Row> rows = new ArrayList<>();

    public void setHeaders(String[] headers) {
        if (headers != null && headers.length > 0) this.headers = headers;
        notifyDataSetChanged();
    }

    public void setRows(List<ReportsActivity.Row> newRows) {
        rows.clear();
        if (newRows != null) rows.addAll(newRows);
        notifyDataSetChanged();
    }

    public List<ReportsActivity.Row> getRows() {
        return new ArrayList<>(rows);
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_report_row, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        ReportsActivity.Row r = rows.get(position);
        h.tv1.setText(r.c1);
        h.tv2.setText(r.c2);
        h.tv3.setText(r.c3);
        h.tv4.setText(r.c4);
    }

    @Override
    public int getItemCount() {
        return rows.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tv1, tv2, tv3, tv4;
        VH(@NonNull View itemView) {
            super(itemView);
            tv1 = itemView.findViewById(R.id.tvCol1);
            tv2 = itemView.findViewById(R.id.tvCol2);
            tv3 = itemView.findViewById(R.id.tvCol3);
            tv4 = itemView.findViewById(R.id.tvCol4);
        }
    }
}
