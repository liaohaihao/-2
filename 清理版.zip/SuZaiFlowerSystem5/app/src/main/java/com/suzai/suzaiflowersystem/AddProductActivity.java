package com.suzai.suzaiflowersystem;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddProductActivity extends BaseDrawerActivity {

    private EditText nameEditText;
    private EditText packingUnitsEditText;
    private EditText priceEditText;
    private Button saveButton;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("新增产品");
        setContentLayout(R.layout.activity_add_product);

        initializeViews();
        databaseHelper = new DatabaseHelper(this);
        setupSaveButton();
    }

    private void initializeViews() {
        nameEditText = findViewById(R.id.nameEditText);
        packingUnitsEditText = findViewById(R.id.packingUnitsEditText);
        priceEditText = findViewById(R.id.priceEditText);
        saveButton = findViewById(R.id.saveButton);
    }

    private void setupSaveButton() {
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveProduct();
            }
        });
    }

    private void saveProduct() {
        String name = nameEditText.getText().toString().trim();
        String packingUnitsStr = packingUnitsEditText.getText().toString().trim();
        String priceStr = priceEditText.getText().toString().trim();

        if (name.isEmpty()) {
            Toast.makeText(this, "请输入产品名称", Toast.LENGTH_SHORT).show();
            return;
        }

        if (packingUnitsStr.isEmpty()) {
            Toast.makeText(this, "请输入装箱件数", Toast.LENGTH_SHORT).show();
            return;
        }

        if (priceStr.isEmpty()) {
            Toast.makeText(this, "请输入单价", Toast.LENGTH_SHORT).show();
            return;
        }

        int packingUnits = Integer.parseInt(packingUnitsStr);
        double price = Double.parseDouble(priceStr);

        long result = databaseHelper.addProduct(name, packingUnits, price);

        if (result != -1) {
            Toast.makeText(this, "产品保存成功", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "产品保存失败", Toast.LENGTH_SHORT).show();
        }
    }
}