package com.suzai.suzaiflowersystem;

import android.app.Activity;
import android.app.Application;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Bundle;

/**
 * 全局 Application：
 * 1) 用于在任意前台页面都能监听剪贴板
 * 2) 注册网络监听：网络恢复后自动触发现有同步逻辑
 *
 * 注意：
 * - 不修改原有数据上传功能
 * - 只增加“离线恢复后自动同步”的触发层
 */
public class SuZaiApp extends Application {

    private Activity currentActivity;
    private ConnectivityManager.NetworkCallback networkCallback;
    private boolean lastNetworkAvailable = false;

    @Override
    public void onCreate() {
        super.onCreate();

        lastNetworkAvailable = isNetworkAvailable();

        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override public void onActivityCreated(Activity activity, Bundle savedInstanceState) { }
            @Override public void onActivityStarted(Activity activity) { }

            @Override
            public void onActivityResumed(Activity activity) {
                currentActivity = activity;

                // 只要 APP 在前台某个页面，就挂载监听
                try { ClipboardOrderAssistant.get().attach(activity); } catch (Exception ignored) {}

                // 前台兜底检查一次网络，防止系统漏发网络变化事件
                try { OfflineSyncManager.trySyncWhenForeground(activity); } catch (Exception ignored) {}
            }

            @Override
            public void onActivityPaused(Activity activity) {
                // 页面切换时先解绑，避免引用泄露
                if (currentActivity == activity) {
                    try { ClipboardOrderAssistant.get().detach(); } catch (Exception ignored) {}
                    currentActivity = null;
                }
            }

            @Override public void onActivityStopped(Activity activity) { }
            @Override public void onActivitySaveInstanceState(Activity activity, Bundle outState) { }
            @Override public void onActivityDestroyed(Activity activity) { }
        });

        registerNetworkWatcher();
    }

    private void registerNetworkWatcher() {
        try {
            final ConnectivityManager cm =
                    (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (cm == null) return;

            networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    boolean nowAvailable = isNetworkAvailable();
                    if (!lastNetworkAvailable && nowAvailable) {
                        try { SyncLogStore.append(getApplicationContext(), "D", "SuZaiApp", "network available callback"); } catch (Exception ignored) {}
                        try { OfflineSyncManager.onNetworkRestored(getApplicationContext()); } catch (Exception ignored) {}
                    }
                    lastNetworkAvailable = nowAvailable;
                }

                @Override
                public void onLost(Network network) {
                    lastNetworkAvailable = false;
                    try { SyncLogStore.append(getApplicationContext(), "D", "SuZaiApp", "network lost callback"); } catch (Exception ignored) {}
                }

                @Override
                public void onCapabilitiesChanged(Network network, NetworkCapabilities networkCapabilities) {
                    boolean nowAvailable = networkCapabilities != null
                            && networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
                    if (!lastNetworkAvailable && nowAvailable) {
                        try { SyncLogStore.append(getApplicationContext(), "D", "SuZaiApp", "network capabilities changed -> available"); } catch (Exception ignored) {}
                        try { OfflineSyncManager.onNetworkRestored(getApplicationContext()); } catch (Exception ignored) {}
                    }
                    lastNetworkAvailable = nowAvailable;
                }
            };

            cm.registerDefaultNetworkCallback(networkCallback);
        } catch (Exception e) {
            try {
                SyncLogStore.append(getApplicationContext(), "W", "SuZaiApp",
                        "register network callback failed: " + e.getMessage());
            } catch (Exception ignored) {}
        }
    }

    private boolean isNetworkAvailable() {
        try {
            ConnectivityManager cm =
                    (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (cm == null) return false;

            Network network = cm.getActiveNetwork();
            if (network == null) return false;

            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            return caps != null
                    && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Exception e) {
            return false;
        }
    }
}
