package com.suzai.suzaiflowersystem;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Calendar;

/**
 * 归档管理器 - 实现"2年热数据 + 历史归档"方案
 * 
 * 功能：
 * 1. 创建归档表结构
 * 2. 扫描待归档数据（超过2年的订单相关数据）
 * 3. 迁移数据到归档表
 * 4. 校验迁移完整性
 * 5. 清理主表旧数据
 * 6. 记录归档日志
 */
public class ArchiveManager {
    
    private static final String TAG = "ArchiveManager";
    
    // 归档表后缀
    private static final String ARCHIVE_SUFFIX = "_archive";
    
    // 热数据边界：当前日期往前24个月
    private static final int HOT_DATA_MONTHS = 24;
    
    /**
     * 创建归档表结构
     */
    public static void createArchiveTables(SQLiteDatabase db) {
        Log.i(TAG, "开始创建归档表结构");
        
        // 1. 创建orders归档表（结构与主表基本一致）
        db.execSQL("CREATE TABLE IF NOT EXISTS orders_archive (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "date TEXT NOT NULL," +
                "customer_name TEXT NOT NULL," +
                "product_name TEXT NOT NULL," +
                "pieces INTEGER NOT NULL DEFAULT 0," +
                "quantity INTEGER NOT NULL DEFAULT 0," +
                "price REAL NOT NULL DEFAULT 0," +
                "location TEXT," +
                "remark TEXT," +
                "status TEXT DEFAULT 'CONFIRMED'," +
                "is_deleted INTEGER NOT NULL DEFAULT 0," +
                "deleted_at TEXT," +
                "voided_at TEXT," +
                "printed_at TEXT," +
                "shipped_at TEXT," +
                "settled_at TEXT," +
                "total_quantity INTEGER NOT NULL DEFAULT 0," +
                "total_amount REAL NOT NULL DEFAULT 0," +
                "created_at TEXT," +
                "updated_at TEXT," +
                "cloud_id TEXT," +
                "synced INTEGER NOT NULL DEFAULT 0," +
                "printed INTEGER NOT NULL DEFAULT 0," +
                // 归档特有字段
                "archive_date TEXT NOT NULL," +           // 归档日期
                "archive_batch_id TEXT," +                // 归档批次ID
                "original_id INTEGER" +                   // 原始主表ID（用于追溯）
                ")");
        
        // 2. 创建order_items归档表
        db.execSQL("CREATE TABLE IF NOT EXISTS order_items_archive (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "order_cloud_id TEXT NOT NULL," +
                "product_name TEXT NOT NULL," +
                "pieces INTEGER NOT NULL DEFAULT 0," +
                "quantity INTEGER NOT NULL DEFAULT 0," +
                "price REAL NOT NULL DEFAULT 0," +
                "remark TEXT," +
                "created_at TEXT," +
                "updated_at TEXT," +
                "cloud_id TEXT," +
                "synced INTEGER NOT NULL DEFAULT 0," +
                "is_deleted INTEGER NOT NULL DEFAULT 0," +
                "deleted_at TEXT," +
                // 归档特有字段
                "archive_date TEXT NOT NULL," +           // 归档日期
                "archive_batch_id TEXT," +                // 归档批次ID
                "original_id INTEGER" +                   // 原始主表ID
                ")");
        
        // 3. 创建logistics_forms归档表
        db.execSQL("CREATE TABLE IF NOT EXISTS logistics_forms_archive (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "date TEXT NOT NULL," +
                "location TEXT," +
                "total_pieces INTEGER NOT NULL DEFAULT 0," +
                "total_cbm REAL NOT NULL DEFAULT 0," +
                "remark TEXT," +
                "cloud_id TEXT," +
                "synced INTEGER NOT NULL DEFAULT 0," +
                // 归档特有字段
                "archive_date TEXT NOT NULL," +           // 归档日期
                "archive_batch_id TEXT," +                // 归档批次ID
                "original_id INTEGER" +                   // 原始主表ID
                ")");
        
        // 4. 创建归档日志表
        db.execSQL("CREATE TABLE IF NOT EXISTS archive_logs (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "batch_id TEXT NOT NULL," +               // 归档批次ID
                "archive_date TEXT NOT NULL," +           // 归档执行日期
                "table_name TEXT NOT NULL," +             // 表名
                "records_migrated INTEGER NOT NULL DEFAULT 0," +  // 迁移记录数
                "records_deleted INTEGER NOT NULL DEFAULT 0," +   // 删除记录数
                "start_time INTEGER NOT NULL," +          // 开始时间戳
                "end_time INTEGER," +                     // 结束时间戳
                "status TEXT NOT NULL," +                 // 状态：SUCCESS/FAILED
                "error_message TEXT" +                    // 错误信息（如果有）
                ")");
        
        Log.i(TAG, "归档表结构创建完成");
    }
    
    /**
     * 获取2年前的日期字符串（YYYY-MM-DD格式）
     */
    public static String getDateTwoYearsAgo() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -HOT_DATA_MONTHS);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        return sdf.format(cal.getTime());
    }
    
    /**
     * 扫描待归档数据数量
     */
    public static ArchiveScanResult scanDataForArchive(Context ctx) {
        DatabaseHelper dbHelper = new DatabaseHelper(ctx);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        
        ArchiveScanResult result = new ArchiveScanResult();
        String twoYearsAgo = getDateTwoYearsAgo();
        
        try {
            // 扫描orders表
            Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM orders WHERE date < ? AND is_deleted = 0",
                new String[]{twoYearsAgo}
            );
            if (cursor.moveToFirst()) {
                result.ordersCount = cursor.getInt(0);
            }
            cursor.close();
            
            // 扫描order_items表（通过关联orders表）
            cursor = db.rawQuery(
                "SELECT COUNT(*) FROM order_items oi " +
                "INNER JOIN orders o ON oi.order_cloud_id = o.cloud_id " +
                "WHERE o.date < ? AND o.is_deleted = 0 AND oi.is_deleted = 0",
                new String[]{twoYearsAgo}
            );
            if (cursor.moveToFirst()) {
                result.orderItemsCount = cursor.getInt(0);
            }
            cursor.close();
            
            // 扫描logistics_forms表
            cursor = db.rawQuery(
                "SELECT COUNT(*) FROM logistics_forms WHERE date < ?",
                new String[]{twoYearsAgo}
            );
            if (cursor.moveToFirst()) {
                result.logisticsFormsCount = cursor.getInt(0);
            }
            cursor.close();
            
            Log.i(TAG, String.format("扫描完成：orders=%d, order_items=%d, logistics_forms=%d",
                result.ordersCount, result.orderItemsCount, result.logisticsFormsCount));
            
        } catch (Exception e) {
            Log.e(TAG, "扫描待归档数据失败", e);
        } finally {
            if (db != null && db.isOpen()) {
                db.close();
            }
        }
        
        return result;
    }
    
    /**
     * 执行归档迁移
     */
    public static ArchiveResult executeArchive(Context ctx, String batchId) {
        DatabaseHelper dbHelper = new DatabaseHelper(ctx);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        
        ArchiveResult result = new ArchiveResult();
        result.batchId = batchId;
        result.startTime = System.currentTimeMillis();
        
        String twoYearsAgo = getDateTwoYearsAgo();
        String archiveDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        
        long logId = -1;
        try {
            db.beginTransaction();
            
            // 1. 记录归档开始日志
            logId = insertArchiveLog(db, batchId, archiveDate, "START", result.startTime, 0, 0, "STARTED", null);
            
            // 2. 迁移orders数据
            result.ordersMigrated = migrateOrders(db, twoYearsAgo, batchId, archiveDate);
            
            // 3. 迁移order_items数据（关联已迁移的orders）
            result.orderItemsMigrated = migrateOrderItems(db, twoYearsAgo, batchId, archiveDate);
            
            // 4. 迁移logistics_forms数据
            result.logisticsFormsMigrated = migrateLogisticsForms(db, twoYearsAgo, batchId, archiveDate);
            
            // 5. 删除已迁移的order_items数据（必须先于orders删除）
            result.orderItemsDeleted = deleteMigratedOrderItems(db, twoYearsAgo);
            
            // 6. 删除已迁移的orders数据
            result.ordersDeleted = deleteMigratedOrders(db, twoYearsAgo);
            
            // 7. 删除已迁移的logistics_forms数据
            result.logisticsFormsDeleted = deleteMigratedLogisticsForms(db, twoYearsAgo);
            
            // 8. 更新归档日志
            updateArchiveLog(db, logId, System.currentTimeMillis(), "SUCCESS", null);
            
            db.setTransactionSuccessful();
            result.status = "SUCCESS";
            result.endTime = System.currentTimeMillis();
            
            Log.i(TAG, String.format("归档完成：迁移 orders=%d, order_items=%d, logistics_forms=%d",
                result.ordersMigrated, result.orderItemsMigrated, result.logisticsFormsMigrated));
            Log.i(TAG, String.format("删除完成：orders=%d, order_items=%d, logistics_forms=%d",
                result.ordersDeleted, result.orderItemsDeleted, result.logisticsFormsDeleted));
                
        } catch (Exception e) {
            Log.e(TAG, "归档执行失败", e);
            result.status = "FAILED";
            result.errorMessage = e.getMessage();
            result.endTime = System.currentTimeMillis();
            
            // 更新日志为失败状态 - 使用真实的logId
            try {
                if (logId > 0) {
                    updateArchiveLog(db, logId, result.endTime, "FAILED", e.getMessage());
                    Log.i(TAG, "归档失败日志已更新，logId=" + logId);
                } else {
                    // 如果logId无效，创建新的失败日志记录
                    insertArchiveLog(db, batchId, archiveDate, "FAILURE", result.startTime, 
                        result.ordersMigrated + result.orderItemsMigrated + result.logisticsFormsMigrated,
                        result.ordersDeleted + result.orderItemsDeleted + result.logisticsFormsDeleted,
                        "FAILED", e.getMessage());
                    Log.w(TAG, "logId无效，创建新的失败日志记录");
                }
            } catch (Exception logEx) {
                Log.e(TAG, "更新归档日志失败", logEx);
            }
        } finally {
            if (db != null) {
                try {
                    db.endTransaction();
                } catch (Exception e) {
                    Log.e(TAG, "结束事务失败", e);
                }
                if (db.isOpen()) {
                    db.close();
                }
            }
        }
        
        return result;
    }
    
    /**
     * 迁移orders数据
     */
    private static int migrateOrders(SQLiteDatabase db, String cutoffDate, String batchId, String archiveDate) {
        String sql = "INSERT INTO orders_archive (" +
            "date, customer_name, product_name, pieces, quantity, price, location, remark, " +
            "status, is_deleted, deleted_at, voided_at, printed_at, shipped_at, settled_at, " +
            "total_quantity, total_amount, created_at, updated_at, cloud_id, synced, printed, " +
            "archive_date, archive_batch_id, original_id" +
            ") SELECT " +
            "date, customer_name, product_name, pieces, quantity, price, location, remark, " +
            "status, is_deleted, deleted_at, voided_at, printed_at, shipped_at, settled_at, " +
            "total_quantity, total_amount, created_at, updated_at, cloud_id, synced, printed, " +
            "?, ?, id " +
            "FROM orders WHERE date < ? AND is_deleted = 0";
        
        db.execSQL(sql, new Object[]{archiveDate, batchId, cutoffDate});
        
        Cursor cursor = db.rawQuery("SELECT changes()", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        
        Log.i(TAG, "迁移orders数据完成，数量：" + count);
        return count;
    }
    
    /**
     * 迁移order_items数据
     */
    private static int migrateOrderItems(SQLiteDatabase db, String cutoffDate, String batchId, String archiveDate) {
        String sql = "INSERT INTO order_items_archive (" +
            "order_cloud_id, product_name, pieces, quantity, price, remark, " +
            "created_at, updated_at, cloud_id, synced, is_deleted, deleted_at, " +
            "archive_date, archive_batch_id, original_id" +
            ") SELECT " +
            "oi.order_cloud_id, oi.product_name, oi.pieces, oi.quantity, oi.price, oi.remark, " +
            "oi.created_at, oi.updated_at, oi.cloud_id, oi.synced, oi.is_deleted, oi.deleted_at, " +
            "?, ?, oi.id " +
            "FROM order_items oi " +
            "INNER JOIN orders o ON oi.order_cloud_id = o.cloud_id " +
            "WHERE o.date < ? AND o.is_deleted = 0 AND oi.is_deleted = 0";
        
        db.execSQL(sql, new Object[]{archiveDate, batchId, cutoffDate});
        
        Cursor cursor = db.rawQuery("SELECT changes()", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        
        Log.i(TAG, "迁移order_items数据完成，数量：" + count);
        return count;
    }
    
    /**
     * 迁移logistics_forms数据
     */
    private static int migrateLogisticsForms(SQLiteDatabase db, String cutoffDate, String batchId, String archiveDate) {
        String sql = "INSERT INTO logistics_forms_archive (" +
            "date, location, total_pieces, total_cbm, remark, cloud_id, synced, " +
            "archive_date, archive_batch_id, original_id" +
            ") SELECT " +
            "date, location, total_pieces, total_cbm, remark, cloud_id, synced, " +
            "?, ?, id " +
            "FROM logistics_forms WHERE date < ?";
        
        db.execSQL(sql, new Object[]{archiveDate, batchId, cutoffDate});
        
        Cursor cursor = db.rawQuery("SELECT changes()", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        
        Log.i(TAG, "迁移logistics_forms数据完成，数量：" + count);
        return count;
    }
    
    /**
     * 删除已迁移的orders数据
     */
    private static int deleteMigratedOrders(SQLiteDatabase db, String cutoffDate) {
        String sql = "DELETE FROM orders WHERE date < ? AND is_deleted = 0";
        db.execSQL(sql, new Object[]{cutoffDate});
        
        Cursor cursor = db.rawQuery("SELECT changes()", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        
        Log.i(TAG, "删除orders数据完成，数量：" + count);
        return count;
    }
    
    /**
     * 删除已迁移的order_items数据
     * 修复：使用缓存策略，先获取待删除的order_items ID列表，再删除
     */
    private static int deleteMigratedOrderItems(SQLiteDatabase db, String cutoffDate) {
        int count = 0;
        Cursor cursor = null;
        
        try {
            // 方案A：先获取待删除的order_items ID列表
            String selectSql = "SELECT oi.id FROM order_items oi " +
                "INNER JOIN orders o ON oi.order_cloud_id = o.cloud_id " +
                "WHERE o.date < ? AND o.is_deleted = 0 AND oi.is_deleted = 0";
            
            cursor = db.rawQuery(selectSql, new String[]{cutoffDate});
            
            if (cursor != null && cursor.getCount() > 0) {
                StringBuilder idList = new StringBuilder();
                boolean first = true;
                
                while (cursor.moveToNext()) {
                    if (!first) {
                        idList.append(",");
                    }
                    idList.append(cursor.getInt(0));
                    first = false;
                }
                
                cursor.close();
                
                // 如果有待删除的ID，执行删除
                if (idList.length() > 0) {
                    String deleteSql = "DELETE FROM order_items WHERE id IN (" + idList.toString() + ")";
                    db.execSQL(deleteSql);
                    
                    // 获取删除数量
                    cursor = db.rawQuery("SELECT changes()", null);
                    if (cursor.moveToFirst()) {
                        count = cursor.getInt(0);
                    }
                    cursor.close();
                }
            }
            
            Log.i(TAG, "删除order_items数据完成，数量：" + count);
        } catch (Exception e) {
            Log.e(TAG, "删除order_items数据失败", e);
            // 备选方案B：使用更简单的删除条件（可能不够精确但不会崩溃）
            try {
                String fallbackSql = "DELETE FROM order_items WHERE order_cloud_id IN (" +
                    "SELECT cloud_id FROM orders WHERE date < ? AND is_deleted = 0)";
                db.execSQL(fallbackSql, new Object[]{cutoffDate});
                
                cursor = db.rawQuery("SELECT changes()", null);
                if (cursor.moveToFirst()) {
                    count = cursor.getInt(0);
                }
                Log.i(TAG, "使用备选方案删除order_items数据，数量：" + count);
            } catch (Exception fallbackEx) {
                Log.e(TAG, "备选方案也失败", fallbackEx);
            }
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        
        return count;
    }
    
    /**
     * 删除已迁移的logistics_forms数据
     */
    private static int deleteMigratedLogisticsForms(SQLiteDatabase db, String cutoffDate) {
        String sql = "DELETE FROM logistics_forms WHERE date < ?";
        db.execSQL(sql, new Object[]{cutoffDate});
        
        Cursor cursor = db.rawQuery("SELECT changes()", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        
        Log.i(TAG, "删除logistics_forms数据完成，数量：" + count);
        return count;
    }
    
    /**
     * 插入归档日志
     */
    private static long insertArchiveLog(SQLiteDatabase db, String batchId, String archiveDate, 
                                        String tableName, long startTime, int migrated, int deleted, 
                                        String status, String error) {
        String sql = "INSERT INTO archive_logs (" +
            "batch_id, archive_date, table_name, records_migrated, records_deleted, " +
            "start_time, end_time, status, error_message" +
            ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        db.execSQL(sql, new Object[]{
            batchId, archiveDate, tableName, migrated, deleted,
            startTime, null, status, error
        });
        
        Cursor cursor = db.rawQuery("SELECT last_insert_rowid()", null);
        long id = -1;
        if (cursor.moveToFirst()) {
            id = cursor.getLong(0);
        }
        cursor.close();
        
        return id;
    }
    
    /**
     * 更新归档日志
     */
    private static void updateArchiveLog(SQLiteDatabase db, long logId, long endTime, 
                                        String status, String error) {
        if (logId <= 0) return;
        
        String sql = "UPDATE archive_logs SET end_time = ?, status = ?, error_message = ? WHERE id = ?";
        db.execSQL(sql, new Object[]{endTime, status, error, logId});
    }
    
    /**
     * 校验归档完整性
     */
    public static ArchiveIntegrityResult verifyArchiveIntegrity(Context ctx, String batchId) {
        DatabaseHelper dbHelper = new DatabaseHelper(ctx);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        
        ArchiveIntegrityResult result = new ArchiveIntegrityResult();
        result.batchId = batchId;
        
        try {
            // 1. 检查归档日志
            Cursor cursor = db.rawQuery(
                "SELECT status, error_message FROM archive_logs WHERE batch_id = ? ORDER BY id DESC LIMIT 1",
                new String[]{batchId}
            );
            if (cursor.moveToFirst()) {
                result.logStatus = cursor.getString(0);
                result.errorMessage = cursor.getString(1);
            }
            cursor.close();
            
            // 2. 检查orders迁移完整性
            cursor = db.rawQuery(
                "SELECT COUNT(*) FROM orders_archive WHERE archive_batch_id = ?",
                new String[]{batchId}
            );
            if (cursor.moveToFirst()) {
                result.ordersInArchive = cursor.getInt(0);
            }
            cursor.close();
            
            // 3. 检查order_items迁移完整性
            cursor = db.rawQuery(
                "SELECT COUNT(*) FROM order_items_archive WHERE archive_batch_id = ?",
                new String[]{batchId}
            );
            if (cursor.moveToFirst()) {
                result.orderItemsInArchive = cursor.getInt(0);
            }
            cursor.close();
            
            // 4. 检查logistics_forms迁移完整性
            cursor = db.rawQuery(
                "SELECT COUNT(*) FROM logistics_forms_archive WHERE archive_batch_id = ?",
                new String[]{batchId}
            );
            if (cursor.moveToFirst()) {
                result.logisticsFormsInArchive = cursor.getInt(0);
            }
            cursor.close();
            
            // 5. 检查主表是否还有旧数据
            String twoYearsAgo = getDateTwoYearsAgo();
            cursor = db.rawQuery(
                "SELECT COUNT(*) FROM orders WHERE date < ? AND is_deleted = 0",
                new String[]{twoYearsAgo}
            );
            if (cursor.moveToFirst()) {
                result.ordersRemaining = cursor.getInt(0);
            }
            cursor.close();
            
            // 6. 计算完整性评分
            result.calculateIntegrityScore();
            
            Log.i(TAG, String.format("归档完整性校验：批次=%s, 状态=%s, 评分=%d",
                batchId, result.logStatus, result.integrityScore));
                
        } catch (Exception e) {
            Log.e(TAG, "归档完整性校验失败", e);
            result.errorMessage = e.getMessage();
            result.integrityScore = 0;
        } finally {
            if (db != null && db.isOpen()) {
                db.close();
            }
        }
        
        return result;
    }
    
    /**
     * 生成归档批次ID
     */
    public static String generateBatchId() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US);
        return "ARCHIVE_" + sdf.format(new Date());
    }
    
    /**
     * 获取归档统计信息
     */
    public static ArchiveStats getArchiveStats(Context ctx) {
        DatabaseHelper dbHelper = new DatabaseHelper(ctx);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        
        ArchiveStats stats = new ArchiveStats();
        
        try {
            // 归档表记录数
            Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM orders_archive", null);
            if (cursor.moveToFirst()) stats.totalOrdersArchived = cursor.getInt(0);
            cursor.close();
            
            cursor = db.rawQuery("SELECT COUNT(*) FROM order_items_archive", null);
            if (cursor.moveToFirst()) stats.totalOrderItemsArchived = cursor.getInt(0);
            cursor.close();
            
            cursor = db.rawQuery("SELECT COUNT(*) FROM logistics_forms_archive", null);
            if (cursor.moveToFirst()) stats.totalLogisticsFormsArchived = cursor.getInt(0);
            cursor.close();
            
            // 归档批次统计
            cursor = db.rawQuery("SELECT COUNT(DISTINCT batch_id) FROM archive_logs WHERE status = 'SUCCESS'", null);
            if (cursor.moveToFirst()) stats.successfulBatches = cursor.getInt(0);
            cursor.close();
            
            cursor = db.rawQuery("SELECT COUNT(DISTINCT batch_id) FROM archive_logs WHERE status = 'FAILED'", null);
            if (cursor.moveToFirst()) stats.failedBatches = cursor.getInt(0);
            cursor.close();
            
            // 最近归档时间
            cursor = db.rawQuery("SELECT MAX(archive_date) FROM archive_logs WHERE status = 'SUCCESS'", null);
            if (cursor.moveToFirst()) stats.lastArchiveDate = cursor.getString(0);
            cursor.close();
            
            Log.i(TAG, String.format("归档统计：orders=%d, order_items=%d, logistics_forms=%d",
                stats.totalOrdersArchived, stats.totalOrderItemsArchived, stats.totalLogisticsFormsArchived));
                
        } catch (Exception e) {
            Log.e(TAG, "获取归档统计失败", e);
        } finally {
            if (db != null && db.isOpen()) {
                db.close();
            }
        }
        
        return stats;
    }
}

/**
 * 归档扫描结果
 */
class ArchiveScanResult {
    int ordersCount = 0;
    int orderItemsCount = 0;
    int logisticsFormsCount = 0;
    
    public int getTotalCount() {
        return ordersCount + orderItemsCount + logisticsFormsCount;
    }
    
    public boolean hasDataToArchive() {
        return getTotalCount() > 0;
    }
    
    @Override
    public String toString() {
        return String.format("ArchiveScanResult{orders=%d, orderItems=%d, logisticsForms=%d, total=%d}",
            ordersCount, orderItemsCount, logisticsFormsCount, getTotalCount());
    }
}

/**
 * 归档执行结果
 */
class ArchiveResult {
    String batchId;
    String status = "PENDING";
    long startTime;
    long endTime;
    String errorMessage;
    
    int ordersMigrated = 0;
    int orderItemsMigrated = 0;
    int logisticsFormsMigrated = 0;
    
    int ordersDeleted = 0;
    int orderItemsDeleted = 0;
    int logisticsFormsDeleted = 0;
    
    public long getDuration() {
        return endTime - startTime;
    }
    
    public boolean isSuccess() {
        return "SUCCESS".equals(status);
    }
    
    public int getTotalMigrated() {
        return ordersMigrated + orderItemsMigrated + logisticsFormsMigrated;
    }
    
    public int getTotalDeleted() {
        return ordersDeleted + orderItemsDeleted + logisticsFormsDeleted;
    }
    
    @Override
    public String toString() {
        return String.format("ArchiveResult{batchId=%s, status=%s, duration=%dms, " +
            "migrated=%d, deleted=%d, error=%s}",
            batchId, status, getDuration(), getTotalMigrated(), getTotalDeleted(), errorMessage);
    }
}

/**
 * 归档完整性校验结果
 */
class ArchiveIntegrityResult {
    String batchId;
    String logStatus;
    String errorMessage;
    int integrityScore = 0; // 0-100分
    
    int ordersInArchive = 0;
    int orderItemsInArchive = 0;
    int logisticsFormsInArchive = 0;
    int ordersRemaining = 0;
    
    public void calculateIntegrityScore() {
        int score = 0;
        
        // 日志状态（40分）
        if ("SUCCESS".equals(logStatus)) {
            score += 40;
        } else if ("FAILED".equals(logStatus)) {
            score += 10;
        }
        
        // 归档数据存在（30分）
        if (ordersInArchive > 0) score += 10;
        if (orderItemsInArchive > 0) score += 10;
        if (logisticsFormsInArchive > 0) score += 10;
        
        // 主表清理情况（30分）
        if (ordersRemaining == 0) {
            score += 30;
        } else if (ordersRemaining < 10) {
            score += 20;
        } else if (ordersRemaining < 100) {
            score += 10;
        }
        
        this.integrityScore = Math.min(100, score);
    }
    
    public boolean isIntegrityGood() {
        return integrityScore >= 80;
    }
    
    @Override
    public String toString() {
        return String.format("ArchiveIntegrityResult{batchId=%s, status=%s, score=%d, " +
            "ordersInArchive=%d, orderItemsInArchive=%d, logisticsFormsInArchive=%d, ordersRemaining=%d}",
            batchId, logStatus, integrityScore, ordersInArchive, orderItemsInArchive, 
            logisticsFormsInArchive, ordersRemaining);
    }
}

/**
 * 归档统计信息
 */
class ArchiveStats {
    int totalOrdersArchived = 0;
    int totalOrderItemsArchived = 0;
    int totalLogisticsFormsArchived = 0;
    int successfulBatches = 0;
    int failedBatches = 0;
    String lastArchiveDate;
    
    public int getTotalArchived() {
        return totalOrdersArchived + totalOrderItemsArchived + totalLogisticsFormsArchived;
    }
    
    public int getTotalBatches() {
        return successfulBatches + failedBatches;
    }
    
    public double getSuccessRate() {
        if (getTotalBatches() == 0) return 0.0;
        return (double) successfulBatches / getTotalBatches() * 100.0;
    }
    
    @Override
    public String toString() {
        return String.format("ArchiveStats{totalArchived=%d, orders=%d, orderItems=%d, logisticsForms=%d, " +
            "batches=%d(success=%d, failed=%d, rate=%.1f%%), lastDate=%s}",
            getTotalArchived(), totalOrdersArchived, totalOrderItemsArchived, totalLogisticsFormsArchived,
            getTotalBatches(), successfulBatches, failedBatches, getSuccessRate(), lastArchiveDate);
    }
}