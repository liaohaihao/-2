package com.suzai.suzaiflowersystem;

/**
 * 新增订单页面的“多产品”行项目。
 */
public class OrderLine {
    private String productName;
    private int pieces;
    private int quantity;
    private double price;
    private String remark;

    public OrderLine(String productName, int pieces, int quantity, double price) {
        this(productName, pieces, quantity, price, "");
    }

    public OrderLine(String productName, int pieces, int quantity, double price, String remark) {
        this.productName = productName;
        this.pieces = pieces;
        this.quantity = quantity;
        this.price = price;
        this.remark = remark == null ? "" : remark.trim();
    }

    public String getProductName() {
        return productName;
    }

    public int getPieces() {
        return pieces;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getPrice() {
        return price;
    }

    public String getRemark() {
        return remark == null ? "" : remark;
    }

    public double getTotalPrice() {
        return quantity * price;
    }
}
