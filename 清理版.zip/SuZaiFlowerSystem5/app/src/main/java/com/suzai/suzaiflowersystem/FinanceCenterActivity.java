package com.suzai.suzaiflowersystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * Step3：财务中心入口
 * - 应收汇总
 * - 对账（可导出Excel）
 * - 客户账期（可导出Excel）
 */
public class FinanceCenterActivity extends BaseDrawerActivity {

    private Button btnReceivables, btnReconcile, btnTerms;
    private Button btnArInvoices, btnArPayments, btnArAlloc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("应收/对账");
        setContentLayout(R.layout.activity_finance_center);

        btnReceivables = findViewById(R.id.btn_receivables);
        btnReconcile = findViewById(R.id.btn_reconcile);
        btnTerms = findViewById(R.id.btn_terms);

        btnArInvoices = findViewById(R.id.btn_ar_invoices);
        btnArPayments = findViewById(R.id.btn_ar_payments);
        btnArAlloc = findViewById(R.id.btn_ar_alloc);

        btnReceivables.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(FinanceCenterActivity.this, ReceivablesActivity.class));
            }
        });
        btnReconcile.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(FinanceCenterActivity.this, ReconciliationActivity.class));
            }
        });
        btnTerms.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(FinanceCenterActivity.this, CustomerTermsActivity.class));
            }
        });

        // ✅ 云端财务（AR）
        btnArInvoices.setOnClickListener(v -> startActivity(new Intent(FinanceCenterActivity.this, ArInvoicesActivity.class)));
        btnArPayments.setOnClickListener(v -> startActivity(new Intent(FinanceCenterActivity.this, ArPaymentsActivity.class)));
        btnArAlloc.setOnClickListener(v -> startActivity(new Intent(FinanceCenterActivity.this, ArAllocationsActivity.class)));
    }
}
