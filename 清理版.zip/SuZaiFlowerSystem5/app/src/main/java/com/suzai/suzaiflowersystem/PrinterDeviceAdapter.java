package com.suzai.suzaiflowersystem;

import android.Manifest;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PrinterDeviceAdapter extends RecyclerView.Adapter<PrinterDeviceAdapter.VH> {

    public interface OnDeviceClickListener {
        void onClick(BluetoothDevice device);
    }

    private final List<BluetoothDevice> devices;
    private final OnDeviceClickListener listener;

    public PrinterDeviceAdapter(List<BluetoothDevice> devices, OnDeviceClickListener listener) {
        this.devices = devices;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_printer_device, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        BluetoothDevice d = devices.get(position);
        holder.bind(d, listener);
    }

    @Override
    public int getItemCount() {
        return devices == null ? 0 : devices.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView name;
        TextView address;

        VH(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.printerNameTextView);
            address = itemView.findViewById(R.id.printerAddressTextView);
        }

        void bind(BluetoothDevice d, OnDeviceClickListener listener) {
            String devName = "未知设备";
            try {
                Context ctx = itemView.getContext();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                        devName = "未知设备";
                    } else {
                        String n = d.getName();
                        devName = (n == null || n.isEmpty()) ? "未知设备" : n;
                    }
                } else {
                    String n = d.getName();
                    devName = (n == null || n.isEmpty()) ? "未知设备" : n;
                }
            } catch (Exception ignored) {
            }

            name.setText(devName);
            address.setText(d.getAddress());

            itemView.setOnClickListener(v -> {
                if (listener != null) listener.onClick(d);
            });
        }
    }
}
