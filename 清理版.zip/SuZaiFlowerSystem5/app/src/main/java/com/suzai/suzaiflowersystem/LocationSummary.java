package com.suzai.suzaiflowersystem;

public class LocationSummary {
    private final String locationName;
    private final int totalPieces;

    public LocationSummary(String locationName, int totalPieces) {
        this.locationName = locationName;
        this.totalPieces = totalPieces;
    }

    public String getLocationName() {
        return locationName;
    }

    public int getTotalPieces() {
        return totalPieces;
    }
}
