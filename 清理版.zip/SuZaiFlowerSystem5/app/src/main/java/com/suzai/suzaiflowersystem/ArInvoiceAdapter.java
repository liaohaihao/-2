package com.suzai.suzaiflowersystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ArInvoiceAdapter extends RecyclerView.Adapter<ArInvoiceAdapter.VH> {

    public interface OnClick {
        void onItem(ArInvoiceRow row);
    }

    private final List<ArInvoiceRow> data = new ArrayList<>();
    private final OnClick onClick;

    public ArInvoiceAdapter(OnClick onClick) {
        this.onClick = onClick;
    }

    public void setData(List<ArInvoiceRow> list) {
        data.clear();
        if (list != null) data.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_ar_invoice, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        ArInvoiceRow r = data.get(position);
        h.tvTitle.setText(String.format(Locale.getDefault(), "%s  %s  %s", nvl(r.siteName), nvl(r.periodYm), nvl(r.customerName)));
        h.tvSub.setText(String.format(Locale.getDefault(), "金额：%.2f   状态：%s%s", r.amount, nvl(r.status),
                (r.note == null || r.note.trim().isEmpty()) ? "" : ("   备注：" + r.note)));
        h.itemView.setOnClickListener(v -> {
            if (onClick != null) onClick.onItem(r);
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvTitle, tvSub;
        VH(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvSub = itemView.findViewById(R.id.tv_sub);
        }
    }

    private static String nvl(String s) { return s == null ? "" : s; }
}
