package com.suzai.suzaiflowersystem;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddCustomerActivity extends BaseDrawerActivity {

    private EditText nameEditText;
    private EditText contactEditText;
    private Button saveButton;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("新增客户");
        setContentLayout(R.layout.activity_add_customer);

        initializeViews();
        databaseHelper = new DatabaseHelper(this);
        setupSaveButton();
    }

    private void initializeViews() {
        nameEditText = findViewById(R.id.nameEditText);
        contactEditText = findViewById(R.id.contactEditText);
        saveButton = findViewById(R.id.saveButton);
    }

    private void setupSaveButton() {
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCustomer();
            }
        });
    }

    private void saveCustomer() {
        String name = nameEditText.getText().toString().trim();
        String contact = contactEditText.getText().toString().trim();

        if (name.isEmpty()) {
            Toast.makeText(this, "请输入客户名称", Toast.LENGTH_SHORT).show();
            return;
        }

        long result = databaseHelper.addCustomer(name, contact);

        if (result != -1) {
            Toast.makeText(this, "客户保存成功", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "客户保存失败", Toast.LENGTH_SHORT).show();
        }
    }
}