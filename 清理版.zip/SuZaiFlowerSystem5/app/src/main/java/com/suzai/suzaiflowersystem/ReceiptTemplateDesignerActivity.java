package com.suzai.suzaiflowersystem;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

/**
 * 小票模板设计器（送货单/物流单）
 * - 左侧：模板名称 + 内容编辑
 * - 顶部：字段插入快捷按钮
 * - 右侧：WebView 实时预览
 */
public class ReceiptTemplateDesignerActivity extends AppCompatActivity {

    public static final String EXTRA_TEMPLATE_ID = "template_id";
    public static final String EXTRA_TYPE = "type";

    private DatabaseHelper db;
    private long templateId;
    private String type;

    private EditText etName;
    private EditText etContent;
    private WebView webPreview;

    private boolean dirty = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("设计小票模板");
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        setContentView(R.layout.activity_receipt_template_designer);

        db = new DatabaseHelper(this);
        templateId = getIntent().getLongExtra(EXTRA_TEMPLATE_ID, -1);
        type = getIntent().getStringExtra(EXTRA_TYPE);

        etName = findViewById(R.id.etTplName);
        etContent = findViewById(R.id.etTplContent);
        webPreview = findViewById(R.id.webTplPreview);

        webPreview.getSettings().setJavaScriptEnabled(false);

        Button btnSave = findViewById(R.id.btnTplSave);

        initFieldButtons();

        PrintTemplate tpl = db.getTemplateById(templateId);
        if (tpl == null) {
            Toast.makeText(this, "模板不存在", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        if (TextUtils.isEmpty(type)) type = tpl.getType();

        etName.setText(safe(tpl.getName()));
        etContent.setText(safe(tpl.getContent()));

        renderPreview();

        etContent.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                dirty = true;
                renderPreview();
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        btnSave.setOnClickListener(v -> save());
    }

    private void initFieldButtons() {
        LinearLayout box = findViewById(R.id.boxFieldButtons);

        // 基础结构按钮
        addBtn(box, "居中标题", () -> insertAtCursor("<CB>标题</CB>\n"));
        addBtn(box, "加粗行", () -> insertAtCursor("<B>加粗内容</B>\n"));
        addBtn(box, "空行", () -> insertAtCursor("<BR>\n"));
        addBtn(box, "分隔线", () -> insertAtCursor("--------------------------------\n"));

        // 字段按钮
        addBtn(box, "客户", () -> insertAtCursor("客户：{{customer}}\n"));
        addBtn(box, "时间", () -> insertAtCursor("时间：{{date}}\n"));
        addBtn(box, "订单号", () -> insertAtCursor("订单号：{{order_no}}\n"));
        addBtn(box, "备注", () -> insertAtCursor("备注：{{remark}}\n"));
        addBtn(box, "发货场地", () -> insertAtCursor("发货场地：{{location}}\n"));

        // 送货单字段
        addBtn(box, "明细表", () -> insertAtCursor("名称        单价  装箱数  数量   金额   件数\n{{items}}\n"));
        addBtn(box, "总件数", () -> insertAtCursor("总件数：{{total_pieces}}\n"));
        addBtn(box, "合计", () -> insertAtCursor("<B>合计：{{total_amount}}</B>\n"));

        // 物流单字段
        addBtn(box, "体积CBM", () -> insertAtCursor("总CBM：{{cbm}}\n"));
        addBtn(box, "联系人", () -> insertAtCursor("联系人：{{contact}}\n"));
        addBtn(box, "电话", () -> insertAtCursor("电话：{{phone}}\n"));
    }

    private void addBtn(LinearLayout box, String text, Runnable r) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(text);
        b.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(dp(6), dp(4), dp(6), dp(4));
        box.addView(b, lp);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void insertAtCursor(String s) {
        if (TextUtils.isEmpty(s)) return;
        int start = Math.max(0, etContent.getSelectionStart());
        int end = Math.max(0, etContent.getSelectionEnd());
        Editable ed = etContent.getText();
        if (ed == null) return;
        ed.replace(Math.min(start, end), Math.max(start, end), s);
        etContent.requestFocus();
        etContent.setSelection(Math.min(ed.length(), start + s.length()));
    }

    private void renderPreview() {
        String html = PrintMarkupRenderer.toPreviewHtml(etContent.getText() == null ? "" : etContent.getText().toString(), type);
        webPreview.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
    }

    private void save() {
        String name = etName.getText() == null ? "" : etName.getText().toString().trim();
        String content = etContent.getText() == null ? "" : etContent.getText().toString();

        if (TextUtils.isEmpty(name)) {
            Toast.makeText(this, "请填写模板名称", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(content)) {
            Toast.makeText(this, "模板内容不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            db.updateTemplate(templateId, name, content, System.currentTimeMillis());
            dirty = false;
            Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
        } catch (Exception e) {
            Toast.makeText(this, "保存失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private static String safe(String s) { return s == null ? "" : s; }
}