package com.suzai.suzaiflowersystem;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 模板中心（客户标签/送货单/物流单）
 *
 * 重要：此文件为“可直接覆盖版”，完全匹配当前项目中的 activity_template_center.xml 的控件 id：
 * spTemplateType / btnAddTemplate / btnImportTemplate / btnPreviewTemplate / btnSetDefault / btnReload / lvTemplates
 *
 * 同时：ListView 使用 CHOICE_MODE_SINGLE + simple_list_item_single_choice，实现“勾选后再设为默认”。
 */
public class TemplateCenterActivity extends BaseDrawerActivity {

    public static final String EXTRA_TYPE = "type";

    // 被其他页面引用（请保持名称不变）
    public static final String TYPE_LABEL = "LABEL";
    public static final String TYPE_DELIVERY = "DELIVERY";
    public static final String TYPE_LOGISTICS = "LOGISTICS";

    private Spinner spType;
    private Button btnAdd;
    private Button btnImport;
    private Button btnPreview;
    private Button btnSetDefault;
    private Button btnDelete;
    private Button btnReload;
    private ListView lv;

    private DatabaseHelper db;

    private final List<PrintTemplate> currentTemplates = new ArrayList<>();
    private final List<String> displayItems = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    private String currentType = TYPE_LABEL;
    private long selectedTemplateId = -1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentLayout(R.layout.activity_template_center);
        if (toolbar != null) toolbar.setTitle("模板中心");
        android.view.View lite = findViewById(R.id.toolbarLite);
        if (lite != null) lite.setVisibility(android.view.View.GONE);

        db = new DatabaseHelper(this);

        spType = findViewById(R.id.spTemplateType);
        btnAdd = findViewById(R.id.btnAddTemplate);
        btnImport = findViewById(R.id.btnImportTemplate);
        btnPreview = findViewById(R.id.btnPreviewTemplate);
        btnSetDefault = findViewById(R.id.btnSetDefault);
        btnDelete = findViewById(R.id.btnDeleteTemplate);
        btnReload = findViewById(R.id.btnReload);
        lv = findViewById(R.id.lvTemplates);

        // ✅ 勾选框/单选框：ListView 单选模式
        lv.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_single_choice,
                displayItems
        );
        lv.setAdapter(adapter);

        initTypeSpinner();

        // 外部跳转指定类型
        String t = getIntent().getStringExtra(EXTRA_TYPE);
        if (!TextUtils.isEmpty(t)) {
            currentType = t;
            selectSpinnerByType(currentType);
        }

        lv.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < currentTemplates.size()) {
                PrintTemplate tpl = currentTemplates.get(position);
                selectedTemplateId = tpl.getId();
                lv.setItemChecked(position, true);
            }
        });

        // 长按条目：进入编辑
        lv.setOnItemLongClickListener((parent, view, position, id) -> {
            if (position < 0 || position >= currentTemplates.size()) return true;
            PrintTemplate tpl = currentTemplates.get(position);
            openEdit(tpl.getId());
            return true;
        });

        btnAdd.setOnClickListener(v -> {
            // ✅ 标签模板：新增时先弹窗输入名称（体验与送货单一致），再进入拖拽编辑器
            if (TYPE_LABEL.equals(currentType)) {
                showCreateLabelTemplateDialog();
            } else {
                openEdit(-1);
            }
        });
        btnImport.setOnClickListener(v -> showImportDialog());

        btnPreview.setOnClickListener(v -> {
            if (selectedTemplateId <= 0) {
                toast("请先点选一个模板再预览");
                return;
            }
            Intent it = new Intent(this, TemplatePreviewActivity.class);
            it.putExtra("template_id", selectedTemplateId);
            it.putExtra(EXTRA_TYPE, currentType);
            startActivity(it);
        });

        // ✅ 修复点：DatabaseHelper.setDefaultTemplate(...) 是 void，不要用 boolean 接
        btnSetDefault.setOnClickListener(v -> {
            if (selectedTemplateId <= 0) {
                toast("请先点选一个模板再设为默认");
                return;
            }
            try {
                db.setDefaultTemplate(currentType, selectedTemplateId); // void
                toast("已设为默认");
                // ✅ 重要：把“默认模板”状态推送到云端，卸载重装可恢复
                try { SupabaseSyncManager.schedulePush(getApplicationContext()); } catch (Exception ignored) {}
                reload();
            } catch (Exception e) {
                toast("设置失败：" + e.getMessage());
            }
        });

        // ✅ 删除模板
        btnDelete.setOnClickListener(v -> {
            if (selectedTemplateId <= 0) {
                toast("请先点选一个模板再删除");
                return;
            }
            PrintTemplate cur = db.getTemplateById(selectedTemplateId);
            String name = (cur == null) ? "" : safe(cur.getName());
            new AlertDialog.Builder(this)
                    .setTitle("删除模板")
                    .setMessage("确定删除模板：" + (TextUtils.isEmpty(name) ? ("#" + selectedTemplateId) : name) + " ？")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("删除", (d, which) -> {
                        try {
                            db.deleteTemplate(selectedTemplateId);
                            toast("已删除");
                            selectedTemplateId = -1;
                            reload();
                        } catch (Exception e) {
                            toast("删除失败：" + e.getMessage());
                        }
                    })
                    .show();
        });

        btnReload.setOnClickListener(v -> reload());

        btnDelete.setOnClickListener(v -> {
            if (selectedTemplateId <= 0) {
                toast("请先点选一个模板再删除");
                return;
            }
            PrintTemplate selected = db.getTemplateById(selectedTemplateId);
            String name = selected == null ? "" : safe(selected.getName());
            new AlertDialog.Builder(this)
                    .setTitle("删除模板")
                    .setMessage("确定删除：" + (TextUtils.isEmpty(name) ? ("ID=" + selectedTemplateId) : name) + " ？\n删除后不可恢复。")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("删除", (d, which) -> {
                        try {
                            db.deleteTemplate(selectedTemplateId);
                            selectedTemplateId = -1;
                            toast("已删除");
                            reload();
                        } catch (Exception e) {
                            toast("删除失败：" + e.getMessage());
                        }
                    })
                    .show();
        });

        reload();
    }

    private void initTypeSpinner() {
        List<String> labels = new ArrayList<>();
        labels.add("客户标签");
        labels.add("送货单");
        labels.add("物流单");

        ArrayAdapter<String> spAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                labels
        );
        spType.setAdapter(spAdapter);

        spType.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
                String newType = (position == 0) ? TYPE_LABEL : (position == 1) ? TYPE_DELIVERY : TYPE_LOGISTICS;
                if (!TextUtils.equals(currentType, newType)) {
                    currentType = newType;
                    selectedTemplateId = -1;
                    reload();
                }
                updateTitle();
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {
            }
        });

        updateTitle();
    }

    private void selectSpinnerByType(@NonNull String type) {
        int pos = 0;
        if (TYPE_DELIVERY.equals(type)) pos = 1;
        else if (TYPE_LOGISTICS.equals(type)) pos = 2;
        spType.setSelection(pos);
    }

    private void updateTitle() {
        String title;
        if (TYPE_DELIVERY.equals(currentType)) title = "模板中心 - 送货单";
        else if (TYPE_LOGISTICS.equals(currentType)) title = "模板中心 - 物流单";
        else title = "模板中心 - 客户标签";
        setTitle(title);
    }

    private void openEdit(long templateId) {
        Intent it = new Intent(this, TemplateEditActivity.class);
        it.putExtra(EXTRA_TYPE, currentType);
        if (templateId > 0) it.putExtra("template_id", templateId);
        startActivity(it);
    }

    @Override
    protected void onResume() {
        super.onResume();
        reload();
    }

    private void reload() {
        currentTemplates.clear();
        displayItems.clear();

        List<PrintTemplate> list = db.getTemplatesByType(currentType);
        if (list != null) currentTemplates.addAll(list);

        int checkedPos = -1;
        for (int i = 0; i < currentTemplates.size(); i++) {
            PrintTemplate t = currentTemplates.get(i);
            String name = safe(t.getName());
            if (t.getIsDefault() == 1) {
                name = name + "（默认）";
                // 若没有选中项，默认选中默认模板
                if (selectedTemplateId <= 0) {
                    selectedTemplateId = t.getId();
                }
            }
            String time = formatTime(t.getUpdatedAt());
            displayItems.add(name + " · " + time);

            if (t.getId() == selectedTemplateId) {
                checkedPos = i;
            }
        }

        adapter.notifyDataSetChanged();

        // 勾选显示
        lv.clearChoices();
        if (checkedPos >= 0) {
            lv.setItemChecked(checkedPos, true);
        }
    }

    private void showImportDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);

        EditText etName = new EditText(this);
        etName.setHint("模板名称");
        etName.setInputType(InputType.TYPE_CLASS_TEXT);
        root.addView(etName, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        EditText etContent = new EditText(this);
        etContent.setHint("模板内容（复制粘贴）");
        etContent.setMinLines(6);
        etContent.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.topMargin = pad / 2;
        root.addView(etContent, lp);

        new AlertDialog.Builder(this)
                .setTitle("导入模板")
                .setView(root)
                .setNegativeButton("取消", null)
                .setPositiveButton("导入", (d, which) -> {
                    String name = safe(etName.getText());
                    String content = safe(etContent.getText());
                    if (TextUtils.isEmpty(name) || TextUtils.isEmpty(content)) {
                        toast("请输入模板名称和内容");
                        return;
                    }
                    long now = System.currentTimeMillis();
                    long id = db.insertTemplate(currentType, name, content, now, 0);
                    if (id > 0) {
                        toast("导入成功");
                        selectedTemplateId = id;
                        reload();
                    } else {
                        toast("导入失败");
                    }
                })
                .show();
    }

    /**
     * ✅ 标签模板新增：弹窗输入名称 -> 创建模板 -> 进入拖拽编辑器
     */
    private void showCreateLabelTemplateDialog() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);

        EditText etName = new EditText(this);
        etName.setHint("模板名称（例如：客户标签-竖排）");
        etName.setInputType(InputType.TYPE_CLASS_TEXT);
        root.addView(etName, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        new AlertDialog.Builder(this)
                .setTitle("新增标签模板")
                .setView(root)
                .setNegativeButton("取消", null)
                .setPositiveButton("创建", (d, which) -> {
                    String name = safe(etName.getText());
                    if (TextUtils.isEmpty(name)) {
                        name = "客户标签模板";
                    }
                    String content = safe(db.getDefaultTemplateContent(TYPE_LABEL));
                    long now = System.currentTimeMillis();
                    long id;
                    try {
                        id = db.insertTemplate(TYPE_LABEL, name, content, now, 0);
                    } catch (Exception e) {
                        toast("创建失败：" + e.getMessage());
                        return;
                    }
                    if (id > 0) {
                        selectedTemplateId = id;
                        // 直接进入拖拽编辑器（无需再中转 TemplateEditActivity）
                        Intent it = new Intent(this, DraggableLabelTemplateEditActivity.class);
                        it.putExtra(TemplateEditActivity.EXTRA_TEMPLATE_ID, id);
                        it.putExtra(EXTRA_TYPE, TYPE_LABEL);
                        startActivity(it);
                    } else {
                        toast("创建失败");
                    }
                })
                .show();
    }

    private String formatTime(long ts) {
        try {
            return new SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(new Date(ts));
        } catch (Exception e) {
            return "";
        }
    }

    private static String safe(@Nullable Object o) {
        return o == null ? "" : String.valueOf(o).trim();
    }

    private void toast(@NonNull String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
