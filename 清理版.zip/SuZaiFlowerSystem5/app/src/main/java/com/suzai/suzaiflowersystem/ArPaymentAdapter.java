package com.suzai.suzaiflowersystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ArPaymentAdapter extends RecyclerView.Adapter<ArPaymentAdapter.VH> {

    public interface OnClick { void onItem(ArPaymentRow row); }

    private final List<ArPaymentRow> data = new ArrayList<>();
    private final OnClick onClick;

    public ArPaymentAdapter(OnClick onClick) {
        this.onClick = onClick;
    }

    public void setData(List<ArPaymentRow> list) {
        data.clear();
        if (list != null) data.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_ar_payment, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        ArPaymentRow r = data.get(position);
        h.tvTitle.setText(String.format(Locale.getDefault(), "%s  %s  %s", nvl(r.siteName), nvl(r.payDate), nvl(r.customerName)));
        h.tvSub.setText(String.format(Locale.getDefault(), "金额：%.2f%s%s", r.amount,
                (r.method == null || r.method.trim().isEmpty()) ? "" : ("   方式：" + r.method),
                (r.note == null || r.note.trim().isEmpty()) ? "" : ("   备注：" + r.note)));
        h.itemView.setOnClickListener(v -> { if (onClick != null) onClick.onItem(r); });
    }

    @Override
    public int getItemCount() { return data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvTitle, tvSub;
        VH(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvSub = itemView.findViewById(R.id.tv_sub);
        }
    }

    private static String nvl(String s) { return s == null ? "" : s; }
}
