package com.suzai.suzaiflowersystem;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class PrintManagementActivity extends BaseDrawerActivity {
    // ====== 送货单商品明细排版：与订单管理界面保持一致 ======
    private static final int UNITS_NAME_MAX_NORMAL = 26;
    private static final int UNITS_NAME_MAX_BOLD = 24;
    private static final int W_PRICE = 8;
    private static final int W_PACK = 6;
    private static final int W_QTY = 6;
    private static final int W_AMOUNT = 10;
    private static final int W_PIECES = 4;
    private static final int GAP_BLANK_LINES_BETWEEN_ITEMS = 1;


    private DatabaseHelper db;
    private RecyclerView rv;
    private TextView tvDate;
    private TextView tvLabelStatus;
    private RadioGroup sortGroup;

    private String today;

    private static final String LOW_STOCK_PREF = "low_stock_pref";
    private static final String KEY_SNOOZE_DATE = "snooze_date";
    private static final String KEY_SNOOZE_IDS = "snooze_ids"; // comma separated ids

    // ✅ 箱唛打印进度（本地）：记录“某天已打印到的订单最大ID”
    private static final String LABEL_PRINT_PREF = "label_print_pref";
    private static final String KEY_LABEL_PRINTED_MAXID_PREFIX = "label_printed_maxid_";
    private static final String DELIVERY_PRINT_PREF = "delivery_print_pref";
    private static final String KEY_DELIVERY_PRINTED_DATE = "delivery_printed_date";

    private long getLabelPrintedMaxId(String date) {
        SharedPreferences sp = getSharedPreferences(LABEL_PRINT_PREF, MODE_PRIVATE);
        return sp.getLong(KEY_LABEL_PRINTED_MAXID_PREFIX + n(date), 0L);
    }

    private void setLabelPrintedMaxId(String date, long maxId) {
        if (maxId < 0) maxId = 0;
        SharedPreferences sp = getSharedPreferences(LABEL_PRINT_PREF, MODE_PRIVATE);
        sp.edit().putLong(KEY_LABEL_PRINTED_MAXID_PREFIX + n(date), maxId).apply();
    }


    private boolean wasDeliveryPrintedToday() {
        SharedPreferences sp = getSharedPreferences(DELIVERY_PRINT_PREF, MODE_PRIVATE);
        return today.equals(n(sp.getString(KEY_DELIVERY_PRINTED_DATE, "")));
    }

    private void markDeliveryPrintedToday() {
        SharedPreferences sp = getSharedPreferences(DELIVERY_PRINT_PREF, MODE_PRIVATE);
        sp.edit().putString(KEY_DELIVERY_PRINTED_DATE, today).apply();
    }

    private boolean wasAllLabelsPrintedToday() {
        long printedMaxId = getLabelPrintedMaxId(today);
        long maxId = 0L;
        try { maxId = db.getMaxOrderIdByDate(today); } catch (Exception ignored) {}
        return printedMaxId > 0 && maxId > 0 && printedMaxId >= maxId;
    }

    private boolean isSnoozedToday(long itemId) {
        SharedPreferences sp = getSharedPreferences(LOW_STOCK_PREF, MODE_PRIVATE);
        String date = sp.getString(KEY_SNOOZE_DATE, "");
        if (!today.equals(date)) return false;
        String ids = sp.getString(KEY_SNOOZE_IDS, "");
        return ("," + ids + ",").contains("," + itemId + ",");
    }

    private void snoozeToday(long itemId) {
        SharedPreferences sp = getSharedPreferences(LOW_STOCK_PREF, MODE_PRIVATE);
        String date = sp.getString(KEY_SNOOZE_DATE, "");
        String ids = sp.getString(KEY_SNOOZE_IDS, "");
        if (!today.equals(date)) {
            date = today;
            ids = "";
        }
        if (!(("," + ids + ",").contains("," + itemId + ","))) {
            if (ids == null || ids.trim().isEmpty()) ids = String.valueOf(itemId);
            else ids = ids + "," + itemId;
        }
        sp.edit().putString(KEY_SNOOZE_DATE, today).putString(KEY_SNOOZE_IDS, ids).apply();
    }

    private void showLowStockDialogsSequentially(List<InventoryItem> lowList) {
        if (lowList == null || lowList.isEmpty()) return;

        List<InventoryItem> filtered = new ArrayList<>();
        for (InventoryItem it : lowList) {
            if (!isSnoozedToday(it.getId())) filtered.add(it);
        }
        if (filtered.isEmpty()) return;

        showLowStockDialogAt(filtered, 0);
    }

    private void showLowStockDialogAt(List<InventoryItem> list, int index) {
        if (list == null || index >= list.size()) return;
        InventoryItem it = list.get(index);

        String typeName = it.getType();
        if (DatabaseHelper.INV_TYPE_PRODUCT.equals(it.getType())) typeName = "产品";
        else if (DatabaseHelper.INV_TYPE_POT.equals(it.getType())) typeName = "花盆";
        else if (DatabaseHelper.INV_TYPE_BAG.equals(it.getType())) typeName = "套袋";

        String msg = typeName + "库存不足：\n" +
                it.getName() + "\n" +
                "当前库存：" + it.getQuantity() + "，安全库存：" + it.getSafetyStock();

        new AlertDialog.Builder(this)
                .setTitle("库存提醒")
                .setMessage(msg)
                .setPositiveButton("确定", (d, w) -> showLowStockDialogAt(list, index + 1))
                .setNegativeButton("今日不再提醒", (d, w) -> {
                    snoozeToday(it.getId());
                    showLowStockDialogAt(list, index + 1);
                })
                .setCancelable(false)
                .show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentLayout(R.layout.activity_print_management);
        setTitle("打印管理");

        db = new DatabaseHelper(this);

        tvDate = findViewById(R.id.printDateTextView);
        tvLabelStatus = findViewById(R.id.printLabelStatusTextView);
        rv = findViewById(R.id.printOrdersRecyclerView);
        sortGroup = findViewById(R.id.sortRadioGroup);

        Button btnPrint = findViewById(R.id.printTodayOrdersButton);
        Button btnClearPending = findViewById(R.id.btnClearPending);

        today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        tvDate.setText("日期：" + today);

        rv.setLayoutManager(new LinearLayoutManager(this));

        sortGroup.setOnCheckedChangeListener((g, checkedId) -> loadList());

        btnPrint.setOnClickListener(v -> showPrintMenu());
        if (btnClearPending != null) btnClearPending.setOnClickListener(v -> confirmClearPending());

        loadList();
    }

    @Override
    protected void onResume() {
        super.onResume();
        today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        if (tvDate != null) tvDate.setText("日期：" + today);
        loadList();
    }

    private void loadList() {
        List<Order> raw = db.getPendingLabelOrdersByDate(today);
        if (raw == null) raw = new ArrayList<>();

        int checked = sortGroup.getCheckedRadioButtonId();
        if (checked == R.id.rbByProduct) {
            Collections.sort(raw, (a, b) -> {
                String ak = n(a.getCustomerName()) + "|" + n(a.getProductName()) + "|" + n(a.getLocation());
                String bk = n(b.getCustomerName()) + "|" + n(b.getProductName()) + "|" + n(b.getLocation());
                return ak.compareTo(bk);
            });
        }

        LinkedHashMap<String, PrintOrdersAdapter.Row> map = new LinkedHashMap<>();
        for (Order o : raw) {
            String key = n(o.getCustomerName()) + "|" + n(o.getProductName()) + "|" + n(o.getLocation()) + "|" + n(o.getRemark());
            PrintOrdersAdapter.Row r = map.get(key);
            int pieces = safePieces(o);
            if (r == null) {
                map.put(key, new PrintOrdersAdapter.Row(o.getCustomerName(), o.getProductName(), pieces, o.getRemark(), o.getLocation()));
            } else {
                map.put(key, new PrintOrdersAdapter.Row(r.customer, r.product, r.pieces + pieces, r.remark, r.location));
            }
        }

        List<PrintOrdersAdapter.Row> rows = new ArrayList<>(map.values());
        rv.setAdapter(new PrintOrdersAdapter(rows));

        try {
            if (tvLabelStatus != null) {
                int pending = raw.size();
                String tip = "箱唛状态：待打印 " + pending + " 单";
                tvLabelStatus.setText(tip);
            }
        } catch (Exception ignored) {}
    }

    private void confirmClearPending() {
        List<Order> pending = db.getPendingLabelOrdersByDate(today);
        final int pendingCount = pending == null ? 0 : pending.size();
        if (pendingCount <= 0) {
            Toast.makeText(this, "今日没有待打印订单", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("清理待打印")
                .setMessage("确定将今日待打印订单全部标记为已打印吗？\n共 " + pendingCount + " 单")
                .setPositiveButton("确定", (d, w) -> {
                    int rows = 0;
                    try { rows = db.markPendingLabelOrdersPrintedByDate(today); } catch (Exception ignored) {}
                    loadList();
                    Toast.makeText(this, "已清理待打印：" + rows + " 单", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showPrintMenu() {
        String[] opts = new String[]{
                "打印今日全部订单（出货单）",
                "打印全部标签（箱唛）",
                "打印加单标签（未打印箱唛）",
                "打印物流单",
                "重置箱唛打印状态（让待打印恢复为全部）"
        };

        new AlertDialog.Builder(this)
                .setTitle("请选择打印内容")
                .setItems(opts, (d, which) -> {
                    if (which == 0) {
                        if (wasDeliveryPrintedToday()) {
                            new AlertDialog.Builder(this)
                                    .setTitle("重复打印提醒")
                                    .setMessage("今天已经打印过全部送货单，再次打印可能重复出单。是否继续？")
                                    .setPositiveButton("继续打印", (dd, ww) -> printTodayDelivery())
                                    .setNegativeButton("取消", null)
                                    .show();
                        } else {
                            printTodayDelivery();
                        }
                    } else if (which == 1) {
                        if (wasAllLabelsPrintedToday()) {
                            new AlertDialog.Builder(this)
                                    .setTitle("重复打印提醒")
                                    .setMessage("今天已经打印过全部箱唛，再次打印可能重复出签。是否继续？")
                                    .setPositiveButton("继续打印", (dd, ww) -> printTodayLabels(false))
                                    .setNegativeButton("取消", null)
                                    .show();
                        } else {
                            printTodayLabels(false);
                        }
                    } else if (which == 2) {
                        printTodayLabels(true);
                    } else {
                        if (which == 3) {
                            printTodayLogistics();
                        } else {
                            confirmResetLabelProgress();
                        }
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void confirmResetLabelProgress() {
        new AlertDialog.Builder(this)
                .setTitle("重置箱唛状态")
                .setMessage("重置后，待打印列表会恢复显示今日全部订单（用于重新打印箱唛）。确定要重置吗？")
                .setPositiveButton("确定", (d, w) -> {
                    setLabelPrintedMaxId(today, 0L);
                    loadList();
                    Toast.makeText(this, "已重置箱唛打印状态", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    // ----------------- 打印逻辑 -----------------

    /** ✅ 今日出货单：按客户分组，且同客户同产品合并 */
    private void printTodayDelivery() {
        List<Order> orders = keepTodayOrders(db.getOrdersByDate(today));
        if (orders == null || orders.isEmpty()) {
            Toast.makeText(this, "今日无订单", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, List<Order>> byCustomer = new LinkedHashMap<>();
        for (Order o : orders) {
            if (o == null) continue;
            String c = n(o.getCustomerName());
            if (!byCustomer.containsKey(c)) byCustomer.put(c, new ArrayList<>());
            byCustomer.get(c).add(o);
        }

        String tpl = db.getDefaultTemplateContent(TemplateCenterActivity.TYPE_DELIVERY);
        if (tpl == null) tpl = "";
        if (tpl.trim().isEmpty()) {
            Toast.makeText(this, "默认送货单模板为空，请到【模板中心】设置默认送货单模板", Toast.LENGTH_LONG).show();
            return;
        }

        int printed = 0;
        for (Map.Entry<String, List<Order>> e : byCustomer.entrySet()) {
            String customer = e.getKey();
            List<Order> list = e.getValue();
            List<Order> merged = mergeSameProduct(list);

            boolean isFeieyunMarkup = false;
            try {
                String t0 = tpl == null ? "" : tpl;
                isFeieyunMarkup = t0.contains("<BR>") || t0.contains("<CB>") || t0.contains("<C>") || t0.contains("<B>");
            } catch (Exception ignore) { }

            String itemsLinesNormal = buildDeliveryItemsLines(merged, false);
            String itemsLinesBold = buildDeliveryItemsLines(merged, true);
            if (isFeieyunMarkup) {
                itemsLinesNormal = toFeieyunBR(itemsLinesNormal);
                itemsLinesBold = toFeieyunBR(itemsLinesBold);
            }

            int totalPieces = 0;
            double totalAmount = 0.0;
            String currentLocation = "";
            for (Order o : merged) {
                if (o == null) continue;
                totalPieces += Math.max(0, o.getPieces());
                totalAmount += (o.getPrice() * o.getQuantity());
                if (currentLocation.isEmpty()) currentLocation = n(o.getLocation());
            }

            HashMap<String, String> vars = new HashMap<>();
            vars.put("customer", customer);
            vars.put("date", today);
            vars.put("location", currentLocation);
            vars.put("items", n(itemsLinesNormal));
            vars.put("items_lines", n(itemsLinesNormal));
            vars.put("items_lines_bold", n(itemsLinesBold));
            vars.put("total_pieces", String.valueOf(totalPieces));
            vars.put("total_amount", String.format(Locale.getDefault(), "%.2f", totalAmount));
            vars.put("order_no", today + "-" + customer);
            vars.put("remark", buildDeliveryRemark(list));
            vars.put("contact", "");
            vars.put("phone", "");

            String rendered = TemplateEngine.render(tpl, vars);
            String sendContent = rendered;
            try {
                String tt = tpl == null ? "" : tpl.trim();
                if (tt.startsWith("{") && (tt.contains("\"renderer\"") || tt.contains("\"els\""))) {
                    org.json.JSONObject wrap = new org.json.JSONObject();
                    wrap.put("__suzai_print", "v1");
                    wrap.put("tpl", new org.json.JSONObject(rendered));

                    org.json.JSONObject payload = new org.json.JSONObject();
                    org.json.JSONArray arr = new org.json.JSONArray();
                    for (Order o2 : list) {
                        if (o2 == null) continue;
                        int qty = Math.max(0, o2.getQuantity());
                        int pcs = Math.max(0, o2.getPieces());
                        double price = o2.getPrice();
                        double amount = price * qty;
                        int pack = (pcs > 0) ? (int) Math.round((double) qty / (double) pcs) : 0;

                        org.json.JSONObject row = new org.json.JSONObject();
                        row.put("name", n(o2.getProductName()));
                        row.put("price", String.format(java.util.Locale.getDefault(), "%.2f", price));
                        row.put("pack", String.valueOf(pack));
                        row.put("qty", String.valueOf(qty));
                        row.put("amount", String.format(java.util.Locale.getDefault(), "%.2f", amount));
                        row.put("pieces", String.valueOf(pcs));
                        arr.put(row);
                    }
                    payload.put("items", arr);
                    wrap.put("payload", payload);
                    sendContent = wrap.toString();
                }
            } catch (Exception ignore) { }

            PrinterManager.printDocText(this, sendContent);
            printed++;
        }

        if (printed > 0) markDeliveryPrintedToday();
        Toast.makeText(this, "已发送出货单：" + printed + "张", Toast.LENGTH_SHORT).show();

        try {
            java.util.LinkedHashSet<Integer> ids = new java.util.LinkedHashSet<>();
            for (Order o : orders) {
                if (o != null && o.getId() > 0) ids.add(o.getId());
            }
            db.deductInventoryForOrderIds(new java.util.ArrayList<>(ids), true);
            List<InventoryItem> low = db.getLowStockItems(new String[]{DatabaseHelper.INV_TYPE_PRODUCT, DatabaseHelper.INV_TYPE_POT, DatabaseHelper.INV_TYPE_BAG, DatabaseHelper.INV_TYPE_CARTON});
            showLowStockDialogsSequentially(low);
        } catch (Exception ex) {
            Toast.makeText(this, "扣减库存失败：" + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private static String toFeieyunBR(String s) {
        if (s == null) return "";
        String t = s.replace("\r\n", "\n").replace("\r", "\n");
        return t.replace("\n", "<BR>");
    }

    /** 合并：同产品名 + 同单价；备注/场地做去重拼接 */
    private List<Order> mergeSameProduct(List<Order> list) {
        LinkedHashMap<String, Order> map = new LinkedHashMap<>();
        for (Order o : list) {
            String key = n(o.getProductName()) + "||" + o.getPrice();
            Order exist = map.get(key);
            if (exist == null) {
                Order neo = new Order();
                neo.setCustomerName(o.getCustomerName());
                neo.setProductName(o.getProductName());
                neo.setPrice(o.getPrice());
                neo.setQuantity(Math.max(0, o.getQuantity()));
                neo.setPieces(Math.max(0, o.getPieces()));
                neo.setRemark(n(o.getRemark()).trim());
                neo.setLocation(n(o.getLocation()).trim());
                map.put(key, neo);
            } else {
                exist.setQuantity(exist.getQuantity() + Math.max(0, o.getQuantity()));
                exist.setPieces(exist.getPieces() + Math.max(0, o.getPieces()));

                // 备注去重拼接
                LinkedHashSet<String> rs = new LinkedHashSet<>();
                if (!TextUtils.isEmpty(n(exist.getRemark()))) rs.add(n(exist.getRemark()));
                if (!TextUtils.isEmpty(n(o.getRemark()))) rs.add(n(o.getRemark()));
                exist.setRemark(joinSet(rs, "；"));

                // 场地去重拼接
                LinkedHashSet<String> ls = new LinkedHashSet<>();
                if (!TextUtils.isEmpty(n(exist.getLocation()))) ls.add(n(exist.getLocation()));
                if (!TextUtils.isEmpty(n(o.getLocation()))) ls.add(n(o.getLocation()));
                exist.setLocation(joinSet(ls, "；"));
            }
        }

        List<Order> out = new ArrayList<>(map.values());
        Collections.sort(out, (a, b) -> n(a.getProductName()).compareTo(n(b.getProductName())));
        return out;
    }

    private String joinSet(LinkedHashSet<String> set, String sep) {
        if (set == null || set.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (String s : set) {
            String t = n(s).trim();
            if (t.isEmpty()) continue;
            if (sb.length() > 0) sb.append(sep);
            sb.append(t);
        }
        return sb.toString();
    }

    private String buildDeliveryItemsLines(List<Order> items, boolean bold) {
        StringBuilder sb = new StringBuilder();
        for (Order o : items) {
            if (o == null) continue;
            String name = n(o.getProductName());
            double price = o.getPrice();
            int qty = Math.max(0, o.getQuantity());
            int pieces = Math.max(0, o.getPieces());

            int packingUnits = 1;
            try { packingUnits = db.getProductPackingUnitsByName(name); } catch (Exception ignore) {}
            if (packingUnits <= 0) packingUnits = 1;

            double amount = price * qty;

            int maxUnits = bold ? UNITS_NAME_MAX_BOLD : UNITS_NAME_MAX_NORMAL;
            String name1 = truncateByUnits(name, maxUnits);
            if (bold) {
                sb.append("<B><BOLD>").append(name1).append("</BOLD></B>\n");
            } else {
                sb.append("<L><BOLD>").append(name1).append("</BOLD></L>\n");
            }

            String priceStr = String.format(Locale.getDefault(), "%.2f", price);
            String amountStr = String.format(Locale.getDefault(), "%.2f", amount);
            String line2 = formatCols(priceStr,
                    String.valueOf(packingUnits),
                    String.valueOf(qty),
                    amountStr,
                    String.valueOf(pieces));
            if (bold) {
                sb.append("<B><BOLD>").append(line2).append("</BOLD></B>\n");
            } else {
                sb.append("<L><BOLD>").append(line2).append("</BOLD></L>\n");
            }

            for (int i = 0; i < GAP_BLANK_LINES_BETWEEN_ITEMS; i++) {
                sb.append("\n");
            }
        }
        return sb.toString();
    }

    private static String formatCols(String price, String pack, String qty, String amount, String pieces) {
        return String.format(Locale.getDefault(),
                "%" + W_PRICE + "s%" + W_PACK + "s%" + W_QTY + "s%" + W_AMOUNT + "s%" + W_PIECES + "s",
                safe(price), safe(pack), safe(qty), safe(amount), safe(pieces));
    }

    private static int unitWidthOfChar(char ch) {
        return (ch <= 127) ? 1 : 2;
    }

    private static String truncateByUnits(String s, int maxUnits) {
        if (s == null) return "";
        String t = s.trim();
        if (t.isEmpty()) return "";

        int units = 0;
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < t.length(); i++) {
            char ch = t.charAt(i);
            int w = unitWidthOfChar(ch);
            if (units + w > maxUnits) {
                out.append("…");
                break;
            }
            out.append(ch);
            units += w;
        }
        return out.toString();
    }

    private static String safe(String s) {
        return s == null ? "" : s;
    }

    private String buildDeliveryRemark(List<Order> items) {
        java.util.LinkedHashSet<String> set = new java.util.LinkedHashSet<>();
        if (items != null) {
            for (Order o : items) {
                if (o == null) continue;
                String r = n(o.getRemark());
                if (!TextUtils.isEmpty(r)) set.add(r);
            }
        }
        return joinSet(set, "；");
    }

    private void printTodayLabels(boolean onlyUnprinted) {
        List<Order> all = keepTodayOrders(db.getOrdersByDate(today));
        if (all == null) all = new ArrayList<>();

        List<Order> orders = new ArrayList<>();
        if (onlyUnprinted) {
            orders.addAll(keepTodayOrders(db.getPendingLabelOrdersByDate(today)));
        } else {
            orders.addAll(all);
        }

        // ✅ 打印箱唛：按产品顺序时，同一产品内按新增顺序打印
        if (sortGroup != null && sortGroup.getCheckedRadioButtonId() == R.id.rbByProduct && orders != null && orders.size() > 1) {
            java.util.Collections.sort(orders, (a, b) -> {
                String pa = a.getProductName() == null ? "" : a.getProductName();
                String pb = b.getProductName() == null ? "" : b.getProductName();
                int cmp = pa.compareTo(pb);
                if (cmp != 0) return cmp;
                return Long.compare(a.getId(), b.getId());
            });
        }

        if (orders == null || orders.isEmpty()) {
            Toast.makeText(this, onlyUnprinted ? "无未打印箱唛订单" : "今日无订单", Toast.LENGTH_SHORT).show();
            return;
        }

        String tpl = db.getDefaultTemplateContent(TemplateCenterActivity.TYPE_LABEL);

        int totalLabels = 0;
        long maxIdPrintedInThisRun = 0;
        for (Order o : orders) {
            try {
                if (o.getId() > maxIdPrintedInThisRun) maxIdPrintedInThisRun = o.getId();
            } catch (Exception ignored) {}
            int pieces = safePieces(o);
            if (pieces <= 0) pieces = Math.max(1, o.getQuantity());

            for (int i = 1; i <= pieces; i++) {
                Map<String, String> vars = new HashMap<>();
                vars.put("customer", n(o.getCustomerName()));
                vars.put("product", n(o.getProductName()));
                vars.put("quantity", String.valueOf(pieces));
                vars.put("remark", n(o.getRemark()));
                vars.put("site", n(o.getLocation()));
                vars.put("location", n(o.getLocation()));
                int packingUnits = 1;
                try { packingUnits = db.getProductPackingUnitsByName(o.getProductName()); } catch (Exception ignored) {}
                vars.put("spec", String.valueOf(packingUnits));
                vars.put("packing_units", String.valueOf(packingUnits));

                vars.put("page", String.valueOf(i));
                vars.put("pages", String.valueOf(pieces));
                // ✅ 兼容模板字段：{{index}}/{{total}}（等价于 page/pages）
                vars.put("pieces", String.valueOf(pieces));
                vars.put("index", String.valueOf(i));
                vars.put("total", String.valueOf(pieces));
                vars.put("date", PrinterManager.normalizeLabelDate(o.getDate()));

                String rendered = TemplateEngine.render(tpl, vars);
                PrinterManager.printLabel(this, rendered);
                totalLabels++;
            }
        }

        try {
            db.markPendingLabelOrdersPrintedByDate(today);
            loadList();
        } catch (Exception ignored) {}

        Toast.makeText(this, (onlyUnprinted ? "加单箱唛已发送：" : "已发送标签：") + totalLabels + "张", Toast.LENGTH_SHORT).show();
    }

    private void printTodayLogistics() {
        List<LogisticsForm> forms = db.getLogisticsFormsByDate(today);
        if (forms == null || forms.isEmpty()) {
            Toast.makeText(this, "今日无物流单", Toast.LENGTH_SHORT).show();
            return;
        }

        int printed = 0;
        for (LogisticsForm f : forms) {
            List<LogisticsSize> sizes = db.getLogisticsSizes(f.getId());
            LogisticsPrinter.print(this, f, sizes);
            printed++;
        }
        Toast.makeText(this, "已发送物流单：" + printed + "张", Toast.LENGTH_SHORT).show();
    }


    private static String n(String s) {
        if (s == null) return "";
        String t = s.trim();
        return "null".equalsIgnoreCase(t) ? "" : t;
    }

    private boolean isTodayOrder(Order o) {
        if (o == null) return false;
        String d = n(o.getDate());
        if (d.length() >= 10) d = d.substring(0, 10);
        return today.equals(d);
    }

    private List<Order> keepTodayOrders(List<Order> src) {
        List<Order> out = new ArrayList<>();
        if (src == null) return out;
        for (Order o : src) {
            if (isTodayOrder(o)) out.add(o);
        }
        return out;
    }

    private static int safePieces(Order o) {
        try {
            int p = o.getPieces();
            if (p > 0) return p;
        } catch (Exception ignore) {}
        return 0;
    }
}