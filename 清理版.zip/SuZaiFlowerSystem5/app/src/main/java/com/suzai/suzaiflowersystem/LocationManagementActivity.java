package com.suzai.suzaiflowersystem;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class LocationManagementActivity extends BaseDrawerActivity {

    private RecyclerView recyclerView;
    private Button addLocationButton;
    private DatabaseHelper databaseHelper;
    private LocationAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("场地管理");
        setContentLayout(R.layout.activity_location_management);

        recyclerView = findViewById(R.id.recyclerView);
        addLocationButton = findViewById(R.id.addLocationButton);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        databaseHelper = new DatabaseHelper(this);
        List<LocationItem> locations = databaseHelper.getAllLocations();
        adapter = new LocationAdapter(locations, new LocationAdapter.OnLocationActionListener() {
            @Override
            public void onEdit(LocationItem item) {
                showEditLocationDialog(item);
            }

            @Override
            public void onDelete(LocationItem item) {
                showDeleteLocationDialog(item);
            }
        });
        recyclerView.setAdapter(adapter);

        addLocationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddLocationDialog();
            }
        });
    }

    private void showAddLocationDialog() {
        final EditText input = new EditText(this);
        input.setHint("请输入场地名称");

        new AlertDialog.Builder(this)
                .setTitle("新增场地")
                .setView(input)
                .setNegativeButton("取消", (dialog, which) -> dialog.dismiss())
                .setPositiveButton("保存", (dialog, which) -> {
                    String name = input.getText().toString().trim();
                    if (TextUtils.isEmpty(name)) {
                        Toast.makeText(this, "场地名称不能为空", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    long result = databaseHelper.addLocation(name);
                    if (result != -1) {
                        Toast.makeText(this, "场地保存成功", Toast.LENGTH_SHORT).show();
                        refreshLocations();
                    } else {
                        Toast.makeText(this, "场地保存失败", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private void showEditLocationDialog(LocationItem item) {
        final EditText input = new EditText(this);
        input.setHint("请输入场地名称");
        input.setText(item.getName());
        input.setSelection(input.getText().length());

        new AlertDialog.Builder(this)
                .setTitle("编辑场地")
                .setView(input)
                .setNegativeButton("取消", (dialog, which) -> dialog.dismiss())
                .setPositiveButton("保存", (dialog, which) -> {
                    String name = input.getText().toString().trim();
                    if (TextUtils.isEmpty(name)) {
                        Toast.makeText(this, "场地名称不能为空", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int rows = databaseHelper.updateLocation(item.getId(), name);
                    if (rows > 0) {
                        Toast.makeText(this, "场地已更新", Toast.LENGTH_SHORT).show();
                        refreshLocations();
                    } else {
                        Toast.makeText(this, "更新失败", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private void showDeleteLocationDialog(LocationItem item) {
        new AlertDialog.Builder(this)
                .setTitle("删除场地")
                .setMessage("确定删除场地：" + item.getName() + " 吗？")
                .setNegativeButton("取消", (dialog, which) -> dialog.dismiss())
                .setPositiveButton("删除", (dialog, which) -> {
                    int rows = databaseHelper.deleteLocation(item.getId());
                    if (rows > 0) {
                        Toast.makeText(this, "已删除", Toast.LENGTH_SHORT).show();
                        refreshLocations();
                    } else {
                        Toast.makeText(this, "删除失败", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshLocations();
    }

    private void refreshLocations() {
        if (databaseHelper == null || adapter == null) return;
        List<LocationItem> locations = databaseHelper.getAllLocations();
        adapter.updateLocationList(locations);
    }
}