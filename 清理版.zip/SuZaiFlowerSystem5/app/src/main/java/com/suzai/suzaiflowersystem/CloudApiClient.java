package com.suzai.suzaiflowersystem;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * MVP 云端接口（通用 REST 协议占位）：
 * 你只需要在服务器实现这些路径即可。客户端默认使用 HttpURLConnection，避免额外依赖。
 */
public class CloudApiClient {

    private final String baseUrl;

    public CloudApiClient(String baseUrl) {
        // 例如：https://your-domain.com 或 http://10.0.2.2:8080（本地调试）
        this.baseUrl = baseUrl != null ? baseUrl.replaceAll("/+$", "") : "";
    }

    public JSONObject login(String email, String password) throws Exception {
        JSONObject body = new JSONObject();
        body.put("email", email);
        body.put("password", password);
        return postJson("/api/login", body, null);
    }

    public JSONObject pullMasterData(String token, long sinceMillis) throws Exception {
        String url = baseUrl + "/api/master-data?since=" + sinceMillis;
        return getJson(url, token);
    }

    public JSONObject pullTemplates(String token, long sinceMillis) throws Exception {
        String url = baseUrl + "/api/templates?since=" + sinceMillis;
        return getJson(url, token);
    }

    public JSONObject pushSyncBatch(String token, JSONArray queueItems) throws Exception {
        JSONObject body = new JSONObject();
        body.put("items", queueItems);
        return postJson("/api/sync", body, token);
    }

    private JSONObject postJson(String path, JSONObject body, String token) throws Exception {
        String urlStr = baseUrl + path;
        HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(20000);
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        if (token != null && !token.isEmpty()) {
            conn.setRequestProperty("Authorization", "Bearer " + token);
        }
        byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
        OutputStream os = conn.getOutputStream();
        os.write(payload);
        os.flush();
        os.close();

        int code = conn.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String resp = readAll(is);
        if (code < 200 || code >= 300) {
            throw new RuntimeException("HTTP " + code + " " + resp);
        }
        conn.disconnect();
        return new JSONObject(resp);
    }

    private JSONObject getJson(String fullUrl, String token) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(fullUrl).openConnection();
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(20000);
        conn.setRequestMethod("GET");
        if (token != null && !token.isEmpty()) {
            conn.setRequestProperty("Authorization", "Bearer " + token);
        }
        int code = conn.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String resp = readAll(is);
        if (code < 200 || code >= 300) {
            throw new RuntimeException("HTTP " + code + " " + resp);
        }
        conn.disconnect();
        return new JSONObject(resp);
    }

    private static String readAll(InputStream is) throws Exception {
        if (is == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }
}
