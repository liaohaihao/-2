package com.suzai.suzaiflowersystem;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 蓝牙打印机搜索页：扫描附近设备，点击后保存到 PrinterPrefs（按角色 LABEL/DOC）。
 */
public class PrinterSearchActivity extends AppCompatActivity {

    public static final String EXTRA_ROLE = "extra_role";

    private BluetoothAdapter btAdapter;

    private final List<BluetoothDevice> devices = new ArrayList<>();
    private final Set<String> deviceAddrSet = new HashSet<>();

    private RecyclerView recyclerView;
    private Button scanButton;
    private PrinterDeviceAdapter adapter;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (device == null) return;

                String addr = device.getAddress();
                if (addr == null) return;

                if (!deviceAddrSet.contains(addr)) {
                    deviceAddrSet.add(addr);
                    devices.add(device);
                    if (adapter != null) adapter.notifyDataSetChanged();
                }
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                scanButton.setEnabled(true);
                scanButton.setText("开始搜索");
                Toast.makeText(PrinterSearchActivity.this, "搜索完成", Toast.LENGTH_SHORT).show();
            }
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_printer_search);

        recyclerView = findViewById(R.id.printerRecyclerView);
        scanButton = findViewById(R.id.scanPrinterButton);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new PrinterDeviceAdapter(devices, device -> onDeviceSelected(device));
        recyclerView.setAdapter(adapter);

        btAdapter = BluetoothAdapter.getDefaultAdapter();
        if (btAdapter == null) {
            Toast.makeText(this, "此设备不支持蓝牙", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        scanButton.setOnClickListener(v -> startScan());

        // 注册广播接收
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        registerReceiver(receiver, filter);
    }

    private void startScan() {
        if (!ensurePermissions()) return;

        try {
            if (!btAdapter.isEnabled()) {
                Toast.makeText(this, "请先打开手机蓝牙", Toast.LENGTH_SHORT).show();
                return;
            }
        } catch (SecurityException e) {
            Toast.makeText(this, "蓝牙权限被拒绝", Toast.LENGTH_SHORT).show();
            return;
        }

        // 清空并重新搜索
        devices.clear();
        deviceAddrSet.clear();
        adapter.notifyDataSetChanged();

        try {
            if (btAdapter.isDiscovering()) {
                btAdapter.cancelDiscovery();
            }
        } catch (SecurityException e) {
            Toast.makeText(this, "蓝牙权限被拒绝", Toast.LENGTH_SHORT).show();
            scanButton.setEnabled(true);
            scanButton.setText("开始搜索");
            return;
        }

        scanButton.setEnabled(false);
        scanButton.setText("搜索中...");

        boolean ok;
        try {
            ok = btAdapter.startDiscovery();
        } catch (SecurityException e) {
            Toast.makeText(this, "蓝牙权限被拒绝", Toast.LENGTH_SHORT).show();
            scanButton.setEnabled(true);
            scanButton.setText("开始搜索");
            return;
        }
        
        if (!ok) {
            scanButton.setEnabled(true);
            scanButton.setText("开始搜索");
            Toast.makeText(this, "启动搜索失败", Toast.LENGTH_SHORT).show();
        }
    }

    private void onDeviceSelected(BluetoothDevice device) {
        String roleStr = getIntent().getStringExtra(EXTRA_ROLE);
        PrinterPrefs.Role role = PrinterPrefs.Role.DOC;
        if (roleStr != null) {
            try { role = PrinterPrefs.Role.valueOf(roleStr); } catch (Exception ignored) {}
        }

        String name = safeGetName(device);
        String addr = device.getAddress();

        PrinterPrefs.setBluetooth(this, role, name, addr);

        Toast.makeText(this,
                (role == PrinterPrefs.Role.LABEL ? "标签机" : "单据机") + "已选择：" + name,
                Toast.LENGTH_SHORT).show();

        finish();
    }

    private String safeGetName(BluetoothDevice device) {
        String devName = "未知设备";
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                        != PackageManager.PERMISSION_GRANTED) {
                    return devName;
                }
            }
            String n = device.getName();
            if (n != null && !n.trim().isEmpty()) devName = n.trim();
        } catch (Exception ignored) {}
        return devName;
    }

    private boolean ensurePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Android 12+
            List<String> req = new ArrayList<>();
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                req.add(Manifest.permission.BLUETOOTH_SCAN);
            }
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                req.add(Manifest.permission.BLUETOOTH_CONNECT);
            }
            if (!req.isEmpty()) {
                requestPermissions(req.toArray(new String[0]), 1001);
                return false;
            }
            return true;
        } else {
            // Android 11 及以下：需要定位权限才能扫描
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1002);
                return false;
            }
            return true;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
        if (btAdapter != null) {
            try {
                if (btAdapter.isDiscovering()) {
                    btAdapter.cancelDiscovery();
                }
            } catch (SecurityException ignored) {}
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // 用户授权后可再次点击“开始搜索”
    }
}
