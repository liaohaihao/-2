package com.suzai.suzaiflowersystem;

import android.text.TextUtils;
import android.util.Base64;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

/**
 * CloudPrinterClient
 * - 飞鹅云：小票接口 Open_printMsg；标签接口 Open_printLabelMsg
 * - 保留 LAST_* 方便弹窗/日志排查
 */
public class CloudPrinterClient {

    public static volatile int LAST_FEIEYUN_RET = Integer.MIN_VALUE;
    public static volatile String LAST_FEIEYUN_MSG = "";
    public static volatile String LAST_FEIEYUN_DATA = "";
    public static volatile String LAST_FEIEYUN_RAW_RESPONSE = "";

    public static void resetLast() {
        LAST_FEIEYUN_RET = Integer.MIN_VALUE;
        LAST_FEIEYUN_MSG = "";
        LAST_FEIEYUN_DATA = "";
        LAST_FEIEYUN_RAW_RESPONSE = "";
    }

    /** 兼容旧的“非飞鹅云”厂商接口（如果 baseUrl 不是飞鹅域名，就走这里） */
    public static void send(String baseUrl, String deviceId, String token, byte[] rawBytes, int timeoutMs) throws Exception {
        // 仅用于非飞鹅平台（你当前用飞鹅云，此方法不应被调用）
        sendJsonVendor(baseUrl, deviceId, token, rawBytes, timeoutMs);
    }

    /** 飞鹅云小票/单据：Open_printMsg */
    public static void sendFeieyunText(String baseUrl,
                                       String user,
                                       String sn,
                                       String ukey,
                                       String content,
                                       int timeoutMs) throws Exception {
        sendFeieyunOpen(baseUrl, user, sn, ukey, "Open_printMsg", content, 1, timeoutMs);
    }

    /** 飞鹅云标签：Open_printLabelMsg（times=打印份数） */
    public static void sendFeieyunLabel(String baseUrl,
                                        String user,
                                        String sn,
                                        String ukey,
                                        String content,
                                        int times,
                                        int timeoutMs) throws Exception {
        sendFeieyunOpen(baseUrl, user, sn, ukey, "Open_printLabelMsg", content, times, timeoutMs);
    }

    private static void sendFeieyunOpen(String baseUrl,
                                        String user,
                                        String sn,
                                        String ukey,
                                        String apiname,
                                        String content,
                                        int times,
                                        int timeoutMs) throws Exception {
        resetLast();

        if (TextUtils.isEmpty(baseUrl)) throw new IllegalArgumentException("云打印URL为空");
        if (TextUtils.isEmpty(user)) throw new IllegalArgumentException("云打印账号USER为空");
        if (TextUtils.isEmpty(sn)) throw new IllegalArgumentException("设备编号SN为空");
        if (TextUtils.isEmpty(ukey)) throw new IllegalArgumentException("设备密钥UKEY为空");

        String urlStr = baseUrl.trim();
        // 统一到 http，和你后台一致
        if (urlStr.toLowerCase(Locale.ROOT).startsWith("https://api.feieyun.cn/")) {
            urlStr = "http://api.feieyun.cn/Api/Open/";
        }
        if (!urlStr.endsWith("/")) urlStr = urlStr + "/";

        String stime = String.valueOf(System.currentTimeMillis() / 1000L);
        String sig = sha1Lower(user + ukey + stime);

        String body =
                "user=" + enc(user) +
                        "&stime=" + enc(stime) +
                        "&sig=" + enc(sig) +
                        "&apiname=" + enc(apiname) +
                        "&sn=" + enc(sn) +
                        "&content=" + enc(content);

        // 标签接口支持打印份数
        if ("Open_printLabelMsg".equals(apiname)) {
            if (times <= 0) times = 1;
            body += "&times=" + enc(String.valueOf(times));
        }

        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(timeoutMs);
            conn.setReadTimeout(timeoutMs);
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");

            byte[] payload = body.getBytes(StandardCharsets.UTF_8);
            OutputStream os = conn.getOutputStream();
            os.write(payload);
            os.flush();
            os.close();

            int code = conn.getResponseCode();
            String resp = readAll(conn);

            LAST_FEIEYUN_RAW_RESPONSE = resp;

            if (TextUtils.isEmpty(resp)) {
                throw new RuntimeException("飞鹅云返回空响应（HTTP " + code + "）");
            }
            if (code < 200 || code >= 300) {
                throw new RuntimeException("飞鹅云请求失败 HTTP " + code + "：" + safe(resp));
            }

            JSONObject jo = new JSONObject(resp);
            int ret = jo.optInt("ret", -999);
            String msg = jo.optString("msg", "");
            String data = jo.optString("data", "");

            LAST_FEIEYUN_RET = ret;
            LAST_FEIEYUN_MSG = msg;
            LAST_FEIEYUN_DATA = data;

            if (ret != 0) {
                throw new RuntimeException("云打印失败：" + msg + "（ret=" + ret + "）");
            }

        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    /** 非飞鹅平台（保留） */
    private static void sendJsonVendor(String baseUrl, String deviceId, String token, byte[] rawBytes, int timeoutMs) throws Exception {
        if (TextUtils.isEmpty(baseUrl)) throw new IllegalArgumentException("云打印URL为空");
        if (TextUtils.isEmpty(deviceId)) throw new IllegalArgumentException("设备ID为空");
        if (TextUtils.isEmpty(token)) throw new IllegalArgumentException("密钥为空");

        String payload = "{\"deviceId\":\"" + escapeJson(deviceId) + "\",\"token\":\"" + escapeJson(token) + "\",\"data\":\"" +
                android.util.Base64.encodeToString(rawBytes == null ? new byte[0] : rawBytes, android.util.Base64.NO_WRAP) + "\"}";

        HttpURLConnection conn = null;
        try {
            URL url = new URL(baseUrl);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(timeoutMs);
            conn.setReadTimeout(timeoutMs);
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");

            OutputStream os = conn.getOutputStream();
            os.write(payload.getBytes(StandardCharsets.UTF_8));
            os.flush();
            os.close();

            int code = conn.getResponseCode();
            String resp = readAll(conn);
            if (code < 200 || code >= 300) {
                throw new RuntimeException("云打印请求失败 HTTP " + code + "：" + safe(resp));
            }
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    

    /**
     * 小票机图片打印（走 Open_printMsg + multipart/form-data，配合 <IMG> 标签）。
     *
     * 说明：
     * - 官方文档对“小票机”主要展示文字排版；但部分机型/服务端支持通过 img 参数配合 <IMG> 打印图片。
     * - 如服务端不支持 img，会返回参数错误/或忽略；上层会给出错误提示，便于排查。
     */
    public static void sendFeieyunReceiptImage(String urlStr, String user, String sn, String ukey,
                                              String contentWithImgTag, byte[] imgBytes, int times) throws Exception {
        if (times <= 0) times = 1;

        String apiname = "Open_printMsg";
        String stime = String.valueOf(System.currentTimeMillis() / 1000L);
        String sig = sha1Lower(user + ukey + stime);

        // multipart 表单字段
        String boundary = "----SuZaiBoundary" + System.currentTimeMillis();
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(20000);
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

            OutputStream os = conn.getOutputStream();

            // text parts
            writePart(os, boundary, "user", user);
            writePart(os, boundary, "stime", stime);
            writePart(os, boundary, "sig", sig);
            writePart(os, boundary, "apiname", apiname);
            writePart(os, boundary, "sn", sn);
            writePart(os, boundary, "content", contentWithImgTag == null ? "" : contentWithImgTag);
            writePart(os, boundary, "times", String.valueOf(times));

            // file part: img
            if (imgBytes != null && imgBytes.length > 0) {
                writeFilePart(os, boundary, "img", "print.png", "image/png", imgBytes);
            }

            // end
            os.write(("--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
            os.flush();
            os.close();

            int code = conn.getResponseCode();
            BufferedReader br = new BufferedReader(new InputStreamReader(
                    (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream(),
                    StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            String resp = sb.toString();

            if (code < 200 || code >= 300) {
                throw new RuntimeException("云打印请求失败 HTTP " + code + "：" + safe(resp));
            }

            // 解析 ret
            try {
                JSONObject jo = new JSONObject(resp);
                int ret = jo.optInt("ret", -999);
                if (ret != 0) {
                    throw new RuntimeException("云打印失败：" + safe(jo.optString("msg")) + "（ret=" + ret + "）");
                }
            } catch (RuntimeException re) {
                throw re;
            } catch (Exception ignore) {
                // 有的服务器可能返回非 JSON（debug=1 或代理干预），不强制
            }
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static void writePart(OutputStream os, String boundary, String name, String value) throws Exception {
        StringBuilder sb = new StringBuilder();
        sb.append("--").append(boundary).append("\r\n");
        sb.append("Content-Disposition: form-data; name=\"").append(name).append("\"\r\n\r\n");
        sb.append(value == null ? "" : value).append("\r\n");
        os.write(sb.toString().getBytes(StandardCharsets.UTF_8));
    }

    private static void writeFilePart(OutputStream os, String boundary, String name, String filename,
                                      String contentType, byte[] data) throws Exception {
        StringBuilder sb = new StringBuilder();
        sb.append("--").append(boundary).append("\r\n");
        sb.append("Content-Disposition: form-data; name=\"").append(name)
                .append("\"; filename=\"").append(filename).append("\"\r\n");
        sb.append("Content-Type: ").append(contentType).append("\r\n\r\n");
        os.write(sb.toString().getBytes(StandardCharsets.UTF_8));
        os.write(data);
        os.write("\r\n".getBytes(StandardCharsets.UTF_8));
    }
private static String enc(String s) throws Exception {
        return URLEncoder.encode(s == null ? "" : s, "UTF-8");
    }

    private static String sha1Lower(String s) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        byte[] b = md.digest((s == null ? "" : s).getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format(Locale.ROOT, "%02x", x));
        return sb.toString();
    }

    private static String readAll(HttpURLConnection conn) {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(
                    conn.getResponseCode() >= 400 ? conn.getErrorStream() : conn.getInputStream(),
                    StandardCharsets.UTF_8
            ));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private static String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String safe(String s) {
        if (s == null) return "";
        s = s.trim();
        if (s.length() > 800) return s.substring(0, 800) + "...";
        return s;
    }
}
