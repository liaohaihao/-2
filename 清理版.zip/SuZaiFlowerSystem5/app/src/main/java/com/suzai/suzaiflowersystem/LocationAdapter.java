package com.suzai.suzaiflowersystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class LocationAdapter extends RecyclerView.Adapter<LocationAdapter.LocationViewHolder> {

    public interface OnLocationActionListener {
        void onEdit(LocationItem item);
        void onDelete(LocationItem item);
    }

    private final List<LocationItem> list = new ArrayList<>();
    private final OnLocationActionListener listener;

    public LocationAdapter(List<LocationItem> initial, OnLocationActionListener listener) {
        if (initial != null) list.addAll(initial);
        this.listener = listener;
    }

    public void updateLocationList(List<LocationItem> newList) {
        list.clear();
        if (newList != null) list.addAll(newList);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public LocationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_location, parent, false);
        return new LocationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LocationViewHolder holder, int position) {
        LocationItem item = list.get(position);
        holder.locationNameTextView.setText(item.getName());

        holder.editButton.setOnClickListener(v -> {
            if (listener != null) listener.onEdit(item);
        });
        holder.deleteButton.setOnClickListener(v -> {
            if (listener != null) listener.onDelete(item);
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class LocationViewHolder extends RecyclerView.ViewHolder {
        TextView locationNameTextView;
        Button editButton;
        Button deleteButton;

        LocationViewHolder(@NonNull View itemView) {
            super(itemView);
            locationNameTextView = itemView.findViewById(R.id.locationNameTextView);
            editButton = itemView.findViewById(R.id.locationEditButton);
            deleteButton = itemView.findViewById(R.id.locationDeleteButton);
        }
    }
}
