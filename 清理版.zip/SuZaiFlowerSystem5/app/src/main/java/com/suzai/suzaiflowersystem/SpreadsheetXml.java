package com.suzai.suzaiflowersystem;

import java.util.List;

/**
 * 轻量 Excel 导出：SpreadsheetML（Excel 2003 XML），保存为 .xls 即可被 Excel/WPS 打开。
 * 不引入 POI，体积小、稳定、适合 Android 商用。
 */
public class SpreadsheetXml {

    public static String buildWorkbook(String sheetName, String subtitle, String[] headers, List<ReportsActivity.Row> rows) {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\"?>\n");
        sb.append("<?mso-application progid=\"Excel.Sheet\"?>\n");
        sb.append("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\"\n");
        sb.append(" xmlns:o=\"urn:schemas-microsoft-com:office:office\"\n");
        sb.append(" xmlns:x=\"urn:schemas-microsoft-com:office:excel\"\n");
        sb.append(" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\"\n");
        sb.append(" xmlns:html=\"http://www.w3.org/TR/REC-html40\">\n");

        // styles
        sb.append("<Styles>\n");
        sb.append("<Style ss:ID=\"sTitle\"><Font ss:Bold=\"1\" ss:Size=\"14\"/></Style>\n");
        sb.append("<Style ss:ID=\"sHeader\"><Font ss:Bold=\"1\"/><Interior ss:Color=\"#DDDDDD\" ss:Pattern=\"Solid\"/></Style>\n");
        sb.append("<Style ss:ID=\"sText\"><Alignment ss:Vertical=\"Center\"/></Style>\n");
        sb.append("</Styles>\n");

        sb.append("<Worksheet ss:Name=\"").append(escape(sheetName)).append("\">\n");
        sb.append("<Table>\n");

        // title row
        sb.append("<Row>\n");
        sb.append(cell("sTitle", sheetName));
        sb.append("</Row>\n");

        if (subtitle != null && subtitle.trim().length() > 0) {
            sb.append("<Row>\n");
            sb.append(cell("sText", subtitle));
            sb.append("</Row>\n");
        }

        // empty row
        sb.append("<Row></Row>\n");

        // header
        sb.append("<Row>\n");
        for (String h : headers) sb.append(cell("sHeader", h));
        sb.append("</Row>\n");

        // data
        if (rows != null) {
            for (ReportsActivity.Row r : rows) {
                sb.append("<Row>\n");
                String[] arr = r.toArray();
                for (int i = 0; i < headers.length && i < arr.length; i++) {
                    sb.append(cell("sText", arr[i]));
                }
                sb.append("</Row>\n");
            }
        }

        sb.append("</Table>\n");
        sb.append("</Worksheet>\n");
        sb.append("</Workbook>\n");
        return sb.toString();
    }


    // ====== 新增：通用单表导出 ======
    public static String buildWorkbookSingle(String sheetName, String subtitle, String[] headers, List<List<String>> rows) {
        Sheet s = new Sheet();
        s.name = sheetName;
        s.title = sheetName;
        s.subtitle = subtitle;
        s.headers = headers;
        s.rows = rows;
        List<Sheet> list = new java.util.ArrayList<>();
        list.add(s);
        return buildWorkbookMulti(list);
    }

    // ====== 新增：多工作表导出（对账用） ======
    public static class Sheet {
        public String name;
        public String title;
        public String subtitle;
        public String[] headers;
        public List<List<String>> rows;
    }

    public static String buildWorkbookMulti(List<Sheet> sheets) {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\"?>\n");
        sb.append("<?mso-application progid=\"Excel.Sheet\"?>\n");
        sb.append("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\"\n");
        sb.append(" xmlns:o=\"urn:schemas-microsoft-com:office:office\"\n");
        sb.append(" xmlns:x=\"urn:schemas-microsoft-com:office:excel\"\n");
        sb.append(" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\"\n");
        sb.append(" xmlns:html=\"http://www.w3.org/TR/REC-html40\">\n");

        // styles
        sb.append("<Styles>\n");
        sb.append("<Style ss:ID=\"sTitle\"><Font ss:Bold=\"1\" ss:Size=\"14\"/></Style>\n");
        sb.append("<Style ss:ID=\"sHeader\"><Font ss:Bold=\"1\"/><Interior ss:Color=\"#DDDDDD\" ss:Pattern=\"Solid\"/></Style>\n");
        sb.append("<Style ss:ID=\"sText\"><Alignment ss:Vertical=\"Center\"/></Style>\n");
        sb.append("</Styles>\n");

        if (sheets != null) {
            for (Sheet sh : sheets) {
                if (sh == null) continue;
                String sName = sh.name == null ? "Sheet" : sh.name;
                sb.append("<Worksheet ss:Name=\"").append(escape(sName)).append("\">\n");
                sb.append("<Table>\n");

                // title row
                sb.append("<Row>\n");
                sb.append(cell("sTitle", sh.title == null ? sName : sh.title));
                sb.append("</Row>\n");

                if (sh.subtitle != null && sh.subtitle.trim().length() > 0) {
                    sb.append("<Row>\n");
                    sb.append(cell("sText", sh.subtitle));
                    sb.append("</Row>\n");
                }

                // empty row
                sb.append("<Row></Row>\n");

                // header
                if (sh.headers != null) {
                    sb.append("<Row>\n");
                    for (String h : sh.headers) sb.append(cell("sHeader", h));
                    sb.append("</Row>\n");
                }

                // data
                if (sh.rows != null && sh.headers != null) {
                    for (List<String> r : sh.rows) {
                        sb.append("<Row>\n");
                        for (int i = 0; i < sh.headers.length; i++) {
                            String v = "";
                            if (r != null && i < r.size() && r.get(i) != null) v = r.get(i);
                            sb.append(cell("sText", v));
                        }
                        sb.append("</Row>\n");
                    }
                }

                sb.append("</Table>\n");
                sb.append("</Worksheet>\n");
            }
        }

        sb.append("</Workbook>\n");
        return sb.toString();
    }

    private static String cell(String styleId, String value) {
        String v = value == null ? "" : value;
        return "<Cell ss:StyleID=\"" + styleId + "\"><Data ss:Type=\"String\">" + escape(v) + "</Data></Cell>\n";
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;");
    }
}
