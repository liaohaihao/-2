package com.suzai.suzaiflowersystem;

public class SyncQueueItem {
    private long id;
    private String type; // MASTER_UPSERT / MOVEMENT_UPSERT / TEMPLATE_UPSERT ...
    private String payload; // JSON string
    private long createdAt;

    public SyncQueueItem(long id, String type, String payload, long createdAt) {
        this.id = id;
        this.type = type;
        this.payload = payload;
        this.createdAt = createdAt;
    }

    public long getId() { return id; }
    public String getType() { return type; }
    public String getPayload() { return payload; }
    public long getCreatedAt() { return createdAt; }
}
