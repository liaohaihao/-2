package com.suzai.suzaiflowersystem;

public class LogisticsSize {

    private long id;
    private long logisticsId;
    private double len;
    private double wid;
    private double hei;
    private int pieces;
    private double cbm;

    public LogisticsSize() {
    }

    public LogisticsSize(long id, long logisticsId, double len, double wid, double hei, int pieces, double cbm) {
        this.id = id;
        this.logisticsId = logisticsId;
        this.len = len;
        this.wid = wid;
        this.hei = hei;
        this.pieces = pieces;
        this.cbm = cbm;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getLogisticsId() {
        return logisticsId;
    }

    public void setLogisticsId(long logisticsId) {
        this.logisticsId = logisticsId;
    }

    public double getLen() {
        return len;
    }

    public void setLen(double len) {
        this.len = len;
    }

    public double getWid() {
        return wid;
    }

    public void setWid(double wid) {
        this.wid = wid;
    }

    public double getHei() {
        return hei;
    }

    public void setHei(double hei) {
        this.hei = hei;
    }

    public int getPieces() {
        return pieces;
    }

    public void setPieces(int pieces) {
        this.pieces = pieces;
    }

    public double getCbm() {
        return cbm;
    }

    public void setCbm(double cbm) {
        this.cbm = cbm;
    }
}
