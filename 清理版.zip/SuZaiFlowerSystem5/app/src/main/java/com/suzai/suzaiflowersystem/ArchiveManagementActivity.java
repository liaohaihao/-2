package com.suzai.suzaiflowersystem;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ProgressBar;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 归档管理界面 - 提供用户手动触发归档、查看统计、监控归档过程的功能
 */
public class ArchiveManagementActivity extends BaseDrawerActivity {
    
    private TextView tvHotDataBoundary;
    private TextView tvScanResult;
    private TextView tvArchiveStats;
    private TextView tvLastArchive;
    private TextView tvIntegrityStatus;
    private Button btnScan;
    private Button btnExecuteArchive;
    private Button btnVerifyIntegrity;
    private ProgressBar progressBar;
    private Handler mainHandler;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentLayout(R.layout.activity_archive_management);
        if (toolbar != null) toolbar.setTitle("归档管理");
        android.view.View lite = findViewById(R.id.toolbarLite);
        if (lite != null) lite.setVisibility(android.view.View.GONE);

        
        // 初始化UI组件
        initViews();
        
        // 初始化主线程Handler
        mainHandler = new Handler(Looper.getMainLooper());
        
        // 初始加载数据
        loadInitialData();
    }
    
    private void initViews() {
        tvHotDataBoundary = findViewById(R.id.tv_hot_data_boundary);
        tvScanResult = findViewById(R.id.tv_scan_result);
        tvArchiveStats = findViewById(R.id.tv_archive_stats);
        tvLastArchive = findViewById(R.id.tv_last_archive);
        tvIntegrityStatus = findViewById(R.id.tv_integrity_status);
        btnScan = findViewById(R.id.btn_scan);
        btnExecuteArchive = findViewById(R.id.btn_execute_archive);
        btnVerifyIntegrity = findViewById(R.id.btn_verify_integrity);
        progressBar = findViewById(R.id.progress_bar);
        
        // 设置按钮点击监听器
        btnScan.setOnClickListener(v -> scanDataForArchive());
        btnExecuteArchive.setOnClickListener(v -> executeArchive());
        btnVerifyIntegrity.setOnClickListener(v -> verifyArchiveIntegrity());
    }
    
    private void loadInitialData() {
        // 显示热数据边界日期
        String boundaryDate = ArchiveManager.getDateTwoYearsAgo();
        tvHotDataBoundary.setText(String.format("热数据边界：%s（当前日期往前24个月）", boundaryDate));
        
        // 加载归档统计
        loadArchiveStats();
        
        // 初始状态
        updateUIState(false);
    }
    
    private void loadArchiveStats() {
        new Thread(() -> {
            try {
                ArchiveStats stats = ArchiveManager.getArchiveStats(this);
                
                mainHandler.post(() -> {
                    // 显示归档统计
                    tvArchiveStats.setText(String.format(
                        "归档统计：\n" +
                        "• 已归档订单：%d 条\n" +
                        "• 已归档明细：%d 条\n" +
                        "• 已归档物流单：%d 条\n" +
                        "• 成功批次：%d，失败批次：%d\n" +
                        "• 成功率：%.1f%%",
                        stats.totalOrdersArchived,
                        stats.totalOrderItemsArchived,
                        stats.totalLogisticsFormsArchived,
                        stats.successfulBatches,
                        stats.failedBatches,
                        stats.getSuccessRate()
                    ));
                    
                    // 显示最近归档时间
                    if (stats.lastArchiveDate != null && !stats.lastArchiveDate.isEmpty()) {
                        tvLastArchive.setText(String.format("最近归档：%s", stats.lastArchiveDate));
                    } else {
                        tvLastArchive.setText("最近归档：暂无");
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
                mainHandler.post(() -> {
                    tvArchiveStats.setText("加载统计失败：" + e.getMessage());
                });
            }
        }).start();
    }
    
    private void scanDataForArchive() {
        updateUIState(true);
        
        new Thread(() -> {
            try {
                ArchiveScanResult result = ArchiveManager.scanDataForArchive(this);
                
                mainHandler.post(() -> {
                    updateUIState(false);
                    
                    if (result.hasDataToArchive()) {
                        tvScanResult.setText(String.format(
                            "扫描结果：\n" +
                            "• 待归档订单：%d 条\n" +
                            "• 待归档明细：%d 条\n" +
                            "• 待归档物流单：%d 条\n" +
                            "• 总计：%d 条数据",
                            result.ordersCount,
                            result.orderItemsCount,
                            result.logisticsFormsCount,
                            result.getTotalCount()
                        ));
                        
                        // 启用执行归档按钮
                        btnExecuteArchive.setEnabled(true);
                        btnExecuteArchive.setAlpha(1.0f);
                        
                        Toast.makeText(this, 
                            String.format("发现 %d 条待归档数据", result.getTotalCount()), 
                            Toast.LENGTH_LONG).show();
                    } else {
                        tvScanResult.setText("扫描结果：暂无待归档数据（所有数据都在2年热数据范围内）");
                        btnExecuteArchive.setEnabled(false);
                        btnExecuteArchive.setAlpha(0.5f);
                        
                        Toast.makeText(this, "暂无待归档数据", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
                mainHandler.post(() -> {
                    updateUIState(false);
                    tvScanResult.setText("扫描失败：" + e.getMessage());
                    Toast.makeText(this, "扫描失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }
    
    private void executeArchive() {
        updateUIState(true);
        
        new Thread(() -> {
            try {
                // 生成批次ID
                String batchId = ArchiveManager.generateBatchId();
                
                // 执行归档
                ArchiveResult result = ArchiveManager.executeArchive(this, batchId);
                
                mainHandler.post(() -> {
                    updateUIState(false);
                    
                    if (result.isSuccess()) {
                        tvScanResult.setText(String.format(
                            "归档执行成功！\n" +
                            "批次ID：%s\n" +
                            "执行时间：%d 毫秒\n\n" +
                            "迁移数据：\n" +
                            "• 订单：%d 条\n" +
                            "• 明细：%d 条\n" +
                            "• 物流单：%d 条\n\n" +
                            "清理数据：\n" +
                            "• 订单：%d 条\n" +
                            "• 明细：%d 条\n" +
                            "• 物流单：%d 条",
                            result.batchId,
                            result.getDuration(),
                            result.ordersMigrated,
                            result.orderItemsMigrated,
                            result.logisticsFormsMigrated,
                            result.ordersDeleted,
                            result.orderItemsDeleted,
                            result.logisticsFormsDeleted
                        ));
                        
                        // 重新加载统计
                        loadArchiveStats();
                        
                        Toast.makeText(this, 
                            String.format("归档成功！迁移 %d 条数据，清理 %d 条数据", 
                                result.getTotalMigrated(), result.getTotalDeleted()), 
                            Toast.LENGTH_LONG).show();
                    } else {
                        tvScanResult.setText(String.format(
                            "归档执行失败！\n" +
                            "批次ID：%s\n" +
                            "错误信息：%s",
                            result.batchId,
                            result.errorMessage
                        ));
                        
                        Toast.makeText(this, 
                            String.format("归档失败：%s", result.errorMessage), 
                            Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
                mainHandler.post(() -> {
                    updateUIState(false);
                    tvScanResult.setText("归档执行异常：" + e.getMessage());
                    Toast.makeText(this, "归档执行异常：" + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }
    
    private void verifyArchiveIntegrity() {
        updateUIState(true);
        
        new Thread(() -> {
            try {
                // 获取最近的批次ID
                DatabaseHelper dbHelper = new DatabaseHelper(this);
                String latestBatchId = getLatestBatchId(dbHelper);
                
                if (latestBatchId == null) {
                    mainHandler.post(() -> {
                        updateUIState(false);
                        tvIntegrityStatus.setText("完整性校验：暂无归档批次记录");
                        Toast.makeText(this, "暂无归档批次记录", Toast.LENGTH_SHORT).show();
                    });
                    return;
                }
                
                // 执行完整性校验
                ArchiveIntegrityResult result = ArchiveManager.verifyArchiveIntegrity(this, latestBatchId);
                
                mainHandler.post(() -> {
                    updateUIState(false);
                    
                    String statusText = String.format(
                        "完整性校验结果：\n" +
                        "批次ID：%s\n" +
                        "日志状态：%s\n" +
                        "完整性评分：%d/100\n\n" +
                        "归档数据：\n" +
                        "• 订单：%d 条\n" +
                        "• 明细：%d 条\n" +
                        "• 物流单：%d 条\n\n" +
                        "剩余数据：\n" +
                        "• 订单：%d 条（超过2年）",
                        result.batchId,
                        result.logStatus,
                        result.integrityScore,
                        result.ordersInArchive,
                        result.orderItemsInArchive,
                        result.logisticsFormsInArchive,
                        result.ordersRemaining
                    );
                    
                    if (result.errorMessage != null && !result.errorMessage.isEmpty()) {
                        statusText += "\n\n错误信息：" + result.errorMessage;
                    }
                    
                    tvIntegrityStatus.setText(statusText);
                    
                    // 根据评分显示不同颜色的提示
                    if (result.isIntegrityGood()) {
                        tvIntegrityStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
                        Toast.makeText(this, "归档完整性良好！", Toast.LENGTH_SHORT).show();
                    } else if (result.integrityScore >= 60) {
                        tvIntegrityStatus.setTextColor(getResources().getColor(android.R.color.holo_orange_dark));
                        Toast.makeText(this, "归档完整性一般，建议检查", Toast.LENGTH_SHORT).show();
                    } else {
                        tvIntegrityStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
                        Toast.makeText(this, "归档完整性较差，需要修复", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
                mainHandler.post(() -> {
                    updateUIState(false);
                    tvIntegrityStatus.setText("完整性校验失败：" + e.getMessage());
                    Toast.makeText(this, "完整性校验失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }
    
    private String getLatestBatchId(DatabaseHelper dbHelper) {
        try {
            android.database.sqlite.SQLiteDatabase db = dbHelper.getReadableDatabase();
            android.database.Cursor cursor = db.rawQuery(
                "SELECT batch_id FROM archive_logs ORDER BY id DESC LIMIT 1", null);
            
            String batchId = null;
            if (cursor.moveToFirst()) {
                batchId = cursor.getString(0);
            }
            cursor.close();
            db.close();
            
            return batchId;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    private void updateUIState(boolean isLoading) {
        mainHandler.post(() -> {
            if (isLoading) {
                progressBar.setVisibility(View.VISIBLE);
                btnScan.setEnabled(false);
                btnExecuteArchive.setEnabled(false);
                btnVerifyIntegrity.setEnabled(false);
                btnScan.setAlpha(0.5f);
                btnExecuteArchive.setAlpha(0.5f);
                btnVerifyIntegrity.setAlpha(0.5f);
            } else {
                progressBar.setVisibility(View.GONE);
                btnScan.setEnabled(true);
                btnVerifyIntegrity.setEnabled(true);
                btnScan.setAlpha(1.0f);
                btnVerifyIntegrity.setAlpha(1.0f);
                
                // 执行归档按钮的状态由扫描结果决定
                // 这里保持原状态，由扫描回调更新
            }
        });
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mainHandler != null) {
            mainHandler.removeCallbacksAndMessages(null);
        }
    }
}