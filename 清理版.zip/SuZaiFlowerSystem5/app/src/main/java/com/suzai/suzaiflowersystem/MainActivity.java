package com.suzai.suzaiflowersystem;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;
import java.text.SimpleDateFormat;
import java.util.Date;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private static final String LABEL_PRINT_PREF = "label_print_pref";
    private static final String KEY_LABEL_PRINTED_MAXID_PREFIX = "label_printed_maxid_";

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Toolbar toolbar;
    private DatabaseHelper databaseHelper;

    private enum Range { DAY, WEEK, MONTH, CUSTOM }
    private Range currentRange = Range.DAY;
    private final SimpleDateFormat dateSdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    private String filterStartDate = "";
    private String filterEndDate = "";

    @Override
    protected void onStart() {
        super.onStart();
        // 前台监听剪贴板（检测到“客户+产品+件数”则弹窗询问是否自动新增订单）
        try { ClipboardOrderAssistant.get().attach(this); } catch (Exception ignored) {}
    }

    @Override
    protected void onStop() {
        // 取消监听，避免泄露
        try { ClipboardOrderAssistant.get().detach(); } catch (Exception ignored) {}
        super.onStop();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 登录校验：未登录先去登录页（MVP）
        if (!AuthManager.isLoggedIn(this)) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }
        setContentView(R.layout.activity_main_drawer);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);

        databaseHelper = new DatabaseHelper(this);

        // 设置首页内容（只更新 DrawerLayout 内的内容区，不要再次 setContentView）
        loadHomeContent();
    }

    private void loadHomeContent() {
        // 注意：这里不要 setContentView，否则会把 DrawerLayout 的布局替换掉，导致 drawerLayout / nav_view 为空而闪退。

        Button btnDay = findViewById(R.id.btnRangeDay);
        Button btnWeek = findViewById(R.id.btnRangeWeek);
        Button btnMonth = findViewById(R.id.btnRangeMonth);
        Button btnStart = findViewById(R.id.btnHomeStartDate);
        Button btnEnd = findViewById(R.id.btnHomeEndDate);
        Button btnApply = findViewById(R.id.btnHomeApplyFilter);

        if (btnDay != null) btnDay.setOnClickListener(v -> { currentRange = Range.DAY; applyPresetRange(); refreshReport(); });
        if (btnWeek != null) btnWeek.setOnClickListener(v -> { currentRange = Range.WEEK; applyPresetRange(); refreshReport(); });
        if (btnMonth != null) btnMonth.setOnClickListener(v -> { currentRange = Range.MONTH; applyPresetRange(); refreshReport(); });
        if (btnStart != null) btnStart.setOnClickListener(v -> showHomeDatePicker(true));
        if (btnEnd != null) btnEnd.setOnClickListener(v -> showHomeDatePicker(false));
        if (btnApply != null) btnApply.setOnClickListener(v -> applyCustomRange());

        applyPresetRange();
        refreshReport();
    }

    private void refreshReport() {
        TextView tvTitle = findViewById(R.id.tvReportTitle);
        TextView tvPieces = findViewById(R.id.tvPieces);
        TextView tvSales = findViewById(R.id.tvSales);
        TextView tvPendingReminders = findViewById(R.id.tvPendingReminders);
        TextView tvLowStock = findViewById(R.id.tvLowStock);
        TextView tvTopCustomers = findViewById(R.id.tvTopCustomers);
        TextView tvTopProducts = findViewById(R.id.tvTopProducts);

        if (tvPieces == null || tvSales == null || tvTopCustomers == null || tvTopProducts == null || tvPendingReminders == null || tvLowStock == null) return;

        ensureHomeRangeReady();
        String start = nvl(filterStartDate);
        String end = nvl(filterEndDate);
        updateHomeFilterButtons();

        if (tvTitle != null) {
            String t = "报表（" + start + " ~ " + end + "）";
            if (currentRange == Range.DAY) t = "日报（" + end + "）";
            else if (currentRange == Range.WEEK) t = "周报（" + start + " ~ " + end + "）";
            else if (currentRange == Range.MONTH) t = "月报（" + start + " ~ " + end + "）";
            else if (currentRange == Range.CUSTOM) t = "自定义筛选（" + start + " ~ " + end + "）";
            tvTitle.setText(t);
        }

        int pieces = 0;
        double sales = 0.0;
        StringBuilder pendingReminders = new StringBuilder();
        StringBuilder lowStockText = new StringBuilder();
        StringBuilder topCustomers = new StringBuilder();
        StringBuilder topProducts = new StringBuilder();

        SQLiteDatabase db = null;
        try {
            db = databaseHelper.getReadableDatabase();

            String defaultSite = AuthManager.getDefaultLocationForCurrentUser(MainActivity.this);
            if (defaultSite == null) defaultSite = "";

            // 1) 汇总：件数 + 销售额（quantity*price）
            try (Cursor c = db.rawQuery(
                    "SELECT COALESCE(SUM(pieces),0) AS sp, COALESCE(SUM(quantity*price),0) AS ss FROM orders WHERE date>=? AND date<=? AND (IFNULL(location,'')=? OR IFNULL(location,'')='') AND (is_deleted IS NULL OR is_deleted=0) AND (status IS NULL OR status!='VOID')",
                    new String[]{start, end, defaultSite})) {
                if (c.moveToFirst()) {
                    pieces = c.getInt(0);
                    sales = c.getDouble(1);
                }
            }

            // 2) 待处理提醒
            int pendingDelivery = 0;
            int pendingSync = 0;
            int pendingLabel = 0;
            try (Cursor c = db.rawQuery(
                    "SELECT COUNT(1) FROM orders WHERE COALESCE(printed,0)=0 AND (is_deleted IS NULL OR is_deleted=0) AND (status IS NULL OR status!='VOID') AND (IFNULL(location,'')=? OR IFNULL(location,'')='')",
                    new String[]{defaultSite})) {
                if (c.moveToFirst()) pendingDelivery = c.getInt(0);
            }
            try (Cursor c = db.rawQuery(
                    "SELECT (SELECT COUNT(1) FROM orders WHERE COALESCE(synced,1)=0) + " +
                    "(SELECT COUNT(1) FROM order_items WHERE COALESCE(synced,1)=0) + " +
                    "(SELECT COUNT(1) FROM inventory_items WHERE COALESCE(synced,1)=0) + " +
                    "(SELECT COUNT(1) FROM logistics_forms WHERE COALESCE(synced,1)=0) + " +
                    "(SELECT COUNT(1) FROM cloud_delete_queue)",
                    null)) {
                if (c.moveToFirst()) pendingSync = c.getInt(0);
            }
            String today = end;
            long printedMaxId = getLabelPrintedMaxId(today);
            try (Cursor c = db.rawQuery(
                    "SELECT COUNT(1) FROM orders WHERE SUBSTR(date,1,10)=? AND id>? AND (is_deleted IS NULL OR is_deleted=0) AND (status IS NULL OR status!='VOID') AND (IFNULL(location,'')=? OR IFNULL(location,'')='')",
                    new String[]{today, String.valueOf(printedMaxId), defaultSite})) {
                if (c.moveToFirst()) pendingLabel = c.getInt(0);
            }
            pendingReminders.append("未打印送货单：").append(pendingDelivery).append(" 单\n");
            pendingReminders.append("今日待打印箱唛：").append(pendingLabel).append(" 单\n");
            pendingReminders.append("待同步数据：").append(pendingSync).append(" 条");

            // 3) 低库存预警
            List<InventoryItem> lowItems = databaseHelper.getLowStockItems();
            int lowCount = 0;
            if (lowItems != null) {
                lowCount = lowItems.size();
                lowItems.sort((a, b) -> {
                    int aq = a == null ? 0 : a.getQuantity();
                    int as = a == null ? 0 : a.getSafetyStock();
                    int bq = b == null ? 0 : b.getQuantity();
                    int bs = b == null ? 0 : b.getSafetyStock();
                    if (aq == 0 && bq != 0) return -1;
                    if (aq != 0 && bq == 0) return 1;
                    return Integer.compare((bs - bq), (as - aq));
                });
                int limit = Math.min(5, lowItems.size());
                for (int i = 0; i < limit; i++) {
                    InventoryItem it = lowItems.get(i);
                    if (it == null) continue;
                    lowStockText.append(i + 1).append(". ")
                            .append(friendlyType(it.getType())).append("/")
                            .append(nvl(it.getName()))
                            .append("  当前").append(it.getQuantity())
                            .append(" / 安全").append(it.getSafetyStock())
                            .append("\n");
                }
                if (lowItems.size() > limit) {
                    lowStockText.append("另有 ").append(lowItems.size() - limit).append(" 项低库存");
                }
            }
            if (lowCount > 0) {
                pendingReminders.append("\n低库存项目：").append(lowCount).append(" 项");
            }

            // 4) 客户排行（按销售额）
            try (Cursor c = db.rawQuery(
                    "SELECT customer_name, COALESCE(SUM(quantity*price),0) AS s FROM orders WHERE date>=? AND date<=? AND (IFNULL(location,'')=? OR IFNULL(location,'')='') AND (is_deleted IS NULL OR is_deleted=0) AND (status IS NULL OR status!='VOID') GROUP BY customer_name ORDER BY s DESC LIMIT 5",
                    new String[]{start, end, defaultSite})) {
                int rank = 1;
                while (c.moveToNext()) {
                    String name = c.getString(0);
                    double s = c.getDouble(1);
                    if (name == null || name.trim().isEmpty()) continue;
                    topCustomers.append(rank).append(". ").append(name).append("  ¥").append(String.format(Locale.getDefault(), "%.2f", s)).append("\n");
                    rank++;
                }
            }

            // 5) 热销产品（按件数）
            try (Cursor c = db.rawQuery(
                    "SELECT product_name, COALESCE(SUM(pieces),0) AS pcs, COALESCE(SUM(quantity*price),0) AS amt FROM orders WHERE date>=? AND date<=? AND (IFNULL(location,'')=? OR IFNULL(location,'')='') AND (is_deleted IS NULL OR is_deleted=0) AND (status IS NULL OR status!='VOID') GROUP BY product_name ORDER BY pcs DESC, amt DESC LIMIT 5",
                    new String[]{start, end, defaultSite})) {
                int rank = 1;
                while (c.moveToNext()) {
                    String name = c.getString(0);
                    int pcs2 = c.getInt(1);
                    double amt = c.getDouble(2);
                    if (name == null || name.trim().isEmpty()) continue;
                    topProducts.append(rank).append(". ").append(name)
                            .append("  ").append(pcs2).append("件")
                            .append("  ¥").append(String.format(Locale.getDefault(), "%.2f", amt)).append("\n");
                    rank++;
                }
            }
        } catch (Exception ignored) {
        }

        tvPieces.setText(String.valueOf(pieces));
        tvSales.setText("¥" + String.format(Locale.getDefault(), "%.2f", sales));

        String pr = pendingReminders.toString().trim();
        String ls = lowStockText.toString().trim();
        String tc = topCustomers.toString().trim();
        String tp = topProducts.toString().trim();
        tvPendingReminders.setText(pr.isEmpty() ? "暂无" : pr);
        tvLowStock.setText(ls.isEmpty() ? "暂无低库存" : ls);
        tvTopCustomers.setText(tc.isEmpty() ? "暂无" : tc);
        tvTopProducts.setText(tp.isEmpty() ? "暂无" : tp);
    }

    private void ensureHomeRangeReady() {
        if (nvl(filterStartDate).isEmpty() || nvl(filterEndDate).isEmpty()) {
            applyPresetRange();
        }
    }

    private void applyPresetRange() {
        Calendar cal = Calendar.getInstance();
        filterEndDate = dateSdf.format(cal.getTime());
        if (currentRange == Range.DAY) {
            filterStartDate = filterEndDate;
        } else if (currentRange == Range.WEEK) {
            cal.add(Calendar.DAY_OF_YEAR, -6);
            filterStartDate = dateSdf.format(cal.getTime());
        } else if (currentRange == Range.MONTH) {
            cal.set(Calendar.DAY_OF_MONTH, 1);
            filterStartDate = dateSdf.format(cal.getTime());
        }
        updateHomeFilterButtons();
    }

    private void showHomeDatePicker(boolean isStart) {
        Calendar cal = Calendar.getInstance();
        try {
            String src = isStart ? filterStartDate : filterEndDate;
            if (!nvl(src).isEmpty()) cal.setTime(dateSdf.parse(src));
        } catch (Exception ignored) {}

        new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            Calendar picked = Calendar.getInstance();
            picked.set(Calendar.YEAR, year);
            picked.set(Calendar.MONTH, month);
            picked.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            String value = dateSdf.format(picked.getTime());
            if (isStart) filterStartDate = value; else filterEndDate = value;
            updateHomeFilterButtons();
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void applyCustomRange() {
        if (nvl(filterStartDate).isEmpty() || nvl(filterEndDate).isEmpty()) {
            toast("请先选择开始和结束日期");
            return;
        }
        if (filterStartDate.compareTo(filterEndDate) > 0) {
            toast("开始日期不能晚于结束日期");
            return;
        }
        currentRange = Range.CUSTOM;
        refreshReport();
    }

    private void updateHomeFilterButtons() {
        Button btnStart = findViewById(R.id.btnHomeStartDate);
        Button btnEnd = findViewById(R.id.btnHomeEndDate);
        if (btnStart != null) btnStart.setText(nvl(filterStartDate).isEmpty() ? "开始日期" : filterStartDate);
        if (btnEnd != null) btnEnd.setText(nvl(filterEndDate).isEmpty() ? "结束日期" : filterEndDate);
    }

    private void toast(String s) {
        try { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); } catch (Exception ignored) {}
    }

    private long getLabelPrintedMaxId(String date) {
        try {
            return getSharedPreferences(LABEL_PRINT_PREF, MODE_PRIVATE)
                    .getLong(KEY_LABEL_PRINTED_MAXID_PREFIX + nvl(date), 0L);
        } catch (Exception ignored) {
            return 0L;
        }
    }

    private String nvl(String s) {
        return s == null ? "" : s;
    }

    private String friendlyType(String type) {
        if (DatabaseHelper.INV_TYPE_PRODUCT.equals(type)) return "产品";
        if (DatabaseHelper.INV_TYPE_POT.equals(type)) return "花盆";
        if (DatabaseHelper.INV_TYPE_BAG.equals(type)) return "套袋";
        if (DatabaseHelper.INV_TYPE_CARTON.equals(type)) return "纸箱";
        return nvl(type);
    }



    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // 已经在首页，重新加载首页内容
            loadHomeContent();
        } else if (id == R.id.nav_sales) {
            startActivity(new Intent(this, SalesManagementActivity.class));
        } else if (id == R.id.nav_reports) {
            startActivity(new Intent(this, ReportsActivity.class));
        } else if (id == R.id.nav_inventory) {
            startActivity(new Intent(this, InventoryManagementActivity.class));
        } else if (id == R.id.nav_customer) {
            startActivity(new Intent(this, CustomerManagementActivity.class));
        } else if (id == R.id.nav_product) {
            startActivity(new Intent(this, ProductManagementActivity.class));
        } else if (id == R.id.nav_worker) {
            startActivity(new Intent(this, WorkerAllocationActivity.class));
        } else if (id == R.id.nav_logistics) {
            startActivity(new Intent(this, LogisticsManagementActivity.class));
        } else if (id == R.id.nav_print) {
            startActivity(new Intent(this, PrintManagementActivity.class));
        } else if (id == R.id.nav_templates) {
            // 模板中心
            startActivity(new Intent(this, TemplateCenterActivity.class));
        } else if (id == R.id.nav_finance) {
            // 应收/对账
            startActivity(new Intent(this, FinanceCenterActivity.class));
        } else if (id == R.id.nav_printer_settings) {
            // 打印机设置
            startActivity(new Intent(this, PrinterSettingsActivity.class));
        } else if (id == R.id.nav_account) {
            // 账号/同步
            startActivity(new Intent(this, SyncStatusActivity.class));
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadHomeContent();
    }
}