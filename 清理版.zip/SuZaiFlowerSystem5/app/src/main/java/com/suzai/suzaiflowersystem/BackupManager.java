package com.suzai.suzaiflowersystem;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.SystemClock;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * 完整备份/恢复管理器
 * 目标：恢复后与导出时 APP 本地状态保持一致。
 */
public class BackupManager {

    public static final String BACKUP_FILE_PREFIX = "SuZaiFullBackup_";
    private static final String MANIFEST_PATH = "meta/manifest.json";
    private static final String ROOT_DATABASES = "databases";
    private static final String ROOT_SHARED_PREFS = "shared_prefs";
    private static final String ROOT_FILES = "files";
    private static final String ROOT_NO_BACKUP = "no_backup";

    private BackupManager() {}

    public static String buildDefaultBackupFileName() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US);
        sdf.setTimeZone(TimeZone.getDefault());
        return BACKUP_FILE_PREFIX + sdf.format(new Date()) + ".zip";
    }

    public static void exportFullBackup(Context ctx, Uri targetUri) throws Exception {
        if (ctx == null || targetUri == null) throw new IllegalArgumentException("导出目标不能为空");
        ContentResolver resolver = ctx.getContentResolver();
        try (OutputStream os = resolver.openOutputStream(targetUri, "w")) {
            if (os == null) throw new IOException("无法打开导出目标");
            try (ZipOutputStream zos = new ZipOutputStream(os)) {
                zos.setLevel(9);

                JSONObject manifest = buildManifest(ctx);
                putTextEntry(zos, MANIFEST_PATH, manifest.toString(2));

                addDirIfExists(zos, getDatabasesDir(ctx), ROOT_DATABASES + "/");
                addDirIfExists(zos, getSharedPrefsDir(ctx), ROOT_SHARED_PREFS + "/");
                addDirIfExists(zos, safeDir(ctx.getFilesDir()), ROOT_FILES + "/");
                addDirIfExists(zos, safeDir(ctx.getNoBackupFilesDir()), ROOT_NO_BACKUP + "/");
            }
        }
    }

    public static void restoreFullBackup(Context ctx, Uri sourceUri) throws Exception {
        if (ctx == null || sourceUri == null) throw new IllegalArgumentException("恢复来源不能为空");

        File tempRoot = new File(ctx.getCacheDir(), "full_restore_" + System.currentTimeMillis());
        if (!tempRoot.mkdirs()) throw new IOException("无法创建临时恢复目录");

        boolean hasManifest = false;
        try {
            try (InputStream is = ctx.getContentResolver().openInputStream(sourceUri)) {
                if (is == null) throw new IOException("无法打开备份文件");
                try (ZipInputStream zis = new ZipInputStream(is)) {
                    ZipEntry entry;
                    while ((entry = zis.getNextEntry()) != null) {
                        String name = sanitizeZipPath(entry.getName());
                        if (name == null) continue;
                        File out = new File(tempRoot, name);
                        if (entry.isDirectory()) {
                            if (!out.exists() && !out.mkdirs()) {
                                throw new IOException("无法创建目录: " + out.getAbsolutePath());
                            }
                        } else {
                            File parent = out.getParentFile();
                            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                                throw new IOException("无法创建目录: " + parent.getAbsolutePath());
                            }
                            try (FileOutputStream fos = new FileOutputStream(out)) {
                                copy(zis, fos);
                            }
                            if (MANIFEST_PATH.equals(name)) hasManifest = true;
                        }
                        zis.closeEntry();
                    }
                }
            }

            if (!hasManifest) throw new IOException("备份包无效：缺少 manifest");

            // 尽量关闭数据库句柄，降低恢复时文件被占用的概率
            try { new DatabaseHelper(ctx).close(); } catch (Exception ignored) {}
            try { android.database.sqlite.SQLiteDatabase.releaseMemory(); } catch (Exception ignored) {}

            restoreDir(new File(tempRoot, ROOT_DATABASES), getDatabasesDir(ctx), true);
            restoreDir(new File(tempRoot, ROOT_SHARED_PREFS), getSharedPrefsDir(ctx), true);
            restoreDir(new File(tempRoot, ROOT_FILES), safeDir(ctx.getFilesDir()), true);
            restoreDir(new File(tempRoot, ROOT_NO_BACKUP), safeDir(ctx.getNoBackupFilesDir()), true);
        } finally {
            deleteRecursively(tempRoot);
        }
    }

    public static void scheduleAppRestart(Context ctx) {
        try {
            Intent i = new Intent(ctx, LoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            PendingIntent pi = PendingIntent.getActivity(
                    ctx,
                    9527,
                    i,
                    PendingIntent.FLAG_CANCEL_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            if (am != null) {
                am.set(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 600, pi);
            }
        } catch (Exception ignored) {}
    }

    private static JSONObject buildManifest(Context ctx) {
        JSONObject o = new JSONObject();
        try {
            o.put("format", "suzai_full_backup_v1");
            o.put("packageName", ctx.getPackageName());
            o.put("createdAt", isoNow());
            o.put("appVersionName", getVersionName(ctx));
            o.put("appVersionCode", getVersionCode(ctx));
            o.put("userEmail", AuthManager.getEmail(ctx));
            o.put("userId", AuthManager.getUserId(ctx));
            JSONArray roots = new JSONArray();
            roots.put(ROOT_DATABASES);
            roots.put(ROOT_SHARED_PREFS);
            roots.put(ROOT_FILES);
            roots.put(ROOT_NO_BACKUP);
            o.put("roots", roots);
            o.put("goal", "restore_exact_same_local_state");
        } catch (Exception ignored) {}
        return o;
    }

    private static String getVersionName(Context ctx) {
        try {
            return ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "unknown";
        }
    }

    private static long getVersionCode(Context ctx) {
        try {
            return ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0).getLongVersionCode();
        } catch (Exception e) {
            return -1;
        }
    }

    private static String isoNow() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US);
        sdf.setTimeZone(TimeZone.getDefault());
        return sdf.format(new Date());
    }

    private static File getDatabasesDir(Context ctx) {
        return new File(ctx.getApplicationInfo().dataDir, ROOT_DATABASES);
    }

    private static File getSharedPrefsDir(Context ctx) {
        return new File(ctx.getApplicationInfo().dataDir, ROOT_SHARED_PREFS);
    }

    private static File safeDir(File dir) {
        return dir != null ? dir : new File("/nonexistent");
    }

    private static void addDirIfExists(ZipOutputStream zos, File dir, String rootPath) throws IOException {
        if (dir == null || !dir.exists()) return;
        List<File> stack = new ArrayList<>();
        stack.add(dir);
        while (!stack.isEmpty()) {
            File f = stack.remove(stack.size() - 1);
            String relative = relativize(dir, f);
            String zipPath = rootPath + relative;
            if (f.isDirectory()) {
                if (!relative.isEmpty()) {
                    if (!zipPath.endsWith("/")) zipPath += "/";
                    zos.putNextEntry(new ZipEntry(zipPath));
                    zos.closeEntry();
                }
                File[] children = f.listFiles();
                if (children != null) {
                    for (int i = children.length - 1; i >= 0; i--) stack.add(children[i]);
                }
            } else if (f.isFile()) {
                ZipEntry ze = new ZipEntry(zipPath);
                ze.setTime(f.lastModified());
                zos.putNextEntry(ze);
                try (FileInputStream fis = new FileInputStream(f)) {
                    copy(fis, zos);
                }
                zos.closeEntry();
            }
        }
    }

    private static String relativize(File root, File f) {
        String rp = root.getAbsolutePath();
        String fp = f.getAbsolutePath();
        if (fp.equals(rp)) return "";
        String rel = fp.substring(rp.length());
        while (rel.startsWith(File.separator)) rel = rel.substring(1);
        return rel.replace(File.separatorChar, '/');
    }

    private static void putTextEntry(ZipOutputStream zos, String path, String text) throws IOException {
        zos.putNextEntry(new ZipEntry(path));
        byte[] data = text.getBytes(StandardCharsets.UTF_8);
        zos.write(data);
        zos.closeEntry();
    }

    private static String sanitizeZipPath(String raw) {
        if (raw == null) return null;
        String name = raw.replace('\\', '/');
        while (name.startsWith("/")) name = name.substring(1);
        if (name.contains("../") || name.equals("..") || name.startsWith("../")) return null;
        return name;
    }

    private static void restoreDir(File extractedRoot, File targetRoot, boolean deleteTargetFirst) throws IOException {
        if (extractedRoot == null || !extractedRoot.exists()) return;
        if (deleteTargetFirst && targetRoot.exists()) deleteChildren(targetRoot);
        if (!targetRoot.exists() && !targetRoot.mkdirs()) {
            throw new IOException("无法创建恢复目录: " + targetRoot.getAbsolutePath());
        }
        copyTree(extractedRoot, targetRoot);
    }

    private static void deleteChildren(File dir) throws IOException {
        File[] children = dir.listFiles();
        if (children == null) return;
        for (File c : children) deleteRecursively(c);
    }

    private static void copyTree(File src, File dest) throws IOException {
        if (src.isDirectory()) {
            if (!dest.exists() && !dest.mkdirs()) {
                throw new IOException("无法创建目录: " + dest.getAbsolutePath());
            }
            File[] children = src.listFiles();
            if (children != null) {
                for (File child : children) {
                    copyTree(child, new File(dest, child.getName()));
                }
            }
        } else {
            File parent = dest.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                throw new IOException("无法创建目录: " + parent.getAbsolutePath());
            }
            try (FileInputStream fis = new FileInputStream(src);
                 FileOutputStream fos = new FileOutputStream(dest)) {
                copy(fis, fos);
            }
            dest.setLastModified(src.lastModified());
        }
    }

    private static void copy(InputStream is, OutputStream os) throws IOException {
        byte[] buf = new byte[8192];
        int len;
        while ((len = is.read(buf)) != -1) {
            os.write(buf, 0, len);
        }
        os.flush();
    }

    private static void deleteRecursively(File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File c : children) deleteRecursively(c);
            }
        }
        try { file.delete(); } catch (Exception ignored) {}
    }
}
