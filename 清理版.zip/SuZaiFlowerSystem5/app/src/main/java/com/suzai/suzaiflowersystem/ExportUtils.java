package com.suzai.suzaiflowersystem;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * 导出工具：把 HTML/CSV 等文本导出到「下载」目录，方便微信/QQ/电脑/WPS/浏览器打开编辑。
 */
public class ExportUtils {

    /**
     * 保存文本到 Downloads/SuZaiExports/{date}/
     * @return 导出文件的 Uri（可能为 null）
     */
    public static Uri saveTextToDownloads(Context context,
                                          String relativeFolderInDownloads,
                                          String fileName,
                                          String mimeType,
                                          String content) throws Exception {

        if (mimeType == null || mimeType.trim().isEmpty()) {
            mimeType = "text/plain";
        }

        // Android 10+ 推荐走 MediaStore
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver resolver = context.getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
            values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
            String rel = Environment.DIRECTORY_DOWNLOADS;
            if (relativeFolderInDownloads != null && !relativeFolderInDownloads.trim().isEmpty()) {
                // 形如: Download/SuZaiExports/2025-12-28
                rel = rel + File.separator + relativeFolderInDownloads;
            }
            values.put(MediaStore.Downloads.RELATIVE_PATH, rel);
            Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) return null;

            OutputStream os = resolver.openOutputStream(uri);
            if (os != null) {
                os.write(content.getBytes(StandardCharsets.UTF_8));
                os.flush();
                os.close();
            }
            return uri;
        }

        // Android 9 及以下：直接写入公共下载目录（部分机型可能需要存储权限）
        File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File dir = downloads;
        if (relativeFolderInDownloads != null && !relativeFolderInDownloads.trim().isEmpty()) {
            dir = new File(downloads, relativeFolderInDownloads);
        }
        if (!dir.exists()) {
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
        }
        File out = new File(dir, fileName);
        FileOutputStream fos = new FileOutputStream(out);
        fos.write(content.getBytes(StandardCharsets.UTF_8));
        fos.flush();
        fos.close();
        return Uri.fromFile(out);
    }
}
