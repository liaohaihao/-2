package com.suzai.suzaiflowersystem;

public class ArAllocationRow {
    public String cloudId;
    public String siteName;
    public String invoiceCloudId;
    public String paymentCloudId;
    public double amount;
    public String note;
}
