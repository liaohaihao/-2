package com.suzai.suzaiflowersystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {

    public interface OnProductActionListener {
        void onProductClick(String productName);
        void onDeleteClick(String productName);
    }

    private final List<String> products;
    private final OnProductActionListener listener;

    public ProductAdapter(List<String> products, OnProductActionListener listener) {
        this.products = products;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        String productName = products.get(position);
        holder.productNameTextView.setText(productName);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onProductClick(productName);
        });

        holder.deleteProductButton.setOnClickListener(v -> {
            if (listener != null) listener.onDeleteClick(productName);
        });
    }

    @Override
    public int getItemCount() {
        return products == null ? 0 : products.size();
    }

    static class ProductViewHolder extends RecyclerView.ViewHolder {
        TextView productNameTextView;
        ImageButton deleteProductButton;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            productNameTextView = itemView.findViewById(R.id.productNameTextView);
            deleteProductButton = itemView.findViewById(R.id.deleteProductButton);
        }
    }
}
