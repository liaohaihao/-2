package com.suzai.suzaiflowersystem;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Step3：对账
 * - 选择客户 + 日期范围
 * - 汇总：出货合计 / 收款合计 / 余额
 * - 列表：时间线（出货/收款）
 * - 导出 Excel：多工作表（Summary/Orders/Payments）
 */
public class ReconciliationActivity extends BaseDrawerActivity {

    public static final String EXTRA_CUSTOMER_NAME = "extra_customer_name";

    private DatabaseHelper db;

    private Spinner spinnerCustomer;
    private Button btnStart, btnEnd, btnRefresh, btnExport, btnAddPayment;
    private TextView tvSummary;

    private Calendar startCal, endCal;

    // 月结设置（来自“客户账期”）：key=settle_mode_<customer> value: monthly/days
    private static final String PREFS = "finance_terms_prefs";
    private static final String KEY_PREFIX = "settle_mode_";

    private ReconcileRowAdapter adapter;
    private List<DatabaseHelper.OrderBrief> currentOrders = new ArrayList<>();
    private List<PaymentRecord> currentPayments = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("对账");
        setContentLayout(R.layout.activity_reconciliation);

        db = new DatabaseHelper(this);

        spinnerCustomer = findViewById(R.id.spinner_customer);
        btnStart = findViewById(R.id.btn_start);
        btnEnd = findViewById(R.id.btn_end);
        btnRefresh = findViewById(R.id.btn_refresh);
        btnExport = findViewById(R.id.btn_export);
        btnAddPayment = findViewById(R.id.btn_add_payment);
        tvSummary = findViewById(R.id.tv_summary);

        RecyclerView rv = findViewById(R.id.recycler_reconcile);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ReconcileRowAdapter(row -> onRowClick(row));
        rv.setAdapter(adapter);

        // customers spinner
        List<String> customers = db.getAllCustomerNamesSafe();
        if (customers == null) customers = new ArrayList<>();
        ArrayAdapter<String> spAd = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, customers);
        spAd.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCustomer.setAdapter(spAd);

        String pre = getIntent().getStringExtra(EXTRA_CUSTOMER_NAME);
        if (!TextUtils.isEmpty(pre)) {
            int idx = customers.indexOf(pre);
            if (idx >= 0) spinnerCustomer.setSelection(idx);
        }

        startCal = Calendar.getInstance();
        endCal = Calendar.getInstance();
        // 默认：
        // - 月结客户：默认当月（本月出货，下月结清）
        // - 按天数客户：默认最近30天
        String initCustomer = (String) spinnerCustomer.getSelectedItem();
        if (isMonthlyMode(initCustomer)) {
            snapToMonth(startCal);
            snapEndToMonth(endCal, startCal);
        } else {
            startCal.add(Calendar.DAY_OF_MONTH, -30);
        }

        updateDateButtons();

        btnStart.setOnClickListener(v -> pickDate(true));
        btnEnd.setOnClickListener(v -> pickDate(false));
        btnRefresh.setOnClickListener(v -> refresh());
        btnExport.setOnClickListener(v -> exportExcel());
        btnAddPayment.setOnClickListener(v -> showAddPaymentDialog());

        refresh();
    }

    private void pickDate(boolean isStart) {
        Calendar c = isStart ? startCal : endCal;
        new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            c.set(Calendar.YEAR, year);
            c.set(Calendar.MONTH, month);
            c.set(Calendar.DAY_OF_MONTH, dayOfMonth);

            // 月结模式下：用户选任意日期 -> 自动对齐到“该月份”
            String customer = (String) spinnerCustomer.getSelectedItem();
            if (isMonthlyMode(customer)) {
                snapToMonth(startCal);
                snapEndToMonth(endCal, startCal);
            }
            updateDateButtons();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void updateDateButtons() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        String customer = (String) spinnerCustomer.getSelectedItem();
        if (isMonthlyMode(customer)) {
            // 月结：显示对账月份（开始/结束仍然是当月首尾）
            btnStart.setText("月份：" + new SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(startCal.getTime()));
            btnEnd.setText("范围：" + sdf.format(startCal.getTime()) + " ~ " + sdf.format(endCal.getTime()));
        } else {
            btnStart.setText("开始：" + sdf.format(startCal.getTime()));
            btnEnd.setText("结束：" + sdf.format(endCal.getTime()));
        }
    }

    private void refresh() {
        String customer = (String) spinnerCustomer.getSelectedItem();
        if (TextUtils.isEmpty(customer)) {
            Toast.makeText(this, "没有客户数据", Toast.LENGTH_SHORT).show();
            return;
        }

        // 月结：强制对账范围=当月首尾（本月出货，下月结清）
        if (isMonthlyMode(customer)) {
            snapToMonth(startCal);
            snapEndToMonth(endCal, startCal);
            updateDateButtons();
        }
        String start = fmtDate(startCal.getTime());
        String end = fmtDate(endCal.getTime());

        // Step2-1：自动维护订单结清状态（SETTLED）
        try { db.recomputeSettlementForRange(customer, start, end); } catch (Exception ignored) {}


        currentOrders = db.queryOrdersBrief(customer, start, end);
        currentPayments = db.queryPayments(customer, start, end);

        double shipSum = 0;
        for (DatabaseHelper.OrderBrief o : currentOrders) shipSum += o.totalAmount;
        double paySum = 0;
        for (PaymentRecord p : currentPayments) paySum += p.amount;
        double balance = shipSum - paySum;

        if (isMonthlyMode(customer)) {
            String due = fmtDate(calcNextMonthLastDay(startCal).getTime());
            tvSummary.setText(String.format(Locale.getDefault(), "出货：%.2f  收款：%.2f  余额：%.2f\n结清截止（下月）：%s", shipSum, paySum, balance, due));
        } else {
            tvSummary.setText(String.format(Locale.getDefault(), "出货：%.2f  收款：%.2f  余额：%.2f", shipSum, paySum, balance));
        }

        // timeline rows
        List<ReconcileRow> timeline = new ArrayList<>();
        for (DatabaseHelper.OrderBrief o : currentOrders) {
            ReconcileRow r = new ReconcileRow();
            r.type = "出货";
            r.date = o.date;
            r.amount = o.totalAmount;
            r.orderId = o.id;
            r.desc = "订单：" + nvl(o.orderNo) + (TextUtils.isEmpty(o.remark) ? "" : (" 备注：" + o.remark));
            timeline.add(r);
        }
        for (PaymentRecord p : currentPayments) {
            ReconcileRow r = new ReconcileRow();
            r.type = "收款";
            r.date = p.payDate;
            r.amount = p.amount;
            r.paymentId = p.id;
            r.desc = (TextUtils.isEmpty(p.method) ? "" : ("方式：" + p.method + " ")) + nvl(p.remark);
            timeline.add(r);
        }
        // 按日期简单排序（字符串 yyyy-MM-dd 可直接比）
        timeline.sort((a,b)-> nvl(a.date).compareTo(nvl(b.date)));

        adapter.setData(timeline);
    }

    private void exportExcel() {
        try {
            String customer = (String) spinnerCustomer.getSelectedItem();
            if (TextUtils.isEmpty(customer)) return;

            double shipSum = 0;
            for (DatabaseHelper.OrderBrief o : currentOrders) shipSum += o.totalAmount;
            double paySum = 0;
            for (PaymentRecord p : currentPayments) paySum += p.amount;
            double balance = shipSum - paySum;

            String start = fmtDate(startCal.getTime());
            String end = fmtDate(endCal.getTime());
            boolean monthly = isMonthlyMode(customer);
            String due = monthly ? fmtDate(calcNextMonthLastDay(startCal).getTime()) : "";

            // sheet1 summary
            List<SpreadsheetXml.Sheet> sheets = new ArrayList<>();

            SpreadsheetXml.Sheet s1 = new SpreadsheetXml.Sheet();
            s1.name = "Summary";
            s1.title = "对账汇总";
            s1.subtitle = monthly
                    ? ("客户：" + customer + "  月结月份：" + new SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(startCal.getTime()) + "  范围：" + start + " ~ " + end + "  结清截止：" + due)
                    : ("客户：" + customer + "  日期：" + start + " ~ " + end);
            s1.headers = new String[]{"项目", "金额"};
            s1.rows = new ArrayList<>();
            s1.rows.add(row("出货合计", fmt2(shipSum)));
            s1.rows.add(row("收款合计", fmt2(paySum)));
            s1.rows.add(row("应收余额", fmt2(balance)));
            if (monthly) s1.rows.add(row("结清截止(下月)", due));
            sheets.add(s1);

            // sheet2 orders
            SpreadsheetXml.Sheet s2 = new SpreadsheetXml.Sheet();
            s2.name = "Orders";
            s2.title = "出货明细";
            s2.subtitle = s1.subtitle;
            s2.headers = new String[]{"日期", "订单号", "金额", "备注"};
            s2.rows = new ArrayList<>();
            for (DatabaseHelper.OrderBrief o : currentOrders) {
                s2.rows.add(row(nvl(o.date), nvl(o.orderNo), fmt2(o.totalAmount), nvl(o.remark)));
            }
            sheets.add(s2);

            // sheet3 payments
            SpreadsheetXml.Sheet s3 = new SpreadsheetXml.Sheet();
            s3.name = "Payments";
            s3.title = "收款明细";
            s3.subtitle = s1.subtitle;
            s3.headers = new String[]{"日期", "金额", "方式", "备注"};
            s3.rows = new ArrayList<>();
            for (PaymentRecord p : currentPayments) {
                s3.rows.add(row(nvl(p.payDate), fmt2(p.amount), nvl(p.method), nvl(p.remark)));
            }
            sheets.add(s3);

            String xml = SpreadsheetXml.buildWorkbookMulti(sheets);

            String month = new SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(new Date());
            String fileName = "对账_" + customer + "_" + start + "_to_" + end + ".xls";
            Uri uri = ExportUtils.saveTextToDownloads(this, "SuZaiExports/Finance/" + month, fileName,
                    "application/vnd.ms-excel", xml);
            Toast.makeText(this, uri == null ? "导出失败" : "已导出：" + fileName, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "导出失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private static List<String> row(String a, String b) {
        List<String> l = new ArrayList<>();
        l.add(a); l.add(b);
        return l;
    }
    private static List<String> row(String a, String b, String c, String d) {
        List<String> l = new ArrayList<>();
        l.add(a); l.add(b); l.add(c); l.add(d);
        return l;
    }

    // ===================== 月结工具（不改数据库，仅读 CustomerTermsActivity 存的 prefs） =====================
    private boolean isMonthlyMode(String customer) {
        // 默认月结：本月货款下月结清
        if (TextUtils.isEmpty(customer)) return true;
        String v = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_PREFIX + customer, "monthly");
        return "monthly".equalsIgnoreCase(v);
    }

    /** 对齐到该月第一天（保留年月） */
    private static void snapToMonth(Calendar c) {
        if (c == null) return;
        c.set(Calendar.DAY_OF_MONTH, 1);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
    }

    /** end= start所在月份的最后一天 */
    private static void snapEndToMonth(Calendar end, Calendar start) {
        if (end == null || start == null) return;
        Calendar tmp = (Calendar) start.clone();
        tmp.set(Calendar.DAY_OF_MONTH, 1);
        tmp.add(Calendar.MONTH, 1);
        tmp.add(Calendar.DAY_OF_MONTH, -1);
        end.setTime(tmp.getTime());
        end.set(Calendar.HOUR_OF_DAY, 23);
        end.set(Calendar.MINUTE, 59);
        end.set(Calendar.SECOND, 59);
        end.set(Calendar.MILLISECOND, 0);
    }

    /** 计算“下月结清”的截止日：= 对账月份的下一个月最后一天 */
    private static Calendar calcNextMonthLastDay(Calendar monthAnyDay) {
        Calendar c = (monthAnyDay == null) ? Calendar.getInstance() : (Calendar) monthAnyDay.clone();
        // 先对齐到本月1号
        c.set(Calendar.DAY_OF_MONTH, 1);
        // 再到下下个月1号-1天 = 下月最后一天
        c.add(Calendar.MONTH, 2);
        c.set(Calendar.DAY_OF_MONTH, 1);
        c.add(Calendar.DAY_OF_MONTH, -1);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c;
    }


    private void onRowClick(ReconcileRow row) {
        if (row == null) return;
        // 点击收款行：支持删除（避免误录）
        if ("收款".equals(row.type) && row.paymentId > 0) {
            new android.app.AlertDialog.Builder(this)
                    .setTitle("收款记录")
                    .setMessage("日期：" + nvl(row.date) + "\n金额：" + fmt2(row.amount) + "\n" + nvl(row.desc) + "\n\n是否删除这条收款？")
                    .setPositiveButton("删除", (d,w)->{
                        db.softDeletePayment(row.paymentId);
                        refresh();
                    })
                    .setNegativeButton("取消", null)
                    .show();
        }
    }

    private void showAddPaymentDialog() {
        String customer = (String) spinnerCustomer.getSelectedItem();
        if (android.text.TextUtils.isEmpty(customer)) return;

        android.widget.LinearLayout wrap = new android.widget.LinearLayout(this);
        wrap.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = (int) (getResources().getDisplayMetrics().density * 12);
        wrap.setPadding(pad, pad, pad, pad);

        final android.widget.EditText etAmount = new android.widget.EditText(this);
        etAmount.setHint("收款金额");
        etAmount.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        wrap.addView(etAmount);

        final android.widget.EditText etMethod = new android.widget.EditText(this);
        etMethod.setHint("方式（现金/转账/微信等，可选）");
        wrap.addView(etMethod);

        final android.widget.EditText etRemark = new android.widget.EditText(this);
        etRemark.setHint("备注（可选）");
        wrap.addView(etRemark);

        final java.util.Calendar payCal = java.util.Calendar.getInstance();
        final android.widget.Button btnDate = new android.widget.Button(this);
        btnDate.setText("日期：" + fmtDate(payCal.getTime()));
        btnDate.setOnClickListener(v -> new android.app.DatePickerDialog(this, (view, year, month, day) -> {
            payCal.set(java.util.Calendar.YEAR, year);
            payCal.set(java.util.Calendar.MONTH, month);
            payCal.set(java.util.Calendar.DAY_OF_MONTH, day);
            btnDate.setText("日期：" + fmtDate(payCal.getTime()));
        }, payCal.get(java.util.Calendar.YEAR), payCal.get(java.util.Calendar.MONTH), payCal.get(java.util.Calendar.DAY_OF_MONTH)).show());
        wrap.addView(btnDate);

        new android.app.AlertDialog.Builder(this)
                .setTitle("新增收款：" + customer)
                .setView(wrap)
                .setPositiveButton("保存", (d,w)->{
                    try {
                        double amt = 0;
                        try { amt = Double.parseDouble(etAmount.getText().toString().trim()); } catch (Exception ignored) {}
                        if (amt <= 0) {
                            Toast.makeText(this, "金额必须大于0", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        db.addPayment(customer, amt, fmtDate(payCal.getTime()),
                                etMethod.getText().toString().trim(),
                                etRemark.getText().toString().trim());
                        refresh();
                    } catch (Exception e) {
                        Toast.makeText(this, "保存失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private static String fmtDate(Date d) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(d);
    }
    private static String fmt2(double v) { return String.format(Locale.getDefault(), "%.2f", v); }
    private static String nvl(String s) { return s == null ? "" : s; }
}
