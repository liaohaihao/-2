package com.suzai.suzaiflowersystem;

import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

public class NetworkPrinterClient {

    public static void send(String host, int port, byte[] data, int timeoutMs) throws Exception {
        if (host == null || host.trim().isEmpty()) {
            throw new IllegalArgumentException("打印机地址为空");
        }
        Socket socket = new Socket();
        socket.connect(new InetSocketAddress(host.trim(), port), timeoutMs);
        socket.setSoTimeout(timeoutMs);

        OutputStream os = socket.getOutputStream();
        os.write(data);
        os.flush();
        try { os.close(); } catch (Exception ignore) {}
        try { socket.close(); } catch (Exception ignore) {}
    }
}