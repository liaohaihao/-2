package com.suzai.suzaiflowersystem;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.UUID;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 云端财务：应收账单（ar_invoices）
 * - 仅做“可同步”的最小可用 UI：列表 + 新增/编辑 + 导出
 * - 删除不做物理删：建议用 status=closed 作为结清/作废
 */
public class ArInvoicesActivity extends BaseDrawerActivity {

    private DatabaseHelper db;
    private ArInvoiceAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("应收账单（云）");
        setContentLayout(R.layout.activity_ar_invoices);

        db = new DatabaseHelper(this);

        Button btnAdd = findViewById(R.id.btn_add);
        Button btnRefresh = findViewById(R.id.btn_refresh);
        Button btnExport = findViewById(R.id.btn_export);

        // ✅ 从订单生成账单（默认当月 + 选择月份）
        addGenerateButtons();

        RecyclerView rv = findViewById(R.id.recycler);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ArInvoiceAdapter(new ArInvoiceAdapter.OnClick() {
            @Override public void onItem(ArInvoiceRow row) {
                showEditDialog(row);
            }
        });
        rv.setAdapter(adapter);

        btnAdd.setOnClickListener(v -> showEditDialog(null));
        btnRefresh.setOnClickListener(v -> refresh());
        btnExport.setOnClickListener(v -> exportExcel());

        refresh();
    }

    private void addGenerateButtons() {
        // 直接在 RecyclerView 上方插入一行按钮，不依赖特定 layout id
        try {
            View activityRoot = findViewById(R.id.recycler);
            if (activityRoot == null) return;
            ViewGroup parent = (ViewGroup) activityRoot.getParent();
            if (parent == null) return;

            // 避免重复插入
            if (parent.findViewWithTag("ar_gen_bar") != null) return;

            android.widget.LinearLayout bar = new android.widget.LinearLayout(this);
            bar.setTag("ar_gen_bar");
            bar.setOrientation(android.widget.LinearLayout.HORIZONTAL);
            bar.setPadding(dp(12), dp(0), dp(12), dp(8));
            bar.setGravity(android.view.Gravity.CENTER_VERTICAL);

            Button btnGenThisMonth = new Button(this);
            btnGenThisMonth.setText("生成当月账单");
            android.widget.LinearLayout.LayoutParams lp1 = new android.widget.LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            btnGenThisMonth.setLayoutParams(lp1);

            Button btnGenPick = new Button(this);
            btnGenPick.setText("选择月份生成");
            android.widget.LinearLayout.LayoutParams lp2 = new android.widget.LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp2.setMarginStart(dp(8));
            btnGenPick.setLayoutParams(lp2);

            bar.addView(btnGenThisMonth);
            bar.addView(btnGenPick);

            // 插在 RecyclerView 上方
            int idx = parent.indexOfChild(activityRoot);
            parent.addView(bar, idx);

            btnGenThisMonth.setOnClickListener(v -> {
                String period = new SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(new Date());
                generateInvoicesForPeriod(period);
            });

            btnGenPick.setOnClickListener(v -> showMonthPickerAndGenerate());
        } catch (Exception ignored) {
        }
    }

    private int dp(int v) {
        float d = getResources().getDisplayMetrics().density;
        return (int) (v * d + 0.5f);
    }

    private void showMonthPickerAndGenerate() {
        Calendar cal = Calendar.getInstance();
        int y = cal.get(Calendar.YEAR);
        int m = cal.get(Calendar.MONTH);
        DatePickerDialog dlg = new DatePickerDialog(this, (android.widget.DatePicker view, int year, int month, int dayOfMonth) -> {
            String period = String.format(Locale.getDefault(), "%04d-%02d", year, (month + 1));
            generateInvoicesForPeriod(period);
        }, y, m, 1);

        // 只选年月：隐藏 day picker（不同系统兼容处理）
        try {
            int dayId = getResources().getIdentifier("android:id/day", null, null);
            View day = dlg.getDatePicker().findViewById(dayId);
            if (day != null) day.setVisibility(View.GONE);
        } catch (Exception ignored) {}
        dlg.setTitle("选择月份");
        dlg.show();
    }

    private void generateInvoicesForPeriod(String periodYm) {
        if (TextUtils.isEmpty(periodYm)) return;

        List<DatabaseHelper.OrderArAggRow> rows = db.getOrderArAggForPeriod(periodYm);
        if (rows == null || rows.isEmpty()) {
            Toast.makeText(this, "该月份没有订单可生成账单", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("生成账单")
                .setMessage("将按【场地+客户】汇总订单生成应收账单（" + periodYm + "）。\n" +
                        "共 " + rows.size() + " 条，生成后可点同步上传云端。\n\n继续吗？")
                .setNegativeButton("取消", null)
                .setPositiveButton("继续", (d, w) -> {
                    String uid = nvl(AuthManager.getUserId(this));
                    int ok = 0;
                    for (DatabaseHelper.OrderArAggRow r : rows) {
                        String site = nvl(r.siteName);
                        String cust = nvl(r.customerName);
                        if (cust.isEmpty()) continue;

                        // ✅ 稳定 cloud_id：避免重复生成（同账号+场地+客户+月份固定一条）
                        String seed = uid + "|ar_inv|" + site + "|" + cust + "|" + periodYm;
                        String cid;
                        try {
                            cid = UUID.nameUUIDFromBytes(seed.getBytes(StandardCharsets.UTF_8)).toString();
                        } catch (Exception e) {
                            cid = UUID.randomUUID().toString();
                        }

                        db.upsertArInvoice(cid, site, cust, periodYm, r.amount, "open", "由订单生成");
                        ok++;
                    }
                    refresh();
                    Toast.makeText(this, "已生成/更新 " + ok + " 条账单（记得点同步上传）", Toast.LENGTH_LONG).show();
                })
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        adapter.setData(db.getArInvoices());
    }

    private void showEditDialog(ArInvoiceRow row) {
        boolean isNew = (row == null);
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_ar_invoice, null);
        EditText etCustomer = view.findViewById(R.id.et_customer);
        EditText etAmount = view.findViewById(R.id.et_amount);
        EditText etPeriod = view.findViewById(R.id.et_period);
        EditText etNote = view.findViewById(R.id.et_note);
        Spinner spStatus = view.findViewById(R.id.sp_status);

        String[] statusArr = new String[]{"open", "closed"};
        spStatus.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, statusArr));

        String defaultSite = nvl(AuthManager.getDefaultLocation(this));
        if (isNew) {
            etPeriod.setText(new SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(new Date()));
            spStatus.setSelection(0);
        } else {
            etCustomer.setText(nvl(row.customerName));
            etAmount.setText(fmt2(row.amount));
            etPeriod.setText(nvl(row.periodYm));
            etNote.setText(nvl(row.note));
            spStatus.setSelection("closed".equalsIgnoreCase(row.status) ? 1 : 0);
        }

        new AlertDialog.Builder(this)
                .setTitle(isNew ? "新增应收账单" : "编辑应收账单")
                .setView(view)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", (d, w) -> {
                    String customer = etCustomer.getText().toString().trim();
                    String amountStr = etAmount.getText().toString().trim();
                    String period = etPeriod.getText().toString().trim();
                    String note = etNote.getText().toString().trim();
                    String status = (String) spStatus.getSelectedItem();

                    if (TextUtils.isEmpty(customer)) {
                        Toast.makeText(this, "请输入客户", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (TextUtils.isEmpty(amountStr)) amountStr = "0";
                    double amount;
                    try { amount = Double.parseDouble(amountStr); } catch (Exception e) { amount = 0; }
                    if (TextUtils.isEmpty(period)) {
                        period = new SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(new Date());
                    }

                    db.upsertArInvoice(row == null ? null : row.cloudId,
                            defaultSite,
                            customer,
                            period,
                            amount,
                            status,
                            note);
                    refresh();
                    Toast.makeText(this, "已保存（记得点同步上传）", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void exportExcel() {
        try {
            List<ArInvoiceRow> rows = db.getArInvoices();
            String[] headers = new String[]{"场地", "客户", "月份", "金额", "状态", "备注"};
            List<List<String>> data = new ArrayList<>();
            for (ArInvoiceRow r : rows) {
                List<String> line = new ArrayList<>();
                line.add(nvl(r.siteName));
                line.add(nvl(r.customerName));
                line.add(nvl(r.periodYm));
                line.add(fmt2(r.amount));
                line.add(nvl(r.status));
                line.add(nvl(r.note));
                data.add(line);
            }
            String xml = SpreadsheetXml.buildWorkbookSingle("应收账单(云)", "ar_invoices", headers, data);
            String month = new SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(new Date());
            String fileName = "应收账单_云_" + month + ".xls";
            Uri uri = ExportUtils.saveTextToDownloads(this, "SuZaiExports/Finance/" + month, fileName,
                    "application/vnd.ms-excel", xml);
            Toast.makeText(this, uri == null ? "导出失败" : "已导出：" + fileName, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "导出失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private static String nvl(String s) { return s == null ? "" : s; }
    private static String fmt2(double v) { return String.format(Locale.getDefault(), "%.2f", v); }
}
