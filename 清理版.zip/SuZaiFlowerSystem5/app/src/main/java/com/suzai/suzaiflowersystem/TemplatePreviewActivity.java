package com.suzai.suzaiflowersystem;

import android.os.Bundle;
import android.text.TextUtils;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class TemplatePreviewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("模板预览");
        setContentView(R.layout.activity_template_preview);

        long id = getIntent().getLongExtra("template_id", 0);
        DatabaseHelper db = new DatabaseHelper(this);
        PrintTemplate t = db.getTemplateById(id);
        if (t == null) {
            Toast.makeText(this, "模板不存在", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String content = t.getContent() == null ? "" : t.getContent();
        String type = getIntent().getStringExtra(TemplateCenterActivity.EXTRA_TYPE);
        if (TextUtils.isEmpty(type)) type = t.getType();

        WebView wv = findViewById(R.id.webTemplatePreview);
        wv.getSettings().setJavaScriptEnabled(false);

        // ✅ 优先走可视化渲染（小票模板）；HTML 仍然支持；标签模板提示去拖拽编辑器
        String html = PrintMarkupRenderer.toPreviewHtml(content, type);
        wv.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
    }
}