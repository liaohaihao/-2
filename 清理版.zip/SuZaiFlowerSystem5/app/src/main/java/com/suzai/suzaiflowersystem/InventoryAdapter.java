package com.suzai.suzaiflowersystem;

import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.VH> {

    public interface Listener {
        void onEdit(InventoryItem item);
        void onInbound(InventoryItem item);
        void onAdjust(InventoryItem item);
        void onStocktake(InventoryItem item);
        void onDelete(InventoryItem item);
    }

    private final List<InventoryItem> items;
    private final Listener listener;

    public InventoryAdapter(List<InventoryItem> items, Listener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        InventoryItem it = items.get(position);

        String title = it.getName();
        if (it.getQuantity() < it.getSafetyStock()) {
            title = "⚠ " + title;
            h.titleTextView.setTypeface(null, Typeface.BOLD);
        } else {
            h.titleTextView.setTypeface(null, Typeface.BOLD);
        }
        h.titleTextView.setText(title);

        String sub = "";
        boolean isBag = DatabaseHelper.INV_TYPE_BAG.equals(it.getType());
        boolean isPot = DatabaseHelper.INV_TYPE_POT.equals(it.getType());
        boolean isProduct = DatabaseHelper.INV_TYPE_PRODUCT.equals(it.getType());
        boolean isBindType = isBag || isPot || isProduct;
        if (it.getSku() != null && !it.getSku().trim().isEmpty()) {
            sub += (isBindType ? "对应产品：" : "SKU：") + it.getSku();
        } else {
            sub += (isBindType ? "对应产品：未绑定" : "SKU：-");
        }
        if (it.getSpec() != null && !it.getSpec().trim().isEmpty()) {
            sub += "  |  规格：" + it.getSpec();
        }
        h.subtitleTextView.setText(sub);

        h.qtyTextView.setText("库存：" + it.getQuantity() + "   安全：" + it.getSafetyStock());

        h.itemView.setOnClickListener(v -> { if (listener != null) listener.onEdit(it); });
        h.inboundButton.setOnClickListener(v -> { if (listener != null) listener.onInbound(it); });
        h.adjustButton.setOnClickListener(v -> { if (listener != null) listener.onAdjust(it); });
        h.stocktakeButton.setOnClickListener(v -> { if (listener != null) listener.onStocktake(it); });
        h.deleteButton.setOnClickListener(v -> { if (listener != null) listener.onDelete(it); });
    }
    /**
     * 替换数据并刷新列表（供 Activity 调用）。
     */
    public void setItems(java.util.List<InventoryItem> newItems) {
        items.clear();
        if (newItems != null) items.addAll(newItems);
        notifyDataSetChanged();
    }



    @Override
    public int getItemCount() { return items == null ? 0 : items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView titleTextView, subtitleTextView, qtyTextView;
        Button inboundButton, adjustButton, stocktakeButton, deleteButton;
        VH(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.titleTextView);
            subtitleTextView = itemView.findViewById(R.id.subtitleTextView);
            qtyTextView = itemView.findViewById(R.id.qtyTextView);
            inboundButton = itemView.findViewById(R.id.inboundButton);
            adjustButton = itemView.findViewById(R.id.adjustButton);
            stocktakeButton = itemView.findViewById(R.id.stocktakeButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
