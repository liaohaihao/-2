package com.suzai.suzaiflowersystem;

import android.app.DatePickerDialog;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * 报表中心
 * - 月度出货（日汇总）
 * - 畅销品（月度，可切换按数量/件数/金额排序）
 * - 客户排行（月度）
 * - 低库存报表（当前库存快照）
 * 支持导出 Excel（SpreadsheetML -> .xls）
 */
public class ReportsActivity extends BaseDrawerActivity {

    private Spinner spinnerType;
    private Spinner spinnerBestSellingSort;
    private LinearLayout layoutBestSellingSort;
    private TextView tvRange;
    private Button btnPickStartDate;
    private Button btnPickEndDate;
    private Button btnRefresh;
    private Button btnExport;

    private RecyclerView recyclerView;
    private SimpleReportAdapter adapter;

    private DatabaseHelper db;
    private Calendar selectedRangeStart;
    private Calendar selectedRangeEnd;
    private final SimpleDateFormat dateSdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

    private enum ReportType {
        MONTHLY_SHIPMENTS("月度出货"),
        BEST_SELLING("畅销品"),
        CUSTOMER_RANKING("客户排行"),
        LOW_STOCK("低库存报表");

        final String label;
        ReportType(String label) { this.label = label; }
        public String toString() { return label; }
    }

    private enum BestSellingSort {
        BY_QUANTITY("按数量"),
        BY_PIECES("按件数"),
        BY_AMOUNT("按金额");

        final String label;
        BestSellingSort(String label) { this.label = label; }
        public String toString() { return label; }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentLayout(R.layout.activity_reports);
        if (toolbar != null) toolbar.setTitle("报表中心");
        android.view.View lite = findViewById(R.id.toolbarLite);
        if (lite != null) lite.setVisibility(android.view.View.GONE);

        db = new DatabaseHelper(this);

        spinnerType = findViewById(R.id.spinnerReportType);
        spinnerBestSellingSort = findViewById(R.id.spinnerBestSellingSort);
        layoutBestSellingSort = findViewById(R.id.layoutBestSellingSort);
        tvRange = findViewById(R.id.tvReportRange);
        btnPickStartDate = findViewById(R.id.btnPickStartDate);
        btnPickEndDate = findViewById(R.id.btnPickEndDate);
        btnRefresh = findViewById(R.id.btnRefreshReport);
        btnExport = findViewById(R.id.btnExportReport);

        recyclerView = findViewById(R.id.recyclerReport);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SimpleReportAdapter();
        recyclerView.setAdapter(adapter);

        ArrayAdapter<ReportType> typeAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, ReportType.values());
        typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerType.setAdapter(typeAdapter);

        ArrayAdapter<BestSellingSort> sortAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, BestSellingSort.values());
        sortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerBestSellingSort.setAdapter(sortAdapter);

        selectedRangeStart = Calendar.getInstance();
        selectedRangeEnd = Calendar.getInstance();
        selectedRangeStart.set(Calendar.DAY_OF_MONTH, 1);
        updateRangeLabel();
        syncBestSellingSortVisibility();

        spinnerType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                syncBestSellingSortVisibility();
                refresh();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        spinnerBestSellingSort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ReportType type = (ReportType) spinnerType.getSelectedItem();
                if (type == ReportType.BEST_SELLING) refresh();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        btnPickStartDate.setOnClickListener(v -> showDatePicker(true));
        btnPickEndDate.setOnClickListener(v -> showDatePicker(false));
        btnRefresh.setOnClickListener(v -> refresh());
        btnExport.setOnClickListener(v -> exportCurrent());

        refresh();
    }

    private void syncBestSellingSortVisibility() {
        if (layoutBestSellingSort == null) return;
        ReportType type = (ReportType) spinnerType.getSelectedItem();
        layoutBestSellingSort.setVisibility(type == ReportType.BEST_SELLING ? View.VISIBLE : View.GONE);
    }

    private void updateRangeLabel() {
        if (tvRange != null) {
            tvRange.setText(dateSdf.format(selectedRangeStart.getTime()) + " ~ " + dateSdf.format(selectedRangeEnd.getTime()));
        }
        if (btnPickStartDate != null) btnPickStartDate.setText(dateSdf.format(selectedRangeStart.getTime()));
        if (btnPickEndDate != null) btnPickEndDate.setText(dateSdf.format(selectedRangeEnd.getTime()));
    }

    private void showDatePicker(boolean isStart) {
        Calendar src = (Calendar) (isStart ? selectedRangeStart : selectedRangeEnd).clone();
        DatePickerDialog dlg = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            Calendar target = isStart ? selectedRangeStart : selectedRangeEnd;
            target.set(Calendar.YEAR, year);
            target.set(Calendar.MONTH, month);
            target.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            if (selectedRangeStart.after(selectedRangeEnd)) {
                toast("开始日期不能晚于结束日期");
                if (isStart) selectedRangeEnd.setTime(selectedRangeStart.getTime());
                else selectedRangeStart.setTime(selectedRangeEnd.getTime());
            }
            updateRangeLabel();
            refresh();
        }, src.get(Calendar.YEAR), src.get(Calendar.MONTH), src.get(Calendar.DAY_OF_MONTH));
        dlg.show();
    }

    private String rangeStartDate() {
        return dateSdf.format(selectedRangeStart.getTime());
    }

    private String rangeEndDate() {
        return dateSdf.format(selectedRangeEnd.getTime());
    }

    private void applyHeaderTexts(String[] headers) {
        try {
            TextView h1 = findViewById(R.id.tvHeader1);
            TextView h2 = findViewById(R.id.tvHeader2);
            TextView h3 = findViewById(R.id.tvHeader3);
            TextView h4 = findViewById(R.id.tvHeader4);
            if (headers != null && headers.length >= 4) {
                if (h1 != null) h1.setText(headers[0]);
                if (h2 != null) h2.setText(headers[1]);
                if (h3 != null) h3.setText(headers[2]);
                if (h4 != null) h4.setText(headers[3]);
            }
        } catch (Exception ignored) {}
    }

    private void refresh() {
        ReportType type = (ReportType) spinnerType.getSelectedItem();
        if (type == null) type = ReportType.MONTHLY_SHIPMENTS;

        String start = rangeStartDate();
        String end = rangeEndDate();
        String loc = AuthManager.getDefaultLocation(this);
        if (loc == null) loc = "";
        loc = loc.trim();

        String[] headers;
        List<Row> rows;

        if (type == ReportType.MONTHLY_SHIPMENTS) {
            headers = new String[]{"日期", "单数", "数量", "金额"};
            rows = queryMonthlyShipments(start, end, loc);
        } else if (type == ReportType.BEST_SELLING) {
            BestSellingSort sort = getSelectedBestSellingSort();
            headers = new String[]{"产品", "数量", "件数", "金额"};
            rows = queryBestSelling(start, end, loc, sort);
        } else if (type == ReportType.CUSTOMER_RANKING) {
            headers = new String[]{"客户", "单数", "数量", "金额"};
            rows = queryCustomerRanking(start, end, loc);
        } else {
            headers = new String[]{"类别", "名称", "当前库存", "安全库存"};
            rows = queryLowStock();
        }

        adapter.setHeaders(headers);
        applyHeaderTexts(headers);
        adapter.setRows(rows);

        TextView tvHint = findViewById(R.id.tvReportHint);
        if (tvHint != null) {
            String locShow = TextUtils.isEmpty(loc) ? "-" : loc;
            if (type == ReportType.LOW_STOCK) {
                tvHint.setText("场地：" + locShow + "  |  当前库存快照  |  共 " + rows.size() + " 行");
            } else {
                tvHint.setText("范围：" + start + " ~ " + end + "  |  场地：" + locShow + "  |  共 " + rows.size() + " 行");
            }
        }
    }

    private List<Row> queryMonthlyShipments(String start, String end, String loc) {
        List<Row> out = new ArrayList<>();
        try {
            String sql =
                    "SELECT SUBSTR(date,1,10) AS d, " +
                    "SUM(pieces) AS pcs, " +
                    "SUM(quantity) AS qty, " +
                    "SUM(quantity * price) AS amt " +
                    "FROM orders " +
                    "WHERE SUBSTR(date,1,10) >= ? AND SUBSTR(date,1,10) <= ? " +
                    "AND (is_deleted IS NULL OR is_deleted=0) AND (status IS NULL OR status!='VOID') " +
                    "AND (IFNULL(location,'') = ? OR IFNULL(location,'') = '') " +
                    "GROUP BY d " +
                    "ORDER BY d ASC";
            android.database.Cursor c = db.getReadableDatabase().rawQuery(sql, new String[]{start, end, loc});
            while (c.moveToNext()) {
                out.add(new Row(
                        nvl(c.getString(0)),
                        String.valueOf(c.getInt(1)),
                        String.valueOf(c.getInt(2)),
                        formatMoney(c.getDouble(3))
                ));
            }
            c.close();
        } catch (Exception e) {
            toast("查询失败：" + e.getMessage());
        }
        return out;
    }

    private List<Row> queryBestSelling(String start, String end, String loc, BestSellingSort sort) {
        List<Row> out = new ArrayList<>();
        try {
            String orderBy = "qty DESC, pcs DESC, amt DESC";
            if (sort == BestSellingSort.BY_PIECES) orderBy = "pcs DESC, qty DESC, amt DESC";
            else if (sort == BestSellingSort.BY_AMOUNT) orderBy = "amt DESC, qty DESC, pcs DESC";

            String sql =
                    "SELECT oi.product_name AS p, " +
                    "SUM(oi.quantity) AS qty, " +
                    "SUM(oi.pieces) AS pcs, " +
                    "SUM(oi.quantity * oi.price) AS amt " +
                    "FROM order_items oi " +
                    "LEFT JOIN orders o ON o.cloud_id = oi.order_cloud_id " +
                    "WHERE o.cloud_id IS NOT NULL " +
                    "AND (o.is_deleted IS NULL OR o.is_deleted=0) AND (o.status IS NULL OR o.status!='VOID') " +
                    "AND (oi.is_deleted IS NULL OR oi.is_deleted=0) " +
                    "AND SUBSTR(o.date,1,10) >= ? AND SUBSTR(o.date,1,10) <= ? " +
                    "AND (IFNULL(o.location,'') = ? OR IFNULL(o.location,'') = '') " +
                    "GROUP BY p " +
                    "ORDER BY " + orderBy;
            android.database.Cursor c = db.getReadableDatabase().rawQuery(sql, new String[]{start, end, loc});
            while (c.moveToNext()) {
                out.add(new Row(
                        nvl(c.getString(0)),
                        String.valueOf(c.getInt(1)),
                        String.valueOf(c.getInt(2)),
                        formatMoney(c.getDouble(3))
                ));
            }
            c.close();
        } catch (Exception e) {
            toast("查询失败：" + e.getMessage());
        }
        return out;
    }

    private List<Row> queryCustomerRanking(String start, String end, String loc) {
        List<Row> out = new ArrayList<>();
        try {
            String sql =
                    "SELECT customer_name AS c, " +
                    "SUM(pieces) AS pcs, " +
                    "SUM(quantity) AS qty, " +
                    "SUM(quantity * price) AS amt " +
                    "FROM orders " +
                    "WHERE SUBSTR(date,1,10) >= ? AND SUBSTR(date,1,10) <= ? " +
                    "AND (is_deleted IS NULL OR is_deleted=0) AND (status IS NULL OR status!='VOID') " +
                    "AND (IFNULL(location,'') = ? OR IFNULL(location,'') = '') " +
                    "GROUP BY c " +
                    "ORDER BY amt DESC";
            android.database.Cursor cur = db.getReadableDatabase().rawQuery(sql, new String[]{start, end, loc});
            while (cur.moveToNext()) {
                out.add(new Row(
                        nvl(cur.getString(0)),
                        String.valueOf(cur.getInt(1)),
                        String.valueOf(cur.getInt(2)),
                        formatMoney(cur.getDouble(3))
                ));
            }
            cur.close();
        } catch (Exception e) {
            toast("查询失败：" + e.getMessage());
        }
        return out;
    }

    private List<Row> queryLowStock() {
        List<Row> out = new ArrayList<>();
        try {
            List<InventoryItem> list = db.getLowStockItems();
            if (list != null) {
                list.sort((a, b) -> {
                    int aq = a == null ? 0 : a.getQuantity();
                    int as = a == null ? 0 : a.getSafetyStock();
                    int bq = b == null ? 0 : b.getQuantity();
                    int bs = b == null ? 0 : b.getSafetyStock();
                    if (aq == 0 && bq != 0) return -1;
                    if (aq != 0 && bq == 0) return 1;
                    return Integer.compare((bs - bq), (as - aq));
                });
                for (InventoryItem it : list) {
                    if (it == null) continue;
                    out.add(new Row(
                            friendlyType(it.getType()),
                            nvl(it.getName()),
                            String.valueOf(it.getQuantity()),
                            String.valueOf(it.getSafetyStock())
                    ));
                }
            }
        } catch (Exception e) {
            toast("查询失败：" + e.getMessage());
        }
        return out;
    }

    private BestSellingSort getSelectedBestSellingSort() {
        BestSellingSort sort = (BestSellingSort) spinnerBestSellingSort.getSelectedItem();
        return sort == null ? BestSellingSort.BY_QUANTITY : sort;
    }

    private void exportCurrent() {
        ReportType type = (ReportType) spinnerType.getSelectedItem();
        if (type == null) type = ReportType.MONTHLY_SHIPMENTS;

        String start = rangeStartDate();
        String end = rangeEndDate();
        String month = start + "_to_" + end;
        String loc = AuthManager.getDefaultLocation(this);
        if (loc == null) loc = "";
        loc = loc.trim();

        String title;
        String[] headers;
        List<Row> rows = adapter.getRows();

        if (type == ReportType.MONTHLY_SHIPMENTS) {
            title = "月度出货_" + month;
            headers = new String[]{"日期", "单数", "数量", "金额"};
        } else if (type == ReportType.BEST_SELLING) {
            title = "畅销品_" + month + "_" + getSelectedBestSellingSort().label;
            headers = new String[]{"产品", "数量", "件数", "金额"};
        } else if (type == ReportType.CUSTOMER_RANKING) {
            title = "客户排行_" + month;
            headers = new String[]{"客户", "单数", "数量", "金额"};
        } else {
            title = "低库存报表_" + month;
            headers = new String[]{"类别", "名称", "当前库存", "安全库存"};
        }

        try {
            String note;
            if (type == ReportType.LOW_STOCK) {
                note = "场地：" + (TextUtils.isEmpty(loc) ? "-" : loc) + "  |  当前库存快照";
            } else {
                note = "范围：" + start + " ~ " + end + "  |  场地：" + (TextUtils.isEmpty(loc) ? "-" : loc);
            }
            String xml = SpreadsheetXml.buildWorkbook(title, note, headers, rows);
            String folder = "SuZaiExports" + java.io.File.separator + "Reports" + java.io.File.separator + month;
            String fileName = title + ".xls";

            Uri uri = ExportUtils.saveTextToDownloads(this, folder, fileName,
                    "application/vnd.ms-excel", xml);

            if (uri != null) toast("已导出：" + fileName);
            else toast("导出失败：无法创建文件");
        } catch (Exception e) {
            toast("导出失败：" + e.getMessage());
        }
    }

    private String friendlyType(String type) {
        if (DatabaseHelper.INV_TYPE_PRODUCT.equals(type)) return "产品";
        if (DatabaseHelper.INV_TYPE_POT.equals(type)) return "花盆";
        if (DatabaseHelper.INV_TYPE_BAG.equals(type)) return "套袋";
        if (DatabaseHelper.INV_TYPE_CARTON.equals(type)) return "纸箱";
        return nvl(type);
    }

    private static String nvl(String s) { return s == null ? "" : s; }

    private static String formatMoney(double v) {
        return String.format(Locale.getDefault(), "%.2f", v);
    }

    private void toast(String s) {
        try { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); } catch (Exception ignored) {}
    }

    public static class Row {
        public final String c1, c2, c3, c4;
        public Row(String c1, String c2, String c3, String c4) {
            this.c1 = nvl(c1); this.c2 = nvl(c2); this.c3 = nvl(c3); this.c4 = nvl(c4);
        }
        public String[] toArray() { return new String[]{c1, c2, c3, c4}; }
    }
}
