package com.suzai.suzaiflowersystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ReconcileRowAdapter extends RecyclerView.Adapter<ReconcileRowAdapter.VH> {

    public interface OnRowClickListener {
        void onClick(ReconcileRow row);
    }

    private final List<ReconcileRow> data = new ArrayList<>();
    private final OnRowClickListener listener;

    public ReconcileRowAdapter(OnRowClickListener listener) {
        this.listener = listener;
    }

    public void setData(List<ReconcileRow> rows) {
        data.clear();
        if (rows != null) data.addAll(rows);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_reconcile_row, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        final ReconcileRow r = data.get(position);
        h.tvType.setText(r.type == null ? "" : r.type);
        h.tvDate.setText(r.date == null ? "" : r.date);
        h.tvDesc.setText(r.desc == null ? "" : r.desc);
        h.tvAmount.setText(String.format("%.2f", r.amount));

        h.itemView.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (listener != null) listener.onClick(r);
            }
        });
    }

    @Override
    public int getItemCount() { return data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvType, tvDate, tvAmount, tvDesc;
        VH(@NonNull View itemView) {
            super(itemView);
            tvType = itemView.findViewById(R.id.tv_type);
            tvDate = itemView.findViewById(R.id.tv_date);
            tvAmount = itemView.findViewById(R.id.tv_amount);
            tvDesc = itemView.findViewById(R.id.tv_desc);
        }
    }
}
