package com.suzai.suzaiflowersystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 新增订单页面：多产品行项目列表适配器。
 */
public class OrderLineAdapter extends RecyclerView.Adapter<OrderLineAdapter.LineVH> {

    public interface OnRemoveListener {
        void onRemove(int position);
    }

    private final List<OrderLine> lines = new ArrayList<>();
    private final OnRemoveListener onRemoveListener;

    public OrderLineAdapter(@NonNull List<OrderLine> initial, OnRemoveListener listener) {
        if (initial != null) {
            lines.addAll(initial);
        }
        this.onRemoveListener = listener;
    }

    @NonNull
    @Override
    public LineVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_order_line, parent, false);
        return new LineVH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull LineVH holder, int position) {
        OrderLine line = lines.get(position);
        holder.title.setText(line.getProductName());
        String detail = String.format(Locale.getDefault(), "件数: %d  数量: %d  金额: ¥%.2f",
                line.getPieces(), line.getQuantity(), line.getTotalPrice());
        if (line.getRemark() != null && !line.getRemark().trim().isEmpty()) {
            detail += "  备注: " + line.getRemark().trim();
        }
        holder.detail.setText(detail);

        holder.remove.setOnClickListener(v -> {
            if (onRemoveListener != null) {
                onRemoveListener.onRemove(holder.getBindingAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return lines.size();
    }

    public void addLine(@NonNull OrderLine line) {
        int pos = lines.size();
        lines.add(line);
        notifyItemInserted(pos);
    }

    public void removeAt(int position) {
        if (position < 0 || position >= lines.size()) return;
        lines.remove(position);
        notifyItemRemoved(position);
    }

    public List<OrderLine> getLines() {
        return new ArrayList<>(lines);
    }

    public void clear() {
        lines.clear();
        notifyDataSetChanged();
    }

    static class LineVH extends RecyclerView.ViewHolder {
        TextView title;
        TextView detail;
        TextView remove;

        LineVH(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.lineTitleTextView);
            detail = itemView.findViewById(R.id.lineDetailTextView);
            remove = itemView.findViewById(R.id.removeLineTextView);
        }
    }
}
