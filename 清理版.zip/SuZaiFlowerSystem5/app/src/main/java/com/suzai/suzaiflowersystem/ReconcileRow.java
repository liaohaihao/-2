package com.suzai.suzaiflowersystem;

public class ReconcileRow {
    public long paymentId = -1;
    public long orderId = -1;
    public String type; // 出货 / 收款
    public String date;
    public String desc;
    public double amount;
}
