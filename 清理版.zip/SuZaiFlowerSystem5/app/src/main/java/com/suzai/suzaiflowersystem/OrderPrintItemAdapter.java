package com.suzai.suzaiflowersystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class OrderPrintItemAdapter extends RecyclerView.Adapter<OrderPrintItemAdapter.VH> {

    private final List<Order> items;
    private final List<Boolean> checked;

    public OrderPrintItemAdapter(List<Order> items) {
        this.items = items == null ? new ArrayList<>() : items;
        this.checked = new ArrayList<>();
        for (int i = 0; i < this.items.size(); i++) checked.add(false);
    }

    public void updateItems(List<Order> newItems) {
        items.clear();
        if (newItems != null) items.addAll(newItems);
        checked.clear();
        for (int i = 0; i < items.size(); i++) checked.add(false);
        notifyDataSetChanged();
    }

    public void setAllChecked(boolean value) {
        for (int i = 0; i < checked.size(); i++) checked.set(i, value);
        notifyDataSetChanged();
    }

    public List<Order> getCheckedItems() {
        List<Order> res = new ArrayList<>();
        for (int i = 0; i < items.size(); i++) {
            if (i < checked.size() && Boolean.TRUE.equals(checked.get(i))) {
                res.add(items.get(i));
            }
        }
        return res;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_order_print, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        Order o = items.get(position);
        holder.cb.setOnCheckedChangeListener(null);
        holder.cb.setChecked(checked.get(position));
        holder.product.setText(o.getProductName());
        holder.pieces.setText(String.valueOf(o.getPieces()));
        holder.quantity.setText(String.valueOf(o.getQuantity()));
        holder.price.setText(String.format(Locale.getDefault(), "%.2f", o.getPrice()));
        holder.amount.setText(String.format(Locale.getDefault(), "%.2f", o.getTotalPrice()));

        holder.cb.setOnCheckedChangeListener((buttonView, isChecked) -> checked.set(holder.getAdapterPosition(), isChecked));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        CheckBox cb;
        TextView product, pieces, quantity, price, amount;

        VH(@NonNull View itemView) {
            super(itemView);
            cb = itemView.findViewById(R.id.itemCheckBox);
            product = itemView.findViewById(R.id.itemProductTextView);
            pieces = itemView.findViewById(R.id.itemPiecesTextView);
            quantity = itemView.findViewById(R.id.itemQuantityTextView);
            price = itemView.findViewById(R.id.itemPriceTextView);
            amount = itemView.findViewById(R.id.itemAmountTextView);
        }
    }
}
