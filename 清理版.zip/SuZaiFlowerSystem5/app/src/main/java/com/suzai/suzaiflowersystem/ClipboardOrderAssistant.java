package com.suzai.suzaiflowersystem;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 监听系统剪贴板，当检测到类似：
 *   客户名  产品名  2件  (备注：xxx 可选)  (可多个产品+件数)
 * 就弹窗询问是否自动新增订单。
 *
 * 说明：
 * - 只在前台 Activity 里监听（避免后台常驻监听带来的系统限制与耗电）
 * - 对同一段剪贴板内容做“去重”，防止反复弹窗
 * - 如果产品不存在，会提示先在产品管理中添加（因为无法自动推断装箱数/单价）
 */
public class ClipboardOrderAssistant {

    private static final String SP_NAME = "clipboard_order_assistant";
    // ✅ 以“复制事件”为单位去重：hash + clipboardTimestamp（Android 13+ 可用）
    // 这样：
    // - App 重启后，剪贴板没变 -> 不重复提示
    // - 用户再次复制同样文本 -> clipboardTimestamp 会变化 -> 仍然会提示/可新增
    private static final String SP_KEY_LAST_HANDLED_EVENT = "last_handled_event";
    private static final String SP_KEY_LAST_HANDLED_AT = "last_handled_at";
    // ✅ 已确认并成功新增过的“复制事件”（持久化），用于避免 App 重启后重复提示
    private static final String SP_KEY_ACCEPTED_EVENTS = "accepted_events_v2";
    // ✅ 已取消/忽略过的“复制事件”（持久化），同一复制事件不再重复提示；重新复制同样内容仍会提示
    private static final String SP_KEY_IGNORED_EVENTS = "ignored_events_v1";
    // 最多记录最近 N 条，防止 SharedPreferences 变大
    private static final int ACCEPTED_MAX = 50;
    // 过期时间：30 天
    private static final long ACCEPTED_TTL_MS = 30L * 24L * 60L * 60L * 1000L;


    private static ClipboardOrderAssistant sInstance;

    private WeakReference<Activity> activityRef;
    private ClipboardManager clipboardManager;
    private ClipboardManager.OnPrimaryClipChangedListener listener;

    // 防止轮询/多次回调导致弹窗连环出现
    private boolean dialogShowing = false;
    private String showingEvent = "";

    
    // Android 15/部分机型上，Clipboard 的 change listener 可能不稳定：
    // 增加前台轮询兜底（APP在前台时每 ~0.8s 读取一次剪贴板变化）。
    private Handler pollHandler;
    private Runnable pollRunnable;
    private boolean isPolling = false;

private ClipboardOrderAssistant() {}

    public static ClipboardOrderAssistant get() {
        if (sInstance == null) sInstance = new ClipboardOrderAssistant();
        return sInstance;
    }

    public void attach(Activity activity) {
        if (activity == null) return;

        activityRef = new WeakReference<>(activity);
        clipboardManager = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);

        if (clipboardManager == null) return;

        if (listener == null) {
            listener = () -> {
                Activity act = activityRef != null ? activityRef.get() : null;
                if (act == null || act.isFinishing()) return;
                handleClipboardIfMatch(act);
            };
        }

        try {
            clipboardManager.removePrimaryClipChangedListener(listener);
        } catch (Exception ignored) {}

        clipboardManager.addPrimaryClipChangedListener(listener);

        // 轮询兜底（Android 15/部分机型 listener 不触发时仍能检测到）
        startPolling();

        // 进入页面时也检查一次（比如刚复制完再打开 APP）
        handleClipboardIfMatch(activity);
    }

    
    private void startPolling() {
        if (isPolling) return;
        isPolling = true;
        if (pollHandler == null) pollHandler = new Handler(Looper.getMainLooper());
        if (pollRunnable == null) {
            pollRunnable = new Runnable() {
                @Override public void run() {
                    if (!isPolling) return;
                    Activity act = activityRef != null ? activityRef.get() : null;
                    if (act != null && !act.isFinishing()) {
                        try { handleClipboardIfMatch(act); } catch (Exception ignored) {}
                    }
                    // 继续轮询（仅前台 attach 时运行）
                    if (pollHandler != null) {
                        pollHandler.postDelayed(this, 800);
                    }
                }
            };
        }
        pollHandler.removeCallbacks(pollRunnable);
        pollHandler.postDelayed(pollRunnable, 800);
    }

    private void stopPolling() {
        isPolling = false;
        if (pollHandler != null && pollRunnable != null) {
            try { pollHandler.removeCallbacks(pollRunnable); } catch (Exception ignored) {}
        }
    }

    /**
     * ✅ 读取/维护“已处理复制事件”列表（格式：eventKey|ts;eventKey|ts;...）
     */
    private static Map<String, Long> loadEventMap(SharedPreferences sp, String spKey) {
        Map<String, Long> map = new HashMap<>();
        if (sp == null || TextUtils.isEmpty(spKey)) return map;

        String raw = sp.getString(spKey, "");
        if (TextUtils.isEmpty(raw)) return map;

        String[] parts = raw.split(";");
        for (String p : parts) {
            if (TextUtils.isEmpty(p)) continue;
            String[] kv = p.split("\\|");
            if (kv.length < 2) continue;
            String h = kv[0].trim();
            long ts = 0L;
            try { ts = Long.parseLong(kv[1].trim()); } catch (Exception ignored) {}
            if (!TextUtils.isEmpty(h) && ts > 0) map.put(h, ts);
        }
        return map;
    }

    private static void saveEventMap(SharedPreferences sp, String spKey, Map<String, Long> map) {
        if (sp == null || map == null || TextUtils.isEmpty(spKey)) return;

        long now = System.currentTimeMillis();
        List<Map.Entry<String, Long>> list = new ArrayList<>(map.entrySet());
        Collections.sort(list, (a, b) -> Long.compare(b.getValue(), a.getValue()));

        StringBuilder sb = new StringBuilder();
        int kept = 0;
        for (Map.Entry<String, Long> e : list) {
            if (e == null) continue;
            String h = e.getKey();
            Long ts = e.getValue();
            if (TextUtils.isEmpty(h) || ts == null || ts <= 0) continue;
            if (now - ts > ACCEPTED_TTL_MS) continue;

            if (kept >= ACCEPTED_MAX) break;
            if (sb.length() > 0) sb.append(";");
            sb.append(h).append("|").append(ts);
            kept++;
        }

        sp.edit().putString(spKey, sb.toString()).apply();
    }

    private static boolean hasEventMark(SharedPreferences sp, String spKey, String eventKey) {
        if (sp == null || TextUtils.isEmpty(spKey) || TextUtils.isEmpty(eventKey)) return false;
        Map<String, Long> map = loadEventMap(sp, spKey);
        if (!map.containsKey(eventKey)) return false;

        long ts = map.get(eventKey) != null ? map.get(eventKey) : 0L;
        long now = System.currentTimeMillis();
        if (ts <= 0 || now - ts > ACCEPTED_TTL_MS) {
            map.remove(eventKey);
            saveEventMap(sp, spKey, map);
            return false;
        }
        return true;
    }

    private static void markEvent(SharedPreferences sp, String spKey, String eventKey) {
        if (sp == null || TextUtils.isEmpty(spKey) || TextUtils.isEmpty(eventKey)) return;
        Map<String, Long> map = loadEventMap(sp, spKey);
        map.put(eventKey, System.currentTimeMillis());
        saveEventMap(sp, spKey, map);
    }

    private static boolean isAcceptedBefore(SharedPreferences sp, String eventKey) {
        return hasEventMark(sp, SP_KEY_ACCEPTED_EVENTS, eventKey);
    }

    private static boolean isIgnoredBefore(SharedPreferences sp, String eventKey) {
        return hasEventMark(sp, SP_KEY_IGNORED_EVENTS, eventKey);
    }

    private static void markAccepted(SharedPreferences sp, String eventKey) {
        markEvent(sp, SP_KEY_ACCEPTED_EVENTS, eventKey);
    }

    private static void markIgnored(SharedPreferences sp, String eventKey) {
        markEvent(sp, SP_KEY_IGNORED_EVENTS, eventKey);
    }


public void detach() {
        stopPolling();
        if (clipboardManager != null && listener != null) {
            try {
                clipboardManager.removePrimaryClipChangedListener(listener);
            } catch (Exception ignored) {}
        }
        clipboardManager = null;
        activityRef = null;
    }

    private void handleClipboardIfMatch(Activity activity) {
        String text = readClipboardText(activity);
        if (TextUtils.isEmpty(text)) return;

        // 归一化：把各种空格/换行/不可见字符压成单空格，避免 hash 因空白差异而不停变化
        // - 微信复制有时会带 NBSP/零宽字符
        String cleaned = text
                .replace('\u00A0', ' ')  // NBSP
                .replace("\u200B", "") // 零宽空格
                .replace("\u200C", "")
                .replace("\u200D", "")
                .replace("\uFEFF", "");
        final String normalized = cleaned.replaceAll("\\s+", " ").trim();
        if (TextUtils.isEmpty(normalized)) return;

        ParsedClipboardOrder parsed = ParsedClipboardOrder.parse(text);
        if (parsed == null || !parsed.isValid()) return;

        // ✅ 去重“复制事件”而不是去重“文本内容”
        // - 用户再次复制相同文本：clipboard timestamp 变化 -> 仍会触发
        // - App 重启后剪贴板没变：timestamp 不变 -> 不再重复提示
        String hash = String.valueOf(normalized.hashCode());
        long clipTs = readClipboardTimestamp(activity);
        final String eventKey = buildEventKey(hash, clipTs);

        // 如果当前已经有同一“复制事件”的弹窗在显示，就不要再弹
        if (dialogShowing && eventKey.equals(showingEvent)) {
            return;
        }
        SharedPreferences sp = activity.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE);
        // ✅ 如果该“复制事件”曾经“确认新增成功”或“已取消/忽略”，则忽略（避免 App 重启后重复提示）
        if (isAcceptedBefore(sp, eventKey) || isIgnoredBefore(sp, eventKey)) {
            return;
        }

        String lastEvent = sp.getString(SP_KEY_LAST_HANDLED_EVENT, "");
        long lastAt = sp.getLong(SP_KEY_LAST_HANDLED_AT, 0L);
        long now = System.currentTimeMillis();
        if (eventKey.equals(lastEvent) && (now - lastAt) < 5L * 60L * 1000L) {
            return;
        }

        // ⭐ 关键修复：只要“首次弹窗显示”，立刻标记已处理，避免轮询 0.8s 重复弹
        sp.edit()
                .putString(SP_KEY_LAST_HANDLED_EVENT, eventKey)
                .putLong(SP_KEY_LAST_HANDLED_AT, now)
                .apply();

        dialogShowing = true;
        showingEvent = eventKey;

        // ✅ 仅用于刷新“最近处理”的时间戳（避免轮询重复弹窗）
        Runnable markHandled = () -> sp.edit()
                .putString(SP_KEY_LAST_HANDLED_EVENT, eventKey)
                .putLong(SP_KEY_LAST_HANDLED_AT, System.currentTimeMillis())
                .apply();

        // ✅ 新增成功时记录为已接受；取消/忽略时也记录，避免下次打开 APP 还重复提示同一复制事件
        Runnable markAccepted = () -> markAccepted(sp, eventKey);
        Runnable markIgnored = () -> markIgnored(sp, eventKey);

        showConfirmDialog(activity, parsed, markHandled, markAccepted, markIgnored);
    }

    private String readClipboardText(Context context) {
        try {
            ClipboardManager cm = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip()) return null;
            ClipData data = cm.getPrimaryClip();
            if (data == null || data.getItemCount() <= 0) return null;
            CharSequence cs = data.getItemAt(0).coerceToText(context);
            return cs != null ? cs.toString() : null;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Android 13+（API 33）剪贴板描述里通常带 timestamp。
     * 这里用反射读取，避免老版本编译失败。
     */
    private long readClipboardTimestamp(Context context) {
        try {
            ClipboardManager cm = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip()) return 0L;
            ClipData data = cm.getPrimaryClip();
            if (data == null || data.getDescription() == null) return 0L;

            Object desc = data.getDescription();
            try {
                java.lang.reflect.Method m = desc.getClass().getMethod("getTimestamp");
                Object v = m.invoke(desc);
                if (v instanceof Long) return (Long) v;
            } catch (NoSuchMethodException ignored) {
                // 低版本没有 timestamp
            }
        } catch (Exception ignored) {}
        return 0L;
    }

    /**
     * 复制事件 key：优先使用 clipboard timestamp；低版本没有 timestamp 时退化为 hash。
     */
    private static String buildEventKey(String hash, long clipTs) {
        if (TextUtils.isEmpty(hash)) hash = "";
        if (clipTs > 0L) return hash + "@" + clipTs;
        // 低版本：无法区分“再次复制相同内容”的场景，会退化为旧逻辑。
        return hash;
    }

    
/**
 * 解析剪贴板里的“产品简写”到真实产品名：
 * - 支持括号别名：110地球（鹿） -> 110地球水培（鹿）
 * - 支持中英文括号统一比较
 * - 兼容“水培/土培”前后位置不同
 */
private String resolveProductName(List<String> productNames, String rawName) {
    if (productNames == null || productNames.isEmpty()) return rawName;
    if (rawName == null) return "";
    String q = rawName.trim();
    if (q.isEmpty()) return q;

    if (productNames.contains(q)) return q;

    String strong = findStrongAliasMatch(productNames, q);
    if (!TextUtils.isEmpty(strong)) return strong;

    String nq = normalizeProdKey(q);
    if (nq.isEmpty()) return q;

    String best = null;
    int bestScore = Integer.MIN_VALUE;
    int secondScore = Integer.MIN_VALUE;
    for (String cand : productNames) {
        if (cand == null) continue;
        String c = cand.trim();
        if (c.isEmpty()) continue;

        int score = calcProductMatchScore(q, c);
        if (score > bestScore) {
            secondScore = bestScore;
            bestScore = score;
            best = c;
        } else if (score > secondScore) {
            secondScore = score;
        }
    }

    if (bestScore < 200) return q;
    if (secondScore > Integer.MIN_VALUE && bestScore - secondScore < 1200) return q;
    return best != null ? best : q;
}

private String findStrongAliasMatch(List<String> productNames, String rawName) {
    if (productNames == null || productNames.isEmpty()) return null;
    String q0 = safeTrim(rawName);
    if (q0.isEmpty()) return null;

    String normalizedRaw = normalizeBracketChars(q0);
    java.util.LinkedHashSet<String> qAlias = extractBracketTokens(normalizedRaw);
    String qCodeBase = normalizeProdCodeBase(q0);
    String qLooseCode = normalizeLooseProdKeyKeepCode(q0);

    // 1) 先尝试显式补全“水培/土培”后精确命中，例如：110地球（鹿） -> 110地球水培（鹿）
    if (!qAlias.isEmpty() && !containsCultivationWord(normalizedRaw)) {
        String[] expanded = buildCultivationAliasCandidates(normalizedRaw);
        int exactHits = 0;
        String exactBest = null;
        for (String name : productNames) {
            String c = safeTrim(name);
            if (c.isEmpty()) continue;
            for (String ex : expanded) {
                if (!TextUtils.isEmpty(ex) && normalizeBracketChars(c).equals(ex)) {
                    exactHits++;
                    exactBest = c;
                    break;
                }
            }
        }
        if (exactHits == 1 && !TextUtils.isEmpty(exactBest)) return exactBest;
    }

    // 2) 再尝试“保留编号 + 去除水培/土培 + 括号别名完全一致”的强匹配
    java.util.ArrayList<String> strongHits = new java.util.ArrayList<>();
    for (String name : productNames) {
        String c = safeTrim(name);
        if (c.isEmpty()) continue;
        if (!qAlias.equals(extractBracketTokens(c))) continue;

        String cCodeBase = normalizeProdCodeBase(c);
        String cLooseCode = normalizeLooseProdKeyKeepCode(c);
        if (!qCodeBase.isEmpty() && qCodeBase.equals(cCodeBase)) {
            strongHits.add(c);
            continue;
        }
        if (!qLooseCode.isEmpty() && qLooseCode.equals(cLooseCode)) {
            strongHits.add(c);
        }
    }
    if (strongHits.size() == 1) return strongHits.get(0);

    return null;
}

private int calcProductMatchScore(String rawQuery, String candidate) {
    int score = 0;
    String q0 = safeTrim(rawQuery);
    String c0 = safeTrim(candidate);
    String q1 = normalizeProdKey(q0);
    String c1 = normalizeProdKey(c0);
    String q2 = removeBracketSegments(q1);
    String c2 = removeBracketSegments(c1);
    String q3 = normalizeLooseProdKey(q0);
    String c3 = normalizeLooseProdKey(c0);
    String q4 = normalizeProdCodeBase(q0);
    String c4 = normalizeProdCodeBase(c0);
    String q5 = normalizeLooseProdKeyKeepCode(q0);
    String c5 = normalizeLooseProdKeyKeepCode(c0);

    if (c0.equals(q0)) score += 10000;
    if (!q1.isEmpty() && c1.equals(q1)) score += 9000;
    if (!q2.isEmpty() && c2.equals(q2)) score += 5500;
    if (!q3.isEmpty() && c3.equals(q3)) score += 7000;
    if (!q4.isEmpty() && c4.equals(q4)) score += 12000;
    if (!q5.isEmpty() && c5.equals(q5)) score += 8500;

    if (!q1.isEmpty() && c1.contains(q1)) score += 2400;
    if (!q2.isEmpty() && c2.contains(q2)) score += 1800;
    if (!q3.isEmpty() && c3.contains(q3)) score += 3200;
    if (!q4.isEmpty() && c4.contains(q4)) score += 4500;
    if (!q5.isEmpty() && c5.contains(q5)) score += 2800;
    if (!c1.isEmpty() && q1.contains(c1)) score += 800;

    java.util.LinkedHashSet<String> qTokens = splitProdTokens(q5);
    java.util.LinkedHashSet<String> cTokens = splitProdTokens(c5);
    int overlap = 0;
    for (String t : qTokens) {
        if (cTokens.contains(t)) overlap++;
    }
    score += overlap * 1200;
    if (!qTokens.isEmpty() && overlap == qTokens.size()) score += 2800;

    java.util.LinkedHashSet<String> qAlias = extractBracketTokens(q0);
    java.util.LinkedHashSet<String> cAlias = extractBracketTokens(c0);
    int aliasOverlap = 0;
    for (String t : qAlias) {
        if (cAlias.contains(t)) aliasOverlap++;
    }
    score += aliasOverlap * 2500;
    if (!qAlias.isEmpty() && aliasOverlap == qAlias.size()) score += 2000;
    if (!qAlias.isEmpty() && qAlias.equals(cAlias)) score += 4500;
    if (!qAlias.isEmpty() && aliasOverlap == 0 && !cAlias.isEmpty()) score -= 1800;

    if (!q3.isEmpty() && c3.startsWith(q3)) score += 1000;
    if (!q3.isEmpty() && c3.endsWith(q3)) score += 600;

    if (q0.contains("水培") && !c0.contains("水培")) score -= 1800;
    if (q0.contains("土培") && !c0.contains("土培")) score -= 1800;
    if (!q5.contains("三杆") && c5.contains("三杆")) score -= 900;
    if (!q5.contains("单杆") && c5.contains("单杆")) score -= 500;

    score -= Math.max(0, c0.length());
    return score;
}

private java.util.LinkedHashSet<String> splitProdTokens(String s) {
    java.util.LinkedHashSet<String> out = new java.util.LinkedHashSet<>();
    if (s == null) return out;
    String t = s.replaceAll("[^0-9a-zA-Z\\u4e00-\\u9fa5]+", " ").trim();
    if (t.isEmpty()) return out;
    for (String part : t.split("\\s+")) {
        String p = part == null ? "" : part.trim();
        if (p.isEmpty()) continue;
        if (p.length() == 1 && !Character.isDigit(p.charAt(0))) continue;
        out.add(p);
    }
    return out;
}

private java.util.LinkedHashSet<String> extractBracketTokens(String s) {
    java.util.LinkedHashSet<String> out = new java.util.LinkedHashSet<>();
    if (s == null) return out;
    String t = normalizeBracketChars(s);
    Matcher m = Pattern.compile("\\(([^()]+)\\)").matcher(t);
    while (m.find()) {
        String inner = safeTrim(m.group(1));
        if (inner.isEmpty()) continue;
        String clean = inner.replaceAll("[^0-9a-zA-Z\\u4e00-\\u9fa5]+", " ").trim();
        if (clean.isEmpty()) continue;
        for (String part : clean.split("\\s+")) {
            String p = safeTrim(part);
            if (!p.isEmpty()) out.add(p);
        }
    }
    return out;
}

private String removeBracketSegments(String s) {
    if (s == null) return "";
    return normalizeBracketChars(s).replaceAll("\\([^()]*\\)", "").trim();
}

private boolean containsCultivationWord(String s) {
    String t = safeTrim(s);
    return t.contains("水培") || t.contains("土培");
}

private String[] buildCultivationAliasCandidates(String s) {
    String t = normalizeBracketChars(s);
    int p = t.indexOf('(');
    if (p >= 0) {
        String head = t.substring(0, p).trim();
        String tail = t.substring(p).trim();
        return new String[]{head + "水培" + tail, head + "土培" + tail};
    }
    return new String[]{t + "水培", t + "土培"};
}

private String normalizeProdCodeBase(String s) {
    if (s == null) return "";
    String t = normalizeBracketChars(s).replace(" ", "").trim();
    t = t.replaceAll("\\([^()]*\\)", "");
    t = t.replace("水培", "").replace("土培", "");
    t = t.replaceAll("[^0-9a-zA-Z\u4e00-\u9fa5]+", "").trim();
    return t;
}

private String normalizeLooseProdKeyKeepCode(String s) {
    if (s == null) return "";
    String t = normalizeBracketChars(s);
    t = t.replaceAll("\\([^()]*\\)", " ");
    t = t.replace("水培", " ").replace("土培", " ");
    t = t.replaceAll("[^0-9a-zA-Z\u4e00-\u9fa5]+", " ").replaceAll("\\s+", " ").trim();
    return t;
}

private String normalizeLooseProdKey(String s) {
    String t = normalizeProdKey(s);
    t = removeBracketSegments(t);
    t = t.replace("水培", "").replace("土培", "");
    t = t.replaceAll("[()（）\\[\\]【】{}『』「」<>《》]", " ");
    t = t.replaceAll("[^0-9a-zA-Z\\u4e00-\\u9fa5]+", " ").replaceAll("\\s+", " ").trim();
    return t;
}

private String normalizeProdKey(String s) {
    if (s == null) return "";
    String t = normalizeBracketChars(s).replace(" ", "").trim();
    if (t.endsWith("水培")) t = t.substring(0, t.length() - 2);
    if (t.endsWith("土培")) t = t.substring(0, t.length() - 2);
    t = t.replaceAll("^[0-9]+(?:\\.[0-9]+)?[a-zA-Z]*", "");
    t = t.replaceAll("^[._-]+", "");
    return t.trim();
}

private String normalizeBracketChars(String s) {
    if (s == null) return "";
    return s.replace('（', '(').replace('）', ')')
            .replace('【', '[').replace('】', ']')
            .replace('｛', '{').replace('｝', '}')
            .replace('《', '<').replace('》', '>');
}

private String safeTrim(String s) {
    return s == null ? "" : s.trim();
}

private void showConfirmDialog(Activity activity, ParsedClipboardOrder parsed, Runnable onHandledFlag, Runnable onAcceptedSuccess, Runnable onIgnored) {

        if (activity == null || activity.isFinishing()) return;

        DatabaseHelper db = new DatabaseHelper(activity);

        // 场地列表
        List<String> locations = db.getAllLocationNames();
        if (locations == null) locations = new ArrayList<>();
        if (locations.isEmpty()) {
            Toast.makeText(activity, "没有场地数据，请先在“场地管理”里添加场地", Toast.LENGTH_LONG).show();
            return;
        }

        // 产品列表（用于可编辑的行）
        List<String> productNames = db.getAllProductNames();
        if (productNames == null) productNames = new ArrayList<>();
        if (productNames.isEmpty()) {
            Toast.makeText(activity, "没有产品数据，请先在“产品管理”里添加产品", Toast.LENGTH_LONG).show();
            return;
        }

        // 构建弹窗布局（可编辑明细 + 场地选择 + 备注可编辑）
        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (activity.getResources().getDisplayMetrics().density * 16);
        root.setPadding(pad, pad, pad, pad);

        TextView header = new TextView(activity);
        header.setText("客户：" + (parsed.customerName == null ? "" : parsed.customerName));
        header.setTextSize(16);
        root.addView(header);

        TextView tip = new TextView(activity);
        tip.setText("\n订单明细（可修改）：");
        root.addView(tip);

        // 明细容器（多行：产品 + 件数，可删除/新增）
        LinearLayout linesContainer = new LinearLayout(activity);
        linesContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(linesContainer);

        class LineRow {
            Spinner sp;
            EditText pieces;
            View row;
        }

        List<LineRow> rows = new ArrayList<>();

        // 统一的产品下拉适配器（每一行复用同一份数据）
// 说明：默认 Spinner 的选中项会单行省略显示，这里用自定义 Adapter 让“选中项”也支持多行换行，避免只看到一部分产品名。
ArrayAdapter<String> prodAdapter = new ArrayAdapter<String>(activity, android.R.layout.simple_spinner_item, productNames) {
    @Override
    public View getView(int position, View convertView, android.view.ViewGroup parent) {
        TextView tv = (TextView) super.getView(position, convertView, parent);
        tv.setSingleLine(false);
        tv.setMaxLines(3);
        tv.setEllipsize(null);
        tv.setTextSize(16);
        tv.setPadding(tv.getPaddingLeft(), tv.getPaddingTop(), tv.getPaddingRight(), tv.getPaddingBottom());
        return tv;
    }

    @Override
    public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) {
        TextView tv = (TextView) super.getDropDownView(position, convertView, parent);
        tv.setSingleLine(false);
        tv.setMaxLines(3);
        tv.setEllipsize(null);
        tv.setTextSize(16);
        return tv;
    }
};
prodAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

final Runnable addEmptyRow = new Runnable() {
    @Override public void run() {
        // 一行拆成两行展示：
        // 第 1 行：产品（全宽，支持多行显示）
        // 第 2 行：件数 + 删除（避免把产品名挤成“...”，也更好点按）
        LinearLayout rowRoot = new LinearLayout(activity);
        rowRoot.setOrientation(LinearLayout.VERTICAL);

        // 产品选择（单独占一行）
        Spinner sp = new Spinner(activity);
        sp.setAdapter(prodAdapter);
        LinearLayout.LayoutParams spLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        sp.setLayoutParams(spLp);

        // 第二行：件数 + 删除
        LinearLayout row2 = new LinearLayout(activity);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setGravity(Gravity.CENTER_VERTICAL);

        EditText piecesEt = new EditText(activity);
        piecesEt.setHint("件数");
        piecesEt.setInputType(InputType.TYPE_CLASS_NUMBER);
        piecesEt.setEms(6);
        LinearLayout.LayoutParams peLp = new LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
        );
        peLp.leftMargin = (int) (activity.getResources().getDisplayMetrics().density * 0);
        piecesEt.setLayoutParams(peLp);

        Button del = new Button(activity);
        del.setText("删除");
        LinearLayout.LayoutParams delLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        delLp.leftMargin = (int) (activity.getResources().getDisplayMetrics().density * 12);
        del.setLayoutParams(delLp);

        row2.addView(piecesEt);
        row2.addView(del);

        // 组装
        rowRoot.addView(sp);
        rowRoot.addView(row2);

        // 顶部/行间距
        int vPad = (int) (activity.getResources().getDisplayMetrics().density * 6);
        rowRoot.setPadding(0, vPad, 0, vPad);

        LineRow lr = new LineRow();
        lr.sp = sp;
        lr.pieces = piecesEt;
        lr.row = rowRoot;
        rows.add(lr);

        del.setOnClickListener(v -> {
            try { linesContainer.removeView(rowRoot); } catch (Exception ignored) {}
            rows.remove(lr);
            // 至少保留一行，避免空界面
            if (rows.isEmpty()) {
                this.run();
            }
        });

        linesContainer.addView(rowRoot);
    }
};

// 根据解析结果预填充行（如果解析出的产品不在列表里，也允许用户改成别的产品）

        if (parsed.lines != null && !parsed.lines.isEmpty()) {
            for (ParsedClipboardOrder.Line line : parsed.lines) {
                addEmptyRow.run();
                LineRow lr = rows.get(rows.size() - 1);

                String resolved = resolveProductName(productNames, line.productName);
                int idx = productNames.indexOf(resolved);
                if (idx < 0) idx = 0;
                try { lr.sp.setSelection(idx); } catch (Exception ignored) {}
                try { lr.pieces.setText(String.valueOf(Math.max(1, line.pieces))); } catch (Exception ignored) {}
            }
        } else {
            // 兜底：至少一行
            addEmptyRow.run();
        }

        Button addLineBtn = new Button(activity);
        addLineBtn.setText("添加一行");
        addLineBtn.setOnClickListener(v -> addEmptyRow.run());
        root.addView(addLineBtn);

        TextView locLabel = new TextView(activity);
        locLabel.setText("\n选择场地：");
        root.addView(locLabel);

        Spinner spinner = new Spinner(activity);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(activity, android.R.layout.simple_spinner_item, locations);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        if (locations.size() == 1) spinner.setSelection(0);
        root.addView(spinner);

        TextView remarkLabel = new TextView(activity);
        remarkLabel.setText("\n备注（可空）：");
        root.addView(remarkLabel);

        EditText remarkEdit = new EditText(activity);
        remarkEdit.setHint("例如：矮");
        if (!TextUtils.isEmpty(parsed.remark)) remarkEdit.setText(parsed.remark);
        root.addView(remarkEdit);

        // 用 ScrollView 包裹，避免小屏/横屏时内容被挤压
        ScrollView sc = new ScrollView(activity);
        sc.addView(root);

        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle("检测到剪贴板订单，是否新增？（可修改）")
                .setView(sc)
                .setNegativeButton("取消", (d, w) -> { if (onHandledFlag != null) onHandledFlag.run(); if (onIgnored != null) onIgnored.run(); })
                .setPositiveButton("新增", null)
                .create();

        // 无论用户点取消/新增/返回键，只要弹窗消失，就解除“正在显示”的标记。
        // 若本次并未成功新增，则记为“已忽略”，避免关闭 APP 后再次提示同一复制事件。
        final boolean[] acceptedNow = {false};
        dialog.setOnDismissListener(d -> {
            dialogShowing = false;
            showingEvent = "";
            if (!acceptedNow[0] && onIgnored != null) onIgnored.run();
        });

        dialog.setOnShowListener(dlg -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String location = spinner.getSelectedItem() != null ? spinner.getSelectedItem().toString().trim() : "";
                String remark = remarkEdit.getText() != null ? remarkEdit.getText().toString().trim() : "";

                if (TextUtils.isEmpty(location)) {
                    Toast.makeText(activity, "请选择场地", Toast.LENGTH_SHORT).show();
                    return;
                }

                // 自动新增：客户不存在则自动创建（联系方式留空）
                List<String> customerNames = db.getAllCustomerNames();
                boolean customerExists = customerNames != null && customerNames.contains(parsed.customerName);
                if (!customerExists) {
                    db.addCustomer(parsed.customerName, "");
                }

                // 从界面收集“可编辑”的明细
                Map<String, Integer> piecesMap = new HashMap<>();
                for (LineRow lr : new ArrayList<>(rows)) {
                    if (lr == null || lr.sp == null || lr.pieces == null) continue;
                    String pn = lr.sp.getSelectedItem() != null ? lr.sp.getSelectedItem().toString().trim() : "";
                    String ps = lr.pieces.getText() != null ? lr.pieces.getText().toString().trim() : "";

                    if (TextUtils.isEmpty(pn)) continue;

                    int pcs = 0;
                    try { pcs = Integer.parseInt(ps); } catch (Exception ignored) {}
                    if (pcs <= 0) continue;

                    Integer old = piecesMap.get(pn);
                    piecesMap.put(pn, (old == null ? 0 : old) + pcs);
                }

                if (piecesMap.isEmpty()) {
                    Toast.makeText(activity, "请至少填写一行产品且件数大于0", Toast.LENGTH_SHORT).show();
                    return;
                }

                String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                int success = 0;
                int fail = 0;
                for (Map.Entry<String, Integer> e : piecesMap.entrySet()) {
                    String product = e.getKey();
                    int pieces = e.getValue() != null ? e.getValue() : 0;
                    if (pieces <= 0) continue;

                    int packingUnits = db.getProductPackingUnitsByName(product);
                    int quantity = pieces * packingUnits;
                    double price = db.getProductPriceByName(product);

                    Order order = new Order(date, parsed.customerName, product, pieces, quantity, price, location, remark);
                    long r = db.addOrder(order);
                    if (r != -1) success++; else fail++;
                }

                if (success > 0 && fail == 0) {
                    Toast.makeText(activity, "已新增订单（" + success + "条）", Toast.LENGTH_SHORT).show();
                    acceptedNow[0] = true;
                    if (onHandledFlag != null) onHandledFlag.run();
                    if (onAcceptedSuccess != null) onAcceptedSuccess.run();
                    dialog.dismiss();
                } else if (success > 0) {
                    Toast.makeText(activity, "部分成功：成功" + success + "条，失败" + fail + "条", Toast.LENGTH_LONG).show();
                    acceptedNow[0] = true;
                    if (onHandledFlag != null) onHandledFlag.run();
                    if (onAcceptedSuccess != null) onAcceptedSuccess.run();
                    dialog.dismiss();
                } else {
                    Toast.makeText(activity, "新增失败", Toast.LENGTH_SHORT).show();
                }
            });
        });

        dialog.show();
    }

    /**
     * 解析剪贴板文本
     */
    static class ParsedClipboardOrder {
        String customerName;
        String remark;
        List<Line> lines = new ArrayList<>();

        static class Line {
            String productName;
            int pieces;
            Line(String productName, int pieces) {
                this.productName = productName;
                this.pieces = pieces;
            }
        }

        boolean isValid() {
            if (TextUtils.isEmpty(customerName)) return false;
            if (lines == null || lines.isEmpty()) return false;
            for (Line l : lines) {
                if (l == null || TextUtils.isEmpty(l.productName) || l.pieces <= 0) return false;
            }
            return true;
        }

        String toPrettyText() {
            StringBuilder sb = new StringBuilder();
            sb.append("客户：").append(customerName).append("\n");
            for (int i = 0; i < lines.size(); i++) {
                Line l = lines.get(i);
                sb.append("• ").append(l.productName).append("  ").append(l.pieces).append("件");
                if (i != lines.size() - 1) sb.append("\n");
            }
            if (!TextUtils.isEmpty(remark)) {
                sb.append("\n备注：").append(remark);
            }
            return sb.toString();
        }

        static ParsedClipboardOrder parse(String raw) {
            if (raw == null) return null;
            String text = raw.trim();
            if (text.length() < 3) return null;

            // 把换行、tab 统一成空格
            text = text.replace("\u3000", " ").replace("\u00A0", " ").replace("\r", " ").replace("\n", " ").replace("\t", " ");
            // 连续空格压缩
            text = text.replaceAll("\\s{2,}", " ").trim();

            // 备注提取（支持 备注： / 备注:）
            String remark = "";
            int idx = indexOfRemark(text);
            if (idx >= 0) {
                String before = text.substring(0, idx).trim();
                String after = text.substring(idx).trim();
                remark = extractRemark(after);
                text = before;
            }

            // 至少要有：客户 + (产品 + 数字件)
            String[] firstSplit = text.split(" ", 2);
            if (firstSplit.length < 2) return null;
            String customer = firstSplit[0].trim();
            String rest = firstSplit[1].trim();
            if (TextUtils.isEmpty(customer) || TextUtils.isEmpty(rest)) return null;

            ParsedClipboardOrder out = new ParsedClipboardOrder();
            out.customerName = customer;
            out.remark = remark;

            // 逐段扫描：找到 “数字 + 件”，前面那段就是产品名
            Pattern p = Pattern.compile("(\\d+)\\s*(件|箱)");
            int pos = 0;
            while (pos < rest.length()) {
                Matcher m = p.matcher(rest);
                if (!m.find(pos)) break;

                int startNum = m.start();
                int endNum = m.end();

                String product = rest.substring(pos, startNum).trim();
                String numStr = m.group(1);

                if (TextUtils.isEmpty(product)) {
                    return null;
                }

                int pieces;
                try {
                    pieces = Integer.parseInt(numStr);
                } catch (Exception e) {
                    return null;
                }
                if (pieces <= 0) return null;

                out.lines.add(new Line(product, pieces));

                pos = endNum;
                // 跳过后续空格
                while (pos < rest.length() && Character.isWhitespace(rest.charAt(pos))) pos++;
            }

            if (!out.isValid()) return null;
            return out;
        }

        private static int indexOfRemark(String text) {
            if (TextUtils.isEmpty(text)) return -1;
            int i1 = text.indexOf("备注：");
            int i2 = text.indexOf("备注:");
            if (i1 < 0) return i2;
            if (i2 < 0) return i1;
            return Math.min(i1, i2);
        }

        private static String extractRemark(String remarkPart) {
            if (TextUtils.isEmpty(remarkPart)) return "";
            String r = remarkPart.trim();
            if (r.startsWith("备注：")) r = r.substring("备注：".length());
            else if (r.startsWith("备注:")) r = r.substring("备注:".length());
            return r.trim();
        }
    }
}