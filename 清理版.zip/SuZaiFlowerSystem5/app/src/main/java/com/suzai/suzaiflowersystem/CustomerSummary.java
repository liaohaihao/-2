package com.suzai.suzaiflowersystem;

public class CustomerSummary {
    private final String customerName;
    private final int totalQty;

    public CustomerSummary(String customerName, int totalQty) {
        this.customerName = customerName;
        this.totalQty = totalQty;
    }

    public String getCustomerName() {
        return customerName;
    }

    public int getTotalQty() {
        return totalQty;
    }
}
