package com.suzai.suzaiflowersystem;

import android.text.TextUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * 将 80mm 小票模板标记（<CB>/<B>/<BR> 等）转换为 HTML 以便 WebView 预览。
 * 备注：这不是打印机指令解析器，只用于“模板预览/设计器”的可视化效果。
 */
public class PrintMarkupRenderer {

    private PrintMarkupRenderer() {}

    public static String toPreviewHtml(String raw, String type) {
        String content = raw == null ? "" : raw;

        // 生成一些示例数据，避免预览全是 {{xxx}}
        Map<String, String> demo = new HashMap<>();
        demo.put("customer", "丽佳");
        demo.put("product", "110钻石水培");
        demo.put("spec", "110圆杯");
        demo.put("quantity", "2");
        demo.put("date", "2026-01-10");
        demo.put("page", "5");
        demo.put("pages", "15");
        demo.put("remark", "矮");
        demo.put("location", "佛山");
        demo.put("order_no", "SO20260110-001");
        demo.put("contact", "张三");
        demo.put("phone", "13800000000");
        demo.put("total_pieces", "15");
        demo.put("total_amount", "¥300.00");
        demo.put("cbm", "0.52");
        demo.put("items", "110钻石水培  20  1   2   40   2\n110圆杯水培  10  1   3   30   3");

        content = replacePlaceholders(content, demo);

        // 如果是 HTML，直接包裹返回
        String lower = content.trim().toLowerCase();
        if (lower.startsWith("<!doctype") || lower.startsWith("<html") || lower.contains("<body")) {
            return content;
        }

        // LABEL 模板（<SIZE><TEXT ...>）不是小票标记，不在这里做复杂渲染
        if (!TextUtils.isEmpty(content) && content.contains("<SIZE>") && content.contains("<TEXT")) {
            return wrapMono("<b>这是“标签模板”格式（<SIZE>/<TEXT>）。</b><br/>" +
                    "请在“拖拽编辑器”中预览与编辑。");
        }

        // 小票模板：把 <CB>/<B>/<BR> 等转换为 HTML
        StringBuilder out = new StringBuilder();
        String[] lines = content.split("\n");
        for (String line : lines) {
            String l = line == null ? "" : line;

            // <BR>
            if (l.trim().equalsIgnoreCase("<BR>")) {
                out.append("<div style='height:8px'></div>");
                continue;
            }

            // 兼容飞鹅云常见控制标签（用于预览）：
            // - <CB></CB>：居中放大
            // - <B></B>：放大一倍
            // - <L></L>：字体变高一倍
            // - <BOLD></BOLD>：字体加粗

            // 1) 处理 <CB>
            if (l.contains("<CB>") && l.contains("</CB>")) {
                String t = l.replace("<CB>", "").replace("</CB>", "");
                t = t.replace("<B>", "").replace("</B>", "")
                        .replace("<L>", "").replace("</L>", "")
                        .replace("<BOLD>", "").replace("</BOLD>", "");
                out.append("<div style='text-align:center;font-weight:700;font-size:18px;'>")
                        .append(escape(t))
                        .append("</div>");
                continue;
            }

            boolean hasB = l.contains("<B>") && l.contains("</B>");
            boolean hasL = l.contains("<L>") && l.contains("</L>");
            boolean hasBold = l.contains("<BOLD>") && l.contains("</BOLD>");

            String t = l;
            t = t.replace("<B>", "").replace("</B>", "")
                    .replace("<L>", "").replace("</L>", "")
                    .replace("<BOLD>", "").replace("</BOLD>", "");

            StringBuilder style = new StringBuilder();
            if (hasBold) style.append("font-weight:700;");
            // 预览里的“放大/变高”用 font-size 模拟（不追求与打印机完全一致）
            if (hasB) style.append("font-size:16px;");
            else if (hasL) style.append("font-size:15px;");

            if (style.length() > 0) {
                out.append("<div style='").append(style).append("'>")
                        .append(escape(t))
                        .append("</div>");
            } else {
                out.append("<div>").append(escape(t)).append("</div>");
            }
        }

        return wrapReceipt(out.toString());
    }

    private static String wrapReceipt(String inner) {
        return "<html><head><meta charset='utf-8'/>"
                + "<style>"
                + "body{margin:0;padding:12px;font-family:monospace;background:#ffffff;}"
                + ".paper{max-width:380px;margin:0 auto;border:1px dashed #ccc;padding:12px;}"
                + "div{white-space:pre-wrap;line-height:1.25;}"
                + "</style></head><body>"
                + "<div class='paper'>"
                + inner
                + "</div></body></html>";
    }

    private static String wrapMono(String msgHtml) {
        return "<html><head><meta charset='utf-8'/>"
                + "<style>body{margin:0;padding:12px;font-family:monospace;}div{white-space:pre-wrap;}</style>"
                + "</head><body><div>" + msgHtml + "</div></body></html>";
    }

    private static String replacePlaceholders(String s, Map<String, String> values) {
        if (TextUtils.isEmpty(s) || values == null || values.isEmpty()) return s;
        String out = s;
        for (Map.Entry<String, String> e : values.entrySet()) {
            String k = e.getKey();
            String v = e.getValue() == null ? "" : e.getValue();
            out = out.replace("{{" + k + "}}", v);
        }
        // 常见别名
        out = out.replace("{{pieces}}", values.get("total_pieces") == null ? "15" : values.get("total_pieces"));
        out = out.replace("{{index}}", "5");
        out = out.replace("{{total}}", values.get("total_pieces") == null ? "15" : values.get("total_pieces"));
        return out;
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("&","&amp;")
                .replace("<","&lt;")
                .replace(">","&gt;");
    }
}