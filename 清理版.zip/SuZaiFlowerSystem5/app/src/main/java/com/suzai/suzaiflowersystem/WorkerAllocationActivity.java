package com.suzai.suzaiflowersystem;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;


import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class WorkerAllocationActivity extends BaseDrawerActivity {

    private TextView dateTextView;
    private TableLayout tableLayout;
    private TextView totalTextView;

    private DatabaseHelper db;
    private final SimpleDateFormat dateFmt = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    private String onlyLocation;
    private String selectedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentLayout(R.layout.activity_worker_allocation);
        if (toolbar != null) toolbar.setTitle("工人配货");
        android.view.View lite = findViewById(R.id.toolbarLite);
        if (lite != null) lite.setVisibility(android.view.View.GONE);

        dateTextView = findViewById(R.id.dateTextView);
        tableLayout = findViewById(R.id.tableLayout);
        totalTextView = findViewById(R.id.totalTextView);

        db = new DatabaseHelper(this);

        // 工人配货：只显示当前账号默认场地的订单
        try {
            onlyLocation = AuthManager.getDefaultLocationForCurrentUser(this);
        } catch (Exception ignored) {
            onlyLocation = null;
        }

        selectedDate = dateFmt.format(new Date());
        dateTextView.setOnClickListener(v -> showDatePicker());
        loadSummaryForDate(selectedDate);
    }

    private void showDatePicker() {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        try {
            Date d = dateFmt.parse(selectedDate);
            if (d != null) cal.setTime(d);
        } catch (Exception ignored) {}
        new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            java.util.Calendar picked = java.util.Calendar.getInstance();
            picked.set(year, month, dayOfMonth, 0, 0, 0);
            picked.set(java.util.Calendar.MILLISECOND, 0);
            selectedDate = dateFmt.format(picked.getTime());
            loadSummaryForDate(selectedDate);
        }, cal.get(java.util.Calendar.YEAR), cal.get(java.util.Calendar.MONTH), cal.get(java.util.Calendar.DAY_OF_MONTH)).show();
    }

    private void loadSummaryForDate(String date) {
        dateTextView.setText("日期：" + date + "  ▼");

        List<Order> orders;
        if (!TextUtils.isEmpty(onlyLocation)) {
            orders = db.getOrdersByDateFiltered(date, null, onlyLocation);
        } else {
            orders = db.getOrdersByDate(date);
        }

        // ✅ 这里的顺序必须与“打印箱唛（按产品顺序）”一致：产品分组 + 同产品按新增顺序
        if (orders != null && orders.size() > 1) {
            Collections.sort(orders, (a, b) -> {
                String pa = a == null ? "" : safe(a.getProductName());
                String pb = b == null ? "" : safe(b.getProductName());
                int c = pa.compareTo(pb);
                if (c != 0) return c;
                return Long.compare(a == null ? 0 : a.getId(), b == null ? 0 : b.getId());
            });
        }

        // 先按产品汇总，再按件数从高到低排序；件数相同按首次创建顺序
        java.util.HashMap<String, Integer> totalsMap = new java.util.HashMap<>();
        java.util.HashMap<String, Long> firstIdMap = new java.util.HashMap<>();

        if (orders != null) {
            for (Order o : orders) {
                if (o == null) continue;
                String productDisplay = buildProductDisplay(o);
                int old = totalsMap.containsKey(productDisplay) ? totalsMap.get(productDisplay) : 0;
                totalsMap.put(productDisplay, old + Math.max(0, o.getPieces()));

                long oid = o.getId();
                if (!firstIdMap.containsKey(productDisplay) || oid < firstIdMap.get(productDisplay)) {
                    firstIdMap.put(productDisplay, oid);
                }
            }
        }

        java.util.ArrayList<java.util.Map.Entry<String, Integer>> rows =
                new java.util.ArrayList<>(totalsMap.entrySet());

        java.util.Collections.sort(rows, (a, b) -> {
            int qa = a.getValue() == null ? 0 : a.getValue();
            int qb = b.getValue() == null ? 0 : b.getValue();
            if (qb != qa) return Integer.compare(qb, qa);

            long ia = firstIdMap.containsKey(a.getKey()) ? firstIdMap.get(a.getKey()) : Long.MAX_VALUE;
            long ib = firstIdMap.containsKey(b.getKey()) ? firstIdMap.get(b.getKey()) : Long.MAX_VALUE;
            if (ia != ib) return Long.compare(ia, ib);

            return safe(a.getKey()).compareTo(safe(b.getKey()));
        });

        LinkedHashMap<String, Integer> totals = new LinkedHashMap<>();
        for (java.util.Map.Entry<String, Integer> e : rows) {
            totals.put(e.getKey(), e.getValue());
        }

        renderTable(date, totals);
    }

    private void renderTable(String date, LinkedHashMap<String, Integer> totals) {
        tableLayout.removeAllViews();

        int grandTotal = 0;
        for (Map.Entry<String, Integer> e : totals.entrySet()) {
            String product = e.getKey();
            int qty = e.getValue() == null ? 0 : e.getValue();
            grandTotal += qty;

            TableRow row = new TableRow(this);
            row.setPadding(0, 8, 0, 8);

            TextView tvDate = new TextView(this);
            tvDate.setText(date);
            tvDate.setTextSize(16);
            tvDate.setPadding(0, 8, 12, 8);

            TextView tvProduct = new TextView(this);
            tvProduct.setText(product);
            tvProduct.setTextSize(16);
            tvProduct.setPadding(0, 8, 12, 8);
            tvProduct.setGravity(android.view.Gravity.CENTER_VERTICAL | android.view.Gravity.CENTER_HORIZONTAL);

            TextView tvQty = new TextView(this);
            tvQty.setText(String.valueOf(qty));
            tvQty.setTextSize(16);
            tvQty.setPadding(0, 8, 0, 8);
            tvQty.setGravity(android.view.Gravity.END | android.view.Gravity.CENTER_VERTICAL);

            // ✅ 让“商品”列真正占满中间区域并居中显示（与 XML 的 stretchColumns=1 保持一致）
            TableRow.LayoutParams lpDate = new TableRow.LayoutParams(
                    TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
            TableRow.LayoutParams lpProduct = new TableRow.LayoutParams(
                    0, TableRow.LayoutParams.WRAP_CONTENT, 1f);
            TableRow.LayoutParams lpQty = new TableRow.LayoutParams(
                    TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);

            row.addView(tvDate, lpDate);
            row.addView(tvProduct, lpProduct);
            row.addView(tvQty, lpQty);

            tableLayout.addView(row);

            // 分隔线
            TableRow divider = new TableRow(this);
            TextView line = new TextView(this);
            line.setHeight(1);
            line.setBackgroundColor(0xFFDDDDDD);
            divider.addView(line, new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, 1, 1f));
            tableLayout.addView(divider);
        }

        totalTextView.setText("总计：" + grandTotal);
    }

    private String buildProductDisplay(Order o) {
        String product = safe(o.getProductName());
        String loc = safe(o.getLocation());
        if (!TextUtils.isEmpty(loc)) {
            // 统一为：产品名（场地）
            if (!product.contains("(" + loc + ")") && !product.contains("（" + loc + "）")) {
                product = product + "（" + loc + "）";
            }
        }
        return product;
    }

    private String safe(String s) {
        return s == null ? "" : s.trim();
    }
}
