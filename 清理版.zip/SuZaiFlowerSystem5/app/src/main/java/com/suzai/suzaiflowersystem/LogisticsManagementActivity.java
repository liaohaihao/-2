package com.suzai.suzaiflowersystem;

import android.content.Intent;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class LogisticsManagementActivity extends BaseDrawerActivity {

    private RecyclerView recyclerView;
    private LogisticsAdapter adapter;
    private DatabaseHelper db;

    private Button addLogisticsButton;
    private Button filterLogisticsButton;
    private TextView tvMonthlyCbm;
    private TextView tvFilterInfo;

    // 当前筛选日期（yyyy-MM-dd），为空表示显示全部
    private String filterDate = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("物流管理");
        setContentLayout(R.layout.activity_logistics_management);

        db = new DatabaseHelper(this);

        addLogisticsButton = findViewById(R.id.addLogisticsButton);
        filterLogisticsButton = findViewById(R.id.filterLogisticsButton);
        tvMonthlyCbm = findViewById(R.id.tvMonthlyCbm);
        tvFilterInfo = findViewById(R.id.tvLogisticsFilterInfo);
        recyclerView = findViewById(R.id.logisticsRecyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // ✅ 新增物流单按钮：跳转到新增页面
        addLogisticsButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddLogisticsActivity.class);
            // 新增不需要传 id
            startActivity(intent);
        });

        // ✅ 筛选按钮：有筛选则清除；无筛选则弹出日期选择
        filterLogisticsButton.setOnClickListener(v -> {
            if (filterDate != null) {
                filterDate = null;
                Toast.makeText(this, "已清除筛选", Toast.LENGTH_SHORT).show();
                loadData();
            } else {
                showDatePicker();
            }
        });

        loadData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData(); // 从新增/编辑页返回时刷新
    }

    private void loadData() {
        List<LogisticsForm> list;
        if (filterDate == null) {
            list = db.getAllLogisticsForms();
        } else {
            list = db.getLogisticsFormsByDate(filterDate);
        }
        adapter = new LogisticsAdapter(list,
                this::openDetail,
                this::deleteItem);
        recyclerView.setAdapter(adapter);

        updateHeaderInfo();
    }

    private void showDatePicker() {
        final Calendar cal = Calendar.getInstance();
        DatePickerDialog dlg = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    // month: 0-11
                    filterDate = String.format(Locale.getDefault(), "%04d-%02d-%02d", year, month + 1, dayOfMonth);
                    loadData();
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
        );
        dlg.show();
    }

    private void updateHeaderInfo() {
        // 1) 筛选提示
        if (tvFilterInfo != null) {
            if (filterDate == null) {
                tvFilterInfo.setText("当前：全部（点“筛选日期”选择日期）");
                filterLogisticsButton.setText("筛选日期");
            } else {
                tvFilterInfo.setText("筛选日期：" + filterDate + "（再次点击按钮清除）");
                filterLogisticsButton.setText("清除筛选");
            }
        }

        // 2) 当月累计方数：按当前筛选日期所属月份；无筛选则按当前月份
        String ym;
        if (filterDate != null && filterDate.length() >= 7) {
            ym = filterDate.substring(0, 7);
        } else {
            Calendar cal = Calendar.getInstance();
            ym = String.format(Locale.getDefault(), "%04d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1);
        }
        double total = db.getMonthlyTotalCbm(ym);
        if (tvMonthlyCbm != null) {
            tvMonthlyCbm.setText("本月累计方数(" + ym + ")：" + formatCbm(total));
        }
    }

    private String formatCbm(double v) {
        // 常用保留 3 位小数（方数一般到 0.001）
        return String.format(Locale.getDefault(), "%.3f", v);
    }

    private void openDetail(LogisticsForm form) {
        Intent intent = new Intent(this, AddLogisticsActivity.class);
        intent.putExtra("id", form.getId());
        startActivity(intent);
    }

    private void deleteItem(LogisticsForm form) {
        int rows = db.deleteLogisticsForm(form.getId());
        if (rows > 0) {
            Toast.makeText(this, "已删除", Toast.LENGTH_SHORT).show();
            loadData();
        } else {
            Toast.makeText(this, "删除失败", Toast.LENGTH_SHORT).show();
        }
    }
}
