package com.suzai.suzaiflowersystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class LogisticsAdapter extends RecyclerView.Adapter<LogisticsAdapter.ViewHolder> {

    /** 点击一行进入详情（在详情页打印/修改）。 */
    public interface OnItemClick {
        void onOpen(LogisticsForm form);
    }

    /** 长按一行：删除。 */
    public interface OnItemLongClick {
        void onDelete(LogisticsForm form);
    }

    private final List<LogisticsForm> list;
    private final OnItemClick itemClick;
    private final OnItemLongClick longClick;

    public LogisticsAdapter(List<LogisticsForm> list,
                            OnItemClick itemClick,
                            OnItemLongClick longClick) {
        this.list = list;
        this.itemClick = itemClick;
        this.longClick = longClick;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_logistics, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        LogisticsForm f = list.get(position);

        holder.serialTv.setText(String.valueOf(f.getId()));
        holder.dateTv.setText(f.getDate() == null ? "" : f.getDate());
        holder.piecesTv.setText(String.valueOf(Math.max(0, f.getTotalPieces())));
        holder.cbmTv.setText(String.format(java.util.Locale.getDefault(), "%.2f", Math.max(0.0, f.getTotalCbm())));

        holder.itemView.setOnClickListener(v -> {
            if (itemClick != null) itemClick.onOpen(f);
        });
        holder.itemView.setOnLongClickListener(v -> {
            if (longClick != null) {
                longClick.onDelete(f);
                return true;
            }
            return false;
        });
    }

    @Override
    public int getItemCount() {
        return list == null ? 0 : list.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView serialTv, dateTv, piecesTv, cbmTv;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            serialTv = itemView.findViewById(R.id.logSerialTextView);
            dateTv = itemView.findViewById(R.id.logDateTextView);
            piecesTv = itemView.findViewById(R.id.logPiecesTextView);
            cbmTv = itemView.findViewById(R.id.logCbmTextView);
        }
    }
}
