package com.suzai.suzaiflowersystem;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Step3：应收汇总
 * - 每个客户：应收=出货累计-收款累计
 * - 点击客户：进入对账（自动带入客户）
 * - 导出 Excel：客户应收清单
 */
public class ReceivablesActivity extends BaseDrawerActivity {

    private DatabaseHelper db;
    private ReceivableAdapter adapter;
    private TextView tvSummary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("应收汇总");
        setContentLayout(R.layout.activity_receivables);

        db = new DatabaseHelper(this);

        Button btnRefresh = findViewById(R.id.btn_refresh);
        Button btnExport = findViewById(R.id.btn_export);
        tvSummary = findViewById(R.id.tv_summary);

        RecyclerView rv = findViewById(R.id.recycler_receivables);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ReceivableAdapter(new ReceivableAdapter.OnItemClickListener() {
            @Override public void onClick(ReceivableRow row) {
                Intent it = new Intent(ReceivablesActivity.this, ReconciliationActivity.class);
                it.putExtra(ReconciliationActivity.EXTRA_CUSTOMER_NAME, row.customerName);
                startActivity(it);
            }
        });
        rv.setAdapter(adapter);

        btnRefresh.setOnClickListener(v -> refresh());
        btnExport.setOnClickListener(v -> exportExcel());

        refresh();
    }

    private void refresh() {
        // 规则：
        // 1) 只显示“应收余额>0”的客户（金额为0的不显示）
        // 2) 按“应收余额”从高到低排列
        List<ReceivableRow> raw = db.getReceivablesSummary();
        List<ReceivableRow> rows = new ArrayList<>();
        if (raw != null) {
            for (ReceivableRow r : raw) {
                if (r == null) continue;
                if (r.balance > 0.0001) rows.add(r);
            }
        }
        Collections.sort(rows, (a, b) -> Double.compare(b.balance, a.balance));
        adapter.setData(rows);

        double totalBalance = 0;
        int cnt = 0;
        for (ReceivableRow r : rows) {
            totalBalance += r.balance;
            cnt++;
        }
        tvSummary.setText(String.format(Locale.getDefault(), "应收客户：%d  总应收：%.2f", cnt, totalBalance));
    }

    private void exportExcel() {
        try {
            // 导出与界面保持一致：只导出应收>0，并按余额降序
            List<ReceivableRow> raw = db.getReceivablesSummary();
            List<ReceivableRow> rows = new ArrayList<>();
            if (raw != null) {
                for (ReceivableRow r : raw) {
                    if (r == null) continue;
                    if (r.balance > 0.0001) rows.add(r);
                }
            }
            Collections.sort(rows, (a, b) -> Double.compare(b.balance, a.balance));
            String[] headers = new String[]{"客户", "应收余额", "出货累计", "收款累计", "账期(天)", "额度"};
            List<List<String>> data = new ArrayList<>();
            for (ReceivableRow r : rows) {
                List<String> line = new ArrayList<>();
                line.add(nvl(r.customerName));
                line.add(fmt2(r.balance));
                line.add(fmt2(r.totalShip));
                line.add(fmt2(r.totalPaid));
                line.add(String.valueOf(r.creditDays));
                line.add(fmt2(r.creditLimit));
                data.add(line);
            }
            String xml = SpreadsheetXml.buildWorkbookSingle("应收汇总", "应收=出货累计-收款累计", headers, data);
            String month = new SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(new Date());
            String fileName = "应收汇总_" + month + ".xls";
            Uri uri = ExportUtils.saveTextToDownloads(this, "SuZaiExports/Finance/" + month, fileName,
                    "application/vnd.ms-excel", xml);
            Toast.makeText(this, uri == null ? "导出失败" : "已导出：" + fileName, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "导出失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private static String nvl(String s) { return s == null ? "" : s; }
    private static String fmt2(double v) { return String.format(Locale.getDefault(), "%.2f", v); }
}
