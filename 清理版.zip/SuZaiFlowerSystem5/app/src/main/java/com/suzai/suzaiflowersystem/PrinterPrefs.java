package com.suzai.suzaiflowersystem;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 打印机配置（支持：蓝牙/网络/TCP/云打印）
 *
 * 说明：
 * 早期版本里只有 saveBluetooth/saveNetwork/saveCloud + 部分 getter。
 * 现在工程里（PrinterManager/PrinterSettingsActivity/PrinterSearchActivity）使用了
 * setBluetooth/setNetwork/setCloud/setMode 以及 getCloudUrl/getCloudToken 等方法。
 * 为保持兼容，这里统一补齐别名方法。
 */
public class PrinterPrefs {

    private static final String PREFS = "printer_prefs";

    /* ========= 打印机角色 ========= */
    public enum Role {
        LABEL,
        DOC
    }

    /* ========= 连接模式 ========= */
    public enum Mode {
        BLUETOOTH,   // 蓝牙
        NETWORK,     // TCP
        CLOUD        // 云打印
    }

    /* ========= Key 生成 ========= */
    private static String keyMode(Role role) {
        return role.name() + "_MODE";
    }

    private static String keyBtName(Role role) {
        return role.name() + "_BT_NAME";
    }

    private static String keyBtAddr(Role role) {
        return role.name() + "_BT_ADDR";
    }

    private static String keyNetIp(Role role) {
        return role.name() + "_NET_IP";
    }

    private static String keyNetPort(Role role) {
        return role.name() + "_NET_PORT";
    }

    private static String keyCloudUser(Role role) {
        return role.name() + "_CLOUD_USER";
    }

    private static String keyCloudUrl(Role role) {
        return role.name() + "_CLOUD_URL";
    }

    private static String keyCloudDevice(Role role) {
        return role.name() + "_CLOUD_DEVICE";
    }

    private static String keyCloudToken(Role role) {
        return role.name() + "_CLOUD_TOKEN";
    }

    /* ========= 保存 ========= */

    /** 保存蓝牙打印机（旧方法名） */
    public static void saveBluetooth(Context ctx, Role role, String name, String address) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit()
                .putString(keyMode(role), Mode.BLUETOOTH.name())
                .putString(keyBtName(role), name == null ? "" : name)
                .putString(keyBtAddr(role), address == null ? "" : address)
                .apply();
    }

    /** 保存网络打印机（旧方法名） */
    public static void saveNetwork(Context ctx, Role role, String ip, int port) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit()
                .putString(keyMode(role), Mode.NETWORK.name())
                .putString(keyNetIp(role), ip == null ? "" : ip)
                .putInt(keyNetPort(role), port)
                .apply();
    }

    /**
     * 保存云打印（旧方法名：仅 deviceId）
     * 兼容旧代码：如果旧调用只传 deviceId，就不覆盖 url/token。
     */
    public static void saveCloud(Context ctx, Role role, String deviceId) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit()
                .putString(keyMode(role), Mode.CLOUD.name())
                .putString(keyCloudDevice(role), deviceId == null ? "" : deviceId)
                .apply();
    }

    /* ========= 新增：工程需要的 set* 别名 ========= */

    /** 工程新方法名：保存蓝牙 */
    public static void setBluetooth(Context ctx, Role role, String name, String address) {
        saveBluetooth(ctx, role, name, address);
    }

    /** 工程新方法名：保存网络 */
    public static void setNetwork(Context ctx, Role role, String ip, int port) {
        saveNetwork(ctx, role, ip, port);
    }

    /** 工程新方法名：保存云打印（url + device + token） */
    public static void setCloud(Context ctx, Role role, String url, String deviceId, String token) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit()
                .putString(keyMode(role), Mode.CLOUD.name())
                .putString(keyCloudUrl(role), url == null ? "" : url)
                .putString(keyCloudDevice(role), deviceId == null ? "" : deviceId)
                .putString(keyCloudToken(role), token == null ? "" : token)
                .apply();
    }

    /** 工程新方法名：设置模式（仅写 mode，不清空其他字段，避免切换时模拟保存丢失） */
    public static void setMode(Context ctx, Role role, Mode mode) {
        if (mode == null) mode = Mode.BLUETOOTH;
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit().putString(keyMode(role), mode.name()).apply();
    }

    /* ========= 读取 ========= */

    public static Mode getMode(Context ctx, Role role) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String m = sp.getString(keyMode(role), Mode.BLUETOOTH.name());
        try {
            return Mode.valueOf(m);
        } catch (Exception ignore) {
            return Mode.BLUETOOTH;
        }
    }

    /** 蓝牙名称 */
    public static String getBtName(Context ctx, Role role) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return sp.getString(keyBtName(role), "");
    }

    /** 蓝牙地址（规范名） */
    public static String getBluetoothAddress(Context ctx, Role role) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return sp.getString(keyBtAddr(role), "");
    }

    /** ✅ 蓝牙地址（兼容旧代码） */
    public static String getBtAddr(Context ctx, Role role) {
        return getBluetoothAddress(ctx, role);
    }

    /** 网络 IP */
    public static String getNetworkIp(Context ctx, Role role) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return sp.getString(keyNetIp(role), "");
    }

    /** 网络端口 */
    public static int getNetworkPort(Context ctx, Role role) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return sp.getInt(keyNetPort(role), 9100);
    }

    /** 兼容旧方法名：getHost */
    public static String getHost(Context ctx, Role role) {
        return getNetworkIp(ctx, role);
    }

    /** 兼容旧方法名：getPort */
    public static int getPort(Context ctx, Role role) {
        return getNetworkPort(ctx, role);
    }

    
    /** 云开发者账号（如飞鹅云 user：邮箱/手机号） */
    public static String getCloudUser(Context ctx, Role role) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return sp.getString(keyCloudUser(role), "");
    }

    public static void setCloudUser(Context ctx, Role role, String user) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit().putString(keyCloudUser(role), user == null ? "" : user).apply();
    }

/** 云URL（新增，供 PrinterManager/PrinterSettingsActivity 使用） */
    public static String getCloudUrl(Context ctx, Role role) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return sp.getString(keyCloudUrl(role), "");
    }

    /** 云设备ID */
    public static String getCloudDevice(Context ctx, Role role) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return sp.getString(keyCloudDevice(role), "");
    }

    /** 云Token（新增，供 PrinterManager/PrinterSettingsActivity 使用） */
    public static String getCloudToken(Context ctx, Role role) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return sp.getString(keyCloudToken(role), "");
    }
}
