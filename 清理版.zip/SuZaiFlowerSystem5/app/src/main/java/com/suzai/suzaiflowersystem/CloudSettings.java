package com.suzai.suzaiflowersystem;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 云端基础配置：BASE URL 可在后期做成设置项。
 */
public class CloudSettings {
    private static final String PREFS = "cloud_settings";
    private static final String KEY_BASE_URL = "base_url";

    // 默认留空，避免误请求；你部署服务器后在登录页可配置或在这里写死。
    private static final String DEFAULT_BASE_URL = "https://YOUR_DOMAIN_HERE";

    public static String getBaseUrl(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return sp.getString(KEY_BASE_URL, DEFAULT_BASE_URL);
    }

    public static void setBaseUrl(Context ctx, String url) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_BASE_URL, url).apply();
    }
}
