package com.suzai.suzaiflowersystem;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.LinearLayout;
import android.widget.GridLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import androidx.annotation.Nullable;

public class AddOrderActivity extends BaseDrawerActivity {

    private TextView customerSelectTextView;
    private TextView productSelectTextView;
    private TextView orderDateTextView;
    private GridLayout recentCustomersContainer;
    private GridLayout recentProductsContainer;
    private Button btnPiecesMinus;
    private Button btnPiecesPlus;
    private Spinner locationSpinner;
    private EditText remarkEditText;
    private EditText piecesEditText;
    // ✅ 新增：本订单可单独修改单价与数量（不影响产品管理价格）
    private EditText priceEditText;
    private EditText quantityEditText;
    private TextView computedQuantityTextView;
    private TextView todaySavedOrdersTitle;
    private TextView todaySavedOrdersSummary;
    private View addItemButton;
    private View saveButton;

    private RecyclerView orderItemsRecyclerView;
    private OrderLineAdapter orderLineAdapter;

    private RecyclerView todayOrdersRecyclerView;
    private OrderAdapter todayOrdersAdapter;

    private DatabaseHelper databaseHelper;



    private final List<String> customerNames = new ArrayList<>();
    private final List<String> productNames = new ArrayList<>();

    private String selectedCustomer = "请选择客户";
    private String selectedProduct = "请选择产品";

    // ✅ 订单日期：默认今天，可选择昨天/明天
    private String selectedOrderDate;

    // ✅ 输入框是否被用户手动修改（用于避免程序刷新覆盖用户输入）
    private boolean userEditedPrice = false;
    private boolean userEditedQuantity = false;
    private boolean programmaticSetting = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("新增订单");
        setContentLayout(R.layout.activity_add_order);

        databaseHelper = new DatabaseHelper(this);
        bindViews();
        initOrderDate();        setupPiecesStepper();
        setupLocationSpinner();
        setupSelectors();
        setupOrderLines();
        setupTodayOrders();
        setupButtons();

        // 初始化一次
        refreshTodayOrders();
        refreshQuickPickChips();
        updateComputedQuantity();
    }

    private void bindViews() {
        customerSelectTextView = findViewById(R.id.customerSelectTextView);
        productSelectTextView = findViewById(R.id.productSelectTextView);
        orderDateTextView = findViewById(R.id.orderDateTextView);        recentCustomersContainer = findViewById(R.id.recentCustomersContainer);
        recentProductsContainer = findViewById(R.id.recentProductsContainer);
        btnPiecesMinus = findViewById(R.id.btnPiecesMinus);
        btnPiecesPlus = findViewById(R.id.btnPiecesPlus);
        locationSpinner = findViewById(R.id.locationSpinner);
        remarkEditText = findViewById(R.id.remarkEditText);
        piecesEditText = findViewById(R.id.piecesEditText);
        priceEditText = findViewById(R.id.priceEditText);
        quantityEditText = findViewById(R.id.quantityEditText);
        computedQuantityTextView = findViewById(R.id.computedQuantityTextView);
        todaySavedOrdersTitle = findViewById(R.id.todaySavedOrdersTitle);
        todaySavedOrdersSummary = findViewById(R.id.todaySavedOrdersSummary);
        addItemButton = findViewById(R.id.addItemButton);
        saveButton = findViewById(R.id.saveButton);

        orderItemsRecyclerView = findViewById(R.id.orderItemsRecyclerView);
        todayOrdersRecyclerView = findViewById(R.id.todayOrdersRecyclerView);
    }

    private void setupLocationSpinner() {
        List<String> locationNames = databaseHelper.getAllLocationNames();
        if (locationNames == null) locationNames = new ArrayList<>();

        // ✅ 默认场地：一个账号对应一个场地（锁定场地选择）
        String defLoc = AuthManager.getDefaultLocation(this);
        boolean lockLocation = false;
        if (defLoc != null && !defLoc.trim().isEmpty()) {
            defLoc = defLoc.trim();
            // 确保本地 locations 表里存在该场地（防止下拉为空）
            boolean exists = false;
            for (String s : locationNames) {
                if (defLoc.equals(s)) { exists = true; break; }
            }
            if (!exists) {
                try { databaseHelper.addLocation(defLoc); } catch (Exception ignored) {}
            }
            // 关键：只显示该账号的默认场地，避免跨账号/跨场地误选
            locationNames = new ArrayList<>();
            locationNames.add(defLoc);
            lockLocation = true;
        }

if (!lockLocation) {
            locationNames.add(0, "请选择场地");
        }
        ArrayAdapter<String> locationAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, locationNames);
        locationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        locationSpinner.setAdapter(locationAdapter);

        // 选中默认场地 &（如需）锁定
        if (defLoc != null && !defLoc.trim().isEmpty()) {
            int idx = locationNames.indexOf(defLoc);
            if (idx >= 0) locationSpinner.setSelection(idx);
        }
        if (lockLocation) {
            // 锁定：一个账号只能操作自己的场地
            locationSpinner.setEnabled(false);
            locationSpinner.setClickable(false);
        }
        try {
            locationSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
                @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                    refreshQuickPickChips();
                }
                @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
            });
        } catch (Exception ignored) {}
    }

    private void setupSelectors() {
        reloadCustomersProducts();

        // 快捷：最近客户/最近产品
        renderRecentCustomers();
        renderRecentProducts();

        customerSelectTextView.setOnClickListener(v -> {
            showSearchableSelectDialog("选择客户", customerNames, name -> {
                selectedCustomer = name;
                customerSelectTextView.setText(name);
            });
        });

        productSelectTextView.setOnClickListener(v -> {
            showSearchableSelectDialog("选择产品", productNames, name -> {
                selectedProduct = name;
                productSelectTextView.setText(name);
                // 选中产品时：默认填入产品单价（用户可改，不影响产品管理价格）
                if (priceEditText != null) {
                    double defPrice = databaseHelper.getProductPriceByName(selectedProduct);
                    programmaticSetting = true;
                    priceEditText.setText(String.format(Locale.getDefault(), "%.2f", defPrice));
                    programmaticSetting = false;
                    userEditedPrice = false;
                }
                // 数量默认跟随自动计算（用户可改）
                userEditedQuantity = false;
                updateComputedQuantity();
            });
        });

        piecesEditText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) { updateComputedQuantity(); }
        });

        if (priceEditText != null) {
            priceEditText.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
                @Override public void afterTextChanged(Editable s) {
                    if (!programmaticSetting) userEditedPrice = true;
                }
            });
        }

        if (quantityEditText != null) {
            quantityEditText.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
                @Override public void afterTextChanged(Editable s) {
                    if (!programmaticSetting) userEditedQuantity = true;
                }
            });
        }

        // 标题改为“当下订单保存情况”
        if (todaySavedOrdersTitle != null) {
            todaySavedOrdersTitle.setText("当下订单保存情况");
        }

        // 快捷：日期按钮（昨天/明天）
        // 快捷：件数 +/-
        setupPiecesStepper();
    }

    private void setupPiecesStepper() {
        if (btnPiecesMinus != null) {
            btnPiecesMinus.setOnClickListener(v -> stepPieces(-1));
        }
        if (btnPiecesPlus != null) {
            btnPiecesPlus.setOnClickListener(v -> stepPieces(1));
        }
    }

    private void stepPieces(int delta) {
        int cur = safeParseInt(piecesEditText == null ? "" : piecesEditText.getText().toString(), 0);
        cur += delta;
        if (cur < 0) cur = 0;
        programmaticSetting = true;
        if (piecesEditText != null) piecesEditText.setText(String.valueOf(cur));
        programmaticSetting = false;
        updateComputedQuantity();
    }

    private int safeParseInt(String s, int def) {
        try {
            s = s == null ? "" : s.trim();
            if (s.isEmpty()) return def;
            return Integer.parseInt(s);
        } catch (Exception e) {
            return def;
        }
    }

    private String getSelectedYearMonth() {
        try {
            String d = selectedOrderDate == null ? "" : selectedOrderDate.trim();
            if (d.length() >= 7) return d.substring(0, 7);
        } catch (Exception ignored) {}
        return new java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault()).format(new java.util.Date());
    }

    private String getCurrentYearMonth() {
        return new java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault()).format(new java.util.Date());
    }

    private boolean isCurrentYearMonth(String ym) {
        return ym != null && ym.equals(getCurrentYearMonth());
    }

    private String getPreviousYearMonth(String ym) {
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault());
            sdf.setLenient(false);
            java.util.Date d = sdf.parse((ym == null || ym.trim().isEmpty()) ? getCurrentYearMonth() : ym.trim());
            java.util.Calendar cal = java.util.Calendar.getInstance();
            cal.setTime(d);
            cal.add(java.util.Calendar.MONTH, -1);
            return sdf.format(cal.getTime());
        } catch (Exception ignored) {
            java.util.Calendar cal = java.util.Calendar.getInstance();
            cal.add(java.util.Calendar.MONTH, -1);
            return new java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault()).format(cal.getTime());
        }
    }

    private void renderRecentCustomers() {
    if (recentCustomersContainer == null) return;
    recentCustomersContainer.removeAllViews();

    String quickLocation = getQuickPickLocation();
    String rankYm = getSelectedYearMonth();
    List<String> rec = databaseHelper.getQuickPickTopCustomerNames(8, rankYm, quickLocation);
    if (rec == null || rec.isEmpty()) {
        rec = databaseHelper.getRecentCustomerNames(8);
    }
    if (rec == null || rec.isEmpty()) {
        recentCustomersContainer.setVisibility(View.GONE);
        return;
    }
    recentCustomersContainer.setVisibility(View.VISIBLE);

    final int columns = 4;
    for (int i = 0; i < rec.size(); i++) {
        final String name = rec.get(i);
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(name);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(18, 10, 18, 10);
        b.setMaxLines(1);
        b.setEllipsize(android.text.TextUtils.TruncateAt.END);

        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = 0;
        lp.height = GridLayout.LayoutParams.WRAP_CONTENT;
        lp.rowSpec = GridLayout.spec(i / columns, 1f);
        lp.columnSpec = GridLayout.spec(i % columns, 1f);
        lp.setMargins(8, 8, 8, 8);
        b.setLayoutParams(lp);

        b.setOnClickListener(v -> {
            selectedCustomer = name;
            customerSelectTextView.setText(name);
        });
        recentCustomersContainer.addView(b);
    }
}

    private void renderRecentProducts() {
        if (recentProductsContainer == null) return;
        recentProductsContainer.removeAllViews();

        String ym = getSelectedYearMonth();

        List<String> rec = null;
        try {
            rec = databaseHelper.getQuickPickTopProductNames(6, ym, getQuickPickLocation());
        } catch (Exception ignored) {}

        if (rec == null || rec.isEmpty()) {
            rec = databaseHelper.getTopProductNamesByQuantity(6, getQuickPickLocation());
        }
        if (rec == null || rec.isEmpty()) {
            rec = databaseHelper.getRecentProductNames(6);
        }
        if (rec == null || rec.isEmpty()) {
            recentProductsContainer.setVisibility(View.GONE);
            return;
        }
        recentProductsContainer.setVisibility(View.VISIBLE);
        final int columns = 3;
        for (int i = 0; i < rec.size(); i++) {
            final String name = rec.get(i);
            Button b = new Button(this);
            b.setAllCaps(false);
            b.setText(name);
            b.setMinHeight(0);
            b.setMinWidth(0);
            b.setPadding(20, 10, 20, 10);
            b.setMaxLines(2);
            b.setEllipsize(android.text.TextUtils.TruncateAt.END);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0;
            lp.height = GridLayout.LayoutParams.WRAP_CONTENT;
            lp.rowSpec = GridLayout.spec(i / columns, 1f);
            lp.columnSpec = GridLayout.spec(i % columns, 1f);
            lp.setMargins(8, 8, 8, 8);
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> {
                selectedProduct = name;
                productSelectTextView.setText(name);
                double defPrice = databaseHelper.getProductPriceByName(selectedProduct);
                programmaticSetting = true;
                priceEditText.setText(String.format(Locale.getDefault(), "%.2f", defPrice));
                programmaticSetting = false;
                userEditedPrice = false;
                userEditedQuantity = false;
                updateComputedQuantity();
            });
            recentProductsContainer.addView(b);
        }
    }

    private void reloadCustomersProducts() {
        customerNames.clear();
        productNames.clear();

        List<String> c = databaseHelper.getAllCustomerNames();
        if (c != null) customerNames.addAll(c);
        List<String> p = databaseHelper.getAllProductNames();
        if (p != null) productNames.addAll(p);

        // 默认项不放入列表（避免被搜索出来），但显示时用“请选择客户/产品”
        if (customerNames.isEmpty()) {
            customerNames.add("(暂无客户，请先在客户管理中添加)");
        }
        if (productNames.isEmpty()) {
            productNames.add("(暂无产品，请先在产品管理中添加)");
        }
    }

    private void setupOrderLines() {
        orderItemsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        orderLineAdapter = new OrderLineAdapter(new ArrayList<>(), position -> {
            orderLineAdapter.removeAt(position);
        });
        orderItemsRecyclerView.setAdapter(orderLineAdapter);
    }

    private void setupTodayOrders() {
        todayOrdersRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        todayOrdersAdapter = new OrderAdapter(new ArrayList<>(), null);
        todayOrdersRecyclerView.setAdapter(todayOrdersAdapter);
    }

    private void setupButtons() {
        addItemButton.setOnClickListener(v -> addCurrentLine());
        saveButton.setOnClickListener(v -> saveOrder());
    }


    private void initOrderDate() {
        // 默认今天
        selectedOrderDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        if (orderDateTextView != null) {
            orderDateTextView.setText(selectedOrderDate);
            orderDateTextView.setOnClickListener(v -> showDatePicker());
        }
        updateSavedOrdersTitle();
    }

    private void showDatePicker() {
        Calendar cal = Calendar.getInstance();
        try {
            // 解析当前选择日期
            String[] parts = selectedOrderDate != null ? selectedOrderDate.split("-") : null;
            if (parts != null && parts.length == 3) {
                cal.set(Calendar.YEAR, Integer.parseInt(parts[0]));
                cal.set(Calendar.MONTH, Integer.parseInt(parts[1]) - 1);
                cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(parts[2]));
            }
        } catch (Exception ignored) {}

        int y = cal.get(Calendar.YEAR);
        int m = cal.get(Calendar.MONTH);
        int d = cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dlg = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            Calendar c = Calendar.getInstance();
            c.set(Calendar.YEAR, year);
            c.set(Calendar.MONTH, month);
            c.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            selectedOrderDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(c.getTime());
            if (orderDateTextView != null) orderDateTextView.setText(selectedOrderDate);
            updateSavedOrdersTitle();
            refreshTodayOrders(); // 复用：刷新“所选日期”的已保存订单列表
            refreshQuickPickChips();
        }, y, m, d);
        dlg.show();
    }

    private void updateSavedOrdersTitle() {
        if (todaySavedOrdersTitle != null) {
            String label = (selectedOrderDate == null || selectedOrderDate.trim().isEmpty())
                    ? "已保存订单"
                    : ("已保存订单（" + selectedOrderDate + "）");
            todaySavedOrdersTitle.setText(label);
        }
    }

    /**
     * 数量 = 件数 * 装箱数
     */
    private void updateComputedQuantity() {
        if (computedQuantityTextView == null) return;

        String piecesStr = piecesEditText != null ? piecesEditText.getText().toString().trim() : "";
        if (selectedProduct == null || selectedProduct.trim().isEmpty() || "请选择产品".equals(selectedProduct) || piecesStr.isEmpty()) {
            computedQuantityTextView.setText("数量: -");
            return;
        }

        int pieces;
        try {
            pieces = Integer.parseInt(piecesStr);
        } catch (Exception e) {
            computedQuantityTextView.setText("数量: -");
            return;
        }
        if (pieces <= 0) {
            computedQuantityTextView.setText("数量: -");
            return;
        }

        int packingUnits = databaseHelper.getProductPackingUnitsByName(selectedProduct);
        int computed = pieces * packingUnits;
        computedQuantityTextView.setText("数量: " + computed);

        // ✅ 若用户未手动改“数量”，则自动把数量框同步为计算值
        if (quantityEditText != null && !userEditedQuantity) {
            programmaticSetting = true;
            quantityEditText.setText(String.valueOf(computed));
            programmaticSetting = false;
        }
    }

    private void addCurrentLine() {
        if ("请选择产品".equals(selectedProduct) || selectedProduct == null || selectedProduct.startsWith("(")) {
            Toast.makeText(this, "请选择产品", Toast.LENGTH_SHORT).show();
            return;
        }


        String piecesStr = piecesEditText.getText().toString().trim();
        if (piecesStr.isEmpty()) {
            Toast.makeText(this, "请输入件数", Toast.LENGTH_SHORT).show();
            return;
        }

        int pieces;
        try {
            pieces = Integer.parseInt(piecesStr);
        } catch (Exception e) {
            Toast.makeText(this, "件数格式不正确", Toast.LENGTH_SHORT).show();
            return;
        }

        if (pieces <= 0) {
            Toast.makeText(this, "件数必须大于 0", Toast.LENGTH_SHORT).show();
            return;
        }

        int packingUnits = databaseHelper.getProductPackingUnitsByName(selectedProduct);
        int computedQty = pieces * packingUnits;

        // ✅ 数量：默认用自动计算值，但允许本订单手动覆盖
        int quantity = computedQty;
        if (quantityEditText != null) {
            String qStr = quantityEditText.getText().toString().trim();
            if (!qStr.isEmpty()) {
                try { quantity = Integer.parseInt(qStr); } catch (Exception ignored) {}
            }
        }
        if (quantity <= 0) quantity = computedQty;

        // ✅ 单价：默认取产品管理价格，但允许手动修改，并同步到产品列表（作为默认单价）
        double price = databaseHelper.getProductPriceByName(selectedProduct);
        if (priceEditText != null) {
            String pStr = priceEditText.getText().toString().trim();
            if (!pStr.isEmpty()) {
                try { price = Double.parseDouble(pStr); } catch (Exception ignored) {}
            }
        }
        if (price < 0) price = 0;

        // ✅ 用户在新增订单里修改单价：同时更新 products.price（产品列表默认价）并触发云端同步
        try {
            databaseHelper.setProductPriceOnly(selectedProduct, price);
        } catch (Exception ignored) {}

        String lineRemark = remarkEditText != null ? remarkEditText.getText().toString().trim() : "";
        orderLineAdapter.addLine(new OrderLine(selectedProduct, pieces, quantity, price, lineRemark));

        // 清空当前行输入，方便继续添加下一项
        selectedProduct = "请选择产品";
        productSelectTextView.setText(selectedProduct);
        piecesEditText.setText("");
        if (priceEditText != null) priceEditText.setText("");
        if (quantityEditText != null) quantityEditText.setText("");
        if (remarkEditText != null) remarkEditText.setText("");
        userEditedPrice = false;
        userEditedQuantity = false;
        computedQuantityTextView.setText("数量: -");
    }

    private void saveOrder() {
        if ("请选择客户".equals(selectedCustomer) || selectedCustomer == null || selectedCustomer.startsWith("(")) {
            Toast.makeText(this, "请选择客户", Toast.LENGTH_SHORT).show();
            return;
        }

        String locationSelection = locationSpinner.getSelectedItem() != null
                ? locationSpinner.getSelectedItem().toString() : "请选择场地";
        if ("请选择场地".equals(locationSelection)) {
            Toast.makeText(this, "请选择场地", Toast.LENGTH_SHORT).show();
            return;
        }

        List<OrderLine> lines = orderLineAdapter.getLines();
        if (lines.isEmpty()) {
            Toast.makeText(this, "请先添加产品", Toast.LENGTH_SHORT).show();
            return;
        }

        String date = (selectedOrderDate != null && !selectedOrderDate.trim().isEmpty())
                ? selectedOrderDate
                : new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        int success = 0;
        int fail = 0;
        for (OrderLine line : lines) {
            String lineRemark = line.getRemark() == null ? "" : line.getRemark().trim();
            Order order = new Order(date, selectedCustomer, line.getProductName(), line.getPieces(), line.getQuantity(), line.getPrice(), locationSelection, lineRemark);
            long r = databaseHelper.addOrder(order);
            if (r != -1) {
                success++;
                try { databaseHelper.setProductPriceOnly(line.getProductName(), line.getPrice()); } catch (Exception ignored) {}
            } else fail++;
        }

        if (success > 0) {
            try {
                getSharedPreferences("sales_management_state", MODE_PRIVATE)
                        .edit()
                        .putString("last_saved_order_date", date)
                        .putBoolean("last_saved_order_date_consumed", false)
                        .apply();
            } catch (Exception ignored) {}
            // ✅ 用弹窗提示保存成功，避免 Toast 在底部被输入法/按钮遮挡
            String msg = (fail == 0)
                    ? ("订单保存成功（" + success + "条）")
                    : ("部分保存成功：成功" + success + "条，失败" + fail + "条");

            new AlertDialog.Builder(this)
                    .setTitle("保存成功")
                    .setMessage(msg)
                    .setCancelable(false)
                    .setPositiveButton("确定", (d, w) -> {
                        // 清空本次输入
                        orderLineAdapter.clear();
                        if (remarkEditText != null) remarkEditText.setText("");

                        // ✅ 成功后客户栏重置
                        selectedCustomer = "请选择客户";
                        if (customerSelectTextView != null) customerSelectTextView.setText(selectedCustomer);

                        // 清空当前行（防止下次误触）
                        selectedProduct = "请选择产品";
                        if (productSelectTextView != null) productSelectTextView.setText(selectedProduct);
                        if (piecesEditText != null) piecesEditText.setText("");
                        if (priceEditText != null) priceEditText.setText("");
                        if (quantityEditText != null) quantityEditText.setText("");
                        userEditedPrice = false;
                        userEditedQuantity = false;
                        if (computedQuantityTextView != null) computedQuantityTextView.setText("数量: -");

                        refreshTodayOrders();
                        refreshQuickPickChips();
                    })
                    .show();
        } else {
            Toast.makeText(this, "订单保存失败", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 可能新增了客户/产品/场地
        reloadCustomersProducts();
        setupLocationSpinner();
        refreshTodayOrders();
        refreshQuickPickChips();
    }

    /**
     * 刷新“最近客户/最近产品”快捷按钮。
     * 只影响 UI，不影响任何业务数据。
     */
    private void refreshQuickPickChips() {
        try { renderRecentCustomers(); } catch (Exception ignored) {}
        try { renderRecentProducts(); } catch (Exception ignored) {}
    }



    private String getQuickPickLocation() {
        try {
            if (locationSpinner != null && locationSpinner.getSelectedItem() != null) {
                String s = String.valueOf(locationSpinner.getSelectedItem()).trim();
                if (!s.isEmpty() && !"请选择场地".equals(s)) return s;
            }
        } catch (Exception ignored) {}
        try {
            String s = AuthManager.getDefaultLocation(this);
            if (s != null && !s.trim().isEmpty()) return s.trim();
        } catch (Exception ignored) {}
        return "";
    }

    private void refreshTodayOrders() {
        if (databaseHelper == null || todayOrdersAdapter == null) return;
        String d = (selectedOrderDate != null && !selectedOrderDate.trim().isEmpty())
                ? selectedOrderDate
                : new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                updateSavedOrdersTitle();
List<Order> list = databaseHelper.getOrdersByDate(d);
        if (list == null) list = new ArrayList<>();
        todayOrdersAdapter.updateOrderList(list);
        updateTodaySummary(list);
    }

    private void updateTodaySummary(@NonNull List<Order> list) {
        if (todaySavedOrdersSummary == null) return;

        int count = list.size();
        int totalPieces = 0;
        int totalQty = 0;
        double totalMoney = 0.0;

        for (Order o : list) {
            if (o == null) continue;
            totalPieces += o.getPieces();
            totalQty += o.getQuantity();
            totalMoney += o.getTotalPrice();
        }

        todaySavedOrdersSummary.setText(String.format(Locale.getDefault(),
                "共 %d 条｜件数合计 %d｜数量合计 %d｜金额合计 ¥%.2f",
                count, totalPieces, totalQty, totalMoney));
    }

    private interface OnSelectListener {
        void onSelect(String name);
    }

    /**
     * 可搜索选择器：用于客户/产品。
     */
    private void showSearchableSelectDialog(String title, List<String> data, OnSelectListener listener) {
        if (data == null || data.isEmpty()) {
            Toast.makeText(this, "暂无数据", Toast.LENGTH_SHORT).show();
            return;
        }

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_search_select, null);
        SearchView searchView = dialogView.findViewById(R.id.searchView);
        ListView listView = dialogView.findViewById(R.id.listView);

        // ✅ 关键：系统自带 ArrayAdapter 默认过滤是“前缀匹配”，必须从开头输入才能搜到。
        // 我们改成“包含匹配”：输入任意 1 个字也能搜出来（例如“圆杯”能搜到“110圆杯水培”）。
        ArrayAdapter<String> adapter = new ContainsFilterArrayAdapter(this, new ArrayList<>(data));
        listView.setAdapter(adapter);

        searchView.setIconifiedByDefault(false);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return true;
            }
        });

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(dialogView)
                .setNegativeButton("取消", null)
                .create();

        listView.setOnItemClickListener((parent, view, position, id) -> {
            String name = adapter.getItem(position);
            if (name != null && listener != null) {
                listener.onSelect(name);
            }
            dialog.dismiss();
        });

        dialog.show();
    }

    /**
     * ✅ “包含匹配”的下拉筛选适配器。
     * - 支持任意子串匹配（而不是必须前缀）
     * - 忽略大小写
     */
    private static class ContainsFilterArrayAdapter extends ArrayAdapter<String> {

        private final List<String> original;
        private final List<String> filtered;
        private Filter filter;

        public ContainsFilterArrayAdapter(@NonNull android.content.Context context, @NonNull List<String> data) {
            super(context, android.R.layout.simple_list_item_1, new ArrayList<>(data));
            this.original = new ArrayList<>(data);
            this.filtered = new ArrayList<>(data);
        }

        @Override
        public int getCount() {
            return filtered.size();
        }

        @Nullable
        @Override
        public String getItem(int position) {
            if (position < 0 || position >= filtered.size()) return null;
            return filtered.get(position);
        }

        @NonNull
        @Override
        public Filter getFilter() {
            if (filter != null) return filter;
            filter = new Filter() {
                @Override
                protected FilterResults performFiltering(CharSequence constraint) {
                    String q = constraint == null ? "" : constraint.toString().trim();
                    String qLower = q.toLowerCase(Locale.getDefault());

                    List<String> out = new ArrayList<>();
                    if (qLower.isEmpty()) {
                        out.addAll(original);
                    } else {
                        for (String s : original) {
                            if (s == null) continue;
                            String sLower = s.toLowerCase(Locale.getDefault());
                            if (sLower.contains(qLower)) {
                                out.add(s);
                            }
                        }
                    }

                    FilterResults fr = new FilterResults();
                    fr.values = out;
                    fr.count = out.size();
                    return fr;
                }

                @Override
                protected void publishResults(CharSequence constraint, FilterResults results) {
                    filtered.clear();
                    if (results != null && results.values instanceof List) {
                        //noinspection unchecked
                        filtered.addAll((List<String>) results.values);
                    }
                    notifyDataSetChanged();
                }
            };
            return filter;
        }
    }}

    /**
     * ✅ 防止“新增订单临时改价”回写到 products 表：
     * 某些历史版本会把订单价同步成产品价，这里强制把 products.price 恢复为保存前的原价。
     */