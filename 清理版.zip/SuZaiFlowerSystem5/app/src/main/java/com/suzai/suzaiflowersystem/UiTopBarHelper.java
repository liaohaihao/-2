package com.suzai.suzaiflowersystem;

import android.content.Intent;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;

import com.google.android.material.appbar.MaterialToolbar;

public final class UiTopBarHelper {
    private UiTopBarHelper() {}

    public static void setup(AppCompatActivity activity, String title) {
        MaterialToolbar toolbar = activity.findViewById(R.id.toolbarLite);
        if (toolbar == null) return;
        toolbar.setTitle(title);
        toolbar.setNavigationIcon(android.R.drawable.ic_menu_sort_by_size);
        toolbar.setNavigationOnClickListener(v -> showMenu(activity, toolbar));
        toolbar.setOnMenuItemClickListener(item -> handleMenu(activity, item));
    }

    private static void showMenu(AppCompatActivity activity, MaterialToolbar anchor) {
        PopupMenu popup = new PopupMenu(activity, anchor);
        popup.getMenuInflater().inflate(R.menu.activity_main_drawer, popup.getMenu());
        popup.setOnMenuItemClickListener(item -> handleMenu(activity, item));
        popup.show();
    }

    private static boolean handleMenu(AppCompatActivity activity, @NonNull MenuItem item) {
        Intent intent = null;
        int id = item.getItemId();
        if (id == R.id.nav_home) intent = new Intent(activity, MainActivity.class);
        else if (id == R.id.nav_sales) intent = new Intent(activity, SalesManagementActivity.class);
        else if (id == R.id.nav_reports) intent = new Intent(activity, ReportsActivity.class);
        else if (id == R.id.nav_finance) intent = new Intent(activity, FinanceCenterActivity.class);
        else if (id == R.id.nav_inventory) intent = new Intent(activity, InventoryManagementActivity.class);
        else if (id == R.id.nav_customer) intent = new Intent(activity, CustomerManagementActivity.class);
        else if (id == R.id.nav_product) intent = new Intent(activity, ProductManagementActivity.class);
        else if (id == R.id.nav_worker) intent = new Intent(activity, WorkerAllocationActivity.class);
        else if (id == R.id.nav_logistics) intent = new Intent(activity, LogisticsManagementActivity.class);
        else if (id == R.id.nav_print) intent = new Intent(activity, PrintManagementActivity.class);
        else if (id == R.id.nav_templates) intent = new Intent(activity, TemplateCenterActivity.class);
        else if (id == R.id.nav_printer_settings) intent = new Intent(activity, PrinterSettingsActivity.class);
        else if (id == R.id.nav_account) intent = new Intent(activity, SyncStatusActivity.class);
        if (intent != null) {
            activity.startActivity(intent);
            return true;
        }
        return false;
    }
}
