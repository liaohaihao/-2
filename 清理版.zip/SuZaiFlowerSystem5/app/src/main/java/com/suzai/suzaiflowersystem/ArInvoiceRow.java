package com.suzai.suzaiflowersystem;

public class ArInvoiceRow {
    public String cloudId;
    public String siteName;
    public String customerName;
    public String periodYm;
    public double amount;
    public String status;
    public String note;
}
