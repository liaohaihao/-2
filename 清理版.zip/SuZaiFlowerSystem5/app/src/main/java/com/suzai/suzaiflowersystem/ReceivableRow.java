package com.suzai.suzaiflowersystem;

public class ReceivableRow {
    public String customerName;
    public double totalShip;   // 出货累计（金额）
    public double totalPaid;   // 收款累计（金额）
    public double balance;     // 应收余额
    public int creditDays;
    public double creditLimit;
}
