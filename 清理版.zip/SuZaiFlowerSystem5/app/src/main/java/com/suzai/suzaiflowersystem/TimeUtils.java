package com.suzai.suzaiflowersystem;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TimeUtils {
    public static String now(String pattern){
        try {
            return new SimpleDateFormat(pattern, Locale.getDefault()).format(new Date());
        } catch (Exception e){
            return "";
        }
    }
}