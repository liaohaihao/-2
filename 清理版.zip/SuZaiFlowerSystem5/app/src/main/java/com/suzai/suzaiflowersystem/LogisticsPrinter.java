package com.suzai.suzaiflowersystem;

import android.content.Context;
import android.widget.Toast;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 物流单打印工具：从 DB 取数据，按“模板中心”的默认模板打印。
 */
public class LogisticsPrinter {

    public static void printById(Context ctx, long logisticsId) {
        if (ctx == null || logisticsId <= 0) return;
        DatabaseHelper db = new DatabaseHelper(ctx);
        LogisticsForm form = db.getLogisticsFormById(logisticsId);
        if (form == null) {
            Toast.makeText(ctx, "物流单不存在", Toast.LENGTH_SHORT).show();
            return;
        }
        List<LogisticsSize> sizes = db.getLogisticsSizes(logisticsId);
        // ✅ A1: 纸箱库存仅由“物流单”扣减；打印前确保已扣减（只扣一次）
        try { db.ensureLogisticsCartonDeducted(logisticsId); } catch (Throwable ignored) {}
        print(ctx, form, sizes);
}

    public static void print(Context ctx, LogisticsForm form, List<LogisticsSize> sizes) {
        try {
            String tpl = dbTemplate(ctx);
            String sizeLines = buildSizeLines(sizes);

            Map<String, String> vars = new HashMap<>();
            vars.put("date", n(form.getDate()));
            // 场地：历史占位符为 {{location}}；为兼容用户模板，新增别名 {{ship_site}}
            String loc = n(form.getLocation());
            vars.put("location", loc);
            vars.put("ship_site", loc);
            vars.put("total_pieces", String.valueOf(form.getTotalPieces()));
            vars.put("cubic", String.format(java.util.Locale.getDefault(), "%.3f", form.getTotalCbm()));
            vars.put("remark", toFeieyunBR(n(form.getRemark())));
            vars.put("serial_no", String.valueOf(form.getId()));
            vars.put("size_lines", sizeLines);

            String rendered = TemplateEngine.render(tpl, vars);

            String sendContent = rendered;
            try {
                String tt = tpl == null ? "" : tpl.trim();
                if (tt.startsWith("{") && (tt.contains("\"renderer\"") || tt.contains("\"els\""))) {
                    org.json.JSONObject wrap = new org.json.JSONObject();
                    wrap.put("__suzai_print", "v1");
                    wrap.put("tpl", new org.json.JSONObject(rendered));
                    wrap.put("payload", new org.json.JSONObject()); // 目前物流单模板以文本/变量为主，payload 预留
                    sendContent = wrap.toString();
                }
            } catch (Exception ignore) {}

            PrinterManager.printDoc(ctx, sendContent);
            Toast.makeText(ctx, "物流单已发送到打印机", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(ctx, "打印失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private static String dbTemplate(Context ctx) {
        DatabaseHelper db = new DatabaseHelper(ctx);
        String tpl = db.getDefaultTemplateContent(TemplateCenterActivity.TYPE_LOGISTICS);
        return (tpl == null || tpl.trim().isEmpty()) ? "" : tpl;
    }

    private static String buildSizeLines(List<LogisticsSize> sizes) {
        StringBuilder sb = new StringBuilder();
        if (sizes != null) {
            for (LogisticsSize s : sizes) {
                sb.append(String.format(java.util.Locale.getDefault(),
                        "%.0f×%.0f×%.0f  %d件",
                        s.getLen(), s.getWid(), s.getHei(), s.getPieces()))
                        .append("<BR>");
            }
        }
        return sb.toString();
    }

    
    // 飞鹅云小票标记语言：把普通换行转换成 <BR>，避免多行备注/各档口件数丢失
    private static String toFeieyunBR(String s) {
        if (s == null) return "";
        String t = s.replace("\r\n", "\n").replace("\r", "\n");
        return t.replace("\n", "<BR>");
    }

private static String n(String s) {
        return s == null ? "" : s;
    }
}
