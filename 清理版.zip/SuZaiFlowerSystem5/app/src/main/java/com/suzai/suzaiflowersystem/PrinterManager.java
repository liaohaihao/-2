package com.suzai.suzaiflowersystem;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * PrinterManager（云打印）
 * - DOC：飞鹅云 Open_printMsg（小票/单据）
 * - LABEL：飞鹅云 Open_printLabelMsg（标签机）
 *
 * ✅ 特别说明（飞鹅云标签接口）：
 * content 不是 TSPL/CPCL/ZPL 原生指令，而是“排版控制标签”（例如 <SIZE>、<TEXT>、<QR> 等）。
 * 如果发送纯文本或其它指令，飞鹅云会返回 ret=1001：
 *   “参数错误 : 请正确输入标签打印测试内容。”
 *
 * 本项目默认标签纸：50x80mm 竖版（飞鹅云文档：1mm=8dots）。
 */
public class PrinterManager {

    private static final String TAG = "PrinterManager";
    private static final int TIMEOUT_MS = 12000;

    /**
     * ✅ 统一打印线程（标签/送货单/物流单全部走这里）
     * - 单线程：保证同一台云打印机请求按顺序发送，避免并发导致丢单/乱序
     * - 后台线程：彻底解决 NetworkOnMainThreadException
     */
    private static final ExecutorService PRINT_EXECUTOR = Executors.newSingleThreadExecutor(new ThreadFactory() {
        private final AtomicInteger idx = new AtomicInteger(1);

        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "print-worker-" + idx.getAndIncrement());
            t.setDaemon(true);
            return t;
        }
    });

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    public interface PrintCallback {
        void onSuccess();

        void onError(Exception e);
    }

    public static void printDocText(Context ctx, String content) {
        enqueue(ctx, PrinterPrefs.Role.DOC, content, null);
    }

    /**
     * 带回调的送货单/物流单打印：
     * - onSuccess: printInternalThrow 成功返回（至少代表“已成功提交到打印流程/配置正确”）
     * - onError: 配置缺失、网络失败等异常（例如 DOC 未配置）
     */
    public static void printDocText(Context ctx, String content, PrintCallback cb) {
        enqueue(ctx, PrinterPrefs.Role.DOC, content, cb);
    }

    public static void printDoc(Context ctx, String content) {
        enqueue(ctx, PrinterPrefs.Role.DOC, content, null);
    }

    public static void printLabel(Context ctx, String content) {
        enqueue(ctx, PrinterPrefs.Role.LABEL, content, null);
    }

    // ✅ 兼容旧调用：OrderPrintActivity 传入客户/产品/件数/备注
    public static void printLabel(Context ctx,
                              String customer,
                              String product,
                              int pieces,
                              String remark) {
        printLabel(ctx, customer, product, pieces, remark, "", null);
    }

    // ✅ 新增：支持场地 + 订单日期（方案2）
    public static void printLabel(Context ctx,
                                  String customer,
                                  String product,
                                  int pieces,
                                  String remark,
                                  String site,
                                  String orderDate) {
        String date = normalizeLabelDate(orderDate);
        String safeSite = site == null ? "" : site.trim();

        // ✅ 优先使用“模板中心”的默认标签模板
        try {
            DatabaseHelper db = new DatabaseHelper(ctx);
            String tpl = db.getDefaultTemplateContent(TemplateCenterActivity.TYPE_LABEL);
            if (tpl != null && !tpl.trim().isEmpty()) {
                Map<String, String> vars = new HashMap<>();
                vars.put("customer", customer == null ? "" : customer);
                vars.put("product", product == null ? "" : product);
                vars.put("quantity", String.valueOf(pieces));
                vars.put("pieces", String.valueOf(pieces));
                vars.put("remark", remark == null ? "" : remark);
                vars.put("site", safeSite);
                // 兼容旧模板字段
                vars.put("location", safeSite);
                int packingUnits = 1;
                try { packingUnits = db.getProductPackingUnitsByName(product); } catch (Exception ignored) {}
                vars.put("spec", String.valueOf(packingUnits));
                vars.put("packing_units", String.valueOf(packingUnits));

                vars.put("page", "1");
                vars.put("pages", "1");
                // ✅ 兼容模板字段：{{index}}/{{total}}（等价于 page/pages）
                vars.put("index", "1");
                vars.put("total", "1");
                vars.put("date", date);
                String rendered = TemplateEngine.render(tpl, vars);
                enqueue(ctx, PrinterPrefs.Role.LABEL, rendered, null);
                return;
            }
        } catch (Exception ignore) {}

        // fallback：旧内置格式
        String label = buildLabelFeie50x80(customer, product, pieces, remark, 1, 1, date);
        enqueue(ctx, PrinterPrefs.Role.LABEL, label, null);
    }

    public static void printRaw(Context ctx, PrinterPrefs.Role role, byte[] rawBytes) throws Exception {
        String content = rawBytes == null ? "" : new String(rawBytes, StandardCharsets.UTF_8);
        // raw 也走统一线程；避免主线程直接网络
        enqueue(ctx, role, content, null);
    }

    /**
     * 外部调用统一走 enqueue（异步）；必要时可传 callback。
     */
    public static void printAsync(Context ctx, PrinterPrefs.Role role, String content, PrintCallback cb) {
        enqueue(ctx, role, content, cb);
    }

    private static void enqueue(Context ctx, PrinterPrefs.Role role, String content, PrintCallback cb) {
        if (ctx == null) {
            if (cb != null) cb.onError(new IllegalArgumentException("Context为空"));
            return;
        }

        final Context appCtx = ctx.getApplicationContext();

        PRINT_EXECUTOR.execute(() -> {
            try {
                printInternalThrow(appCtx, role, content);
                if (cb != null) {
                    MAIN.post(cb::onSuccess);
                }
            } catch (Exception e) {
                Log.e(TAG, "printInternal error", e);
                if (cb != null) {
                    MAIN.post(() -> cb.onError(e));
                } else {
                    // 默认兜底：给用户一个可见提示
                    MAIN.post(() -> Toast.makeText(appCtx, "打印失败：" + safeMsg(e), Toast.LENGTH_LONG).show());
                }
            }
        });
    }

    private static String safeMsg(Exception e) {
        if (e == null) return "未知错误";
        String m = e.getMessage();
        if (m == null || m.trim().isEmpty()) return e.getClass().getSimpleName();
        if (m.length() > 160) return m.substring(0, 160) + "…";
        return m;
    }

    private static void printInternalThrow(Context ctx, PrinterPrefs.Role role, String content) throws Exception {
        if (ctx == null) throw new IllegalArgumentException("Context为空");

        // ✅ 强制分流：
        // - DOC（送货单/物流单）必须走“小票机（DOC）”配置
        // - LABEL（箱唛/标签）必须走“标签机（LABEL）”配置
        // 绝不允许 DOC 自动复用 LABEL，否则会把送货单发到标签机导致“不出纸/无反应”。
        PrinterPrefs.Mode mode = PrinterPrefs.getMode(ctx, role);
        if (mode != PrinterPrefs.Mode.CLOUD) {
            throw new IllegalStateException("当前仅支持云打印模式（请在设置里选择云打印）");
        }

        String user = PrinterPrefs.getCloudUser(ctx, role);
        String url = PrinterPrefs.getCloudUrl(ctx, role);
        String sn = PrinterPrefs.getCloudDevice(ctx, role);
        String ukey = PrinterPrefs.getCloudToken(ctx, role);

        if (TextUtils.isEmpty(user) || TextUtils.isEmpty(url) || TextUtils.isEmpty(sn) || TextUtils.isEmpty(ukey)) {
            if (role == PrinterPrefs.Role.DOC) {
                throw new IllegalArgumentException("小票机(DOC)云打印参数不完整：请到【打印机设置】配置‘送货单/物流单(小票机)’的 USER/URL/SN/KEY");
            } else {
                throw new IllegalArgumentException("标签机(LABEL)云打印参数不完整：请到【打印机设置】配置‘箱唛/标签(标签机)’的 USER/URL/SN/KEY");
            }
        }

        if (role == PrinterPrefs.Role.DOC) {
            // ✅ DOC：支持两种方式
            // 1) 传统：飞鹅小票排版标签（文本）
            // 2) JSON 模板：先 canvas 渲染成图片，再走“图片打印”（Open_printMsg + multipart + <IMG>）
            try {
                String t = content == null ? "" : content.trim();
                if (t.startsWith("{") && t.contains("\"__suzai_print\"")) {
                    JSONObject wrap = new JSONObject(t);
                    JSONObject tplObj = wrap.optJSONObject("tpl");
                    JSONObject payloadObj = wrap.optJSONObject("payload");

                    if (tplObj == null) throw new IllegalArgumentException("JSON模板缺少 tpl 字段");
                    // 渲染图片
                    byte[] png = JsonCanvasReceiptRenderer.renderToPng(ctx, tplObj, payloadObj);

                    // 内容里放一个 <IMG> 标签，服务端会用上传的 img 替换打印
                    // 末尾追加 <CUT>，有切刀的机型会自动切纸
                    String imgContent = "<IMG><BR><CUT>";

                    CloudPrinterClient.sendFeieyunReceiptImage(url, user, sn, ukey, imgContent, png, 1);
                    return;
                }
            } catch (Exception e) {
                // JSON 打印失败：继续抛出，让上层 Toast 提示
                throw e;
            }

            String safe = safeDocContent(content);
            CloudPrinterClient.sendFeieyunText(url, user, sn, ukey, safe, TIMEOUT_MS);
            return;
        }


        // LABEL：必须是“飞鹅云排版控制标签”内容
        String label = content;
        if (!looksLikeLabelCommand(label)) {
            // 如果上层传了纯文本，这里自动转换成飞鹅标签内容，避免 ret=1001
            label = buildLabelFeie50x80("", content, 1, "", 1, 1, "");
        }
        label = normalizeLabel(label);

        // 标签接口支持 times（份数）；这里默认 1
        CloudPrinterClient.sendFeieyunLabel(url, user, sn, ukey, label, 1, TIMEOUT_MS);
    }

    /** 小票/单据接口：末尾补换行更稳 */
    private static String safeDocContent(String s) {
        if (s == null) return "";
        return s.endsWith("\n") ? s : (s + "\n");
    }

    /** 把飞鹅云小票/单据内容里的常见控制标签去掉，保留可读文本（用于转换成标签打印） */
    private static String stripFeieyunTextTags(String s) {
        if (s == null) return "";
        String t = s;
        // 常见换行标签
        t = t.replace("<BR>", "\n").replace("<br>", "\n");
        // 去掉其余 <...> 标签
        t = t.replaceAll("<[^>]+>", "");
        // 规整空行
        t = t.replaceAll("\r\n?", "\n");
        return t.trim();
    }

    /** 判断是不是标签内容（飞鹅云排版标签 / TSPL / CPCL / ZPL 任意一种） */
    private static boolean looksLikeLabelCommand(String s) {
        if (s == null) return false;
        String t = s.trim().toUpperCase(Locale.ROOT);
        // 飞鹅云标签排版：<SIZE>...<TEXT ...>
        if (t.contains("<SIZE>") || t.contains("<TEXT") || t.contains("<QR") || t.contains("<BC")) return true;
        // TSPL 常见：SIZE/GAP/CLS/PRINT/TEXT/QRCODE
        if (t.startsWith("SIZE ") || t.contains("\nSIZE ") || t.contains("\r\nSIZE ")) return true;
        if (t.startsWith("CLS") || t.contains("\nCLS") || t.contains("\r\nCLS")) return true;
        // ZPL：^XA
        if (t.startsWith("^XA") || t.contains("\n^XA") || t.contains("\r\n^XA")) return true;
        // CPCL：! 0 200 200 ...
        if (t.startsWith("! ") || t.startsWith("!0") || t.contains("\n! ")) return true;
        return false;
    }

    /** 统一换行到 \n，并尽量保证末尾有换行（飞鹅云/TSPL 都更稳） */
    private static String normalizeLabel(String s) {
        if (s == null) return "";
        // 1) 统一换行
        String t = s.replace("\r\n", "\n").replace("\r", "\n");

        // 2) ✅ 兼容 Web/旧模板导出的 rotate/size 写法：
        //    - rotate="90"  -> r="90"（飞鹅云标签旋转参数是 r）
        //    - size="34"    -> 自动换算 w/h（缩放倍数），并补全 font/w/h/r
        t = upgradeFeieyunLabelMarkup(t);

        // 3) 建议末尾带换行
        return t.endsWith("\n") ? t : (t + "\n");
    }

    /**
     * 把 <TEXT x=".." y=".." size=".." rotate=".."> 这种“简化标签模板”升级为飞鹅云可识别的：
     * <TEXT x=".." y=".." font="12" w=".." h=".." r="..">...
     *
     * 说明：
     * - 你网页设计器导出的 rotate/size 在飞鹅云标签接口里不会生效（属性名不对）。
     * - 升级后，竖排（rotate=90）就会按 r=90 打印。
     */
    private static String upgradeFeieyunLabelMarkup(String input) {
        if (TextUtils.isEmpty(input)) return "";
        try {
            // ✅ 支持网页设计器导出的“标定参数”注释：
            // <!-- calib sx=1 sy=0.98 offX=30 offY=0 anchor=TL -->
            // 说明：很多机型会有左边距/纵向缩放差异，直接在模板内标定后可显著贴近真实打印。
            float sx = pickFloatFromComment(input, "sx", 1f);
            float sy = pickFloatFromComment(input, "sy", 1f);
            float offX = pickFloatFromComment(input, "offX", 0f);
            float offY = pickFloatFromComment(input, "offY", 0f);

            java.util.regex.Pattern p = java.util.regex.Pattern.compile(
                    "<TEXT\\s+([^>]*)>(.*?)</TEXT>",
                    java.util.regex.Pattern.CASE_INSENSITIVE | java.util.regex.Pattern.DOTALL
            );
            java.util.regex.Matcher m = p.matcher(input);
            StringBuffer sb = new StringBuffer();
            while (m.find()) {
                String attr = m.group(1) == null ? "" : m.group(1);
                String body = m.group(2) == null ? "" : m.group(2);

                // 读取属性
                String x = pickAttr(attr, "x");
                String y = pickAttr(attr, "y");
                String font = pickAttr(attr, "font");
                String w = pickAttr(attr, "w");
                String h = pickAttr(attr, "h");
                String r = pickAttr(attr, "r");
                String rotate = pickAttr(attr, "rotate");
                String size = pickAttr(attr, "size");

                if (TextUtils.isEmpty(x)) x = "0";
                if (TextUtils.isEmpty(y)) y = "0";

                // ✅ 应用标定：x/y 先做缩放再偏移（单位仍然是 dots）
                try {
                    int xi = Integer.parseInt(x.trim());
                    int yi = Integer.parseInt(y.trim());
                    xi = Math.round(xi * sx + offX);
                    yi = Math.round(yi * sy + offY);
                    x = String.valueOf(Math.max(0, xi));
                    y = String.valueOf(Math.max(0, yi));
                } catch (Exception ignore) {
                }

                // rotate -> r
                if (TextUtils.isEmpty(r) && !TextUtils.isEmpty(rotate)) {
                    r = rotate;
                }
                if (TextUtils.isEmpty(r)) r = "0";

                // size -> w/h（缩放倍数），并补 font
                if (TextUtils.isEmpty(font)) font = "12";
                if ((TextUtils.isEmpty(w) || TextUtils.isEmpty(h)) && !TextUtils.isEmpty(size)) {
                    int sz;
                    try {
                        sz = Integer.parseInt(size.trim());
                    } catch (Exception ignore) {
                        sz = 24;
                    }
                    int wh = Math.max(1, Math.min(6, Math.round(sz / 24f)));
                    if (TextUtils.isEmpty(w)) w = String.valueOf(wh);
                    if (TextUtils.isEmpty(h)) h = String.valueOf(wh);
                }
                if (TextUtils.isEmpty(w)) w = "1";
                if (TextUtils.isEmpty(h)) h = "1";

                // 重新输出（只输出飞鹅云认可字段，避免乱字段导致不生效）
                String rebuilt = "<TEXT x=\"" + x + "\" y=\"" + y + "\" font=\"" + font
                        + "\" w=\"" + w + "\" h=\"" + h + "\" r=\"" + r + "\">" + body + "</TEXT>";

                m.appendReplacement(sb, java.util.regex.Matcher.quoteReplacement(rebuilt));
            }
            m.appendTail(sb);
            return sb.toString();
        } catch (Exception e) {
            // 任何异常都不影响打印（只是不升级）
            return input;
        }
    }

    private static float pickFloatFromComment(String input, String key, float def) {
        if (TextUtils.isEmpty(input) || TextUtils.isEmpty(key)) return def;
        try {
            java.util.regex.Pattern p = java.util.regex.Pattern.compile(
                    key + "\\s*=\\s*([0-9]+(?:\\.[0-9]+)?)",
                    java.util.regex.Pattern.CASE_INSENSITIVE
            );
            java.util.regex.Matcher m = p.matcher(input);
            if (m.find()) {
                return Float.parseFloat(m.group(1));
            }
        } catch (Exception ignore) {
        }
        return def;
    }

    private static String pickAttr(String attrs, String key) {
        if (TextUtils.isEmpty(attrs) || TextUtils.isEmpty(key)) return "";
        try {
            java.util.regex.Pattern p = java.util.regex.Pattern.compile(
                    key + "\\s*=\\s*\\\"([^\\\"]*)\\\"",
                    java.util.regex.Pattern.CASE_INSENSITIVE
            );
            java.util.regex.Matcher m = p.matcher(attrs);
            if (m.find()) return m.group(1);
            return "";
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * ✅ 50x80mm 竖版 标签（飞鹅云排版控制标签）
     * - 1mm = 8 dots（飞鹅云文档）
     * - 50mm 宽：x 0~400
     * - 80mm 高：y 0~640
     */
    public static String buildLabelFeie50x80(String customer,
                                             String product,
                                             int pieces,
                                             String remark,
                                             int index,
                                             int total,
                                             String orderNo) {
        // 目标样式（参考你给的图一）：
        // 顶部：客户名（大字）
        // 行1：产品：xxx
        // 行2：规格：
        // 行3：数量：20装   25-12-28   1/1
        // 行4：备注：佛山|
        //
        // 纸张：50*80 竖版（1mm=8dots）
        String cust = TextUtils.isEmpty(customer) ? "" : customer;
        String prod = TextUtils.isEmpty(product) ? "" : product;

        // 规格：当前订单数据结构没有独立规格字段，先留空（你后续如果加字段，再接进来）
        String spec = "";

        String dateShort = normalizeLabelDate(orderNo);

        int idx = (index <= 0 ? 1 : index);
        int tot = (total <= 0 ? 1 : total);
        String idxText = idx + "/" + tot;

        String qtyText = (pieces > 0 ? (pieces + "装") : "");
        String rm = TextUtils.isEmpty(remark) ? "" : remark;

        StringBuilder sb = new StringBuilder();
        sb.append("<SIZE>50,80</SIZE>\n");
        sb.append("<DIRECTION>1</DIRECTION>\n");

        // 客户名（大字）
        if (!TextUtils.isEmpty(cust)) {
            sb.append(textTag(10, 10, 12, 3, 3, 0, cust)).append('\n');
        } else {
            sb.append(textTag(10, 10, 12, 3, 3, 0, "客户")).append('\n');
        }

        // 产品
        sb.append(textTag(10, 170, 12, 1, 1, 0, "产品：" + prod)).append('\n');

        // 规格（留空）
        sb.append(textTag(10, 250, 12, 1, 1, 0, "规格：" + spec)).append('\n');

        // 数量 + 日期 + 张数
        sb.append(textTag(10, 330, 12, 1, 1, 0, "数量：" + qtyText)).append('\n');
        if (!TextUtils.isEmpty(dateShort)) {
            sb.append(textTag(200, 330, 12, 1, 1, 0, dateShort)).append('\n');
        }
        sb.append(textTag(320, 330, 12, 1, 1, 0, idxText)).append('\n');

        // 备注
        sb.append(textTag(10, 420, 12, 1, 1, 0, "备注：" + rm)).append('\n');

        return sb.toString();
    }

    /** 把订单日期标准化为 yy-MM-dd；拿不到就用今天 */
    public static String normalizeLabelDate(String s) {
        try {
            // 如果传入就是日期（yyyy-MM-dd 或 yy-MM-dd），直接用
            if (!TextUtils.isEmpty(s)) {
                String t = s.trim();
                if (t.matches("\\d{4}-\\d{2}-\\d{2}")) {
                    return t.substring(2); // -> yy-MM-dd
                }
                if (t.matches("\\d{2}-\\d{2}-\\d{2}")) {
                    return t;
                }
            }
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yy-MM-dd", java.util.Locale.getDefault());
            return sdf.format(new java.util.Date());
        } catch (Exception e) {
            return "";
        }
    }

    private static String textTag(int x, int y, int font, int w, int h, int r, String text) {
        return "<TEXT x=\"" + x + "\" y=\"" + y + "\" font=\"" + font + "\" w=\"" + w + "\" h=\"" + h + "\" r=\"" + r + "\">" + escapeFeie(text) + "</TEXT>";
    }

    private static String escapeFeie(String s) {
        if (s == null) return "";
        // 标签内容里不需要转义 < >，但为了稳妥，替换掉可能破坏标签的字符
        return s.replace("</", "< /").replace("<", "＜").replace(">", "＞");
    }
}
