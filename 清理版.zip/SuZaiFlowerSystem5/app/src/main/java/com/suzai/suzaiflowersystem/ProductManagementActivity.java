package com.suzai.suzaiflowersystem;

import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ProductManagementActivity extends BaseDrawerActivity {

    private RecyclerView recyclerView;
    private ProductAdapter adapter;
    private DatabaseHelper databaseHelper;

    // 注意：ProductAdapter 内部持有的是这个 list（可变），刷新时我们 clear/addAll 即可
    private final List<String> productNames = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentLayout(R.layout.activity_product_management);
        if (toolbar != null) toolbar.setTitle("产品管理");
        android.view.View lite = findViewById(R.id.toolbarLite);
        if (lite != null) lite.setVisibility(android.view.View.GONE);

        databaseHelper = new DatabaseHelper(this);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // 初始加载
        productNames.clear();
        productNames.addAll(databaseHelper.getAllProductNames());

        adapter = new ProductAdapter(productNames, new ProductAdapter.OnProductActionListener() {
            @Override
            public void onProductClick(String productName) {
                showEditProductDialog(productName);
            }

            @Override
            public void onDeleteClick(String productName) {
                showDeleteConfirm(productName);
            }
        });
        recyclerView.setAdapter(adapter);

        findViewById(R.id.addProductButton).setOnClickListener(v -> showAddProductDialog());
        View importBtn = findViewById(R.id.importProductsButton);
        if (importBtn != null) {
            importBtn.setOnClickListener(v -> confirmAndImportProducts());
        }
        findViewById(R.id.adjustAllPricesButton).setOnClickListener(v -> showAdjustAllPricesDialog());
    }

    private void confirmAndImportProducts() {
        new AlertDialog.Builder(this)
                .setTitle("一键导入产品")
                .setMessage("将内置的产品清单导入到本机数据库。\n\n重复的产品名称会自动跳过。")
                .setNegativeButton("取消", null)
                .setPositiveButton("开始导入", (d, w) -> {
                    int[] result = importProductsFromAssets();
                    Toast.makeText(this,
                            "导入完成：新增 " + result[0] + " 个，跳过 " + result[1] + " 个",
                            Toast.LENGTH_LONG).show();
                    refreshList();
                })
                .show();
    }

    /**
     * 从 assets/products_import.csv 导入
     * 文件格式示例：name,price,packing_units
     */
    private int[] importProductsFromAssets() {
        int inserted = 0;
        int skipped = 0;
        try {
            java.io.InputStream is = getAssets().open("products_import.csv");
            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(is, java.nio.charset.StandardCharsets.UTF_8));
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first) {
                    line = stripBom(line);
                    first = false;
                    if (line.toLowerCase().contains("name") && line.toLowerCase().contains("price")) {
                        continue; // header
                    }
                }
                line = line.trim();
                if (line.isEmpty()) continue;

                // 兼容 , ; \t
                String[] parts;
                if (line.contains(",")) parts = line.split(",", -1);
                else if (line.contains(";")) parts = line.split(";", -1);
                else parts = line.split("\\t", -1);

                if (parts.length < 1) continue;
                String name = parts[0] == null ? "" : parts[0].trim();
                if (name.isEmpty()) continue;

                double price = 0;
                int packing = 1;
                if (parts.length >= 2) price = parseDouble(parts[1], 0);
                if (parts.length >= 3) packing = parseInt(parts[2], 1);
                if (packing <= 0) packing = 1;

                long id = databaseHelper.addProduct(name, packing, price);
                if (id > 0) inserted++;
                else skipped++;
            }
            br.close();
        } catch (Exception e) {
            Toast.makeText(this, "导入失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        return new int[]{inserted, skipped};
    }

    private String stripBom(String s) {
        if (s == null) return "";
        return s.replace("\uFEFF", "");
    }

    private void refreshList() {
        productNames.clear();
        productNames.addAll(databaseHelper.getAllProductNames());
        adapter.notifyDataSetChanged();
    }

    private void showDeleteConfirm(String productName) {
        new AlertDialog.Builder(this)
                .setTitle("删除产品")
                .setMessage("确定删除产品：\n" + productName + "\n\n注意：已存在的订单不会被删除，但后续下单将无法再选择该产品。")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", (d, w) -> {
                    boolean ok = databaseHelper.deleteProductByName(productName);
                    if (ok) {
                        Toast.makeText(this, "已删除：" + productName, Toast.LENGTH_SHORT).show();
                        refreshList();
                    } else {
                        Toast.makeText(this, "删除失败，请重试", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private void showAddProductDialog() {
        // 复用你现有的 dialog_edit_product.xml（包含：名称/装箱数/单价）
        View view = getLayoutInflater().inflate(R.layout.dialog_edit_product, null);

        EditText etName = view.findViewById(R.id.editProductName);
        EditText etPacking = view.findViewById(R.id.editProductPacking);
        EditText etPrice = view.findViewById(R.id.editProductPrice);

        etPacking.setText("1");
        etPrice.setText("");

        new AlertDialog.Builder(this)
                .setTitle("新增产品")
                .setView(view)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", (dialog, which) -> {
                    String name = safeTrim(etName.getText().toString());
                    if (name.isEmpty()) {
                        Toast.makeText(this, "产品名不能为空", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int packing = parseInt(etPacking.getText().toString(), 1);
                    if (packing <= 0) packing = 1;

                    double price = parseDouble(etPrice.getText().toString(), 0);

                    long id = databaseHelper.addProduct(name, packing, price);
                    if (id > 0) {
                        Toast.makeText(this, "已新增：" + name, Toast.LENGTH_SHORT).show();
                        refreshList();
                    } else {
                        Toast.makeText(this, "新增失败，请重试", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private void showEditProductDialog(String oldName) {
        View view = getLayoutInflater().inflate(R.layout.dialog_edit_product, null);

        EditText etName = view.findViewById(R.id.editProductName);
        EditText etPacking = view.findViewById(R.id.editProductPacking);
        EditText etPrice = view.findViewById(R.id.editProductPrice);

        etName.setText(oldName);

        ProductInfo info = databaseHelper.getProductInfoByName(oldName);
        if (info != null) {
            etPacking.setText(String.valueOf(info.getPackingUnits()));
            etPrice.setText(String.valueOf(info.getPrice()));
        } else {
            etPacking.setText("1");
            etPrice.setText("0");
        }

        new AlertDialog.Builder(this)
                .setTitle("编辑产品")
                .setView(view)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", (dialog, which) -> {
                    String newName = safeTrim(etName.getText().toString());
                    if (newName.isEmpty()) {
                        Toast.makeText(this, "产品名不能为空", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int packing = parseInt(etPacking.getText().toString(), 1);
                    if (packing <= 0) packing = 1;

                    double price = parseDouble(etPrice.getText().toString(), 0);

                    int rows = databaseHelper.updateProductByName(oldName, newName, packing, price);
                    if (rows > 0) {
                        Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show();
                        refreshList();
                    } else {
                        Toast.makeText(this, "保存失败，请重试", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    /**
     * ✅ 系列统一调价：
     * - 土培：名称不含“水培”
     * - 水培：含“水培”且不含括号
     * - 水培带公仔：含“水培”且含括号（( 或 （）
     */
    private void showAdjustAllPricesDialog() {
        // 不依赖任何 layout 文件，避免你本地缺资源导致编译失败
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        root.setPadding(pad, pad, pad, pad);

        // 方向：上调/下调
        RadioGroup rgDir = new RadioGroup(this);
        rgDir.setOrientation(RadioGroup.HORIZONTAL);

        RadioButton rbUp = new RadioButton(this);
        rbUp.setText("上涨");
        RadioButton rbDown = new RadioButton(this);
        rbDown.setText("下调");

        rgDir.addView(rbUp);
        rgDir.addView(rbDown);
        rbUp.setChecked(true);

        // 调价金额
        EditText etDelta = new EditText(this);
        etDelta.setHint("输入调价金额（例如：0.5）");
        etDelta.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        // 系列：全部/土培/水培/水培带公仔
        RadioGroup rgSeries = new RadioGroup(this);
        rgSeries.setOrientation(RadioGroup.VERTICAL);

        RadioButton rbAll = new RadioButton(this);
        rbAll.setText("全部产品");
        RadioButton rbSoil = new RadioButton(this);
        rbSoil.setText("土培（不含“水培”）");
        RadioButton rbWater = new RadioButton(this);
        rbWater.setText("水培（含“水培”，不含括号）");
        RadioButton rbWaterDoll = new RadioButton(this);
        rbWaterDoll.setText("水培带公仔（含“水培”且含括号）");

        rgSeries.addView(rbAll);
        rgSeries.addView(rbSoil);
        rgSeries.addView(rbWater);
        rgSeries.addView(rbWaterDoll);
        rbAll.setChecked(true);

        root.addView(rgDir);
        root.addView(space(10));
        root.addView(etDelta);
        root.addView(space(16));
        root.addView(rgSeries);

        new AlertDialog.Builder(this)
                .setTitle("统一调价（按系列）")
                .setView(root)
                .setNegativeButton("取消", null)
                .setPositiveButton("确定", (dialog, which) -> {
                    double deltaAbs = parseDouble(etDelta.getText().toString(), Double.NaN);
                    if (Double.isNaN(deltaAbs) || deltaAbs <= 0) {
                        Toast.makeText(this, "请输入正确的调价金额（>0）", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    boolean isUp = rbUp.isChecked();
                    double delta = isUp ? deltaAbs : -deltaAbs;

                    int series = DatabaseHelper.PRICE_SERIES_ALL;
                    if (rbSoil.isChecked()) series = DatabaseHelper.PRICE_SERIES_SOIL;
                    else if (rbWater.isChecked()) series = DatabaseHelper.PRICE_SERIES_WATER;
                    else if (rbWaterDoll.isChecked()) series = DatabaseHelper.PRICE_SERIES_WATER_DOLL;

                    int affected = databaseHelper.adjustProductPricesBySeries(delta, series);
                    Toast.makeText(this, "已调价产品数：" + affected, Toast.LENGTH_SHORT).show();
                    refreshList();
                })
                .show();
    }

    // ---------- utils ----------

    private String safeTrim(String s) {
        return s == null ? "" : s.trim();
    }

    private int parseInt(String s, int def) {
        try {
            if (s == null) return def;
            s = s.trim();
            if (s.isEmpty()) return def;
            return Integer.parseInt(s);
        } catch (Exception e) {
            return def;
        }
    }

    private double parseDouble(String s, double def) {
        try {
            if (s == null) return def;
            s = s.trim();
            if (s.isEmpty()) return def;
            return Double.parseDouble(s);
        } catch (Exception e) {
            return def;
        }
    }

    private View space(int dp) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(dp)
        ));
        return v;
    }

    private int dp(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return (int) (dp * density + 0.5f);
    }
}
