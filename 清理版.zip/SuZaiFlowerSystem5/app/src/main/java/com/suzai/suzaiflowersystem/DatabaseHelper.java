package com.suzai.suzaiflowersystem;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.text.SimpleDateFormat;
import java.util.Date;
import android.util.Log;

/**
 * ✅ 可用的本地数据库实现（支持：客户/产品/订单）
 *
 * 说明：之前的 DatabaseHelper 是“仅为通过编译的空壳”。
 * 这会导致客户/产品列表为空，导入也无法生效。
 *
 * 这里提供一个稳定的 SQLite 实现：
 * - customers(name UNIQUE, contact)
 * - products(name UNIQUE, packing_units, price)
 * - orders(date, customer_name, product_name, pieces, quantity, price, location, remark)
 * - locations(name UNIQUE)
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // =========================
    // Order Status (Step2-1)
    // =========================
    public static final String ORDER_STATUS_DRAFT = "DRAFT";       // 草稿（未确认）
    public static final String ORDER_STATUS_CONFIRMED = "CONFIRMED"; // 已确认（默认）
    public static final String ORDER_STATUS_PRINTED = "PRINTED";   // 已打印出货/箱唛
    public static final String ORDER_STATUS_SHIPPED = "SHIPPED";   // 已出库/发货（预留，后续与物流单联动）
    public static final String ORDER_STATUS_SETTLED = "SETTLED";   // 已结清
    public static final String ORDER_STATUS_VOID = "VOID";         // 作废（软删除）


    private String normalizeCloudDate(String date) {
        if (date == null) return null;

        String d = date.trim();
        if (d.isEmpty() || "null".equalsIgnoreCase(d)) return null;

        if (d.length() >= 10) {
            String head = d.substring(0, 10);
            if (head.charAt(4) == '-' && head.charAt(7) == '-') {
                return head;
            }
        }

        int t = d.indexOf('T');
        if (t > 0) d = d.substring(0, t);

        int sp = d.indexOf(' ');
        if (sp > 0) d = d.substring(0, sp);

        return d;
    }

    public static final String DB_NAME_BASE = "flower";
    // ⚠️ 为了实现“账号切换后订单不共享”，本地数据库按账号隔离：flower_<hash>.db
    private static String resolveDbName(Context c) {
        try {
            String uid = AuthManager.getUserId(c);
            if (uid == null || uid.trim().isEmpty()) {
                String em = AuthManager.getEmail(c);
                uid = (em == null) ? "" : em.trim().toLowerCase();
            }
            if (uid == null) uid = "";
            // 用 nameUUIDFromBytes 生成文件名安全且稳定的 hash
            String h = java.util.UUID.nameUUIDFromBytes(uid.getBytes("UTF-8")).toString().replace("-", "");
            return DB_NAME_BASE + "_" + h + ".db";
        } catch (Exception e) {
            return DB_NAME_BASE + "_default.db";
        }
    }
    // ✅ 升级版本：新增 locations 表 + 补齐云端同步所需方法
    // ✅ 版本号上调：确保旧安装能触发 onUpgrade，补建 locations 表并种入默认场地
    // ✅ 版本号上调：修复“卸载重装后物流单会被重复推送到云端（产生两条相同物流单）”的问题
    // - logistics_forms 增加 cloud_id + synced 字段：
    //   * cloud_id：云端主键（uuid），从云端拉取时写入；本地新建时生成
    //   * synced：是否已成功推送到云端（1=已同步，0=待同步）
    // 2026-02-05: Step2(稳定性) - 订单作废/软删除 + 同步冲突(按 updated_at 最后写入优先)
    // ✅ v2.0：共享表（customers/products/print_templates）补齐 cloud_id，用于“按 cloud_id 精确 upsert/delete”。
    // 这是“补列升级”，不会影响已有 orders/order_items 的精确删除与同步逻辑。
    // v15: add AR (invoices/payments/allocations) local tables for upcoming Finance/Reports cloud sync
    public static final int DB_VERSION = 17;

    // inventory types
    public static final String INV_TYPE_CARTON = "CARTON";
    public static final String INV_TYPE_POT = "POT";
    public static final String INV_TYPE_BAG = "BAG";
    public static final String INV_TYPE_PRODUCT = "PRODUCT";

    // price series
    public static final int PRICE_SERIES_ALL = 0;
    public static final int PRICE_SERIES_SOIL = 1;
    public static final int PRICE_SERIES_WATER = 2;
    public static final int PRICE_SERIES_WATER_DOLL = 3;

    private final Context ctx;

    /**
     * ✅ 数据发生变更后，尽最大努力触发一次云端同步（失败不影响本地）。
     * 说明：SupabaseSyncManager 内部已经是新线程，不会阻塞 UI。
     */
    private void scheduleCloudPushSafe() {
        try {
            if (AuthManager.isLoggedIn(ctx)) {
                SupabaseSyncManager.schedulePush(ctx);
            }
        } catch (Exception ignored) {
        }
    }

    public DatabaseHelper(Context c) {
        super(c, resolveDbName(c), null, DB_VERSION);
        this.ctx = c.getApplicationContext();

        // ✅ 让“第一次安装/刚登录”也能立刻在下拉里出现默认场地：
        // - 不依赖用户手动去【场地管理】新增
        // - 也不依赖其它页面一定先调用 setupLocationSpinner
        try {
            ensureDefaultLocationSeeded();
        } catch (Exception ignored) {
        }

        // ✅ 修复“库存扣减后又被云端拉回重置”的历史遗留：
        // 旧版本可能存在 inventory_items.cloud_id 为空的库存行。
        // 当云端 pull 到同一条库存（带 cloud_id）时，会走旧的 fallback（按 type/name/sku/spec 覆盖写入），
        // 从而把本地扣减后的 qty 覆盖回云端旧值。
        // 这里在启动时为缺失 cloud_id 的库存行补齐 cloud_id，并标记为 synced=0，确保后续：
        // 1) push 使用 on_conflict=cloud_id 幂等更新云端；
        // 2) pull 合并时能命中 cloud_id，不会覆盖本地未推送的 qty。
        try {
            ensureInventoryCloudIdsBackfilled();
        } catch (Exception ignored) {
        }
    }


    // =========================================================
    // SITE FILTER (账号默认场地过滤)
    // 说明：
    // - 除【订单管理】可切换查看各场地外，其它统计/财务页面必须只看当前账号默认场地数据
    // - 为兼容旧订单 location 为空，默认把 location 为空/'' 的订单也归到当前账号默认场地
    // ⚠️ 不可随意修改此逻辑（会导致跨场地数据混入）
    // 
    // 【审计发现】当前逻辑会导致空场地数据被所有场地一起统计，违反"默认只统计当前账号场地数据"规则
    // 【处理建议】如需严格场地隔离，应修改 SQL 条件为：AND IFNULL(location,'')=? 
    // 【当前决策】保持现状以兼容历史数据，业务上需注意空场地数据的归属问题
    // =========================================================
    private String getDefaultSiteForReports() {
        try {
            String s = AuthManager.getDefaultLocationForCurrentUser(this.ctx);
            return s == null ? "" : s.trim();
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * 为本地 inventory_items 中 cloud_id 为空的旧数据补齐 cloud_id，并标记 synced=0。
     * 这一步是“就地修复”，不会改变 qty/safety 等业务字段。
     */
    private void ensureInventoryCloudIdsBackfilled() {
        SQLiteDatabase db = null;
        Cursor c = null;
        try {
            db = getWritableDatabase();
            c = db.rawQuery(
                    "SELECT id FROM inventory_items WHERE cloud_id IS NULL OR TRIM(cloud_id)=''",
                    null
            );
            while (c.moveToNext()) {
                long id = c.getLong(0);
                ContentValues cv = new ContentValues();
                cv.put("cloud_id", java.util.UUID.randomUUID().toString());
                cv.put("synced", 0);
                db.update("inventory_items", cv, "id=?", new String[]{String.valueOf(id)});
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) try { c.close(); } catch (Exception ignored) {}
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createTables(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // ✅ 只做“补建表/补列”，不做粗暴 drop，避免用户数据丢失
        createTables(db);

        // ✅ v2.0：共享表补齐 cloud_id（用于云端精确 upsert/delete）
        try { db.execSQL("ALTER TABLE customers ADD COLUMN cloud_id TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE products ADD COLUMN cloud_id TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE print_templates ADD COLUMN cloud_id TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE customers ADD COLUMN updated_at TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE products ADD COLUMN updated_at TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_customers_cloud_id ON customers(cloud_id)"); } catch (Exception ignored) {}
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_products_cloud_id ON products(cloud_id)"); } catch (Exception ignored) {}
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_print_templates_cloud_id ON print_templates(cloud_id)"); } catch (Exception ignored) {}

        // ✅ logistics_forms：补齐 cloud_id + synced（用于防止卸载重装后重复推送造成云端重复物流单）
        try { db.execSQL("ALTER TABLE logistics_forms ADD COLUMN cloud_id TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE logistics_forms ADD COLUMN synced INTEGER NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_logistics_forms_cloud_id ON logistics_forms(cloud_id)"); } catch (Exception ignored) {}
        try { db.execSQL("CREATE TABLE IF NOT EXISTS carton_rules (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "product_name TEXT UNIQUE NOT NULL," +
                "len REAL NOT NULL DEFAULT 0," +
                "wid REAL NOT NULL DEFAULT 0," +
                "hei REAL NOT NULL DEFAULT 0," +
                "updated_at TEXT" +
                ")"); } catch (Exception ignored) {}
                // ✅ logistics_forms：纸箱扣减标记（方案A1：纸箱只由物流单扣减，且只扣减一次）
        try { db.execSQL("ALTER TABLE logistics_forms ADD COLUMN carton_deducted INTEGER NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
// ✅ 库存表字段补齐（旧版本可能没有）
        try { db.execSQL("ALTER TABLE inventory_items ADD COLUMN sku TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE inventory_items ADD COLUMN spec TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE inventory_items ADD COLUMN qty INTEGER NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE inventory_items ADD COLUMN safety INTEGER NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE inventory_items ADD COLUMN updated_at TEXT"); } catch (Exception ignored) {}

        // ✅ 库存流水表：旧版本没有则补建（createTables 已建，这里仅兜底）
        try { db.execSQL("CREATE TABLE IF NOT EXISTS inventory_movements (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "item_id INTEGER," +
                "change_qty INTEGER," +
                "reason TEXT," +
                "ref_type TEXT," +
                "ref_id INTEGER," +
                "date TEXT," +
                "uuid TEXT," +
                "created_at INTEGER DEFAULT 0" +
                ")"); } catch (Exception ignored) {}
        
        // ✅ 归档表：2年热数据 + 历史归档方案
        try { ArchiveManager.createArchiveTables(db); } catch (Exception ignored) {}
// 备注列：如果旧表没有 remark，补上
        try {
            db.execSQL("ALTER TABLE orders ADD COLUMN remark TEXT");
        } catch (Exception ignored) {
        }

        // ✅ 订单表：补齐 printed 列（用于“只扣减未扣减过的订单库存”，避免重复扣减）
        try { db.execSQL("ALTER TABLE orders ADD COLUMN printed INTEGER NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
        // orders: ensure cloud_id + synced for cloud idempotency
        try { db.execSQL("ALTER TABLE orders ADD COLUMN cloud_id TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE orders ADD COLUMN synced INTEGER NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE orders ADD COLUMN created_at TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE orders ADD COLUMN updated_at TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("UPDATE orders SET created_at = COALESCE(created_at, datetime('now')), updated_at = COALESCE(updated_at, datetime('now'))"); } catch (Exception ignored) {}

        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_orders_cloud_id ON orders(cloud_id)"); } catch (Exception ignored) {}

        // ✅ orders：商业化增强字段（状态 + 汇总）
        try { db.execSQL("ALTER TABLE orders ADD COLUMN status TEXT DEFAULT 'CONFIRMED'"); } catch (Exception ignored) {}
        // ✅ Step2：软删除/作废（不做物理删除）
        try { db.execSQL("ALTER TABLE orders ADD COLUMN is_deleted INTEGER NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE orders ADD COLUMN deleted_at TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE orders ADD COLUMN cloud_delete_tracked INTEGER NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE orders ADD COLUMN voided_at TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE orders ADD COLUMN printed_at TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE orders ADD COLUMN shipped_at TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE orders ADD COLUMN settled_at TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE orders ADD COLUMN total_quantity INTEGER NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE orders ADD COLUMN total_amount REAL NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
        try { db.execSQL("UPDATE orders SET status='CONFIRMED' WHERE status IS NULL OR TRIM(status)=''"); } catch (Exception ignored) {}
        // 兼容：若历史数据存在 VOID，则标记为 is_deleted=1
        try { db.execSQL("UPDATE orders SET is_deleted=1, deleted_at=COALESCE(deleted_at, datetime('now')) WHERE UPPER(COALESCE(status,''))='VOID'"); } catch (Exception ignored) {}
        try { db.execSQL("UPDATE orders SET total_quantity=quantity WHERE total_quantity IS NULL OR total_quantity=0"); } catch (Exception ignored) {}
        try { db.execSQL("UPDATE orders SET total_amount=(quantity*price) WHERE total_amount IS NULL OR total_amount=0"); } catch (Exception ignored) {}


        // inventory_items: ensure cloud_id + synced for cloud idempotency
        try { db.execSQL("ALTER TABLE inventory_items ADD COLUMN cloud_id TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE inventory_items ADD COLUMN synced INTEGER NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_inventory_items_cloud_id ON inventory_items(cloud_id)"); } catch (Exception ignored) {}
        // inventory_items logical unique (type+name+spec) to prevent duplicated names
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_inventory_items_logical ON inventory_items(type,name,spec)"); } catch (Exception ignored) {}

        // backfill missing cloud_id for existing rows
        try { backfillCloudId(db, "customers"); } catch (Exception ignored) {}
        try { backfillCloudId(db, "products"); } catch (Exception ignored) {}
        try { backfillCloudId(db, "print_templates"); } catch (Exception ignored) {}
        try { backfillCloudId(db, "orders"); } catch (Exception ignored) {}
        try { backfillCloudId(db, "inventory_items"); } catch (Exception ignored) {}


        // locations 表：旧版本没有则自动补建
        try {
db.execSQL("CREATE TABLE IF NOT EXISTS locations (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "name TEXT UNIQUE NOT NULL" +
                    ")");
        } catch (Exception ignored) {
        }
    }
    // Backfill cloud_id for existing local rows (SQLite has no built-in UUID)
    private static void backfillCloudId(SQLiteDatabase db, String table) {
        if (db == null || table == null) return;
        String t = table.trim();
        if (t.isEmpty()) return;
        try {
            // 修复旧代码的 SQL 拼接错误（cloud_id= 缺少空字符串比较）
            android.database.Cursor c = db.rawQuery("SELECT id FROM " + t + " WHERE cloud_id IS NULL OR TRIM(cloud_id)=''", null);
            if (c == null) return;
            try {
                while (c.moveToNext()) {
                    long id = c.getLong(0);
                    android.content.ContentValues cv = new android.content.ContentValues();
                    cv.put("cloud_id", java.util.UUID.randomUUID().toString());
                    db.update(t, cv, "id=?", new String[]{String.valueOf(id)});
                }
            } finally {
                c.close();
            }
        } catch (Exception ignored) {
        }
    }



    private void createTables(SQLiteDatabase db) {
        try { ensureSharedMasterSyncColumns(db); } catch (Exception ignored) {}
        db.execSQL("CREATE TABLE IF NOT EXISTS customers (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                // ✅ 共享表也补齐 cloud_id：用于云端 on_conflict=cloud_id 与精确删除
                "cloud_id TEXT," +
                "name TEXT UNIQUE NOT NULL," +
                "contact TEXT," +
                "updated_at TEXT" +
                ")");
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_customers_cloud_id ON customers(cloud_id)"); } catch (Exception ignored) {}

        
        // ✅ Step3：财务 - 客户账期/额度（本地）
        db.execSQL("CREATE TABLE IF NOT EXISTS customer_finance_profile (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "customer_name TEXT UNIQUE NOT NULL," +
                "credit_days INTEGER NOT NULL DEFAULT 0," +
                "credit_limit REAL NOT NULL DEFAULT 0," +
                "updated_at INTEGER NOT NULL DEFAULT 0" +
                ")");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_customer_finance_name ON customer_finance_profile(customer_name)");

        // ✅ Step3：财务 - 收款记录（用于应收/对账）
        db.execSQL("CREATE TABLE IF NOT EXISTS payments (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "customer_name TEXT NOT NULL," +
                "amount REAL NOT NULL DEFAULT 0," +
                "pay_date TEXT NOT NULL," +
                "method TEXT," +
                "remark TEXT," +
                "created_at INTEGER NOT NULL DEFAULT 0," +
                "cloud_id TEXT," +
                "synced INTEGER NOT NULL DEFAULT 0," +
                "is_deleted INTEGER NOT NULL DEFAULT 0" +
                ")");
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_payments_cloud_id ON payments(cloud_id)"); } catch (Exception ignored) {}
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_payments_customer_date ON payments(customer_name, pay_date)");

        // =========================
        // v15：云端财务/报表（AR）同步专用本地表
        // - 先建表并接入同步；后续再在 APP 界面中逐步启用
        // - 这些表与 Step3 的 payments/customer_finance_profile 暂时并行，避免一次改动过大
        // =========================
        db.execSQL("CREATE TABLE IF NOT EXISTS ar_invoices (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "cloud_id TEXT," +
                "site_name TEXT NOT NULL," +
                "customer_name TEXT NOT NULL," +
                "period_ym TEXT NOT NULL," +
                "amount REAL NOT NULL DEFAULT 0," +
                "status TEXT NOT NULL DEFAULT 'OPEN'," +
                "note TEXT," +
                "created_at INTEGER NOT NULL DEFAULT 0," +
                "updated_at INTEGER NOT NULL DEFAULT 0," +
                "synced INTEGER NOT NULL DEFAULT 0," +
                "is_deleted INTEGER NOT NULL DEFAULT 0" +
                ")");
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_ar_invoices_cloud_id ON ar_invoices(cloud_id)"); } catch (Exception ignored) {}
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_ar_invoices_site_period ON ar_invoices(site_name, period_ym)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_ar_invoices_customer ON ar_invoices(customer_name)");

        db.execSQL("CREATE TABLE IF NOT EXISTS ar_payments (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "cloud_id TEXT," +
                "site_name TEXT NOT NULL," +
                "customer_name TEXT NOT NULL," +
                "amount REAL NOT NULL DEFAULT 0," +
                "pay_date TEXT NOT NULL," +
                "method TEXT," +
                "note TEXT," +
                "created_at INTEGER NOT NULL DEFAULT 0," +
                "updated_at INTEGER NOT NULL DEFAULT 0," +
                "synced INTEGER NOT NULL DEFAULT 0," +
                "is_deleted INTEGER NOT NULL DEFAULT 0" +
                ")");
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_ar_payments_cloud_id ON ar_payments(cloud_id)"); } catch (Exception ignored) {}
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_ar_payments_site_date ON ar_payments(site_name, pay_date)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_ar_payments_customer ON ar_payments(customer_name)");

        db.execSQL("CREATE TABLE IF NOT EXISTS ar_allocations (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "cloud_id TEXT," +
                "site_name TEXT NOT NULL," +
                "invoice_cloud_id TEXT NOT NULL," +
                "payment_cloud_id TEXT NOT NULL," +
                "amount REAL NOT NULL DEFAULT 0," +
                "note TEXT," +
                "created_at INTEGER NOT NULL DEFAULT 0," +
                "updated_at INTEGER NOT NULL DEFAULT 0," +
                "synced INTEGER NOT NULL DEFAULT 0," +
                "is_deleted INTEGER NOT NULL DEFAULT 0" +
                ")");
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_ar_allocations_cloud_id ON ar_allocations(cloud_id)"); } catch (Exception ignored) {}
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_ar_allocations_invoice ON ar_allocations(invoice_cloud_id)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_ar_allocations_payment ON ar_allocations(payment_cloud_id)");

db.execSQL("CREATE TABLE IF NOT EXISTS products (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                // ✅ 共享表也补齐 cloud_id：用于云端 on_conflict=cloud_id 与精确删除
                "cloud_id TEXT," +
                "name TEXT UNIQUE NOT NULL," +
                "packing_units INTEGER NOT NULL DEFAULT 1," +
                "price REAL NOT NULL DEFAULT 0," +
                "updated_at TEXT" +
                ")");
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_products_cloud_id ON products(cloud_id)"); } catch (Exception ignored) {}

        db.execSQL("CREATE TABLE IF NOT EXISTS orders (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "date TEXT NOT NULL," +
                "customer_name TEXT NOT NULL," +
                "product_name TEXT NOT NULL," +
                "pieces INTEGER NOT NULL DEFAULT 0," +
                "quantity INTEGER NOT NULL DEFAULT 0," +
                "price REAL NOT NULL DEFAULT 0," +
                "location TEXT," +
                "remark TEXT," +
                "status TEXT DEFAULT 'CONFIRMED'," +
                // ✅ Step2：软删除/作废（不做物理删除，避免换设备/重装后“删除又回来”）
                "is_deleted INTEGER NOT NULL DEFAULT 0," +
                "deleted_at TEXT," +
                // ✅ 删除补扫已跟踪标记：避免历史已删订单每轮都重复回填 cloud_delete_queue
                "cloud_delete_tracked INTEGER NOT NULL DEFAULT 0," +
                "voided_at TEXT," +
                // ✅ 打印时间（可选；printed 仍保留为 0/1 标记）
                "printed_at TEXT," +
                "shipped_at TEXT," +
                "settled_at TEXT," +
                "total_quantity INTEGER NOT NULL DEFAULT 0," +
                "total_amount REAL NOT NULL DEFAULT 0," +
                "created_at TEXT," +
                "updated_at TEXT," +
                "cloud_id TEXT," +
                "synced INTEGER NOT NULL DEFAULT 0," +
                "printed INTEGER NOT NULL DEFAULT 0" +
                ")");
        // orders cloud_id unique index for idempotent sync
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_orders_cloud_id ON orders(cloud_id)"); } catch (Exception ignored) {}


        
        // ✅ order_items：订单明细（多品订单）
        db.execSQL("CREATE TABLE IF NOT EXISTS order_items (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "order_cloud_id TEXT NOT NULL," +
                "product_name TEXT NOT NULL," +
                "pieces INTEGER NOT NULL DEFAULT 0," +
                "quantity INTEGER NOT NULL DEFAULT 0," +
                "price REAL NOT NULL DEFAULT 0," +
                "remark TEXT," +
                "created_at TEXT," +
                "updated_at TEXT," +
                "cloud_id TEXT," +
                "synced INTEGER NOT NULL DEFAULT 0," +
                "is_deleted INTEGER NOT NULL DEFAULT 0," +
                "deleted_at TEXT" +
                ")");
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_order_items_cloud_id ON order_items(cloud_id)"); } catch (Exception ignored) {}
        try { db.execSQL("CREATE INDEX IF NOT EXISTS idx_order_items_order_cloud_id ON order_items(order_cloud_id)"); } catch (Exception ignored) {}

// 场地表：用于下拉选择（首次安装也能插入默认场地）
        db.execSQL("CREATE TABLE IF NOT EXISTS locations (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT UNIQUE NOT NULL" +
                ")");
        // ✅ 物流单：表头
        db.execSQL("CREATE TABLE IF NOT EXISTS logistics_forms (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "date TEXT NOT NULL," +
                "location TEXT," +
                "total_pieces INTEGER NOT NULL DEFAULT 0," +
                "total_cbm REAL NOT NULL DEFAULT 0," +
                "remark TEXT," +
                // ✅ 云端主键（uuid 字符串）；从云端拉取时写入，本地新建时生成
                "cloud_id TEXT," +
                // ✅ 是否已成功同步到云端（0=待同步，1=已同步）
                "synced INTEGER NOT NULL DEFAULT 0" +
                ")");
        // ✅ 让 cloud_id 在本地唯一，避免重复写入
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_logistics_forms_cloud_id ON logistics_forms(cloud_id)"); } catch (Exception ignored) {}

        // ✅ 物流单：尺寸明细（多行）
        db.execSQL("CREATE TABLE IF NOT EXISTS logistics_sizes (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "logistics_id INTEGER NOT NULL," +
                "len REAL NOT NULL DEFAULT 0," +
                "wid REAL NOT NULL DEFAULT 0," +
                "hei REAL NOT NULL DEFAULT 0," +
                "pieces INTEGER NOT NULL DEFAULT 0," +
                "cbm REAL NOT NULL DEFAULT 0" +
                ")");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_logistics_sizes_lid ON logistics_sizes(logistics_id)");


        // ✅ 库存：物料表
        db.execSQL("CREATE TABLE IF NOT EXISTS inventory_items (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "type TEXT," +
                "name TEXT," +
                "sku TEXT," +
                "spec TEXT," +
                "qty INTEGER NOT NULL DEFAULT 0," +
                "safety INTEGER NOT NULL DEFAULT 0," +
                "updated_at TEXT," +
                "cloud_id TEXT," +
                "synced INTEGER NOT NULL DEFAULT 0" +
                ")");
        // inventory_items cloud_id unique index for idempotent sync
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_inventory_items_cloud_id ON inventory_items(cloud_id)"); } catch (Exception ignored) {}
        // inventory_items logical unique (type+name+spec) to prevent duplicated names
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_inventory_items_logical ON inventory_items(type,name,spec)"); } catch (Exception ignored) {}


        // ✅ 库存：变动流水（用于追踪/云端备份）
        db.execSQL("CREATE TABLE IF NOT EXISTS inventory_movements (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "item_id INTEGER," +
                "change_qty INTEGER," +
                "reason TEXT," +
                "ref_type TEXT," +
                "ref_id INTEGER," +
                "date TEXT," +
                "uuid TEXT," +
                "created_at INTEGER DEFAULT 0" +
                ")");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_inv_items_type_name ON inventory_items(type, name)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_inv_mov_item ON inventory_movements(item_id)");

        

// ✅ 云端删除队列：本地删了以后，下一次 push 时对 Supabase 执行 DELETE
db.execSQL("CREATE TABLE IF NOT EXISTS cloud_delete_queue (" +
        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
        "table_name TEXT NOT NULL," +
        "where_json TEXT NOT NULL," +
        "created_at INTEGER NOT NULL DEFAULT 0" +
        ")");
db.execSQL("CREATE INDEX IF NOT EXISTS idx_cloud_delete_queue_created ON cloud_delete_queue(created_at)");

        
        // ✅ 打印模板（模板中心）
        db.execSQL("CREATE TABLE IF NOT EXISTS print_templates (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                // ✅ 模板也补齐 cloud_id（用于云端 on_conflict=cloud_id；若云端未建约束会自动回退旧策略）
                "cloud_id TEXT," +
                "type TEXT NOT NULL," +
                "name TEXT NOT NULL," +
                "content TEXT NOT NULL," +
                "updated_at INTEGER NOT NULL DEFAULT 0," +
                "is_default INTEGER NOT NULL DEFAULT 0" +
                ")");
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_print_templates_cloud_id ON print_templates(cloud_id)"); } catch (Exception ignored) {}
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_print_templates_type ON print_templates(type)");

db.execSQL("CREATE INDEX IF NOT EXISTS idx_orders_date_customer ON orders(date, customer_name)");
    }

    @Override
    public SQLiteDatabase getWritableDatabase() {
        // 确保表被创建（某些机型极端情况下 onCreate/onUpgrade 时序异常）
        SQLiteDatabase db = super.getWritableDatabase();
        try { createTables(db); } catch (Exception ignored) {}
        return db;
    }

    @Override
    public SQLiteDatabase getReadableDatabase() {
        SQLiteDatabase db = super.getReadableDatabase();
        try { createTables(db); } catch (Exception ignored) {}
        return db;
    }

    /**
     * ✅ 确保默认场地存在于本地 locations 表中。
     * 这样：第一次安装/刚登录后，任何页面只要读取 locations 列表，下拉里就立刻能看到。
     */
    private void ensureDefaultLocationSeeded() {
        String def = AuthManager.getDefaultLocation(ctx);
        if (def == null) return;
        def = safeTrim(def);
        if (def.isEmpty()) return;
        try {
            addLocation(def);
        } catch (Exception ignored) {
        }
    }

    // ---------- CUSTOMER ----------

    public long addCustomer(String name, String contact) {
        name = safeTrim(name);
        contact = safeTrim(contact);
        if (name.isEmpty()) return -1;

        SQLiteDatabase db = getWritableDatabase();
        try { ensureSharedMasterSyncColumns(db); } catch (Exception ignored) {}
        ContentValues cv = new ContentValues();
        // ✅ 共享表也生成 cloud_id（改名不变；云端用 on_conflict=cloud_id 可精确对齐）
        cv.put("cloud_id", java.util.UUID.randomUUID().toString());
        cv.put("name", name);
        cv.put("contact", contact);
        cv.put("updated_at", nowIso8601());
        // ✅ 冲突忽略，避免重复导入导致崩溃
        long r = db.insertWithOnConflict("customers", null, cv, SQLiteDatabase.CONFLICT_IGNORE);
        if (r != -1) scheduleCloudPushSafe();
        return r;
    }

    public String getCustomerContactByName(String n) {
        n = safeTrim(n);
        if (n.isEmpty()) return "";
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT contact FROM customers WHERE name=? LIMIT 1", new String[]{n})) {
            if (c.moveToFirst()) {
                String v = c.getString(0);
                return v == null ? "" : v;
            }
        }
        return "";
    }

    public int updateCustomerByName(String oldName, String newName, String contact) {
        oldName = safeTrim(oldName);
        newName = safeTrim(newName);
        contact = safeTrim(contact);
        if (oldName.isEmpty() || newName.isEmpty()) return 0;

        SQLiteDatabase db = getWritableDatabase();
        try { ensureSharedMasterSyncColumns(db); } catch (Exception ignored) {}
        ContentValues cv = new ContentValues();
        cv.put("name", newName);
        cv.put("contact", contact);
        cv.put("updated_at", nowIso8601());
        int n = db.update("customers", cv, "name=?", new String[]{oldName});
        if (n > 0) scheduleCloudPushSafe();
        return n;
    }


    public boolean deleteCustomerByName(String name) {
        name = safeTrim(name);
        if (name.isEmpty()) return false;
        SQLiteDatabase db = getWritableDatabase();
        // 先取 cloud_id（用于云端精确删除），再删本地
        String cloudId = "";
        try (Cursor c = db.rawQuery("SELECT cloud_id FROM customers WHERE name=? LIMIT 1", new String[]{name})) {
            if (c.moveToFirst()) cloudId = nvl(c.getString(0));
        } catch (Exception ignored) {}

        boolean ok = db.delete("customers", "name=?", new String[]{name}) > 0;
        if (ok) {
            // ✅ 本地删除 → 入队云端 DELETE
            try {
                JSONObject w = new JSONObject();
                // 共享表：优先 cloud_id 精确删除；无 cloud_id 则回退 name（兼容旧云端约束）
                String uid = AuthManager.getUserId(ctx);
                String orgId = AuthManager.getOrgId(ctx);
                w.put("owner_uid", uid);
                if (orgId != null && !orgId.trim().isEmpty()) w.put("org_id", orgId.trim());
                if (cloudId != null && !cloudId.trim().isEmpty()) {
                    w.put("id", cloudId.trim());
        } else {
            w.put("org_id", orgId);
            w.put("name", name);
        }
                enqueueCloudDelete("customers", w);
            } catch (Exception ignored) {}
            scheduleCloudPushSafe();
        }
        return ok;
    }

    public List<String> getAllCustomerNames() {
        SQLiteDatabase db = getReadableDatabase();
        List<String> list = new ArrayList<>();
        try (Cursor c = db.rawQuery("SELECT name FROM customers ORDER BY name COLLATE NOCASE", null)) {
            while (c.moveToNext()) {
                String v = c.getString(0);
                if (v != null && !v.trim().isEmpty()) list.add(v);
            }
        }
        return list;
    }

    /**
     * 最近使用客户（按订单 updated_at/created_at 最近优先；排除作废/删除订单）。
     * 用于“新增订单”页面快捷选择。
     */
    public List<String> getRecentCustomerNames(int limit) {
        if (limit <= 0) limit = 6;
        SQLiteDatabase db = getReadableDatabase();
        List<String> list = new ArrayList<>();
        String sql = "SELECT customer_name, MAX(COALESCE(updated_at, created_at)) AS mx " +
                "FROM orders " +
                "WHERE is_deleted=0 AND (status IS NULL OR status!='VOID') " +
                "GROUP BY customer_name " +
                "ORDER BY mx DESC LIMIT " + limit;
        try (Cursor c = db.rawQuery(sql, null)) {
            while (c.moveToNext()) {
                String v = c.getString(0);
                if (v != null && !v.trim().isEmpty()) list.add(v);
            }
        } catch (Exception ignored) {}
        return list;
    }

    /**
     * 常用客户：按订单金额累计从高到低取前 N。
     * 说明：这里用 orders.total_amount 汇总（仅本地订单、未删除）。
     */
    
public List<String> getTopCustomerNamesByAmount(int limit) {
    return getTopCustomerNamesByAmount(limit, "");
}

public List<String> getTopCustomerNamesByAmount(int limit, String location) {
    List<String> list = new ArrayList<>();
    SQLiteDatabase db = getReadableDatabase();
    Cursor c = null;
    if (location == null) location = "";
    try {
        String sql;
        String[] args;
        if (location.trim().isEmpty()) {
            sql =
                "SELECT TRIM(COALESCE(NULLIF(customer_name,''), NULLIF(customer,''))) AS cname, " +
                "SUM(COALESCE(total_amount, COALESCE(quantity,0) * COALESCE(price,0))) AS amt " +
                "FROM orders " +
                "WHERE is_deleted=0 " +
                "AND (status IS NULL OR status!='VOID') " +
                "AND TRIM(COALESCE(NULLIF(customer_name,''), NULLIF(customer,''), ''))<>'' " +
                "GROUP BY TRIM(COALESCE(NULLIF(customer_name,''), NULLIF(customer,''))) " +
                "HAVING amt > 0 " +
                "ORDER BY amt DESC, MIN(id) ASC " +
                "LIMIT ?";
            args = new String[]{String.valueOf(Math.max(1, limit))};
        } else {
            sql =
                "SELECT TRIM(COALESCE(NULLIF(customer_name,''), NULLIF(customer,''))) AS cname, " +
                "SUM(COALESCE(total_amount, COALESCE(quantity,0) * COALESCE(price,0))) AS amt " +
                "FROM orders " +
                "WHERE is_deleted=0 " +
                "AND (status IS NULL OR status!='VOID') " +
                "AND (IFNULL(location,'')=? OR IFNULL(location,'')='') " +
                "AND TRIM(COALESCE(NULLIF(customer_name,''), NULLIF(customer,''), ''))<>'' " +
                "GROUP BY TRIM(COALESCE(NULLIF(customer_name,''), NULLIF(customer,''))) " +
                "HAVING amt > 0 " +
                "ORDER BY amt DESC, MIN(id) ASC " +
                "LIMIT ?";
            args = new String[]{location.trim(), String.valueOf(Math.max(1, limit))};
        }
        c = db.rawQuery(sql, args);
        while (c.moveToNext()) {
            String name = c.getString(0);
            if (name != null && name.trim().length() > 0) list.add(name.trim());
        }
    } catch (Exception ignored) {
    } finally {
        if (c != null) c.close();
    }
    return list;
}

public List<String> getTopCustomerNamesByCurrentMonthAmount(int limit) {
    String ym = new java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault()).format(new java.util.Date());
    return getTopCustomerNamesByMonthAmount(limit, ym);
}

public List<String> getTopCustomerNamesByMonthAmount(int limit, String ym) {
    return getTopCustomerNamesByMonthAmount(limit, ym, "");
}

public List<String> getTopCustomerNamesByMonthAmount(int limit, String ym, String location) {
    List<String> list = new ArrayList<>();
    SQLiteDatabase db = getReadableDatabase();
    Cursor c = null;
    if (ym == null) ym = "";
    if (location == null) location = "";
    try {
        String sql =
                "SELECT TRIM(COALESCE(NULLIF(customer_name,''), NULLIF(customer,''))) AS cname, " +
                "SUM(COALESCE(total_amount, COALESCE(quantity,0) * COALESCE(price,0))) AS amt " +
                "FROM orders " +
                "WHERE is_deleted=0 " +
                "AND (status IS NULL OR status!='VOID') " +
                "AND TRIM(COALESCE(NULLIF(customer_name,''), NULLIF(customer,''), ''))<>'' " +
                "AND substr(COALESCE(date,''),1,7)=? " +
                (location.trim().isEmpty() ? "" : "AND IFNULL(location,'')=? ") +
                "GROUP BY TRIM(COALESCE(NULLIF(customer_name,''), NULLIF(customer,''))) " +
                "HAVING amt > 0 " +
                "ORDER BY amt DESC, MIN(id) ASC " +
                "LIMIT ?";
        String[] args = location.trim().isEmpty()
                ? new String[]{ym, String.valueOf(Math.max(1, limit))}
                : new String[]{ym, location.trim(), String.valueOf(Math.max(1, limit))};
        c = db.rawQuery(sql, args);
        while (c.moveToNext()) {
            String name = c.getString(0);
            if (name != null && name.trim().length() > 0) list.add(name.trim());
        }
    } catch (Exception ignored) {
    } finally {
        if (c != null) c.close();
    }
    return list;
}

public List<String> getTopProductNamesByQuantity(int limit) {
    return getTopProductNamesByQuantity(limit, "");
}

public List<String> getTopProductNamesByQuantity(int limit, String location) {
    List<String> list = new ArrayList<>();
    SQLiteDatabase db = getReadableDatabase();
    Cursor c = null;
    if (location == null) location = "";
    try {
        String sql;
        String[] args;
        if (location.trim().isEmpty()) {
            sql =
                "SELECT TRIM(COALESCE(NULLIF(product_name,''), NULLIF(product,''))) AS pname, " +
                "SUM(COALESCE(quantity, total_quantity, 0)) AS qty " +
                "FROM orders " +
                "WHERE is_deleted=0 " +
                "AND (status IS NULL OR status!='VOID') " +
                "AND TRIM(COALESCE(NULLIF(product_name,''), NULLIF(product,''), ''))<>'' " +
                "GROUP BY TRIM(COALESCE(NULLIF(product_name,''), NULLIF(product,''))) " +
                "HAVING qty > 0 " +
                "ORDER BY qty DESC, MIN(id) ASC " +
                "LIMIT ?";
            args = new String[]{String.valueOf(Math.max(1, limit))};
        } else {
            sql =
                "SELECT TRIM(COALESCE(NULLIF(product_name,''), NULLIF(product,''))) AS pname, " +
                "SUM(COALESCE(quantity, total_quantity, 0)) AS qty " +
                "FROM orders " +
                "WHERE is_deleted=0 " +
                "AND (status IS NULL OR status!='VOID') " +
                "AND (IFNULL(location,'')=? OR IFNULL(location,'')='') " +
                "AND TRIM(COALESCE(NULLIF(product_name,''), NULLIF(product,''), ''))<>'' " +
                "GROUP BY TRIM(COALESCE(NULLIF(product_name,''), NULLIF(product,''))) " +
                "HAVING qty > 0 " +
                "ORDER BY qty DESC, MIN(id) ASC " +
                "LIMIT ?";
            args = new String[]{location.trim(), String.valueOf(Math.max(1, limit))};
        }
        c = db.rawQuery(sql, args);
        while (c.moveToNext()) {
            String name = c.getString(0);
            if (name != null && name.trim().length() > 0) list.add(name.trim());
        }
    } catch (Exception ignored) {
    } finally {
        if (c != null) c.close();
    }
    return list;
}

public List<String> getTopProductNamesByCurrentMonthQuantity(int limit) {
    String ym = new java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault()).format(new java.util.Date());
    return getTopProductNamesByMonthQuantity(limit, ym);
}

public List<String> getTopProductNamesByMonthQuantity(int limit, String ym) {
    return getTopProductNamesByMonthQuantity(limit, ym, "");
}

public List<String> getTopProductNamesByMonthQuantity(int limit, String ym, String location) {
    List<String> list = new ArrayList<>();
    SQLiteDatabase db = getReadableDatabase();
    Cursor c = null;
    if (ym == null) ym = "";
    if (location == null) location = "";
    try {
        String sql =
                "SELECT TRIM(COALESCE(NULLIF(product_name,''), NULLIF(product,''))) AS pname, " +
                "SUM(COALESCE(quantity, total_quantity, 0)) AS qty " +
                "FROM orders " +
                "WHERE is_deleted=0 " +
                "AND (status IS NULL OR status!='VOID') " +
                "AND TRIM(COALESCE(NULLIF(product_name,''), NULLIF(product,''), ''))<>'' " +
                "AND substr(COALESCE(date,''),1,7)=? " +
                (location.trim().isEmpty() ? "" : "AND IFNULL(location,'')=? ") +
                "GROUP BY TRIM(COALESCE(NULLIF(product_name,''), NULLIF(product,''))) " +
                "HAVING qty > 0 " +
                "ORDER BY qty DESC, MIN(id) ASC " +
                "LIMIT ?";
        String[] args = location.trim().isEmpty()
                ? new String[]{ym, String.valueOf(Math.max(1, limit))}
                : new String[]{ym, location.trim(), String.valueOf(Math.max(1, limit))};
        c = db.rawQuery(sql, args);
        while (c.moveToNext()) {
            String name = c.getString(0);
            if (name != null && name.trim().length() > 0) list.add(name.trim());
        }
    } catch (Exception ignored) {
    } finally {
        if (c != null) c.close();
    }
    return list;
}


    /**
     * 新增订单快捷客户：与首页客户排行口径保持一致。
     * 规则：本月有数据时按本月；本月无数据时回退上月。
     * 统计口径：SUM(quantity*price)，场地为(当前场地 或 空场地)。
     */
    public List<String> getQuickPickTopCustomerNames(int limit, String ym, String location) {
        if (limit <= 0) limit = 8;
        if (ym == null || ym.trim().isEmpty()) {
            ym = new java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault()).format(new java.util.Date());
        }
        return queryQuickPickTopCustomerNames(limit, ym.trim(), safeTrim(location));
    }

    /**
     * 新增订单快捷产品：与首页热销产品口径保持一致。
     * 规则：本月有数据时按本月；本月无数据时回退上月。
     * 统计口径：先按 pieces 件数降序，再按金额降序；场地为(当前场地 或 空场地)。
     */
    public List<String> getQuickPickTopProductNames(int limit, String ym, String location) {
        if (limit <= 0) limit = 6;
        if (ym == null || ym.trim().isEmpty()) {
            ym = new java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault()).format(new java.util.Date());
        }
        return queryQuickPickTopProductNames(limit, ym.trim(), safeTrim(location));
    }

    private List<String> queryQuickPickTopCustomerNames(int limit, String ym, String location) {
        List<String> list = queryTopCustomersForMonth(limit, ym, location);
        if ((list == null || list.isEmpty()) && isCurrentMonthString(ym)) {
            list = queryTopCustomersForMonth(limit, previousYearMonth(ym), location);
        }
        return list == null ? new ArrayList<>() : list;
    }

    private List<String> queryQuickPickTopProductNames(int limit, String ym, String location) {
        List<String> list = queryTopProductsForMonth(limit, ym, location);
        if ((list == null || list.isEmpty()) && isCurrentMonthString(ym)) {
            list = queryTopProductsForMonth(limit, previousYearMonth(ym), location);
        }
        return list == null ? new ArrayList<>() : list;
    }

    private List<String> queryTopCustomersForMonth(int limit, String ym, String location) {
        List<String> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String sql =
                "SELECT customer_name, COALESCE(SUM(COALESCE(quantity,0)*COALESCE(price,0)),0) AS s " +
                "FROM orders " +
                "WHERE date>=? AND date<=? " +
                "AND (is_deleted IS NULL OR is_deleted=0) " +
                "AND (status IS NULL OR status!='VOID') " +
                "AND TRIM(COALESCE(customer_name,''))<>'' " +
                "AND (IFNULL(location,'')=? OR IFNULL(location,'')='') " +
                "GROUP BY customer_name " +
                "HAVING s > 0 " +
                "ORDER BY s DESC, MIN(id) ASC LIMIT ?";
        String start = ym + "-01";
        String end = ym + "-31";
        try (Cursor c = db.rawQuery(sql, new String[]{start, end, safeTrim(location), String.valueOf(Math.max(1, limit))})) {
            while (c.moveToNext()) {
                String name = c.getString(0);
                if (name != null && !name.trim().isEmpty()) list.add(name.trim());
            }
        } catch (Exception ignored) {}
        return list;
    }

    private List<String> queryTopProductsForMonth(int limit, String ym, String location) {
        List<String> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String sql =
                "SELECT product_name, COALESCE(SUM(COALESCE(pieces,0)),0) AS pcs, COALESCE(SUM(COALESCE(quantity,0)*COALESCE(price,0)),0) AS amt " +
                "FROM orders " +
                "WHERE date>=? AND date<=? " +
                "AND (is_deleted IS NULL OR is_deleted=0) " +
                "AND (status IS NULL OR status!='VOID') " +
                "AND TRIM(COALESCE(product_name,''))<>'' " +
                "AND (IFNULL(location,'')=? OR IFNULL(location,'')='') " +
                "GROUP BY product_name " +
                "HAVING pcs > 0 " +
                "ORDER BY pcs DESC, amt DESC, MIN(id) ASC LIMIT ?";
        String start = ym + "-01";
        String end = ym + "-31";
        try (Cursor c = db.rawQuery(sql, new String[]{start, end, safeTrim(location), String.valueOf(Math.max(1, limit))})) {
            while (c.moveToNext()) {
                String name = c.getString(0);
                if (name != null && !name.trim().isEmpty()) list.add(name.trim());
            }
        } catch (Exception ignored) {}
        return list;
    }

    private boolean isCurrentMonthString(String ym) {
        String cur = new java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault()).format(new java.util.Date());
        return cur.equals(safeTrim(ym));
    }

    private String previousYearMonth(String ym) {
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault());
            sdf.setLenient(false);
            java.util.Date d = sdf.parse(safeTrim(ym));
            java.util.Calendar cal = java.util.Calendar.getInstance();
            cal.setTime(d);
            cal.add(java.util.Calendar.MONTH, -1);
            return sdf.format(cal.getTime());
        } catch (Exception ignored) {
            java.util.Calendar cal = java.util.Calendar.getInstance();
            cal.add(java.util.Calendar.MONTH, -1);
            return new java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault()).format(cal.getTime());
        }
    }


    // ---------- PRODUCT ----------

    public long addProduct(String name, int packingUnits, double price) {
        name = safeTrim(name);
        if (name.isEmpty()) return -1;
        if (packingUnits <= 0) packingUnits = 1;

        SQLiteDatabase db = getWritableDatabase();
        try { ensureSharedMasterSyncColumns(db); } catch (Exception ignored) {}
        ContentValues cv = new ContentValues();
        // ✅ 共享表也生成 cloud_id（改名不变；云端用 on_conflict=cloud_id 可精确对齐）
        cv.put("cloud_id", java.util.UUID.randomUUID().toString());
        cv.put("name", name);
        cv.put("packing_units", packingUnits);
        cv.put("price", price);
        cv.put("updated_at", nowIso8601());
        long r = db.insertWithOnConflict("products", null, cv, SQLiteDatabase.CONFLICT_IGNORE);
        if (r != -1) scheduleCloudPushSafe();
        return r;
    }

    public boolean deleteProductByName(String name) {
        name = safeTrim(name);
        if (name.isEmpty()) return false;
        SQLiteDatabase db = getWritableDatabase();
        // 先取 cloud_id（用于云端精确删除），再删本地
        String cloudId = "";
        try (Cursor c = db.rawQuery("SELECT cloud_id FROM products WHERE name=? LIMIT 1", new String[]{name})) {
            if (c.moveToFirst()) cloudId = nvl(c.getString(0));
        } catch (Exception ignored) {}

boolean ok = db.delete("products", "name=?", new String[]{name}) > 0;
if (ok) {
    // ✅ 本地删除 → 入队云端 DELETE
    try {
        JSONObject w = new JSONObject();
        String uid = AuthManager.getUserId(ctx);
        String orgId = AuthManager.getOrgId(ctx);
        w.put("owner_uid", uid);
        if (orgId != null && !orgId.trim().isEmpty()) w.put("org_id", orgId.trim());
        if (cloudId != null && !cloudId.trim().isEmpty()) {
            w.put("id", cloudId.trim());
        } else {
            w.put("org_id", orgId);
            w.put("name", name);
        }
        enqueueCloudDelete("products", w);
    } catch (Exception ignored) {}
    scheduleCloudPushSafe();
}
return ok;
    }

    public ProductInfo getProductInfoByName(String name) {
        name = safeTrim(name);
        if (name.isEmpty()) return null;
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT packing_units, price FROM products WHERE name=? LIMIT 1", new String[]{name})) {
            if (c.moveToFirst()) {
                int packing = c.getInt(0);
                double price = c.getDouble(1);
                return new ProductInfo(name, packing, price);
            }
        }
        return null;
    }

    public int updateProductByName(String oldName, String newName, int packingUnits, double price) {
        oldName = safeTrim(oldName);
        newName = safeTrim(newName);
        if (oldName.isEmpty() || newName.isEmpty()) return 0;
        if (packingUnits <= 0) packingUnits = 1;

        SQLiteDatabase db = getWritableDatabase();
        try { ensureSharedMasterSyncColumns(db); } catch (Exception ignored) {}
        ContentValues cv = new ContentValues();
        cv.put("name", newName);
        cv.put("packing_units", packingUnits);
        cv.put("price", price);
        cv.put("updated_at", nowIso8601());
        int n = db.update("products", cv, "name=?", new String[]{oldName});
        if (n > 0) scheduleCloudPushSafe();
        return n;
    }

    public double getProductPriceByName(String name) {
        ProductInfo info = getProductInfoByName(name);
        return info == null ? 0 : info.getPrice();
    }

    public int getProductPackingUnitsByName(String name) {
        ProductInfo info = getProductInfoByName(name);
        return info == null ? 1 : Math.max(1, info.getPackingUnits());
    }

    public List<String> getAllProductNames() {
        SQLiteDatabase db = getReadableDatabase();
        List<String> list = new ArrayList<>();
        try (Cursor c = db.rawQuery("SELECT name FROM products ORDER BY name COLLATE NOCASE", null)) {
            while (c.moveToNext()) {
                String v = c.getString(0);
                if (v != null && !v.trim().isEmpty()) list.add(v);
            }
        }
        return list;
    }

    /**
     * 最近使用产品（优先从 order_items 统计；若不存在则从 orders.product_name 统计）。
     */
    public List<String> getRecentProductNames(int limit) {
        if (limit <= 0) limit = 6;
        SQLiteDatabase db = getReadableDatabase();
        List<String> list = new ArrayList<>();
        try {
            String sqlItems = "SELECT product_name, MAX(COALESCE(updated_at, created_at)) AS mx " +
                    "FROM order_items " +
                    "WHERE (is_deleted=0 OR is_deleted IS NULL) " +
                    "GROUP BY product_name " +
                    "ORDER BY mx DESC LIMIT " + limit;
            try (Cursor c = db.rawQuery(sqlItems, null)) {
                while (c.moveToNext()) {
                    String v = c.getString(0);
                    if (v != null && !v.trim().isEmpty()) list.add(v);
                }
            }
        } catch (Exception ignored) {}

        if (!list.isEmpty()) return list;

        try {
            String sqlOrders = "SELECT product_name, MAX(COALESCE(updated_at, created_at)) AS mx " +
                    "FROM orders " +
                    "WHERE is_deleted=0 AND (status IS NULL OR status!='VOID') " +
                    "GROUP BY product_name " +
                    "ORDER BY mx DESC LIMIT " + limit;
            try (Cursor c = db.rawQuery(sqlOrders, null)) {
                while (c.moveToNext()) {
                    String v = c.getString(0);
                    if (v != null && !v.trim().isEmpty()) list.add(v);
                }
            }
        } catch (Exception ignored) {}
        return list;
    }

    public int adjustProductPricesBySeries(double delta, int series) {
        SQLiteDatabase db = getWritableDatabase();

        List<ProductInfo> all = new ArrayList<>();
        try (Cursor c = db.rawQuery("SELECT name, packing_units, price FROM products", null)) {
            while (c.moveToNext()) {
                String n = c.getString(0);
                int p = c.getInt(1);
                double pr = c.getDouble(2);
                all.add(new ProductInfo(n, p, pr));
            }
        }

        int affected = 0;
        for (ProductInfo info : all) {
            String n = info.getName() == null ? "" : info.getName();
            boolean isWater = n.contains("水培");
            boolean hasBracket = n.contains("(") || n.contains("（");

            boolean match;
            if (series == PRICE_SERIES_ALL) match = true;
            else if (series == PRICE_SERIES_SOIL) match = !isWater;
            else if (series == PRICE_SERIES_WATER) match = isWater && !hasBracket;
            else if (series == PRICE_SERIES_WATER_DOLL) match = isWater && hasBracket;
            else match = true;

            if (!match) continue;

            double newPrice = info.getPrice() + delta;
            if (newPrice < 0) newPrice = 0;
            ContentValues cv = new ContentValues();
            cv.put("price", newPrice);
            affected += db.update("products", cv, "name=?", new String[]{n});
        }
        if (affected > 0) scheduleCloudPushSafe();
        return affected;
    }

    
    /**
     * ✅ 仅更新 products.price，不改 packing_units；用于避免“新增订单临时改价”回写产品价。
     */
    public int setProductPriceOnly(String name, double price) {
        String n = safeTrim(name);
        if (n.isEmpty()) return 0;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("price", price);
        cv.put("updated_at", nowIso8601());
        int affected = 0;
        try {
            affected = db.update("products", cv, "TRIM(name)=?", new String[]{n});
            if (affected <= 0) {
                affected = db.update("products", cv, "name=?", new String[]{n});
            }
        } catch (Exception ignored) {}
        if (affected > 0) scheduleCloudPushSafe();
        return affected;
    }

private static final String CARTON_RULE_TEMPLATE_TYPE = "_carton_rules";
private static final String CARTON_RULE_TEMPLATE_NAME = "shared_rules";

public static class CartonRule {
    public final String productName;
    public final double len;
    public final double wid;
    public final double hei;
    public CartonRule(String productName, double len, double wid, double hei) {
        this.productName = productName == null ? "" : productName.trim();
        this.len = len;
        this.wid = wid;
        this.hei = hei;
    }
}

public static class CartonRuleGroup {
    public final double len;
    public final double wid;
    public final double hei;
    public final java.util.ArrayList<String> products = new java.util.ArrayList<>();
    public CartonRuleGroup(double len, double wid, double hei) {
        this.len = len;
        this.wid = wid;
        this.hei = hei;
    }
}

public static class ProductPiecesSummary {
    public final String productName;
    public final int totalPieces;
    public ProductPiecesSummary(String productName, int totalPieces) {
        this.productName = productName == null ? "" : productName.trim();
        this.totalPieces = totalPieces;
    }
}

private String normalizeCartonRuleProductName(String s) {
    s = safeTrim(s);
    if (s.isEmpty()) return "";
    s = s.replace("（", "(").replace("）", ")")
            .replace("【", "(").replace("】", ")")
            .replace("[", "(").replace("]", ")")
            .replaceAll("\\s+", "")
            .toLowerCase(java.util.Locale.ROOT);
    s = s.replace("水培", "").replace("土培", "").replace("精品", "");
    s = s.replaceAll("[-_/、,，;；:：]", "");
    s = s.replaceAll("\\(([^)]*)\\)", "$1");
    return s;
}

private String buildCartonRuleTemplateContent(java.util.List<CartonRule> rules) {
    org.json.JSONArray arr = new org.json.JSONArray();
    if (rules != null) {
        for (CartonRule r : rules) {
            if (r == null || safeTrim(r.productName).isEmpty()) continue;
            org.json.JSONObject o = new org.json.JSONObject();
            try {
                o.put("product_name", safeTrim(r.productName));
                o.put("len", r.len);
                o.put("wid", r.wid);
                o.put("hei", r.hei);
                arr.put(o);
            } catch (Exception ignored) {}
        }
    }
    org.json.JSONObject wrap = new org.json.JSONObject();
    try { wrap.put("rules", arr); } catch (Exception ignored) {}
    return wrap.toString();
}

private java.util.List<CartonRule> parseCartonRulesContent(String content) {
    java.util.ArrayList<CartonRule> list = new java.util.ArrayList<>();
    String s = safeTrim(content);
    if (s.isEmpty()) return list;
    try {
        org.json.JSONObject wrap = new org.json.JSONObject(s);
        org.json.JSONArray arr = wrap.optJSONArray("rules");
        if (arr == null) return list;
        for (int i = 0; i < arr.length(); i++) {
            org.json.JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String product = safeTrim(o.optString("product_name"));
            double len = o.optDouble("len", 0);
            double wid = o.optDouble("wid", 0);
            double hei = o.optDouble("hei", 0);
            if (!product.isEmpty() && len > 0 && wid > 0 && hei > 0) list.add(new CartonRule(product, len, wid, hei));
        }
    } catch (Exception ignored) {}
    return list;
}

private String getCartonRuleTemplateContent() {
    SQLiteDatabase db = getReadableDatabase();
    try (Cursor c = db.rawQuery("SELECT content FROM print_templates WHERE type=? AND name=? ORDER BY updated_at DESC, id DESC LIMIT 1", new String[]{CARTON_RULE_TEMPLATE_TYPE, CARTON_RULE_TEMPLATE_NAME})) {
        if (c.moveToFirst()) return nvl(c.getString(0));
    } catch (Exception ignored) {}
    return "";
}

private void saveCartonRuleTemplateContent(String content) {
    SQLiteDatabase db = getWritableDatabase();
    long now = System.currentTimeMillis();
    ContentValues cv = new ContentValues();
    cv.put("type", CARTON_RULE_TEMPLATE_TYPE);
    cv.put("name", CARTON_RULE_TEMPLATE_NAME);
    cv.put("content", nvl(content));
    cv.put("updated_at", now);
    cv.put("is_default", 0);
    try {
        int upd = db.update("print_templates", cv, "type=? AND name=?", new String[]{CARTON_RULE_TEMPLATE_TYPE, CARTON_RULE_TEMPLATE_NAME});
        if (upd <= 0) db.insert("print_templates", null, cv);
    } catch (Exception ignored) {}
    scheduleCloudPushSafe();
}

private void replaceLocalCartonRulesFromTemplate(java.util.List<CartonRule> rules) {
    SQLiteDatabase db = getWritableDatabase();
    db.beginTransaction();
    try {
        db.delete("carton_rules", null, null);
        if (rules != null) {
            for (CartonRule r : rules) {
                ContentValues cv = new ContentValues();
                cv.put("product_name", safeTrim(r.productName));
                cv.put("len", r.len);
                cv.put("wid", r.wid);
                cv.put("hei", r.hei);
                cv.put("updated_at", nowIso8601());
                db.insertWithOnConflict("carton_rules", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
            }
        }
        db.setTransactionSuccessful();
    } catch (Exception ignored) {
    } finally {
        try { db.endTransaction(); } catch (Exception ignored) {}
    }
}

private java.util.List<CartonRule> getLocalCartonRulesRaw() {
    java.util.ArrayList<CartonRule> list = new java.util.ArrayList<>();
    SQLiteDatabase db = getReadableDatabase();
    try (Cursor c = db.rawQuery("SELECT product_name,len,wid,hei FROM carton_rules ORDER BY product_name COLLATE NOCASE ASC", null)) {
        while (c.moveToNext()) list.add(new CartonRule(c.getString(0), c.getDouble(1), c.getDouble(2), c.getDouble(3)));
    } catch (Exception ignored) {}
    return list;
}

public java.util.List<CartonRule> getAllCartonRules() {
    java.util.List<CartonRule> fromTpl = parseCartonRulesContent(getCartonRuleTemplateContent());
    if (fromTpl != null && !fromTpl.isEmpty()) {
        replaceLocalCartonRulesFromTemplate(fromTpl);
        return fromTpl;
    }
    return getLocalCartonRulesRaw();
}

private void persistCartonRules(java.util.List<CartonRule> rules) {
    replaceLocalCartonRulesFromTemplate(rules);
    saveCartonRuleTemplateContent(buildCartonRuleTemplateContent(rules));
}

public boolean saveCartonRule(String productName, double len, double wid, double hei) {
    String name = safeTrim(productName);
    if (name.isEmpty() || len <= 0 || wid <= 0 || hei <= 0) return false;
    java.util.ArrayList<CartonRule> rules = new java.util.ArrayList<>(getAllCartonRules());
    boolean replaced = false;
    for (int i = 0; i < rules.size(); i++) {
        if (name.equals(safeTrim(rules.get(i).productName))) { rules.set(i, new CartonRule(name, len, wid, hei)); replaced = true; break; }
    }
    if (!replaced) rules.add(new CartonRule(name, len, wid, hei));
    persistCartonRules(rules);
    return true;
}

public int deleteCartonRule(String productName) {
    String name = safeTrim(productName);
    if (name.isEmpty()) return 0;
    java.util.ArrayList<CartonRule> rules = new java.util.ArrayList<>(getAllCartonRules());
    int before = rules.size();
    rules.removeIf(r -> name.equals(safeTrim(r.productName)));
    persistCartonRules(rules);
    return Math.max(0, before - rules.size());
}

public int deleteCartonRulesBySize(double len, double wid, double hei) {
    java.util.ArrayList<CartonRule> rules = new java.util.ArrayList<>(getAllCartonRules());
    int before = rules.size();
    rules.removeIf(r -> Math.abs(r.len - len) < 0.0001 && Math.abs(r.wid - wid) < 0.0001 && Math.abs(r.hei - hei) < 0.0001);
    persistCartonRules(rules);
    return Math.max(0, before - rules.size());
}

public java.util.List<CartonRuleGroup> getCartonRuleGroups() {
    java.util.LinkedHashMap<String, CartonRuleGroup> map = new java.util.LinkedHashMap<>();
    for (CartonRule r : getAllCartonRules()) {
        String key = String.format(java.util.Locale.getDefault(), "%.4f|%.4f|%.4f", r.len, r.wid, r.hei);
        CartonRuleGroup g = map.get(key);
        if (g == null) {
            g = new CartonRuleGroup(r.len, r.wid, r.hei);
            map.put(key, g);
        }
        g.products.add(r.productName);
    }
    return new java.util.ArrayList<>(map.values());
}

public boolean saveCartonRulesForSize(@androidx.annotation.Nullable CartonRuleGroup oldGroup, double len, double wid, double hei, java.util.List<String> products) {
    if (len <= 0 || wid <= 0 || hei <= 0 || products == null || products.isEmpty()) return false;
    java.util.ArrayList<CartonRule> rules = new java.util.ArrayList<>(getAllCartonRules());
    if (oldGroup != null) {
        rules.removeIf(r -> Math.abs(r.len - oldGroup.len) < 0.0001 && Math.abs(r.wid - oldGroup.wid) < 0.0001 && Math.abs(r.hei - oldGroup.hei) < 0.0001);
    }
    java.util.HashSet<String> selected = new java.util.HashSet<>();
    for (String p : products) {
        String n = safeTrim(p);
        if (!n.isEmpty()) selected.add(n);
    }
    rules.removeIf(r -> selected.contains(safeTrim(r.productName)));
    for (String p : selected) rules.add(new CartonRule(p, len, wid, hei));
    persistCartonRules(rules);
    return true;
}

public List<ProductPiecesSummary> getProductPiecesSummaryByDate(String date, String location) {
    java.util.LinkedHashMap<String, Integer> merged = new java.util.LinkedHashMap<>();
    java.util.HashSet<String> ordersCoveredByItems = new java.util.HashSet<>();
    SQLiteDatabase db = getReadableDatabase();
    date = safeTrim(date);
    String loc = safeTrim(location);
    if (date.isEmpty()) return new ArrayList<>();

    // 1) 优先统计 order_items（多品订单）
    Cursor c = null;
    try {
        String sql = "SELECT IFNULL(o.cloud_id,''), oi.product_name, IFNULL(SUM(oi.pieces),0) AS pcs " +
                "FROM order_items oi " +
                "JOIN orders o ON IFNULL(o.cloud_id,'') = IFNULL(oi.order_cloud_id,'') " +
                "WHERE IFNULL(oi.is_deleted,0)=0 AND IFNULL(o.is_deleted,0)=0 AND UPPER(COALESCE(o.status,'CONFIRMED'))!='VOID' " +
                "AND SUBSTR(IFNULL(o.date,''),1,10)=? ";
        java.util.ArrayList<String> args = new java.util.ArrayList<>();
        args.add(date);
        if (!loc.isEmpty() && !"全部".equals(loc)) {
            sql += "AND IFNULL(o.location,'')=? ";
            args.add(loc);
        }
        sql += "GROUP BY IFNULL(o.cloud_id,''), oi.product_name HAVING pcs>0";
        c = db.rawQuery(sql, args.toArray(new String[0]));
        while (c.moveToNext()) {
            String orderCid = safeTrim(c.getString(0));
            String name = safeTrim(c.getString(1));
            int pcs = c.getInt(2);
            if (!orderCid.isEmpty()) ordersCoveredByItems.add(orderCid);
            if (!name.isEmpty() && pcs > 0) merged.put(name, merged.getOrDefault(name, 0) + pcs);
        }
    } catch (Exception ignored) {
    } finally { if (c != null) try { c.close(); } catch (Exception ignored) {} }

    // 2) 回退统计 orders 主表：仅统计“没有 order_items 明细”的旧订单，避免重复累计
    try {
        String sql = "SELECT IFNULL(cloud_id,''), TRIM(COALESCE(NULLIF(product_name,''), NULLIF(product,''))) AS pname, IFNULL(SUM(pieces),0) AS pcs " +
                "FROM orders WHERE is_deleted=0 AND UPPER(COALESCE(status,'CONFIRMED'))!='VOID' AND SUBSTR(IFNULL(date,''),1,10)=? ";
        java.util.ArrayList<String> args = new java.util.ArrayList<>();
        args.add(date);
        if (!loc.isEmpty() && !"全部".equals(loc)) {
            sql += "AND IFNULL(location,'')=? ";
            args.add(loc);
        }
        sql += "AND TRIM(COALESCE(NULLIF(product_name,''), NULLIF(product,''), ''))<>'' GROUP BY IFNULL(cloud_id,''), TRIM(COALESCE(NULLIF(product_name,''), NULLIF(product,''))) HAVING pcs>0";
        c = db.rawQuery(sql, args.toArray(new String[0]));
        while (c.moveToNext()) {
            String orderCid = safeTrim(c.getString(0));
            if (!orderCid.isEmpty() && ordersCoveredByItems.contains(orderCid)) continue;
            String name = safeTrim(c.getString(1));
            int pcs = c.getInt(2);
            if (!name.isEmpty() && pcs > 0) merged.put(name, merged.getOrDefault(name, 0) + pcs);
        }
    } catch (Exception ignored) {
    } finally { if (c != null) try { c.close(); } catch (Exception ignored) {} }

    java.util.ArrayList<ProductPiecesSummary> list = new java.util.ArrayList<>();
    for (java.util.Map.Entry<String, Integer> e : merged.entrySet()) {
        list.add(new ProductPiecesSummary(e.getKey(), e.getValue()));
    }
    list.sort((a, b) -> {
        int r = Integer.compare(b.totalPieces, a.totalPieces);
        if (r != 0) return r;
        return a.productName.compareToIgnoreCase(b.productName);
    });
    return list;
}

public List<LogisticsSize> buildAutoCartonSizesForDate(String date, String location) {
    List<LogisticsSize> out = new ArrayList<>();
    List<ProductPiecesSummary> products = getProductPiecesSummaryByDate(date, location);
    if (products == null || products.isEmpty()) return out;
    Map<String, int[]> merged = new HashMap<>();
    Map<String, Double> lenMap = new HashMap<>();
    Map<String, Double> widMap = new HashMap<>();
    Map<String, Double> heiMap = new HashMap<>();
    List<CartonRule> allRules = getAllCartonRules();
    if (allRules == null || allRules.isEmpty()) return out;
    for (ProductPiecesSummary p : products) {
        if (p.totalPieces <= 0) continue;
        String pn = normalizeCartonRuleProductName(p.productName);
        CartonRule best = null;
        int bestScore = -1;
        for (CartonRule r : allRules) {
            if (r == null || safeTrim(r.productName).isEmpty()) continue;
            String rn = normalizeCartonRuleProductName(r.productName);
            int score = -1;
            if (pn.equals(rn)) {
                score = 100;
            } else if (!pn.isEmpty() && !rn.isEmpty() && (pn.contains(rn) || rn.contains(pn))) {
                score = 80;
            } else {
                // 只允许“主干名 + 括号别名”较强匹配，避免把 110钻石/110圆杯 等误判进 110地球/110葫芦 规则
                String pnBase = pn.replaceAll("[（(].*?[)）]", "");
                String rnBase = rn.replaceAll("[（(].*?[)）]", "");
                String pnAlias = "";
                String rnAlias = "";
                java.util.regex.Matcher mp = java.util.regex.Pattern.compile("[（(](.*?)[)）]").matcher(pn);
                if (mp.find()) pnAlias = safeTrim(mp.group(1));
                java.util.regex.Matcher mr = java.util.regex.Pattern.compile("[（(](.*?)[)）]").matcher(rn);
                if (mr.find()) rnAlias = safeTrim(mr.group(1));
                if (!pnBase.isEmpty() && pnBase.equals(rnBase)) {
                    if (!pnAlias.isEmpty() && !rnAlias.isEmpty() && pnAlias.equals(rnAlias)) score = 95;
                    else if (pnAlias.isEmpty() || rnAlias.isEmpty()) score = 70;
                }
            }
            if (score > bestScore) { bestScore = score; best = r; }
        }
        if (best == null || bestScore < 70) continue;
        String key = String.format(Locale.getDefault(), "%.0f×%.0f×%.0f", best.len, best.wid, best.hei);
        int[] holder = merged.get(key);
        if (holder == null) {
            holder = new int[]{0};
            merged.put(key, holder);
            lenMap.put(key, best.len);
            widMap.put(key, best.wid);
            heiMap.put(key, best.hei);
        }
        holder[0] += p.totalPieces;
    }
    for (Map.Entry<String, int[]> e : merged.entrySet()) {
        String key = e.getKey();
        int pcs = e.getValue()[0];
        double len = lenMap.get(key);
        double wid = widMap.get(key);
        double hei = heiMap.get(key);
        double cbm = (len * wid * hei / 1000000.0) * pcs;
        out.add(new LogisticsSize(0, 0, len, wid, hei, pcs, cbm));
    }
    return out;
}

// ---------- ORDER ----------

    public long addOrder(Order o) {
        if (o == null) return -1;
        SQLiteDatabase db = getWritableDatabase();

        // ✅ P0：云端 orders.cloud_id 为 NOT NULL，用于幂等去重（on_conflict=cloud_id）
        // 本地新增订单时必须立刻生成 cloud_id，避免云端 23502 (null cloud_id)
        String cid = java.util.UUID.randomUUID().toString();

        ContentValues cv = new ContentValues();
        cv.put("date", safeTrim(o.getDate()));
        cv.put("customer_name", safeTrim(o.getCustomerName()));
        cv.put("product_name", safeTrim(o.getProductName()));
        cv.put("pieces", Math.max(0, o.getPieces()));
        cv.put("quantity", Math.max(0, o.getQuantity()));
        cv.put("price", o.getPrice());
        cv.put("location", safeTrim(o.getLocation()));
        cv.put("remark", safeTrim(o.getRemark()));
        cv.put("status", ORDER_STATUS_CONFIRMED);
        cv.put("printed", 0);
        cv.put("printed_at", (String) null);
        cv.put("shipped_at", (String) null);
        cv.put("settled_at", (String) null);
        cv.put("is_deleted", 0);
        cv.put("deleted_at", (String) null);
        cv.put("cloud_delete_tracked", 0);
        cv.put("voided_at", (String) null);
        cv.put("total_quantity", Math.max(0, o.getQuantity()));
        cv.put("total_amount", Math.max(0, o.getQuantity()) * o.getPrice());
        cv.put("cloud_id", cid);
        String nowIso = nowIso8601();
        cv.put("created_at", nowIso);
        cv.put("updated_at", nowIso);
        cv.put("synced", 0);

        long r = db.insert("orders", null, cv);
        if (r != -1) scheduleCloudPushSafe();
        return r;
    }


    /**
     * 删除订单时需要在删除前取出关键字段，用于构造云端 DELETE where。
     * 返回：{date, customer, product, location, priceStr}
     */
    private String[] getOrderDeleteInfoById(int id) {
        if (id <= 0) return null;
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = null;
        try {
            c = db.rawQuery(
                    "SELECT date, customer_name, product_name, IFNULL(location,''), price FROM orders WHERE id=? LIMIT 1",
                    new String[]{String.valueOf(id)}
            );
            if (c.moveToFirst()) {
                String date = c.getString(0);
                String customer = c.getString(1);
                String product = c.getString(2);
                String location = c.getString(3);
                double price = c.getDouble(4);
                return new String[]{date, customer, product, location, String.valueOf(price)};
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) try { c.close(); } catch (Exception ignore) {}
        }
        return null;
    }
    private String getOrderCloudIdByLocalId(int id) {
        if (id <= 0) return null;
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = null;
        try {
            c = db.rawQuery("SELECT cloud_id FROM orders WHERE id=? LIMIT 1", new String[]{String.valueOf(id)});
            if (c != null && c.moveToFirst()) {
                String cid = c.getString(0);
                if (cid != null) cid = cid.trim();
                return (cid != null && cid.length() > 0) ? cid : null;
            }
        } catch (Exception ignored) {
        } finally {
            try { if (c != null) c.close(); } catch (Exception ignored) {}
        }
        return null;
    }


    public int deleteOrderById(int id) {
        if (id <= 0) return 0;

        SQLiteDatabase db = getWritableDatabase();

        // Step2稳定性：本地不物理删除，改为“作废/软删除”，避免重装/多设备后云端回拉复活
        // 同时：为满足“精确删除云端订单”的需求，额外入队 cloud_delete_queue，
        // 让 SupabaseSyncManager.processCloudDeletes() 使用 cloud_id 精确 DELETE（并连带删除 order_items）。
        String orderCloudId = null;
        try { orderCloudId = getOrderCloudIdByLocalId(id); } catch (Exception ignored) {}

        String now = nowIso8601();

        int rows = 0;
        db.beginTransaction();
        try {
            // 1) 软删除订单（本地）
            ContentValues cv = new ContentValues();
            cv.put("status", ORDER_STATUS_VOID);
            cv.put("is_deleted", 1);
            cv.put("deleted_at", now);
            cv.put("cloud_delete_tracked", 0);
            cv.put("voided_at", now);
            cv.put("updated_at", now);

            // ★关键：这里不要把 deleted 订单再推送 upsert，否则会把云端删掉的订单又“复活”
            cv.put("synced", 1);

            rows = db.update("orders", cv, "id=?", new String[]{String.valueOf(id)});

            // 2) 软删除该订单的明细（本地）
            if (orderCloudId != null && orderCloudId.trim().length() > 0) {
                ContentValues iv = new ContentValues();
                iv.put("is_deleted", 1);
                iv.put("deleted_at", now);
                iv.put("updated_at", now);
                iv.put("synced", 1); // 同理：避免 upsert 复活
                db.update("order_items", iv, "order_cloud_id=?", new String[]{orderCloudId.trim()});
            }

            // 3) 入队云端精确 DELETE
            // 优先使用 cloud_id 精确删除 orders；并删除该 order_cloud_id 下所有 order_items
            if (orderCloudId != null && orderCloudId.trim().length() > 0) {
                try {
                    JSONObject w1 = new JSONObject();
                    w1.put("cloud_id", orderCloudId.trim());
                    enqueueCloudDelete("orders", w1);

                    JSONObject w2 = new JSONObject();
                    w2.put("order_cloud_id", orderCloudId.trim());
                    enqueueCloudDelete("order_items", w2);

                    ContentValues mark = new ContentValues();
                    mark.put("cloud_delete_tracked", 1);
                    db.update("orders", mark, "id=?", new String[]{String.valueOf(id)});
                } catch (Exception ignored) {}
            } else {
                // 兜底：如果本地订单没有 cloud_id，就走旧版组合字段 where（可能不精确）
                try {
                    String[] info = getOrderDeleteInfoById(id);
                    if (info != null && info.length >= 5) {
                        String date = info[0];
                        String customer = info[1];
                        String product = info[2];
                        String location = info[3];
                        double price = 0;
                        try { price = Double.parseDouble(info[4]); } catch (Exception ignore) {}
                        enqueueCloudDelete("orders", buildWhereJsonForOrderDelete(date, customer, product, location, price));
                    }
                } catch (Exception ignored) {}
            }

            db.setTransactionSuccessful();
        } catch (Exception ignored) {
        } finally {
            try { db.endTransaction(); } catch (Exception ignored) {}
        }

        scheduleCloudPushSafe(); // 触发 processCloudDeletes
        return rows;
    }


    public int deleteOrderGroup(String date, String customer, String product, String location, double price) {
        // Step2：组删除同样改为作废
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("status", "VOID");
        cv.put("is_deleted", 1);
        cv.put("deleted_at", nowIso8601());
        cv.put("cloud_delete_tracked", 0);
        cv.put("voided_at", nowIso8601());
        cv.put("updated_at", nowIso8601());
        cv.put("synced", 0);
        int n = db.update("orders",
                cv,
                "date=? AND customer_name=? AND product_name=? AND IFNULL(location,'')=? AND price=?",
                new String[]{safeTrim(date), safeTrim(customer), safeTrim(product), safeTrim(location), String.valueOf(price)});
        if (n > 0) scheduleCloudPushSafe();
        return n;
    }

    public int updateOrderById(int id, int pieces, int qty, String location, double price, String remark) {
        if (id <= 0) return 0;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("pieces", Math.max(0, pieces));
        cv.put("quantity", Math.max(0, qty));
        cv.put("location", safeTrim(location));
        cv.put("price", price);
        cv.put("remark", safeTrim(remark));
        cv.put("status", ORDER_STATUS_CONFIRMED);
        cv.put("printed", 0);
        cv.put("printed_at", (String) null);
        cv.put("shipped_at", (String) null);
        cv.put("settled_at", (String) null);
        cv.put("is_deleted", 0);
        cv.put("deleted_at", (String) null);
        cv.put("cloud_delete_tracked", 0);
        cv.put("voided_at", (String) null);
        cv.put("total_quantity", Math.max(0, qty));
        cv.put("total_amount", Math.max(0, qty) * price);
        cv.put("updated_at", nowIso8601());
        cv.put("synced", 0); // P0-3: 修改订单后标记待同步
        int n = db.update("orders", cv, "id=?", new String[]{String.valueOf(id)});
        if (n > 0) scheduleCloudPushSafe();
        return n;
    }

    public int updateOrderGroup(String date, String customer, String product, String location, double price,
                                int pieces, int qty, String newLocation, double newPrice, String remark) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("pieces", Math.max(0, pieces));
        cv.put("quantity", Math.max(0, qty));
        cv.put("location", safeTrim(newLocation));
        cv.put("price", newPrice);
        cv.put("remark", safeTrim(remark));
        cv.put("status", ORDER_STATUS_CONFIRMED);
        cv.put("printed", 0);
        cv.put("printed_at", (String) null);
        cv.put("shipped_at", (String) null);
        cv.put("settled_at", (String) null);
        cv.put("is_deleted", 0);
        cv.put("deleted_at", (String) null);
        cv.put("voided_at", (String) null);
        cv.put("total_quantity", Math.max(0, qty));
        cv.put("total_amount", Math.max(0, qty) * newPrice);
        cv.put("updated_at", nowIso8601());
        cv.put("synced", 0); // P0-3: 批量修改订单后标记待同步
        return db.update("orders", cv,
                "date=? AND customer_name=? AND product_name=? AND IFNULL(location,'')=? AND price=?",
                new String[]{safeTrim(date), safeTrim(customer), safeTrim(product), safeTrim(location), String.valueOf(price)});
    }

    public List<Order> getOrdersByDate(String date) {
        SQLiteDatabase db = getReadableDatabase();
        return queryOrders(db, "SUBSTR(IFNULL(date,''),1,10)=?", new String[]{safeTrim(date)});
    }

    public List<Order> getPendingLabelOrdersByDate(String date) {
        SQLiteDatabase db = getReadableDatabase();
        return queryOrders(db, "SUBSTR(IFNULL(date,''),1,10)=? AND COALESCE(printed,0)=0", new String[]{safeTrim(date)});
    }

    public int markPendingLabelOrdersPrintedByDate(String date) {
        SQLiteDatabase db = getWritableDatabase();
        android.content.ContentValues cv = new android.content.ContentValues();
        cv.put("printed", 1);
        cv.put("printed_at", new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US).format(new java.util.Date()));
        cv.put("status", ORDER_STATUS_PRINTED);
        cv.put("updated_at", new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US).format(new java.util.Date()));
        return db.update("orders", cv, "SUBSTR(IFNULL(date,''),1,10)=? AND COALESCE(printed,0)=0 AND IFNULL(is_deleted,0)=0 AND UPPER(COALESCE(status,'CONFIRMED'))!='VOID'", new String[]{safeTrim(date)});
    }

    public int markOrdersPrintedByIds(java.util.List<Long> ids) {
        if (ids == null || ids.isEmpty()) return 0;
        java.util.ArrayList<String> valid = new java.util.ArrayList<>();
        for (Long id : ids) {
            if (id != null && id.longValue() > 0L) valid.add(String.valueOf(id.longValue()));
        }
        if (valid.isEmpty()) return 0;
        SQLiteDatabase db = getWritableDatabase();
        android.content.ContentValues cv = new android.content.ContentValues();
        String now = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US).format(new java.util.Date());
        cv.put("printed", 1);
        cv.put("printed_at", now);
        cv.put("status", ORDER_STATUS_PRINTED);
        cv.put("updated_at", now);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < valid.size(); i++) {
            if (i > 0) sb.append(',');
            sb.append('?');
        }
        return db.update("orders", cv,
                "id IN (" + sb + ") AND IFNULL(is_deleted,0)=0 AND UPPER(COALESCE(status,'CONFIRMED'))!='VOID'",
                valid.toArray(new String[0]));
    }

    public List<Order> getOrdersByDateAndCustomer(String date, String customer) {
        SQLiteDatabase db = getReadableDatabase();
        return queryOrders(db, "SUBSTR(IFNULL(date,''),1,10)=? AND customer_name=?", new String[]{safeTrim(date), safeTrim(customer)});
    }

    public List<Order> getMergedOrdersByDate(String date) {
        // 简化：当前版本按原始订单返回
        return getOrdersByDate(date);
    }

    public List<Order> getOrdersByDateFiltered(String date, String customer, String location) {
        SQLiteDatabase db = getReadableDatabase();
        String where = "SUBSTR(IFNULL(date,''),1,10)=?";
        List<String> args = new ArrayList<>();
        args.add(safeTrim(date));
        // ✅ 兼容 UI 的“全部”选项：传入“全部”时不作为筛选条件
        if (customer != null) {
            String c = customer.trim();
            if (!c.isEmpty() && !"全部".equals(c)) {
                where += " AND TRIM(IFNULL(customer_name,''))=?";
                args.add(c);
            }
        }
        if (location != null) {
            String loc = location.trim();
            if (!loc.isEmpty() && !"全部".equals(loc)) {
                where += " AND IFNULL(location,'')=?";
                args.add(loc);
            }
        }
        return queryOrders(db, where, args.toArray(new String[0]));
    }

    public List<Order> getMergedOrdersByDateFiltered(String date, String customer, String location) {
        // 简化：当前版本按原始订单返回
        return getOrdersByDateFiltered(date, customer, location);
    }

    public int getMaxOrderId() {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT IFNULL(MAX(id),0) FROM orders", null)) {
            if (c.moveToFirst()) return c.getInt(0);
        }
        return 0;
    }

    private List<Order> queryOrders(SQLiteDatabase db, String where, String[] args) {
        List<Order> list = new ArrayList<>();
        // Step2：默认只展示“未作废/未删除”的订单
        String active = "(IFNULL(is_deleted,0)=0 AND UPPER(COALESCE(status,'CONFIRMED'))!='VOID')";

        String sql = "SELECT id,date,TRIM(IFNULL(customer_name,'')) AS c, TRIM(IFNULL(product_name,'')) AS p,pieces,quantity,price,location,remark,created_at FROM orders";
        if (where != null && !where.trim().isEmpty()) {
            sql += " WHERE (" + where + ") AND " + active;
        } else {
            sql += " WHERE " + active;
        }
        sql += " ORDER BY CASE WHEN created_at IS NULL OR TRIM(created_at)='' THEN 1 ELSE 0 END, datetime(created_at) DESC, id DESC";

        try (Cursor c = db.rawQuery(sql, args)) {
            while (c.moveToNext()) {
                Order o = new Order();
                o.setId(c.getInt(0));
                o.setDate(nvl(c.getString(1)));
                o.setCustomerName(nvl(c.getString(2)));
                o.setProductName(nvl(c.getString(3)));
                o.setPieces(c.getInt(4));
                o.setQuantity(c.getInt(5));
                o.setPrice(c.getDouble(6));
                o.setLocation(nvl(c.getString(7)));
                o.setRemark(nvl(c.getString(8)));
                o.setCreatedAt(nvl(c.getString(9)));
                list.add(o);
            }
        }
        return list;
    }

    // ---------- LOGISTICS（保持编译：非本次需求范围，先占位） ----------

    
public long addLogisticsForm(LogisticsForm f, List<LogisticsSize> sizes) {
    if (f == null) return -1;

    SQLiteDatabase db = null;
    long newId = -1;

    try {
        db = getWritableDatabase();
        // ✅ 事务必须与 setTransactionSuccessful/endTransaction 成对使用
        db.beginTransaction();

        ContentValues cv = new ContentValues();
        cv.put("date", nvl(f.getDate()));
        cv.put("location", nvl(f.getLocation()));
        cv.put("total_pieces", f.getTotalPieces());
        cv.put("total_cbm", f.getTotalCbm());
        cv.put("remark", nvl(f.getRemark()));
        // ✅ 有编辑就重新标记为待同步
        cv.put("synced", 0);

        // ✅ 本地新建物流单：生成云端主键（uuid），并标记为待同步
        // 说明：之前用 (uid|localId) 生成稳定 uuid，会导致“卸载重装后 localId 变化 → 又生成新 uuid → 云端重复两条”
        cv.put("cloud_id", java.util.UUID.randomUUID().toString());
        cv.put("synced", 0);

        newId = db.insert("logistics_forms", null, cv);
        if (newId <= 0) {
            throw new IllegalStateException("insert logistics_forms failed");
        }

        // 明细（尺寸/件数）
        if (sizes != null) {
            for (LogisticsSize s : sizes) {
                if (s == null) continue;
                ContentValues sv = new ContentValues();
                sv.put("logistics_id", newId);
                sv.put("len", s.getLen());
                sv.put("wid", s.getWid());
                sv.put("hei", s.getHei());
                sv.put("pieces", s.getPieces());
                sv.put("cbm", s.getCbm());
                db.insert("logistics_sizes", null, sv);
            }
        }

        db.setTransactionSuccessful();
        return newId;

    } catch (Throwable t) {
        Log.e("DatabaseHelper", "addLogisticsForm failed", t);
        return -1;

    } finally {
        // ✅ 防止“没有事务却 endTransaction”导致崩溃
        if (db != null) {
            try {
                if (db.inTransaction()) {
                    db.endTransaction();
                }
            } catch (Throwable ignore) {}
        }
    }
}



public boolean updateLogisticsForm(long id, LogisticsForm f, List<LogisticsSize> sizes) {
    if (id <= 0 || f == null) return false;
    SQLiteDatabase db = getWritableDatabase();
    db.beginTransaction();
    try {
        ContentValues cv = new ContentValues();
        cv.put("date", nvl(f.getDate()));
        cv.put("location", nvl(f.getLocation()));
        cv.put("total_pieces", f.getTotalPieces());
        cv.put("total_cbm", f.getTotalCbm());
        cv.put("remark", nvl(f.getRemark()));
        // ✅ 有修改就重新标记为待同步（走 upsert）
        cv.put("synced", 0);
        int rows = db.update("logistics_forms", cv, "id=?", new String[]{String.valueOf(id)});
        if (rows <= 0) {
            return false;
        }
        // replace sizes
        // ✅ 云端幂等：编辑物流单后本地会删除并重插尺寸，导致每次同步云端产生不同 id 进而累计重复。
        // 处理方式：保存时先入队一个云端删除(logistics_sizes)动作，下一次同步会先删云端尺寸，再上传新的尺寸。
        try {
            String __tenantId = null;
            String __formCloudId = null;
            android.database.Cursor __c0 = null;
            try {
                __c0 = db.rawQuery("SELECT tenant_id, cloud_id FROM logistics_forms WHERE id=?", new String[]{String.valueOf(id)});
                if (__c0 != null && __c0.moveToFirst()) {
                    __tenantId = nvl(__c0.getString(0));
                    __formCloudId = nvl(__c0.getString(1));
                }
            } finally {
                if (__c0 != null) __c0.close();
            }
            if (__tenantId.length() > 0 && __formCloudId.length() > 0) {
                enqueueCloudDelete("logistics_sizes", buildWhereJsonForLogisticsSizesDelete(__tenantId, __formCloudId));
            }
        } catch (Exception ignored) {}

        db.delete("logistics_sizes", "logistics_id=?", new String[]{String.valueOf(id)});
        if (sizes != null) {
            for (LogisticsSize s : sizes) {
                if (s == null) continue;
                ContentValues sv = new ContentValues();
                sv.put("logistics_id", id);
                sv.put("len", s.getLen());
                sv.put("wid", s.getWid());
                sv.put("hei", s.getHei());
                sv.put("pieces", s.getPieces());
                sv.put("cbm", s.getCbm());
                db.insert("logistics_sizes", null, sv);
            }
        }
        db.setTransactionSuccessful();
        return true;
    } catch (Exception e) {
        return false;
    } finally {
        try {
            if (db != null && db.inTransaction()) db.endTransaction();
        } catch (Throwable ignore) {}
    }
}



public LogisticsForm getLogisticsFormById(long id) {
    if (id <= 0) return null;
    SQLiteDatabase db = getReadableDatabase();
    Cursor c = null;
    try {
        c = db.rawQuery("SELECT id,date,location,total_pieces,total_cbm,remark FROM logistics_forms WHERE id=?",
                new String[]{String.valueOf(id)});
        if (c.moveToFirst()) {
            return new LogisticsForm(
                    c.getLong(0),
                    nvl(c.getString(1)),
                    nvl(c.getString(2)),
                    c.getInt(3),
                    c.getDouble(4),
                    nvl(c.getString(5))
            );
        }
    } catch (Exception ignored) {
    } finally {
        if (c != null) c.close();
    }
    return null;
}



public List<LogisticsSize> getLogisticsSizes(long logisticsId) {
    List<LogisticsSize> list = new ArrayList<>();
    if (logisticsId <= 0) return list;
    SQLiteDatabase db = getReadableDatabase();
    Cursor c = null;
    try {
        c = db.rawQuery("SELECT id,logistics_id,len,wid,hei,pieces,cbm FROM logistics_sizes WHERE logistics_id=? ORDER BY id ASC",
                new String[]{String.valueOf(logisticsId)});
        while (c.moveToNext()) {
            LogisticsSize s = new LogisticsSize(
                    c.getLong(0),
                    c.getLong(1),
                    c.getDouble(2),
                    c.getDouble(3),
                    c.getDouble(4),
                    c.getInt(5),
                    c.getDouble(6)
            );
            list.add(s);
        }
    } catch (Exception ignored) {
    } finally {
        if (c != null) c.close();
    }
    return list;
}

/**
 * ✅ 方案A1：纸箱只由“物流单”扣减。
 * 我们在【新增物流单成功落库】时自动扣减一次，避免用户忘记点其它按钮导致库存不变。
 *
 * 规则：
 * - 每一条 logistics_sizes 视为一种纸箱尺寸：len*wid*hei
 * - pieces 视为该尺寸纸箱数量
 * - inventory_items 里用 type=CARTON，name=如 "53*44*45" 作为主键（同名自动建档）
 * - 同一张物流单只扣减一次：logistics_forms.carton_deducted=1
 */
public void ensureLogisticsCartonDeducted(long logisticsId) {
    if (logisticsId <= 0) return;
    SQLiteDatabase db = getWritableDatabase();

    // 读取标记：已扣减则直接返回
    int already = 0;
    try (Cursor c = db.rawQuery("SELECT COALESCE(carton_deducted,0) FROM logistics_forms WHERE id=? LIMIT 1",
            new String[]{String.valueOf(logisticsId)})) {
        if (c.moveToFirst()) already = c.getInt(0);
    } catch (Exception ignored) {}
    if (already == 1) return;

    db.beginTransaction();
    try {
        // 再查一次（事务内防并发重复扣减）
        int again = 0;
        try (Cursor c = db.rawQuery("SELECT COALESCE(carton_deducted,0) FROM logistics_forms WHERE id=? LIMIT 1",
                new String[]{String.valueOf(logisticsId)})) {
            if (c.moveToFirst()) again = c.getInt(0);
        } catch (Exception ignored) {}
        if (again == 1) {
            db.setTransactionSuccessful();
            return;
        }

        Cursor c = null;
        try {
            c = db.rawQuery("SELECT len,wid,hei,pieces FROM logistics_sizes WHERE logistics_id=?",
                    new String[]{String.valueOf(logisticsId)});
            while (c.moveToNext()) {
                double len = c.getDouble(0);
                double wid = c.getDouble(1);
                double hei = c.getDouble(2);
                int pieces = c.getInt(3);
                if (pieces <= 0) continue;

                String cartonName = formatCartonSize(len, wid, hei);
                if (cartonName.isEmpty()) continue;

                long cartonItemId = findOrCreateCartonItemId(db, cartonName);
                adjustInventory(cartonItemId, -pieces, "物流单出库(纸箱)", "LOGISTICS", (int) logisticsId);
            }
        } finally {
            if (c != null) try { c.close(); } catch (Exception ignore) {}
        }

        // 写入标记
        try {
            ContentValues cv = new ContentValues();
            cv.put("carton_deducted", 1);
            cv.put("synced", 0); // 物流单字段变化，触发云端同步
            db.update("logistics_forms", cv, "id=?", new String[]{String.valueOf(logisticsId)});
        } catch (Exception ignored) {}

        db.setTransactionSuccessful();
    } catch (Exception e) {
        // ignore
    } finally {
        try { if (db.inTransaction()) db.endTransaction(); } catch (Exception ignored) {}
    }

    scheduleCloudPushSafe();
}

/** 删除物流单时，如果曾经扣减过纸箱，则先把纸箱库存加回去，避免误删导致库存永久减少。 */
private void rollbackLogisticsCartonIfNeeded(SQLiteDatabase db, long logisticsId) {
    if (db == null || logisticsId <= 0) return;
    int deducted = 0;
    try (Cursor c = db.rawQuery("SELECT COALESCE(carton_deducted,0) FROM logistics_forms WHERE id=? LIMIT 1",
            new String[]{String.valueOf(logisticsId)})) {
        if (c.moveToFirst()) deducted = c.getInt(0);
    } catch (Exception ignored) {}
    if (deducted != 1) return;

    Cursor c = null;
    try {
        c = db.rawQuery("SELECT len,wid,hei,pieces FROM logistics_sizes WHERE logistics_id=?",
                new String[]{String.valueOf(logisticsId)});
        while (c.moveToNext()) {
            double len = c.getDouble(0);
            double wid = c.getDouble(1);
            double hei = c.getDouble(2);
            int pieces = c.getInt(3);
            if (pieces <= 0) continue;

            String cartonName = formatCartonSize(len, wid, hei);
            if (cartonName.isEmpty()) continue;

            long cartonItemId = findOrCreateCartonItemId(db, cartonName);
            adjustInventory(cartonItemId, +pieces, "删除物流单回滚(纸箱)", "LOGISTICS_DEL", (int) logisticsId);
        }
    } catch (Exception ignored) {
    } finally {
        if (c != null) try { c.close(); } catch (Exception ignore) {}
    }
}

private static String formatCartonSize(double len, double wid, double hei) {
    // 统一使用用户界面里更常见的 “×” 符号，避免与库存项名称不一致
    return fmtDim(len) + "×" + fmtDim(wid) + "×" + fmtDim(hei);
}

private static String fmtDim(double v) {
    // 尽量输出用户习惯的 “53” 而不是 “53.0”
    long r = Math.round(v);
    if (Math.abs(v - r) < 1e-6) return String.valueOf(r);
    // 保留 1 位小数，去尾 0
    String s = String.format(java.util.Locale.US, "%.1f", v);
    if (s.endsWith(".0")) s = s.substring(0, s.length() - 2);
    return s;
}

    /**
     * 纸箱库存项名称在历史版本里可能用 "*", "x", "×" 三种符号。
     * 为避免“扣错对象 / 生成重复库存项”，这里做一次规范化匹配：
     * - 先尝试用不同符号在 inventory_items(type=CARTON) 中查找已存在条目
     * - 找到则复用；找不到再用当前规范名称（含 ×）创建
     */
    private long findOrCreateCartonItemId(SQLiteDatabase db, String cartonName) {
        if (db == null) db = getWritableDatabase();
        String n = cartonName == null ? "" : cartonName.trim();
        if (n.isEmpty()) return -1;

        String nStar = n.replace('×', '*').replace('x', '*').replace('X', '*');
        String nCross = n.replace('*', '×').replace('x', '×').replace('X', '×');
        String nLowerX = n.replace('*', 'x').replace('×', 'x').replace('X', 'x');

        // 1) 先查已存在
        try (Cursor c = db.rawQuery(
                "SELECT id,name FROM inventory_items WHERE type=? AND (name=? OR name=? OR name=?) LIMIT 1",
                new String[]{String.valueOf(INV_TYPE_CARTON), n, nStar, nCross})) {
            if (c != null && c.moveToFirst()) {
                return c.getLong(0);
            }
        } catch (Exception ignored) {}

        try (Cursor c = db.rawQuery(
                "SELECT id,name FROM inventory_items WHERE type=? AND name=? LIMIT 1",
                new String[]{String.valueOf(INV_TYPE_CARTON), nLowerX})) {
            if (c != null && c.moveToFirst()) {
                return c.getLong(0);
            }
        } catch (Exception ignored) {}

        // 2) 找不到则创建（用规范化后的 × 名称）
        return getOrCreateInventoryItemId(INV_TYPE_CARTON, nCross);
    }



public List<LogisticsForm> getAllLogisticsForms() {
    List<LogisticsForm> list = new ArrayList<>();
    SQLiteDatabase db = getReadableDatabase();
    Cursor c = null;
    try {
        c = db.rawQuery("SELECT id,date,location,total_pieces,total_cbm,remark FROM logistics_forms ORDER BY id DESC", null);
        while (c.moveToNext()) {
            LogisticsForm f = new LogisticsForm(
                    c.getLong(0),
                    nvl(c.getString(1)),
                    nvl(c.getString(2)),
                    c.getInt(3),
                    c.getDouble(4),
                    nvl(c.getString(5))
            );
            list.add(f);
        }
    } catch (Exception ignored) {
    } finally {
        if (c != null) c.close();
    }
    return list;
}


public List<LogisticsForm> getLogisticsFormsByDate(String d) {
    List<LogisticsForm> list = new ArrayList<>();
    d = safeTrim(d);
    if (d.isEmpty()) return list;
    SQLiteDatabase db = getReadableDatabase();
    Cursor c = null;
    try {
        c = db.rawQuery("SELECT id,date,location,total_pieces,total_cbm,remark FROM logistics_forms WHERE date=? ORDER BY id DESC",
                new String[]{d});
        while (c.moveToNext()) {
            LogisticsForm f = new LogisticsForm(
                    c.getLong(0),
                    nvl(c.getString(1)),
                    nvl(c.getString(2)),
                    c.getInt(3),
                    c.getDouble(4),
                    nvl(c.getString(5))
            );
            list.add(f);
        }
    } catch (Exception ignored) {
    } finally {
        if (c != null) c.close();
    }
    return list;
}

/**
 * 获取某月累计方数（合计 logistics_forms.total_cbm）
 * @param yearMonth "yyyy-MM"，例如 "2026-01"
 */
public double getMonthlyTotalCbm(String yearMonth) {
    yearMonth = yearMonth == null ? "" : yearMonth.trim();
    if (yearMonth.length() < 7) return 0;
    SQLiteDatabase db = getReadableDatabase();
    String like = yearMonth + "%";
    try (Cursor c = db.rawQuery("SELECT IFNULL(SUM(total_cbm),0) FROM logistics_forms WHERE date LIKE ?", new String[]{like})) {
        if (c.moveToFirst()) return c.getDouble(0);
    } catch (Exception ignored) {}
    return 0;
}
    
public int deleteLogisticsForm(long id) {
    if (id <= 0) return 0;
    SQLiteDatabase db = getWritableDatabase();
    // ✅ 删除前先取 cloud_id（因为删除后就查不到了）
    String cloudId = "";
    try {
        Cursor c0 = db.rawQuery("SELECT cloud_id FROM logistics_forms WHERE id=?", new String[]{String.valueOf(id)});
        if (c0 != null) {
            if (c0.moveToFirst()) cloudId = nvl(c0.getString(0));
            try { c0.close(); } catch (Exception ignored) {}
        }
    } catch (Exception ignored) {}
    db.beginTransaction();
    try {
        // ✅ 如曾扣减过纸箱，删除物流单前先把纸箱库存加回去
        try { rollbackLogisticsCartonIfNeeded(db, id); } catch (Exception ignored) {}

        db.delete("logistics_sizes", "logistics_id=?", new String[]{String.valueOf(id)});
        int rows = db.delete("logistics_forms", "id=?", new String[]{String.valueOf(id)});
        db.setTransactionSuccessful();
                    if (rows > 0) {
                // ✅ 本地删除 → 入队云端 DELETE（云端 logistics_forms 使用稳定 uuid + tenant_id）
                try {
                    String uid = AuthManager.getUserId(ctx);
                    // ✅ 云端删除必须使用 cloud_id（云端主键），避免旧的 stable(uuid|localId) 策略导致找不到/误删
                    enqueueCloudDelete("logistics_forms", buildWhereJsonForLogisticsDelete(uid, cloudId));
                    // ✅ 同步删除明细行（sizes）：按 tenant_id + form_id 删除该单所有尺寸
                    enqueueCloudDelete("logistics_sizes", buildWhereJsonForLogisticsSizesDelete(uid, cloudId));
                    // logistics_sizes 通常依赖 form_id 外键；云端若无级联，可在 Supabase 侧加 ON DELETE CASCADE
                } catch (Exception ignored) {}
                scheduleCloudPushSafe();
            }
            return rows;
    } catch (Exception e) {
        return 0;
    } finally {
        try {
            if (db != null && db.inTransaction()) db.endTransaction();
        } catch (Throwable ignore) {}
    }
}


public int getTotalPiecesByDate(String d) {
    return getTotalPiecesByDate(d, null);
}

/**
 * ✅ 获取某天订单最大自增ID（用于“箱唛已打印到哪一单”的本地标记）
 */
public long getMaxOrderIdByDate(String d) {
    d = safeTrim(d);
    if (d.isEmpty()) return 0;
    SQLiteDatabase db = getReadableDatabase();
    try (Cursor c = db.rawQuery(
            "SELECT IFNULL(MAX(id),0) FROM orders WHERE SUBSTR(IFNULL(date,''),1,10)=? AND IFNULL(is_deleted,0)=0 AND UPPER(COALESCE(status,'CONFIRMED'))!='VOID'",
            new String[]{d})) {
        if (c.moveToFirst()) return c.getLong(0);
    } catch (Exception ignored) {}
    return 0;
}

public int getTotalPiecesByDate(String d, String location) {
    d = safeTrim(d);
    if (d.isEmpty()) return 0;
    String loc = location == null ? "" : location.trim();
    SQLiteDatabase db = getReadableDatabase();
    String sql = "SELECT IFNULL(SUM(pieces),0) FROM orders WHERE date=? AND IFNULL(is_deleted,0)=0 AND UPPER(COALESCE(status,'CONFIRMED'))!='VOID'";
    List<String> args = new ArrayList<>();
    args.add(d);
    if (!loc.isEmpty() && !"全部".equals(loc)) {
        sql += " AND IFNULL(location,'')=?";
        args.add(loc);
    }
    try (Cursor c = db.rawQuery(sql, args.toArray(new String[0]))) {
        if (c.moveToFirst()) return c.getInt(0);
    } catch (Exception ignored) {}
    return 0;
}

public int getTotalQuantityByDate(String d, String location) {
    d = safeTrim(d);
    if (d.isEmpty()) return 0;
    String loc = location == null ? "" : location.trim();
    SQLiteDatabase db = getReadableDatabase();
    String sql = "SELECT IFNULL(SUM(quantity),0) FROM orders WHERE date=? AND IFNULL(is_deleted,0)=0 AND UPPER(COALESCE(status,'CONFIRMED'))!='VOID'";
    List<String> args = new ArrayList<>();
    args.add(d);
    if (!loc.isEmpty() && !"全部".equals(loc)) {
        sql += " AND IFNULL(location,'')=?";
        args.add(loc);
    }
    try (Cursor c = db.rawQuery(sql, args.toArray(new String[0]))) {
        if (c.moveToFirst()) return c.getInt(0);
    } catch (Exception ignored) {}
    return 0;
}

public List<CustomerPiecesSummary> getCustomerPiecesSummaryByDate(String d) {
    return getCustomerPiecesSummaryByDate(d, null);
}

public List<CustomerPiecesSummary> getCustomerPiecesSummaryByDate(String d, String location) {
    List<CustomerPiecesSummary> list = new ArrayList<>();
    d = safeTrim(d);
    if (d.isEmpty()) return list;

    String loc = location == null ? "" : location.trim();

    SQLiteDatabase db = getReadableDatabase();
    String sql = "SELECT customer_name, IFNULL(SUM(pieces),0) AS total_pieces " +
            "FROM orders WHERE date=? AND IFNULL(is_deleted,0)=0 AND UPPER(COALESCE(status,'CONFIRMED'))!='VOID' ";
    List<String> args = new ArrayList<>();
    args.add(d);
    if (!loc.isEmpty() && !"全部".equals(loc)) {
        sql += " AND IFNULL(location,'')=? ";
        args.add(loc);
    }
    sql += "GROUP BY customer_name ORDER BY total_pieces DESC, customer_name ASC";

    try (Cursor c = db.rawQuery(sql, args.toArray(new String[0]))) {
        while (c.moveToNext()) {
            String customer = nvl(c.getString(0));
            int pieces = c.getInt(1);
            if (!customer.isEmpty()) {
                list.add(new CustomerPiecesSummary(customer, pieces));
            }
        }
    } catch (Exception ignored) {}
    return list;
}

    // ---------- LOCATION ----------

    public long addLocation(String name) {
        name = safeTrim(name);
        if (name.isEmpty()) return -1;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        return db.insertWithOnConflict("locations", null, cv, SQLiteDatabase.CONFLICT_IGNORE);
    }

    public int updateLocation(long id, String name) {
        name = safeTrim(name);
        if (id <= 0 || name.isEmpty()) return 0;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        return db.update("locations", cv, "id=?", new String[]{String.valueOf(id)});
    }

    public int deleteLocation(long id) {
        if (id <= 0) return 0;
        SQLiteDatabase db = getWritableDatabase();
        return db.delete("locations", "id=?", new String[]{String.valueOf(id)});
    }

    public List<LocationItem> getAllLocations() {
        SQLiteDatabase db = getReadableDatabase();
        List<LocationItem> list = new ArrayList<>();
        try (Cursor c = db.rawQuery("SELECT id,name FROM locations ORDER BY name COLLATE NOCASE", null)) {
            while (c.moveToNext()) {
                LocationItem it = new LocationItem(c.getLong(0), nvl(c.getString(1)));
                list.add(it);
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    public List<String> getAllLocationNames() {
        SQLiteDatabase db = getReadableDatabase();
        List<String> list = new ArrayList<>();
        try (Cursor c = db.rawQuery("SELECT name FROM locations ORDER BY name COLLATE NOCASE", null)) {
            while (c.moveToNext()) {
                String v = c.getString(0);
                if (v != null && !v.trim().isEmpty()) list.add(v.trim());
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    // ---------- INVENTORY（可用版：本地可用 + 云端可恢复） ----------

    // 表名/列名（与 Supabase 表字段保持一致）
    private static final String TABLE_INVENTORY_ITEMS = "inventory_items";
    private static final String COL_INV_ID = "id";
    private static final String COL_INV_TYPE = "type";
    private static final String COL_INV_NAME = "name";
    private static final String COL_INV_SKU = "sku";
    private static final String COL_INV_SPEC = "spec";
    private static final String COL_INV_QTY = "qty";
    private static final String COL_INV_SAFETY = "safety";

    private static final String TABLE_INVENTORY_MOVEMENTS = "inventory_movements";
    private static final String COL_MOV_ID = "id";
    private static final String COL_MOV_ITEM_ID = "item_id";
    private static final String COL_MOV_CHANGE = "change_qty";
    private static final String COL_MOV_REASON = "reason";
    private static final String COL_MOV_REF_TYPE = "ref_type";
    private static final String COL_MOV_REF_ID = "ref_id";
    private static final String COL_MOV_DATE = "date";
    private static final String COL_MOV_UUID = "uuid";
    private static final String COL_MOV_CREATED_AT = "created_at";

    public List<InventoryItem> getInventoryItemsByType(String type) {
        List<InventoryItem> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_INVENTORY_ITEMS, null,
                COL_INV_TYPE + "=?",
                new String[]{type},
                null, null,
                COL_INV_NAME + " COLLATE NOCASE ASC");
        try {
            while (c.moveToNext()) {
                InventoryItem it = new InventoryItem();
                it.setId(c.getLong(c.getColumnIndexOrThrow(COL_INV_ID)));
                it.setType(nvl(c.getString(c.getColumnIndexOrThrow(COL_INV_TYPE))));
                it.setName(nvl(c.getString(c.getColumnIndexOrThrow(COL_INV_NAME))));
                it.setSku(nvl(c.getString(c.getColumnIndexOrThrow(COL_INV_SKU))));
                it.setSpec(nvl(c.getString(c.getColumnIndexOrThrow(COL_INV_SPEC))));
                it.setQuantity(c.getInt(c.getColumnIndexOrThrow(COL_INV_QTY)));
                it.setSafetyStock(c.getInt(c.getColumnIndexOrThrow(COL_INV_SAFETY)));
                list.add(it);
            }
        } finally {
            c.close();
        }
        return list;
    }

    /** 低库存（低于安全值）清单：默认覆盖所有类型 */
    public List<InventoryItem> getLowStockItems() {
        return getLowStockItems(new String[]{"CARTON", "POT", "BAG", "PRODUCT"});
    }

    public List<InventoryItem> getLowStockItems(String[] types) {
        List<InventoryItem> list = new ArrayList<>();
        if (types == null || types.length == 0) return list;

        StringBuilder where = new StringBuilder();
        where.append(COL_INV_SAFETY).append(">0 AND ")
                .append(COL_INV_QTY).append("<").append(COL_INV_SAFETY)
                .append(" AND (");
        for (int i = 0; i < types.length; i++) {
            if (i > 0) where.append(" OR ");
            where.append(COL_INV_TYPE).append("=?");
        }
        where.append(")");

        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_INVENTORY_ITEMS, null,
                where.toString(),
                types,
                null, null,
                COL_INV_TYPE + " ASC, " + COL_INV_NAME + " COLLATE NOCASE ASC");
        try {
            while (c.moveToNext()) {
                InventoryItem it = new InventoryItem();
                it.setId(c.getLong(c.getColumnIndexOrThrow(COL_INV_ID)));
                it.setType(nvl(c.getString(c.getColumnIndexOrThrow(COL_INV_TYPE))));
                it.setName(nvl(c.getString(c.getColumnIndexOrThrow(COL_INV_NAME))));
                it.setSku(nvl(c.getString(c.getColumnIndexOrThrow(COL_INV_SKU))));
                it.setSpec(nvl(c.getString(c.getColumnIndexOrThrow(COL_INV_SPEC))));
                it.setQuantity(c.getInt(c.getColumnIndexOrThrow(COL_INV_QTY)));
                it.setSafetyStock(c.getInt(c.getColumnIndexOrThrow(COL_INV_SAFETY)));
                list.add(it);
            }
        } finally {
            c.close();
        }
        return list;
    }

    public InventoryItem getInventoryItemById(long id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_INVENTORY_ITEMS, null,
                COL_INV_ID + "=?",
                new String[]{String.valueOf(id)},
                null, null, null);
        try {
            if (c.moveToFirst()) {
                InventoryItem it = new InventoryItem();
                it.setId(c.getLong(c.getColumnIndexOrThrow(COL_INV_ID)));
                it.setType(nvl(c.getString(c.getColumnIndexOrThrow(COL_INV_TYPE))));
                it.setName(nvl(c.getString(c.getColumnIndexOrThrow(COL_INV_NAME))));
                it.setSku(nvl(c.getString(c.getColumnIndexOrThrow(COL_INV_SKU))));
                it.setSpec(nvl(c.getString(c.getColumnIndexOrThrow(COL_INV_SPEC))));
                it.setQuantity(c.getInt(c.getColumnIndexOrThrow(COL_INV_QTY)));
                it.setSafetyStock(c.getInt(c.getColumnIndexOrThrow(COL_INV_SAFETY)));
                return it;
            }
        } finally {
            c.close();
        }
        return null;
    }

    private long getOrCreateInventoryItemId(String type, String name) {
        if (name == null) name = "";
        name = name.trim();
        if (name.isEmpty()) return -1;

        SQLiteDatabase db = getWritableDatabase();
        Cursor c = db.rawQuery("SELECT " + COL_INV_ID + " FROM " + TABLE_INVENTORY_ITEMS +
                        " WHERE " + COL_INV_TYPE + "=? AND " + COL_INV_NAME + "=? LIMIT 1",
                new String[]{type, name});
        try {
            if (c.moveToFirst()) return c.getLong(0);
        } finally {
            c.close();
        }

        ContentValues cv = new ContentValues();
        cv.put(COL_INV_TYPE, type);
        cv.put(COL_INV_NAME, name);
        cv.put(COL_INV_SKU, "");
        cv.put(COL_INV_SPEC, "");
        cv.put(COL_INV_QTY, 0);
        cv.put(COL_INV_SAFETY, 0);

        // ✅ P0：云端 inventory_items.cloud_id 为 NOT NULL，用于幂等去重（on_conflict=cloud_id）
        cv.put("cloud_id", java.util.UUID.randomUUID().toString());
        cv.put("synced", 0);

        return db.insert(TABLE_INVENTORY_ITEMS, null, cv);
    }

    // =========================
    // A2: 物料(套袋/花盆)按“绑定产品”扣减
    // 绑定规则：inventory_items.sku 存放绑定产品名列表（以逗号/中文逗号/顿号/分号/换行分隔）
    // 若未绑定，则不会自动建档，只记录日志；但会尝试兼容旧数据：同类型同名已存在则使用该条目
    // =========================

    private static String normName(String s) {
        if (s == null) return "";
        return s.trim().replaceAll("\\s+", " ");
    }

    private static String[] splitBoundProducts(String sku) {
        if (sku == null) return new String[0];
        sku = sku.trim();
        if (sku.isEmpty()) return new String[0];
        // 支持 , ， 、 ; ； 换行
        return sku.split("[,，、;；\\n]+");
    }

    private long findBoundItemIdByProductName(String invType, String productName) {
        String p = normName(productName);
        if (p.isEmpty()) return -1;

        SQLiteDatabase db = getReadableDatabase();
        Cursor c = null;
        try {
            c = db.rawQuery("SELECT id, name, sku FROM inventory_items WHERE type=?",
                    new String[]{invType});
            while (c.moveToNext()) {
                long id = c.getLong(0);
                String name = c.getString(1);
                String sku = c.getString(2);

                // 1) 优先按绑定列表匹配
                String[] arr = splitBoundProducts(sku);
                for (String t : arr) {
                    if (normName(t).equals(p)) {
                        return id;
                    }
                }
            }
        } catch (Exception e) {
            try { android.util.Log.w("DB", "findBoundItemIdByProductName err: " + e); } catch (Exception ignored) {}
        } finally {
            if (c != null) try { c.close(); } catch (Exception ignored) {}
        }

        // 2) 兼容旧数据：同类型同名存在则使用（但不会创建新条目）
        Cursor c2 = null;
        try {
            c2 = db.rawQuery("SELECT id FROM inventory_items WHERE type=? AND name=? LIMIT 1",
                    new String[]{invType, p});
            if (c2.moveToFirst()) return c2.getLong(0);
        } catch (Exception e) {
            try { android.util.Log.w("DB", "findBoundItemIdByProductName fallback err: " + e); } catch (Exception ignored) {}
        } finally {
            if (c2 != null) try { c2.close(); } catch (Exception ignored) {}
        }

        return -1;
    }
    /** 
     * 返回所有命中该产品名绑定的库存条目ID（支持一个产品命中多个库存项：商业化逻辑）
     * - invType: POT/BAG 等
     * - productName: 产品名（会做规范化匹配）
     */
    private List<Long> findBoundItemIdsByProductName(String invType, String productName) {
        List<Long> ids = new ArrayList<>();
        String p = normName(productName);
        if (p.isEmpty()) return ids;

        SQLiteDatabase db = getReadableDatabase();
        Cursor c = null;
        try {
            c = db.rawQuery("SELECT id, name, sku FROM inventory_items WHERE type=?",
                    new String[]{invType});
            while (c.moveToNext()) {
                long id = c.getLong(0);
                String name = c.getString(1);
                String sku = c.getString(2);

                boolean matched = false;

                // 1) 绑定列表匹配（sku 里逗号分隔）
                String[] arr = splitBoundProducts(sku);
                for (String t : arr) {
                    if (normName(t).equals(p)) {
                        matched = true;
                        break;
                    }
                }

                // 2) 兼容旧数据：同类型同名
                if (!matched && normName(name).equals(p)) {
                    matched = true;
                }

                if (matched) {
                    ids.add(id);
                }
            }
        } catch (Exception e) {
            try { android.util.Log.w("DB", "findBoundItemIdsByProductName err: " + e); } catch (Exception ignored) {}
        } finally {
            if (c != null) try { c.close(); } catch (Exception ignored) {}
        }

        return ids;
    }



    private long findBoundBagItemId(String productName) {
        return findBoundItemIdByProductName(INV_TYPE_BAG, productName);
    }

    private long findBoundPotItemId(String productName) {
        return findBoundItemIdByProductName(INV_TYPE_POT, productName);
    }

    public int updateInventoryItemBasic(long id, String name, String sku, String spec, Integer safety) {
        if (id <= 0) return 0;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_INV_NAME, nvl(name).trim());
        cv.put(COL_INV_SKU, nvl(sku).trim());
        cv.put(COL_INV_SPEC, nvl(spec).trim());
        if (safety != null) cv.put(COL_INV_SAFETY, Math.max(0, safety));
        cv.put("updated_at", nowIso8601());
        cv.put("synced", 0);
        int rows = db.update(TABLE_INVENTORY_ITEMS, cv, COL_INV_ID + "=?", new String[]{String.valueOf(id)});
        if (rows > 0) scheduleCloudPushSafe();
        return rows;
    }


    public long addInventoryItem(String type, String name, String sku, String spec, int qty, int safety) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(COL_INV_TYPE, type);
        cv.put(COL_INV_NAME, name);
        cv.put(COL_INV_SKU, sku);
        cv.put(COL_INV_SPEC, spec);
        cv.put(COL_INV_QTY, qty);
        cv.put("updated_at", nowIso8601());
        cv.put("synced", 0);
        cv.put(COL_INV_SAFETY, safety);

        // ✅ P0：本地新增库存项必须生成 cloud_id，避免云端 23502 (null cloud_id)
        cv.put("cloud_id", java.util.UUID.randomUUID().toString());
        cv.put("synced", 0);

        long id = db.insert(TABLE_INVENTORY_ITEMS, null, cv);

        // 初始入库流水（可为空）
        if (id > 0 && qty != 0) {
            insertMovement(id, qty, "新增库存", "INIT", (int) id);
        }

        scheduleCloudPushSafe();
        return id;
    }


    public int deleteInventoryItem(long id) {
        SQLiteDatabase db = getWritableDatabase();

        // ✅ P1：删除必须同步到云端，否则下次 pull 会把已删库存“拉回来”
        // 逻辑：在本地删除前，把 cloud_id 取出并写入 cloud_delete_queue，让 SupabaseSyncManager 在 push 时执行 REST DELETE
        try {
            String cloudId = "";
            try (Cursor c = db.rawQuery("SELECT cloud_id FROM inventory_items WHERE id=?",
                    new String[]{String.valueOf(id)})) {
                if (c.moveToFirst()) cloudId = nvl(c.getString(0));
            }

            if (!cloudId.isEmpty()) {
                org.json.JSONObject w = new org.json.JSONObject();
                w.put("cloud_id", cloudId);
                // 由 SupabaseSyncManager 自动补 owner_uid / org_id 过滤
                enqueueCloudDelete("inventory_items", w);
            }
        } catch (Exception ignored) { }

        int rows = db.delete(TABLE_INVENTORY_ITEMS, COL_INV_ID + "=?", new String[]{String.valueOf(id)});

        // 同时清理流水（避免孤儿数据）
        try {
            db.delete(TABLE_INVENTORY_MOVEMENTS, COL_MOV_ITEM_ID + "=?", new String[]{String.valueOf(id)});
        } catch (Exception ignored) {
        }

        scheduleCloudPushSafe();
        return rows;
    }

    public void adjustInventory(long id, int delta, String reason, String refType, int refId) {
        if (id <= 0) return;
        SQLiteDatabase db = getWritableDatabase();
        InventoryItem it = getInventoryItemById(id);
        int cur = it == null ? 0 : it.getQuantity();
        int next = cur + delta;
        if (next < 0) next = 0;

        ContentValues cv = new ContentValues();
        cv.put(COL_INV_QTY, next);
        cv.put("updated_at", nowIso8601());
        cv.put("synced", 0);
        db.update(TABLE_INVENTORY_ITEMS, cv, COL_INV_ID + "=?", new String[]{String.valueOf(id)});

        if (delta != 0) {
            insertMovement(id, delta, reason, refType, refId);
        }
        scheduleCloudPushSafe();
    }

    public void setInventoryQuantityWithLog(long id, int qty, String reason) {
        if (id <= 0) return;
        if (qty < 0) qty = 0;
        InventoryItem it = getInventoryItemById(id);
        int cur = it == null ? 0 : it.getQuantity();
        int delta = qty - cur;

        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_INV_QTY, qty);
        cv.put("updated_at", nowIso8601());
        cv.put("synced", 0);
        db.update(TABLE_INVENTORY_ITEMS, cv, COL_INV_ID + "=?", new String[]{String.valueOf(id)});
        if (delta != 0) {
            insertMovement(id, delta, reason, "MANUAL", (int) id);
        }
        scheduleCloudPushSafe();
    }

    public void setInventorySafetyStock(long id, int safety, String reason) {
        if (id <= 0) return;
        if (safety < 0) safety = 0;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_INV_SAFETY, safety);
        cv.put("updated_at", nowIso8601());
        cv.put("synced", 0);
        db.update(TABLE_INVENTORY_ITEMS, cv, COL_INV_ID + "=?", new String[]{String.valueOf(id)});
        if (reason != null && !reason.trim().isEmpty()) {
            insertMovement(id, 0, "安全库存：" + reason, "SAFETY", (int) id);
        }
        scheduleCloudPushSafe();
    }

    public void setInventorySku(long id, String sku) {
        if (id <= 0) return;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_INV_SKU, sku);
        cv.put("updated_at", nowIso8601());
        cv.put("synced", 0);
        db.update(TABLE_INVENTORY_ITEMS, cv, COL_INV_ID + "=?", new String[]{String.valueOf(id)});
        scheduleCloudPushSafe();
    }

    public void stocktakeSingleItem(long id, int qty, String reason) {
        if (id <= 0) return;
        if (qty < 0) qty = 0;
        setInventoryQuantityWithLog(id, qty, reason == null ? "盘点" : ("盘点：" + reason));
    }

    private void insertMovement(long itemId, int delta, String reason, String refType, int refId) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues cv = new ContentValues();
            cv.put(COL_MOV_ITEM_ID, itemId);
            cv.put(COL_MOV_CHANGE, delta);
            cv.put(COL_MOV_REASON, reason);
            cv.put(COL_MOV_REF_TYPE, refType);
            cv.put(COL_MOV_REF_ID, refId);

            long now = System.currentTimeMillis();
            cv.put(COL_MOV_CREATED_AT, now);
            cv.put(COL_MOV_UUID, java.util.UUID.randomUUID().toString());
            cv.put(COL_MOV_DATE, new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(new java.util.Date(now)));

            db.insert(TABLE_INVENTORY_MOVEMENTS, null, cv);
        } catch (Exception ignored) {
        }
    }

    /**
     * ✅ 扣减指定日期范围内“未打印”的订单库存（并把这些订单标记为已打印），避免重复扣减。
     * 说明：此逻辑与程序2保持一致，只影响库存模块，不影响订单数据结构。
     */
    public void deductInventoryForUnprintedOrders(String startDateInclusive, String endDateInclusive) {
        SQLiteDatabase db = getWritableDatabase();
        Cursor c = db.rawQuery(
                "SELECT id,product_name,quantity FROM orders " +
                        "WHERE date>=? AND date<=? AND COALESCE(printed,0)=0 " +
                        "AND IFNULL(is_deleted,0)=0 AND UPPER(COALESCE(status,'CONFIRMED'))!='VOID'",
                new String[]{startDateInclusive, endDateInclusive}
        );

        List<Integer> ids = new ArrayList<>();
        db.beginTransaction();
        try {
            while (c.moveToNext()) {
                int orderId = c.getInt(0);
                String productName = nvl(c.getString(1));
                int qty = c.getInt(2);
                ids.add(orderId);

                // 产品：改为与花盆/套袋一致，只扣减手动创建且已绑定该产品的库存项；不再自动建档
                List<Long> productIds = findBoundItemIdsByProductName(INV_TYPE_PRODUCT, productName);
                if (productIds != null && !productIds.isEmpty()) {
                    for (Long pid : productIds) {
                        if (pid == null || pid <= 0) continue;
                        adjustInventory(pid, -qty, "订单出库(产品)", "ORDER", orderId);
                    }
                } else {
                    try { android.util.Log.w("DB", "skip product deduct: product not bound -> " + productName); } catch (Exception ignored) {}
                }

                // 花盆：支持一个产品命中多个库存项（SKU 绑定或同名）
                List<Long> potIds = findBoundItemIdsByProductName(INV_TYPE_POT, productName);
                if (potIds != null && !potIds.isEmpty()) {
                    for (Long pid : potIds) {
                        if (pid == null || pid <= 0) continue;
                        adjustInventory(pid, -qty, "订单出库(花盆)", "ORDER", orderId);
                    }
                } else {
                    try { android.util.Log.w("DB", "skip pot deduct: product not bound -> " + productName); } catch (Exception ignored) {}
                }

                // 套袋：支持一个产品命中多个库存项（SKU 绑定或同名）
                List<Long> bagIds = findBoundItemIdsByProductName(INV_TYPE_BAG, productName);
                if (bagIds != null && !bagIds.isEmpty()) {
                    for (Long bid : bagIds) {
                        if (bid == null || bid <= 0) continue;
                        adjustInventory(bid, -qty, "订单出库(套袋)", "ORDER", orderId);
                    }
                } else {
                    try { android.util.Log.w("DB", "skip bag deduct: product not bound -> " + productName); } catch (Exception ignored) {}
                }

                // ✅ 纸箱不在订单出库阶段扣减：改为由“物流单”扣减（方案A1）
                try { android.util.Log.d("DB", "skip carton deduct in ORDER: handled by logistics form"); } catch (Exception ignored) {}

            }

            for (int id : ids) {
                // ✅ Step2-1：打印联动订单状态（Last-write-wins 同步依赖 updated_at）
                String now = nowIso8601();
                try {
                    db.execSQL(
                            "UPDATE orders SET " +
                                    "printed=1, " +
                                    "printed_at=?, " +
                                    "status=CASE " +
                                    "WHEN UPPER(COALESCE(status,'')) IN ('" + ORDER_STATUS_VOID + "','" + ORDER_STATUS_SETTLED + "') THEN status " +
                                    "WHEN UPPER(COALESCE(status,''))='" + ORDER_STATUS_SHIPPED + "' THEN status " +
                                    "ELSE '" + ORDER_STATUS_PRINTED + "' END, " +
                                    "updated_at=?, " +
                                    "synced=0 " +
                                    "WHERE id=?",
                            new Object[]{now, now, id}
                    );
                } catch (Exception ignored) { }
            }

            scheduleCloudPushSafe(); // P0-3: 打印后触发云端同步
            db.setTransactionSuccessful();
        } finally {
            try { c.close(); } catch (Exception ignore) {}
            try { db.endTransaction(); } catch (Exception ignore) {}
        }
    }

    /**
     * ✅ 仅扣减本次实际打印的订单，避免按日期扫描误伤同日其他订单。
     * @param orderIds 本次打印成功的订单ID列表
     * @param markPrinted 是否同时把订单标记为已打印/已扣库存
     */
    public void deductInventoryForOrderIds(java.util.ArrayList<Integer> orderIds, boolean markPrinted) {
        if (orderIds == null || orderIds.isEmpty()) return;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        Cursor c = null;
        try {
            for (Integer orderIdObj : orderIds) {
                if (orderIdObj == null) continue;
                int orderId = orderIdObj;
                c = db.rawQuery(
                        "SELECT id,product_name,quantity,COALESCE(printed,0),COALESCE(shipped_at,'') FROM orders WHERE id=? AND IFNULL(is_deleted,0)=0 AND UPPER(COALESCE(status,'CONFIRMED'))!='VOID'",
                        new String[]{String.valueOf(orderId)}
                );
                if (!c.moveToFirst()) {
                    try { c.close(); } catch (Exception ignore) {}
                    c = null;
                    continue;
                }
                String productName = nvl(c.getString(1));
                int qty = c.getInt(2);
                int alreadyPrinted = c.getInt(3);
                String shippedAt = nvl(c.getString(4));
                try { c.close(); } catch (Exception ignore) {}
                c = null;

                // ✅ 2026-04：库存扣减改为“打印送货单时扣减”。
                // printed/printed_at 现在主要承载“箱唛/标签已打印”语义，
                // 不能再用 printed=1 作为“已扣库存”的唯一判断，否则先打箱唛会导致送货单不再扣减花盆/套袋。
                // 这里改为以 shipped_at 是否为空作为“本订单是否已执行过送货单扣库存”的幂等标记。
                if (!android.text.TextUtils.isEmpty(shippedAt)) {
                    if (markPrinted) {
                        String now = nowIso8601();
                        try {
                            db.execSQL(
                                    "UPDATE orders SET " +
                                            "shipped_at=COALESCE(NULLIF(shipped_at,''), ?), " +
                                            "updated_at=?, " +
                                            "synced=0 " +
                                            "WHERE id=?",
                                    new Object[]{now, now, orderId}
                            );
                        } catch (Exception ignored) { }
                    }
                    continue;
                }

                // 产品：仅扣减手动创建且已绑定该产品的库存项
                java.util.List<Long> productIds = findBoundItemIdsByProductName(INV_TYPE_PRODUCT, productName);
                if (productIds != null && !productIds.isEmpty()) {
                    for (Long pid : productIds) {
                        if (pid == null || pid <= 0) continue;
                        adjustInventory(pid, -qty, "订单出库(产品)", "ORDER", orderId);
                    }
                }

                // 花盆
                java.util.List<Long> potIds = findBoundItemIdsByProductName(INV_TYPE_POT, productName);
                if (potIds != null && !potIds.isEmpty()) {
                    for (Long pid : potIds) {
                        if (pid == null || pid <= 0) continue;
                        adjustInventory(pid, -qty, "订单出库(花盆)", "ORDER", orderId);
                    }
                }

                // 套袋
                java.util.List<Long> bagIds = findBoundItemIdsByProductName(INV_TYPE_BAG, productName);
                if (bagIds != null && !bagIds.isEmpty()) {
                    for (Long bid : bagIds) {
                        if (bid == null || bid <= 0) continue;
                        adjustInventory(bid, -qty, "订单出库(套袋)", "ORDER", orderId);
                    }
                }

                // 纸箱仍由物流单扣减，这里不处理
                if (markPrinted) {
                    String now = nowIso8601();
                    try {
                        db.execSQL(
                                "UPDATE orders SET " +
                                        // 保留 printed/printed_at（箱唛打印语义）原值，不在送货单扣库存时强行改写
                                        "shipped_at=COALESCE(NULLIF(shipped_at,''), ?), " +
                                        "updated_at=?, " +
                                        "synced=0 " +
                                        "WHERE id=?",
                                new Object[]{now, now, orderId}
                        );
                    } catch (Exception ignored) { }
                }
            }
            scheduleCloudPushSafe();
            db.setTransactionSuccessful();
        } finally {
            try { if (c != null) c.close(); } catch (Exception ignore) {}
            try { db.endTransaction(); } catch (Exception ignore) {}
        }
    }


        // ---------- TEMPLATE（模板中心） ----------

    public long insertTemplate(String type, String name, String content, long updatedAt, int isDefault) {
        type = safeTrim(type);
        name = safeTrim(name);
        content = content == null ? "" : content;
        // ✅ 新增模板必须带 updated_at/cloud_id，否则“按 updated_at 增量挑选待同步数据”时会被遗漏，导致新增不同步
        if (updatedAt <= 0) updatedAt = System.currentTimeMillis();
        if (type.isEmpty() || name.isEmpty()) return -1;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        // ✅ 模板是共享表，同步依赖稳定 cloud_id（云端用 on_conflict=cloud_id 幂等 upsert）
        cv.put("cloud_id", java.util.UUID.randomUUID().toString());
        cv.put("type", type);
        cv.put("name", name);
        cv.put("content", content);
        cv.put("updated_at", updatedAt);
        cv.put("is_default", isDefault);
        long id = db.insert("print_templates", null, cv);
        if (id > 0) {
            if (isDefault == 1) setDefaultTemplate(type, id);
            scheduleCloudPushSafe();
        }
        return id;
    }

    public int updateTemplate(long id, String name, String content, long updatedAt) {
        if (id <= 0) return 0;
        name = safeTrim(name);
        content = content == null ? "" : content;
        if (updatedAt <= 0) updatedAt = System.currentTimeMillis();
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("content", content);
        cv.put("updated_at", updatedAt);
        int n = db.update("print_templates", cv, "id=?", new String[]{String.valueOf(id)});
        if (n > 0) scheduleCloudPushSafe();
        return n;
    }

    public int deleteTemplate(long id) {
        if (id <= 0) return 0;
        SQLiteDatabase db = getWritableDatabase();

        // 先取 cloud_id/type/name（删除本地后就拿不到了）
        String cloudId = "";
        String type0 = "";
        String name0 = "";
        try (Cursor c = db.rawQuery("SELECT cloud_id,type,name FROM print_templates WHERE id=? LIMIT 1", new String[]{String.valueOf(id)})) {
            if (c.moveToFirst()) {
                cloudId = nvl(c.getString(0));
                type0 = nvl(c.getString(1));
                name0 = nvl(c.getString(2));
            }
        } catch (Exception ignored) {}

        int n = db.delete("print_templates", "id=?", new String[]{String.valueOf(id)});

        // ✅ 关键修复：模板是【组织共享表】（按 org_id 管控），云端 print_templates 通常没有 owner_uid 字段。
        // 若把 owner_uid 放进 where，会导致 REST 过滤字段不存在，从而 DELETE 失败，队列一直卡住。
        // 同时：即便本地已经被重复删除/提前清理(n==0)，只要拿得到 cloud_id 或 (type+name)，也要尝试入队删除。
        try {
            boolean hasKey = (cloudId != null && !cloudId.trim().isEmpty()) || (!type0.isEmpty() && !name0.isEmpty());
            if (hasKey) {
                JSONObject w = new JSONObject();
                String orgId = AuthManager.getOrgId(ctx);
                if (orgId != null && !orgId.trim().isEmpty()) w.put("org_id", orgId.trim());
                if (cloudId != null && !cloudId.trim().isEmpty()) {
                    // 云端主键字段为 id（本地 cloud_id 即 stableId）
                    w.put("id", cloudId.trim());
                } else {
                    // 兜底：无 cloud_id 时退回用 type+name（可能不够精确，但比不删强）
                    if (!type0.isEmpty()) w.put("type", type0);
                    if (!name0.isEmpty()) w.put("name", name0);
                }
                enqueueCloudDelete("print_templates", w);
                scheduleCloudPushSafe();
            }
        } catch (Exception ignored) {}

        return n;
    }

    public PrintTemplate getTemplateById(long id) {
        if (id <= 0) return null;
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery(
                "SELECT id,type,name,content,updated_at,is_default FROM print_templates WHERE id=? LIMIT 1",
                new String[]{String.valueOf(id)}
        )) {
            if (c.moveToFirst()) {
                return new PrintTemplate(
                        c.getLong(0),
                        nvl(c.getString(1)),
                        nvl(c.getString(2)),
                        nvl(c.getString(3)),
                        c.getLong(4),
                        c.getInt(5)
                );
            }
        } catch (Exception ignored) {}
        return null;
    }

    public List<PrintTemplate> getTemplatesByType(String type) {
        type = safeTrim(type);
        SQLiteDatabase db = getReadableDatabase();
        List<PrintTemplate> list = new ArrayList<>();
        try (Cursor c = db.rawQuery(
                "SELECT id,type,name,content,updated_at,is_default FROM print_templates WHERE type=? ORDER BY is_default DESC, updated_at DESC, id DESC",
                new String[]{type}
        )) {
            while (c.moveToNext()) {
                list.add(new PrintTemplate(
                        c.getLong(0),
                        nvl(c.getString(1)),
                        nvl(c.getString(2)),
                        nvl(c.getString(3)),
                        c.getLong(4),
                        c.getInt(5)
                ));
            }
        } catch (Exception ignored) {}
        return list;
    }

    public void setDefaultTemplate(String type, long id) {
        type = safeTrim(type);
        if (type.isEmpty() || id <= 0) return;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues cv0 = new ContentValues();
            cv0.put("is_default", 0);
            db.update("print_templates", cv0, "type=?", new String[]{type});

            ContentValues cv1 = new ContentValues();
            cv1.put("is_default", 1);
            db.update("print_templates", cv1, "id=? AND type=?", new String[]{String.valueOf(id), type});

            db.setTransactionSuccessful();
        } catch (Exception ignored) {
        } finally {
            try { db.endTransaction(); } catch (Exception ignored2) {}
        }
        scheduleCloudPushSafe();
    }

    public String getDefaultTemplateContent(String type) {
        type = safeTrim(type);
        if (type.isEmpty()) return "";
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery(
                "SELECT content FROM print_templates WHERE type=? AND is_default=1 ORDER BY updated_at DESC, id DESC LIMIT 1",
                new String[]{type}
        )) {
            if (c.moveToFirst()) return nvl(c.getString(0));
        } catch (Exception ignored) {}
        // 没有默认模板时，回退到最新一条
        try (Cursor c = db.rawQuery(
                "SELECT content FROM print_templates WHERE type=? ORDER BY updated_at DESC, id DESC LIMIT 1",
                new String[]{type}
        )) {
            if (c.moveToFirst()) return nvl(c.getString(0));
        } catch (Exception ignored) {}
        return "";
    }

    // 与云同步模板的队列（当前版本不强制依赖，保留空实现以兼容旧逻辑）
    public void enqueueTemplateUpsert(long id) { }


    
    // 用于云端恢复库存条目（覆盖式恢复时调用）
    private void upsertInventoryItemFromCloud(String type, String name, String sku, String spec, int qty, int safety) {
        type = safeTrim(type);
        name = safeTrim(name);
        sku = safeTrim(sku);
        spec = safeTrim(spec);
        SQLiteDatabase db = getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put("type", type);
        cv.put("name", name);
        cv.put("sku", sku);
        cv.put("spec", spec);
        cv.put("qty", qty);
        cv.put("safety", safety);

        String where = "type=? AND name=? AND COALESCE(sku,'')=? AND COALESCE(spec,'')=?";
        String[] args = new String[]{type, name, sku, spec};

        try {
            int updated = db.update("inventory_items", cv, where, args);
            if (updated <= 0) {
                db.insertWithOnConflict("inventory_items", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
            }
        } catch (Exception e) {
            try { db.insertWithOnConflict("inventory_items", null, cv, SQLiteDatabase.CONFLICT_REPLACE); } catch (Exception ignored) {}
        }
    }



// ✅ inventory_items：合并写入（按 cloud_id），避免覆盖本地未推送的 qty 变动
private void upsertInventoryItemFromCloudMerge(JSONObject it) {
    if (it == null) return;
    String type = safeTrim(it.optString("type", ""));
    String name = safeTrim(it.optString("name", ""));
    String sku = safeTrim(it.optString("sku", ""));
    String spec = safeTrim(it.optString("spec", ""));
    int qty = it.optInt("qty", 0);
    int safety = it.optInt("safety", 0);

    String cloudId = safeTrim(it.optString("cloud_id", ""));
    if (cloudId.isEmpty()) cloudId = safeTrim(it.optString("id", ""));

    // 云端没有 cloud_id：退回旧逻辑（按 type/name/sku/spec）
    if (cloudId.isEmpty()) {
        upsertInventoryItemFromCloud(type, name, sku, spec, qty, safety);
        return;
    }

    SQLiteDatabase db = getWritableDatabase();
    long localId = -1;
    int localSynced = 0;
    String localExistingCloudId = "";

    Cursor c = null;
    try {
        // 1) 优先按 cloud_id 命中
        c = db.rawQuery("SELECT id, COALESCE(synced,0), COALESCE(cloud_id,''), COALESCE(safety,0) FROM inventory_items WHERE cloud_id=? LIMIT 1", new String[]{cloudId});
        if (c.moveToFirst()) {
            localId = c.getLong(0);
            localSynced = c.getInt(1);
            localExistingCloudId = nvl(c.getString(2));
            int localSafety = c.getInt(3);
            // 如果云端未提供 safety（或为0），保留本地 safety，避免“低库存提醒消失”
            if (safety <= 0 && localSafety > 0) safety = localSafety;
        }
    } catch (Exception ignored) {
    } finally {
        if (c != null) try { c.close(); } catch (Exception ignored) {}
    }

    // 2) 如果按 cloud_id 没命中，尝试用 (type,name,sku,spec) 命中旧行，并把 cloud_id 认领过来。
    //    这是为了兼容旧版本本地库存行没有 cloud_id 的情况（否则会走 fallback 覆盖 qty，导致“库存回弹/重置”）。
    if (localId <= 0) {
        Cursor c2 = null;
        try {
            c2 = db.rawQuery(
                    "SELECT id, COALESCE(synced,0), COALESCE(cloud_id,''), COALESCE(safety,0) FROM inventory_items " +
                            "WHERE type=? AND name=? AND COALESCE(sku,'')=? AND COALESCE(spec,'')=? LIMIT 1",
                    new String[]{type, name, sku, spec}
            );
            if (c2.moveToFirst()) {
                localId = c2.getLong(0);
                localSynced = c2.getInt(1);
                localExistingCloudId = nvl(c2.getString(2));
                int localSafety2 = c2.getInt(3);
                if (safety <= 0 && localSafety2 > 0) safety = localSafety2;

                // 旧行没有 cloud_id：直接写入云端 cloud_id，并标记为待同步（synced=0）
                if (localExistingCloudId.isEmpty()) {
                    ContentValues fix = new ContentValues();
                    fix.put("cloud_id", cloudId);
                    // 这里不动 qty；同时标记为 unsynced，确保下一次 push 会把本地 qty 推上云端。
                    fix.put("synced", 0);
                    db.update("inventory_items", fix, "id=?", new String[]{String.valueOf(localId)});
                    localExistingCloudId = cloudId;
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (c2 != null) try { c2.close(); } catch (Exception ignored) {}
        }
    }

    ContentValues cv = new ContentValues();
    cv.put("type", type);
    cv.put("name", name);
    cv.put("sku", sku);
    cv.put("spec", spec);
    cv.put("safety", safety);
    cv.put("cloud_id", cloudId);
    String cloudUpdatedAt = safeTrim(it.optString("updated_at", it.optString("updatedAt", "")));
    if (!cloudUpdatedAt.isEmpty()) cv.put("updated_at", cloudUpdatedAt);

    if (localId > 0) {
        if (localSynced == 0) {
            // 本地有未推送改动：不覆盖 qty，只补齐其他字段
            db.update("inventory_items", cv, "id=?", new String[]{String.valueOf(localId)});
        } else {
            cv.put("qty", qty);
            cv.put("synced", 1);
            db.update("inventory_items", cv, "id=?", new String[]{String.valueOf(localId)});
        }
    } else {
        cv.put("qty", qty);
        cv.put("synced", 1);
        db.insertWithOnConflict("inventory_items", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }
}

    // ✅ 清理本地库存重复（同 type+name+spec）：合并数量后删除多余行，避免库存名称无限复制
    private void dedupInventoryItems(SQLiteDatabase db) {
        if (db == null) return;
        try {
            // 合并 qty/safety 到保留行（id 最小）
            db.execSQL("UPDATE inventory_items SET " +
                    "qty = (SELECT SUM(qty) FROM inventory_items t2 WHERE t2.type=inventory_items.type AND t2.name=inventory_items.name AND t2.spec=inventory_items.spec)," +
                    "safety = (SELECT MAX(safety) FROM inventory_items t2 WHERE t2.type=inventory_items.type AND t2.name=inventory_items.name AND t2.spec=inventory_items.spec) " +
                    "WHERE id IN (SELECT MIN(id) FROM inventory_items GROUP BY type,name,spec)");
            // 删除重复行（保留 id 最小那行）
            db.execSQL("DELETE FROM inventory_items WHERE id NOT IN (SELECT MIN(id) FROM inventory_items GROUP BY type,name,spec)");
        } catch (Exception ignored) {}
    }

// ---------- CLOUD（用于 SupabaseSyncManager） ----------

    public void applyMasterDataFromCloud(JSONObject o) {
        // 目前同步走 replaceMasterDataFromCloud（覆盖式恢复），这里保留兼容接口
        replaceMasterDataFromCloud(o);
    }

    /**
     * ✅ 从云端 master-data 覆盖恢复本地（换手机/重装后能恢复）。
     * 期望 JSON:
     * - customers: [{name/contact 或 customer_name/customer_contact ...}]
     * - products: [{name/packing_units/price ...}]
     * - orders: [{date, customer/customer_name, product/product_name, pieces, quantity, price, location, remark}]
     */
    public void replaceMasterDataFromCloud(JSONObject o) {
        if (o == null) return;

        JSONArray customers = o.optJSONArray("customers");
        JSONArray products = o.optJSONArray("products");
        JSONArray orders = o.optJSONArray("orders");
        JSONArray orderItems = o.optJSONArray("order_items");
        JSONArray templates = o.optJSONArray("print_templates");
        JSONArray arInvoices = o.optJSONArray("ar_invoices");
        JSONArray arPayments = o.optJSONArray("ar_payments");
        JSONArray arAllocations = o.optJSONArray("ar_allocations");

        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            if (customers != null) {
                long localCustomers = android.database.DatabaseUtils.queryNumEntries(db, "customers");
                boolean protectCustomers = customers.length() == 0 && localCustomers > 0;
                if (!protectCustomers) {
                    db.delete("customers", null, null);
                } else {
                    Log.w("DatabaseHelper", "云端恢复 customers 为空，已跳过覆盖本地，保留现有 " + localCustomers + " 条客户");
                }
                for (int i = 0; i < customers.length(); i++) {
                    JSONObject r = customers.optJSONObject(i);
                    if (r == null) continue;
                    String cloudId = nvl(r.optString("cloud_id"));
                    if (cloudId.isEmpty()) cloudId = nvl(r.optString("id"));
                    String name = nvl(r.optString("name"));
                    if (name.isEmpty()) name = nvl(r.optString("customer_name"));
                    String contact = nvl(r.optString("contact"));
                    if (contact.isEmpty()) contact = nvl(r.optString("customer_contact"));
                    if (name.isEmpty()) continue;
                    ContentValues cv = new ContentValues();
                    if (!cloudId.isEmpty()) cv.put("cloud_id", cloudId);
                    cv.put("name", name);
                    cv.put("contact", contact);
                    String updatedAt = nvl(r.optString("updated_at"));
                    if (updatedAt.isEmpty()) updatedAt = nowIso8601();
                    cv.put("updated_at", updatedAt);
                    db.insertWithOnConflict("customers", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
                }
            }

            if (products != null) {
                long localProducts = android.database.DatabaseUtils.queryNumEntries(db, "products");
                boolean protectProducts = products.length() == 0 && localProducts > 0;
                if (!protectProducts) {
                    db.delete("products", null, null);
                } else {
                    Log.w("DatabaseHelper", "云端恢复 products 为空，已跳过覆盖本地，保留现有 " + localProducts + " 条产品");
                }
                for (int i = 0; i < products.length(); i++) {
                    JSONObject r = products.optJSONObject(i);
                    if (r == null) continue;
                    String cloudId = nvl(r.optString("cloud_id"));
                    if (cloudId.isEmpty()) cloudId = nvl(r.optString("id"));
                    String name = nvl(r.optString("name"));
                    if (name.isEmpty()) name = nvl(r.optString("product_name"));
                    if (name.isEmpty()) continue;

                    int packing = r.has("packing_units") ? r.optInt("packing_units", 1) : r.optInt("packingUnits", 1);
                    if (packing <= 0) packing = 1;
                    double price = r.has("price") ? r.optDouble("price", 0) : r.optDouble("unit_price", 0);

                    ContentValues cv = new ContentValues();
                    if (!cloudId.isEmpty()) cv.put("cloud_id", cloudId);
                    cv.put("name", name);
                    cv.put("packing_units", packing);
                    cv.put("price", price);
                    String updatedAt = nvl(r.optString("updated_at"));
                    if (updatedAt.isEmpty()) updatedAt = nowIso8601();
                    cv.put("updated_at", updatedAt);
                    db.insertWithOnConflict("products", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
                }
            }

            // ✅ 模板中心：从云端恢复（卸载重装后默认模板可直接使用）
            if (templates != null) {
                long localTemplates = android.database.DatabaseUtils.queryNumEntries(db, "print_templates");
                boolean protectTemplates = templates.length() == 0 && localTemplates > 0;
                if (!protectTemplates) {
                    db.delete("print_templates", null, null);
                } else {
                    Log.w("DatabaseHelper", "云端恢复 print_templates 为空，已跳过覆盖本地，保留现有 " + localTemplates + " 条模板");
                }
                for (int i = 0; i < templates.length(); i++) {
                    JSONObject r = templates.optJSONObject(i);
                    if (r == null) continue;
                    String cloudId = nvl(r.optString("cloud_id"));
                    if (cloudId.isEmpty()) cloudId = nvl(r.optString("id"));
                    String type = nvl(r.optString("type"));
                    String name = nvl(r.optString("name"));
                    String content = nvl(r.optString("content"));
                    long updatedAt = 0;
                    try { updatedAt = r.has("updated_at") ? r.optLong("updated_at", 0) : r.optLong("updatedAt", 0); } catch (Exception ignored) {}
                    int isDefault = 0;
                    try { isDefault = r.has("is_default") ? r.optInt("is_default", 0) : r.optInt("isDefault", 0); } catch (Exception ignored) {}

                    if (type.isEmpty() || content.isEmpty()) continue;
                    ContentValues cv = new ContentValues();
                    if (!cloudId.isEmpty()) cv.put("cloud_id", cloudId);
                    cv.put("type", type);
                    cv.put("name", name);
                    cv.put("content", content);
                    cv.put("updated_at", updatedAt);
                    cv.put("is_default", isDefault);
                    db.insertWithOnConflict("print_templates", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
                }
            }

            // ✅ v15：财务/对账云端表恢复（覆盖式）
            // 说明：这些表目前只用于“云端主，卸载重装可恢复”。
            // 后续 UI 启用时，再做更精细的增量合并。
            if (arInvoices != null) {
                db.delete("ar_invoices", null, null);
                for (int i = 0; i < arInvoices.length(); i++) {
                    JSONObject r = arInvoices.optJSONObject(i);
                    if (r == null) continue;
                    String cloudId = nvl(r.optString("cloud_id"));
                    if (cloudId.isEmpty()) cloudId = nvl(r.optString("id"));
                    String site = nvl(r.optString("site_name"));
                    if (site.isEmpty()) site = nvl(r.optString("location"));
                    String customer = nvl(r.optString("customer_name"));
                    String periodYm = nvl(r.optString("period_ym"));
                    double amount = r.optDouble("amount", 0);
                    String status = nvl(r.optString("status"));
                    String note = nvl(r.optString("note"));
                    long updatedAt = 0;
                    try { updatedAt = r.has("updated_at") ? r.optLong("updated_at", 0) : 0; } catch (Exception ignored) {}
                    if (updatedAt <= 0) updatedAt = System.currentTimeMillis();
                    ContentValues cv = new ContentValues();
                    if (!cloudId.isEmpty()) cv.put("cloud_id", cloudId);
                    cv.put("site_name", site);
                    cv.put("customer_name", customer);
                    cv.put("period_ym", periodYm);
                    cv.put("amount", amount);
                    cv.put("status", status.isEmpty() ? "OPEN" : status);
                    cv.put("note", note);
                    cv.put("created_at", updatedAt);
                    cv.put("updated_at", updatedAt);
                    cv.put("synced", 1);
                    cv.put("is_deleted", 0);
                    db.insertWithOnConflict("ar_invoices", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
                }
            }

            if (arPayments != null) {
                db.delete("ar_payments", null, null);
                for (int i = 0; i < arPayments.length(); i++) {
                    JSONObject r = arPayments.optJSONObject(i);
                    if (r == null) continue;
                    String cloudId = nvl(r.optString("cloud_id"));
                    if (cloudId.isEmpty()) cloudId = nvl(r.optString("id"));
                    String site = nvl(r.optString("site_name"));
                    if (site.isEmpty()) site = nvl(r.optString("location"));
                    String customer = nvl(r.optString("customer_name"));
                    double amount = r.optDouble("amount", 0);
                    String payDate = nvl(r.optString("pay_date"));
                    String method = nvl(r.optString("method"));
                    String note = nvl(r.optString("note"));
                    long updatedAt = 0;
                    try { updatedAt = r.has("updated_at") ? r.optLong("updated_at", 0) : 0; } catch (Exception ignored) {}
                    if (updatedAt <= 0) updatedAt = System.currentTimeMillis();
                    ContentValues cv = new ContentValues();
                    if (!cloudId.isEmpty()) cv.put("cloud_id", cloudId);
                    cv.put("site_name", site);
                    cv.put("customer_name", customer);
                    cv.put("amount", amount);
                    cv.put("pay_date", payDate);
                    cv.put("method", method);
                    cv.put("note", note);
                    cv.put("created_at", updatedAt);
                    cv.put("updated_at", updatedAt);
                    cv.put("synced", 1);
                    cv.put("is_deleted", 0);
                    db.insertWithOnConflict("ar_payments", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
                }
            }

            if (arAllocations != null) {
                db.delete("ar_allocations", null, null);
                for (int i = 0; i < arAllocations.length(); i++) {
                    JSONObject r = arAllocations.optJSONObject(i);
                    if (r == null) continue;
                    String cloudId = nvl(r.optString("cloud_id"));
                    if (cloudId.isEmpty()) cloudId = nvl(r.optString("id"));
                    String site = nvl(r.optString("site_name"));
                    if (site.isEmpty()) site = nvl(r.optString("location"));
                    String invCid = nvl(r.optString("invoice_cloud_id"));
                    String payCid = nvl(r.optString("payment_cloud_id"));
                    double amount = r.optDouble("amount", 0);
                    String note = nvl(r.optString("note"));
                    long updatedAt = 0;
                    try { updatedAt = r.has("updated_at") ? r.optLong("updated_at", 0) : 0; } catch (Exception ignored) {}
                    if (updatedAt <= 0) updatedAt = System.currentTimeMillis();
                    if (invCid.isEmpty() || payCid.isEmpty()) continue;
                    ContentValues cv = new ContentValues();
                    if (!cloudId.isEmpty()) cv.put("cloud_id", cloudId);
                    cv.put("site_name", site);
                    cv.put("invoice_cloud_id", invCid);
                    cv.put("payment_cloud_id", payCid);
                    cv.put("amount", amount);
                    cv.put("note", note);
                    cv.put("created_at", updatedAt);
                    cv.put("updated_at", updatedAt);
                    cv.put("synced", 1);
                    cv.put("is_deleted", 0);
                    db.insertWithOnConflict("ar_allocations", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
                }
            }

            
            // ✅ 库存：从云端恢复 inventory_items（合并写入，避免覆盖本地未推送扣减）
            // 同时补齐“云端已删除 → 本地也要消失”（多设备一致性）。
            JSONArray inv = o.optJSONArray("inventory_items");
            java.util.HashSet<String> invCloudIds = null;
            if (inv != null) {
                invCloudIds = new java.util.HashSet<>();
                for (int i = 0; i < inv.length(); i++) {
                    JSONObject it = inv.optJSONObject(i);
                    if (it == null) continue;
                    String cid = nvl(it.optString("cloud_id"));
                    if (cid.isEmpty()) cid = nvl(it.optString("id"));
                    if (!cid.isEmpty()) invCloudIds.add(cid);
                    upsertInventoryItemFromCloudMerge(it);
                }
            }
            // ✅ 云端删除对齐：如果云端已无该 cloud_id 且本地没有待同步变更（synced=1），则删除本地库存项及其流水。
            // 说明：本地新建未推送的库存项 synced=0，不会被误删。
            if (invCloudIds != null) {
                try {
                    java.util.ArrayList<String> args = new java.util.ArrayList<>();
                    StringBuilder sb = new StringBuilder();
                    sb.append("SELECT id,cloud_id FROM inventory_items WHERE cloud_id IS NOT NULL AND cloud_id<>'' AND COALESCE(synced,0)=1");
                    try (Cursor c = db.rawQuery(sb.toString(), null)) {
                        while (c.moveToNext()) {
                            long localId = c.getLong(0);
                            String cid = nvl(c.getString(1));
                            if (!cid.isEmpty() && !invCloudIds.contains(cid)) {
                                // 删除库存项
                                db.delete("inventory_items", "id=?", new String[]{String.valueOf(localId)});
                                // 删除流水
                                try { db.delete("inventory_movements", "item_id=?", new String[]{String.valueOf(localId)}); } catch (Exception ignored) {}
                            }
                        }
                    }
                } catch (Exception ignored) {}
            }
            // ✅ 去重：防止库存名称被无限复制
            dedupInventoryItems(db);

if (orders != null) {
                // ✅ 不再清空本地 orders：改为按 cloud_id 合并写入，避免 printed/synced 被 pull 清零
                for (int i = 0; i < orders.length(); i++) {
                    JSONObject r = orders.optJSONObject(i);
                    if (r == null) continue;

                    String cloudId = nvl(r.optString("cloud_id"));
                    if (cloudId.isEmpty()) cloudId = nvl(r.optString("id"));

                    String date = nvl(r.optString("date"));
                    String customer = nvl(r.optString("customer"));
                    if (customer.isEmpty()) customer = nvl(r.optString("customer_name"));
                    String product = nvl(r.optString("product"));
                    if (product.isEmpty()) product = nvl(r.optString("product_name"));

                    date = normalizeCloudDate(date);

                    if (date.isEmpty() || customer.isEmpty() || product.isEmpty()) continue;

                    int pieces = r.optInt("pieces", 0);
                    int quantity = r.optInt("quantity", 0);
                    double price = r.optDouble("price", 0);
                    String location = nvl(r.optString("location"));
                    String remark = nvl(r.optString("remark"));
                    String status = nvl(r.optString("status"));
                    String cloudUpdatedAt = nvl(r.optString("updated_at"));
                    String cloudCreatedAt = nvl(r.optString("created_at"));
                    String printedAt = nvl(r.optString("printed_at"));
                    String shippedAt = nvl(r.optString("shipped_at"));
                    String settledAt = nvl(r.optString("settled_at"));
                    int isDeleted = r.optInt("is_deleted", 0);
                    String deletedAt = nvl(r.optString("deleted_at"));
                    String voidedAt = nvl(r.optString("voided_at"));

                    // 同步冲突：以 updated_at 最新为准（最后写入优先）
                    String cloudCreated = nvl(r.optString("created_at"));
                    if (cloudCreated.isEmpty()) cloudCreated = nvl(r.optString("createdAt"));
                    String cloudUpdated = nvl(r.optString("updated_at"));
                    if (cloudUpdated.isEmpty()) cloudUpdated = nvl(r.optString("updatedAt"));
                    long cloudUpdatedMs = parseIsoToMillis(cloudUpdated);
                    if (cloudUpdatedMs <= 0) cloudUpdatedMs = System.currentTimeMillis();
                    int totalQty = r.has("total_quantity") ? r.optInt("total_quantity", 0) : r.optInt("total_qty", 0);
                    double totalAmt = r.has("total_amount") ? r.optDouble("total_amount", 0) : r.optDouble("total", 0);
                    if (totalQty == 0) totalQty = quantity;
                    if (totalAmt == 0) totalAmt = quantity * price;

                    ContentValues cv = new ContentValues();
                    cv.put("date", date);
                    cv.put("customer_name", customer);
                    cv.put("product_name", product);
                    cv.put("pieces", pieces);
                    cv.put("quantity", quantity);
                    cv.put("price", price);
                    cv.put("location", location);
                    cv.put("remark", remark);
                    String st = status.isEmpty() ? "CONFIRMED" : status;
                    cv.put("status", st);
                    // Step2：云端若标记 VOID，则本地也视为删除/作废
                    if ("VOID".equalsIgnoreCase(st)) {
                        cv.put("is_deleted", 1);
                        cv.put("deleted_at", nowIso8601());
                        cv.put("cloud_delete_tracked", 1);
                        cv.put("voided_at", nowIso8601());
                    } else {
                        cv.put("is_deleted", 0);
                        cv.put("cloud_delete_tracked", 0);
                    }
                    cv.put("total_quantity", totalQty);
                    cv.put("total_amount", totalAmt);
                    if (!cloudCreated.isEmpty()) cv.put("created_at", cloudCreated);
                    if (cloudUpdated == null || cloudUpdated.trim().isEmpty()) cloudUpdated = nowIso8601();
                    cv.put("updated_at", cloudUpdated);
                    if (!cloudId.isEmpty()) cv.put("cloud_id", cloudId);

                    // pull 下来的记录默认视为已同步（除非本地有未推送改动）
                    cv.put("synced", 1);

                    long localId = -1;
                    int localPrinted = 0;
                    int localSynced = 1;
                    long localUpdatedMs = 0;

                    if (!cloudId.isEmpty()) {
                        Cursor c = null;
                        try {
                            c = db.rawQuery("SELECT id, COALESCE(printed,0), COALESCE(synced,1), COALESCE(updated_at,''), COALESCE(status,''), COALESCE(is_deleted,0) FROM orders WHERE cloud_id=?", new String[]{cloudId});
                            if (c.moveToFirst()) {
                                localId = c.getLong(0);
                                localPrinted = c.getInt(1);
                                localSynced = c.getInt(2);
                                String localUpdatedAt = nvl(c.getString(3));
                                String localStatus = nvl(c.getString(4));
                                int localIsDeleted = c.getInt(5);

                                // ✅ Step2-1：冲突策略（Last-write-wins）：updated_at 更新更晚者优先
                                long localMs = parseIsoToMillis(localUpdatedAt);
                                long cloudMs = parseIsoToMillis(cloudUpdatedAt);
                                boolean keepLocal = (localSynced == 0) || (localMs > 0 && cloudMs > 0 && localMs > cloudMs);
                                if (keepLocal) {
                                    // 保留本地：只修正 cloud_id（如果缺失）
                                    if (!cloudId.isEmpty()) {
                                        ContentValues fix = new ContentValues();
                                        fix.put("cloud_id", cloudId);
                                        db.update("orders", fix, "id=?", new String[]{String.valueOf(localId)});
                                    }
                                    continue;
                                }

                                // 删除/作废合并：云端已作废则本地必须作废
                                if (isDeleted == 1 && localIsDeleted == 0) {
                                    // 云端更晚且已删除：以云端为准
                                }

                                // printed 合并：取最大（避免被 pull 清零）
                                if (localPrinted == 1 && r.optInt("printed", 0) == 0) {
                                    cv.put("printed", 1);
                                }
                                
                                localUpdatedMs = parseIsoToMillis(nvl(c.getString(3)));
                            }
                        } catch (Exception ignored) {
                        } finally {
                            if (c != null) try { c.close(); } catch (Exception ignored) {}
                        }
                    }

                    int cloudPrinted = r.optInt("printed", 0);

                    if (localId > 0) {
                        // Step2：冲突策略（最后写入优先）
                        // - 如果本地有未同步修改：仅当云端 updated_at 更新更晚，才用云端覆盖
                        // - 其它情况：谁的 updated_at 更新更晚，谁生效
                        boolean cloudIsNewer = cloudUpdatedMs >= Math.max(0, localUpdatedMs);
                        boolean shouldApplyCloud = (localSynced == 0) ? cloudIsNewer : cloudIsNewer;

                        if (shouldApplyCloud) {
                            // 覆盖云端内容，但打印状态取“最大值”（避免 pull 清零）
                            cv.put("printed", Math.max(localPrinted, cloudPrinted));
                            // pull 下来的记录默认视为已同步（除非本地仍在编辑）
                            cv.put("synced", 1);
                            db.update("orders", cv, "id=?", new String[]{String.valueOf(localId)});
                        } else {
                            // 本地更新更晚：仅回填 cloud_id（若需要），不覆盖本地内容
                            ContentValues cvMin = new ContentValues();
                            if (!cloudId.isEmpty()) cvMin.put("cloud_id", cloudId);
                            if (cvMin.size() > 0) db.update("orders", cvMin, "id=?", new String[]{String.valueOf(localId)});
                        }
                    } else {
                        // 新订单
                        cv.put("printed", cloudPrinted);
                        cv.put("synced", 1);
                        db.insert("orders", null, cv);
                    }

                    // ✅ 若云端订单带了场地，也顺便加入 locations 表，保证下拉里能看到
                    if (location != null && !location.trim().isEmpty()) {
                        try { addLocation(location); } catch (Exception ignored) {}
                    }
                }
            }



// ✅ 物流单：从云端恢复（卸载重装后能回来）
JSONArray logisticsForms = o.optJSONArray("logistics_forms");
JSONArray logisticsSizes = o.optJSONArray("logistics_sizes");
if (logisticsForms != null) {
    // 清空本地
    try { db.delete("logistics_sizes", null, null); } catch (Exception ignored) {}
    try { db.delete("logistics_forms", null, null); } catch (Exception ignored) {}

    java.util.HashMap<String, Long> cloudFormIdToLocalId = new java.util.HashMap<>();
    for (int i = 0; i < logisticsForms.length(); i++) {
        JSONObject lf = logisticsForms.optJSONObject(i);
        if (lf == null) continue;
        String date = nvl(lf.optString("date", ""));
        String location = nvl(lf.optString("location", ""));
        int totalPieces = lf.optInt("total_pieces", lf.optInt("totalPieces", 0));
        double totalCbm = lf.optDouble("total_cbm", lf.optDouble("totalCbm", 0));
        String remark = nvl(lf.optString("remark", ""));
        String cloudId = nvl(lf.optString("id", ""));

        ContentValues cv = new ContentValues();
        cv.put("date", date);
        cv.put("location", location);
        cv.put("total_pieces", totalPieces);
        cv.put("total_cbm", totalCbm);
        cv.put("remark", remark);
        // ✅ 云端拉取回来的单：写入 cloud_id，并标记为已同步，避免“卸载重装后再次 push 造成云端重复”
        if (!cloudId.isEmpty()) cv.put("cloud_id", cloudId);
        cv.put("synced", 1);
        long localId = db.insert("logistics_forms", null, cv);
        if (!cloudId.isEmpty() && localId > 0) cloudFormIdToLocalId.put(cloudId, localId);

        // location 下拉补齐
        if (!location.trim().isEmpty()) {
            try { addLocation(location); } catch (Exception ignored) {}
        }
    }

    // 插入 sizes
    if (logisticsSizes != null) {
        // ✅ 幂等：同一物流单每次从云端恢复前先清空旧尺寸，避免重复累加
        java.util.HashSet<Long> clearedLogisticsIds = new java.util.HashSet<>();
        for (int i = 0; i < logisticsSizes.length(); i++) {
            JSONObject s = logisticsSizes.optJSONObject(i);
            if (s == null) continue;
            String formId = nvl(s.optString("form_id", s.optString("logistics_form_id", "")));
            long localFormId = -1;
            if (!formId.isEmpty() && cloudFormIdToLocalId.containsKey(formId)) {
                localFormId = cloudFormIdToLocalId.get(formId);
            }
            // 兜底：如果云端没有 form_id，就跳过（避免插错）
            if (localFormId <= 0) continue;

            // ✅ 幂等：只对每个物流单清空一次旧尺寸（防止多次同步重复插入）
            if (!clearedLogisticsIds.contains(localFormId)) {
                db.delete("logistics_sizes", "logistics_id=?", new String[]{String.valueOf(localFormId)});
                clearedLogisticsIds.add(localFormId);
            }

            double len = s.optDouble("len", s.optDouble("length", 0));
            double wid = s.optDouble("wid", s.optDouble("width", 0));
            double hei = s.optDouble("hei", s.optDouble("height", 0));
            int pieces = s.optInt("pieces", 0);
            double cbm = s.optDouble("cbm", 0);

            ContentValues cv = new ContentValues();
            cv.put("logistics_id", localFormId);
            cv.put("len", len);
            cv.put("wid", wid);
            cv.put("hei", hei);
            cv.put("pieces", pieces);
            cv.put("cbm", cbm);
            db.insert("logistics_sizes", null, cv);
        }
    }
}

            
            // ✅ order_items：从云端恢复（按 cloud_id 合并，避免覆盖本地未同步修改）
            if (orderItems != null) {
                for (int i = 0; i < orderItems.length(); i++) {
                    JSONObject r = orderItems.optJSONObject(i);
                    if (r == null) continue;

                    String cloudId = nvl(r.optString("cloud_id"));
                    if (cloudId.isEmpty()) cloudId = nvl(r.optString("id"));
                    String orderCloudId = nvl(r.optString("order_cloud_id"));
                    if (orderCloudId.isEmpty()) orderCloudId = nvl(r.optString("order_id"));

                    String product = nvl(r.optString("product"));
                    if (product.isEmpty()) product = nvl(r.optString("product_name"));
                    int pieces = r.has("pieces") ? r.optInt("pieces", 0) : 0;
                    int qty = r.has("quantity") ? r.optInt("quantity", 0) : 0;
                    double price = r.has("price") ? r.optDouble("price", 0) : 0;
                    String remark = nvl(r.optString("remark"));

                    boolean isDel = r.has("is_deleted") ? (r.optInt("is_deleted", 0) == 1 || r.optBoolean("is_deleted", false)) : false;
                    String deletedAt = nvl(r.optString("deleted_at"));
                    String createdAt = nvl(r.optString("created_at"));
                    String updatedAt = nvl(r.optString("updated_at"));

                    ContentValues cv = new ContentValues();
                    cv.put("order_cloud_id", orderCloudId);
                    cv.put("product_name", product);
                    cv.put("pieces", pieces);
                    cv.put("quantity", qty);
                    cv.put("price", price);
                    cv.put("remark", remark);
                    if (!cloudId.isEmpty()) cv.put("cloud_id", cloudId);
                    cv.put("is_deleted", isDel ? 1 : 0);
                    if (!deletedAt.isEmpty()) cv.put("deleted_at", deletedAt);
                    if (!createdAt.isEmpty()) cv.put("created_at", createdAt);
                    if (!updatedAt.isEmpty()) cv.put("updated_at", updatedAt);

                    // pull 下来的记录默认视为已同步
                    cv.put("synced", 1);

                    long localId = -1;
                    int localSynced = 1;
                    if (!cloudId.isEmpty()) {
                        Cursor c = null;
                        try {
                            c = db.rawQuery("SELECT id, synced FROM order_items WHERE cloud_id=?", new String[]{cloudId});
                            if (c.moveToFirst()) {
                                localId = c.getLong(0);
                                localSynced = c.getInt(1);
                            }
                        } catch (Exception ignored) {
                        } finally {
                            if (c != null) try { c.close(); } catch (Exception ignored) {}
                        }
                    }

                    if (localId > 0) {
                        if (localSynced == 0) {
                            // 本地有未推送改动：只补齐 cloud_id / order_cloud_id
                            ContentValues cvMin = new ContentValues();
                            if (!cloudId.isEmpty()) cvMin.put("cloud_id", cloudId);
                            if (!orderCloudId.isEmpty()) cvMin.put("order_cloud_id", orderCloudId);
                            if (cvMin.size() > 0) db.update("order_items", cvMin, "id=?", new String[]{String.valueOf(localId)});
                        } else {
                            db.update("order_items", cv, "id=?", new String[]{String.valueOf(localId)});
                        }
                    } else {
                        db.insert("order_items", null, cv);
                    }
                }
            }

db.setTransactionSuccessful();
        }
        finally {
            try {
                if (db != null && db.inTransaction()) db.endTransaction();
            } catch (Throwable ignore) {}
        }

        // ✅ 再保证一次默认场地一定在 locations 里
        try { ensureDefaultLocationSeeded(); } catch (Exception ignored) {}
    }

    public void applyTemplatesFromCloud(JSONObject o) {
        // 本版本暂不做模板云同步
    }

    public List<SyncQueueItem> getPendingSyncQueue(int l) { return new ArrayList<>(); }
    public void markSyncQueueDone(long id) { }

    /**
     * ✅ 导出本地 master-data（供 SupabaseSyncManager upsert）。
     * - 单账号模式：orgId 为空 -> 继续写 owner_uid
     * - 组织共享模式：orgId 不为空 -> customers/products/print_templates 写 org_id（且稳定 id 用 orgId 做种子）
     */
    public JSONObject exportMasterDataForCloud(String uid) {
        return exportMasterDataForCloud(uid, null);
    }

    public JSONObject exportMasterDataForCloud(String uid, String orgId) {
        JSONObject out = new JSONObject();
        String seed = (orgId != null && !orgId.trim().isEmpty()) ? orgId.trim() : uid;
        try {
            JSONArray cs = new JSONArray();
            SQLiteDatabase db = getReadableDatabase();
            // ✅ customers：确保 cloud_id 不为空（用于云端精确 upsert/delete）
            try { backfillCloudIdIfMissing("customers"); } catch (Exception ignored) {}
            try (Cursor c = db.rawQuery("SELECT cloud_id,name,contact,updated_at FROM customers", null)) {
                while (c.moveToNext()) {
                    JSONObject r = new JSONObject();
                    // 兼容：仍保留 owner_uid（审计），共享则额外写 org_id
                    r.put("owner_uid", uid);
                    if (orgId != null && !orgId.trim().isEmpty()) r.put("org_id", orgId.trim());
                    r.put("id", nvl(c.getString(0)));
r.put("name", nvl(c.getString(1)));
                    r.put("contact", nvl(c.getString(2)));
                    String updatedAt = nvl(c.getString(3));
                    r.put("updated_at", updatedAt.isEmpty() ? JSONObject.NULL : updatedAt);
                    cs.put(r);
                }
            }
            out.put("customers", cs);

            JSONArray ps = new JSONArray();
            // ✅ products：确保 cloud_id 不为空（用于云端精确 upsert/delete）
            try { backfillCloudIdIfMissing("products"); } catch (Exception ignored) {}
            try (Cursor c = db.rawQuery("SELECT cloud_id,name,packing_units,price,updated_at FROM products", null)) {
                while (c.moveToNext()) {
                    JSONObject r = new JSONObject();
                    r.put("owner_uid", uid);
                    if (orgId != null && !orgId.trim().isEmpty()) r.put("org_id", orgId.trim());
                    r.put("id", nvl(c.getString(0)));
r.put("name", nvl(c.getString(1)));
                    r.put("packing_units", c.getInt(2));
                    r.put("price", c.getDouble(3));
                    String updatedAt = nvl(c.getString(4));
                    r.put("updated_at", updatedAt.isEmpty() ? JSONObject.NULL : updatedAt);
                    ps.put(r);
                }
            }
            out.put("products", ps);

            // ✅ inventory_items：不共享（仍然按 owner_uid）
            JSONArray inv = new JSONArray();

            // ✅ P0：确保本地 inventory_items.cloud_id 不为空（云端 NOT NULL）
            backfillCloudIdIfMissing("inventory_items");

            try (Cursor c = db.rawQuery("SELECT cloud_id,type,name,sku,spec,qty,safety,updated_at FROM inventory_items", null)) {
                while (c.moveToNext()) {
                    JSONObject r = new JSONObject();
                    r.put("owner_uid", uid);
                    String cloudId = nvl(c.getString(0));
                    r.put("cloud_id", cloudId);
                    r.put("id", cloudId);
                    r.put("type", nvl(c.getString(1)));
                    r.put("name", nvl(c.getString(2)));
                    r.put("sku", nvl(c.getString(3)));
                    r.put("spec", nvl(c.getString(4)));
                    r.put("qty", c.getInt(5));
                    r.put("safety", c.getInt(6));
                    String updatedAt = nvl(c.getString(7));
                    r.put("updated_at", updatedAt.isEmpty() ? nowIso8601() : updatedAt);
                    inv.put(r);
                }
            } catch (Exception ignored) {}
            out.put("inventory_items", inv);

            // ✅ inventory_movements：不共享（仍然按 owner_uid）
            JSONArray movs = new JSONArray();
            try (Cursor c = db.rawQuery("SELECT item_id,change_qty,reason,ref_type,ref_id,date,uuid,created_at FROM inventory_movements", null)) {
                while (c.moveToNext()) {
                    JSONObject r = new JSONObject();
                    r.put("owner_uid", uid);
                    r.put("item_id", c.getLong(0));
                    r.put("change_qty", c.getInt(1));
                    r.put("reason", nvl(c.getString(2)));
                    r.put("ref_type", nvl(c.getString(3)));
                    r.put("ref_id", c.getInt(4));
                    r.put("date", nvl(c.getString(5)));
                    r.put("uuid", nvl(c.getString(6)));
                    r.put("created_at", c.getLong(7));
                    movs.put(r);
                }
            } catch (Exception ignored) {}
            out.put("inventory_movements", movs);

            // ✅ print_templates：共享（走 org_id）。
            // - 本地保存 cloud_id（默认随机），但云端为了去重更稳定：优先使用“内容级稳定 id”。
            // - 当本地 cloud_id 为空时，这里会把稳定 id 写回本地，保证后续删除/更新都能精确对齐。
            JSONArray tpls = new JSONArray();
            try { backfillCloudIdIfMissing("print_templates"); } catch (Exception ignored) {}
            try (Cursor c = db.rawQuery("SELECT id,cloud_id,type,name,content,updated_at,is_default FROM print_templates", null)) {
                while (c.moveToNext()) {
                    long localId = c.getLong(0);
                    String localCloudId = nvl(c.getString(1));
                    String type = nvl(c.getString(2));
                    String name = nvl(c.getString(3));
                    String content = nvl(c.getString(4));
                    long updatedAt = c.getLong(5);
                    int isDefault = c.getInt(6);

                    JSONObject r = new JSONObject();
                    r.put("owner_uid", uid);
                    if (orgId != null && !orgId.trim().isEmpty()) r.put("org_id", orgId.trim());

                    // 稳定 id = UUID(nameUUIDFromBytes(seed|tpl|type|name|sha1(content)))
                    String h = sha1(content);
                    String stableId = java.util.UUID.nameUUIDFromBytes((seed + "|tpl|" + type + "|" + name + "|" + h)
                            .getBytes(java.nio.charset.StandardCharsets.UTF_8)).toString();
                    // 兼容旧云端字段：仍保留 id（如云端 id=uuid 用于主键）
                    r.put("id", stableId);
                    // ✅ 新策略：cloud_id 用于 on_conflict=cloud_id；优先 stableId，避免同模板多端重复
                    // cloud_id 字段云端未必存在；以 id 作为主键对齐

                    // 写回本地，保证后续删除/更新能精确对齐
                    try {
                        if (localId > 0 && (localCloudId == null || localCloudId.trim().isEmpty() || !stableId.equals(localCloudId))) {
                            ContentValues cv = new ContentValues();
                            cv.put("cloud_id", stableId);
                            db.update("print_templates", cv, "id=?", new String[]{String.valueOf(localId)});
                        }
                    } catch (Exception ignored) {}
                    r.put("type", type);
                    r.put("name", name);
                    r.put("content", content);
                    r.put("updated_at", updatedAt);
                    r.put("is_default", isDefault);
                    tpls.put(r);
                }
            } catch (Exception ignored) {}
            out.put("print_templates", tpls);
        } catch (Exception ignored) {
        }
        return out;
    }

    /**
     * ✅ 导出本地新增订单（增量推送到云端 orders 表）。
     * lastLocalId：上次已推送的本地自增 id。
     * 输出字段按 SupabaseSyncManager.sanitizeOrdersForCloud 可识别的 key 生成。
     */
    public JSONArray exportOrdersForCloudSince(String uid, int lastLocalId) {
        JSONArray out = new JSONArray();

        // ✅ P0：确保本地 orders.cloud_id 不为空（云端 NOT NULL）
        backfillCloudIdIfMissing("orders");

        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery(
                "SELECT id,cloud_id,date,customer_name,product_name,pieces,quantity,price,location,remark,status,total_quantity,total_amount " +
                        "FROM orders WHERE id>? ORDER BY id ASC",
                new String[]{String.valueOf(Math.max(0, lastLocalId))})) {
            while (c.moveToNext()) {
                JSONObject r = new JSONObject();
                try {
                    r.put("owner_uid", uid);
                    r.put("cloud_id", nvl(c.getString(1)));
                    r.put("date", nvl(c.getString(2)));
                    r.put("customer", nvl(c.getString(3)));
                    r.put("product", nvl(c.getString(4)));
                    r.put("pieces", c.getInt(5));
                    r.put("quantity", c.getInt(6));
                    r.put("price", c.getDouble(7));
                    r.put("location", nvl(c.getString(8)));
                    r.put("remark", nvl(c.getString(9)));
                    r.put("status", nvl(c.getString(10)).isEmpty() ? "CONFIRMED" : nvl(c.getString(10)));
                    r.put("total_quantity", c.getInt(15));
                    r.put("total_amount", c.getDouble(16));
                } catch (Exception ignored) {
                }
                out.put(r);
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    /**
     * P0-3：导出待同步订单（orders.synced=0），用于云端 upsert。
     * limit 用于避免一次推送过大（建议 200~500）。
     */
    public JSONArray exportOrdersPendingForCloud(String uid, int limit) {
        JSONArray out = new JSONArray();
        backfillCloudIdIfMissing("orders");
        int lim = Math.max(1, Math.min(2000, limit));
        SQLiteDatabase db = getReadableDatabase();
        // columns:
        // 0 cloud_id,1 date,2 customer_name,3 product_name,4 pieces,5 quantity,6 price,7 location,8 remark,
        // 9 printed,10 printed_at,11 status,12 is_deleted,13 deleted_at,14 voided_at,15 total_quantity,16 total_amount,17 updated_at,18 created_at
        try (Cursor c = db.rawQuery(
                "SELECT cloud_id,date,customer_name,product_name,pieces,quantity,price,location,remark,printed,printed_at,status,is_deleted,deleted_at,voided_at,total_quantity,total_amount,updated_at,created_at " +
                        "FROM orders WHERE synced=0 ORDER BY id ASC LIMIT " + lim,
                null)) {
            while (c.moveToNext()) {
                // ⚠️ PostgREST 批量 UPSERT 对数组内对象要求“键集合一致”，否则会报 PGRST102。
                // 旧逻辑按需 put（location/remark/print_last_at/created_at/updated_at/deleted_at 等）会导致：
                // - 第一次上传刚好键集合一致 -> 成功
                // - 后续新增订单键集合不一致 -> 400(PGRST102) -> 看起来像“只上传了一次”
                // 这里统一把所有可能字段都写入（空值写 NULL），保证键集合一致，彻底锁死此类问题。
                JSONObject r = new JSONObject();
                try {
                    r.put("owner_uid", uid);

                    String cloudId = nvl(c.getString(0));
                    // orders.cloud_id 云端为 uuid NOT NULL，理论上本地永远不为空；这里仍做兜底。
                    r.put("cloud_id", cloudId.isEmpty() ? JSONObject.NULL : cloudId);

                    r.put("date", nvl(c.getString(1)));
                    r.put("customer", nvl(c.getString(2)));
                    r.put("product", nvl(c.getString(3)));
                    r.put("pieces", c.getInt(4));
                    r.put("quantity", c.getInt(5));
                    r.put("price", c.getDouble(6));

                    String location = nvl(c.getString(7));
                    r.put("location", location.isEmpty() ? JSONObject.NULL : location);

                    String remark = nvl(c.getString(8));
                    r.put("remark", remark.isEmpty() ? JSONObject.NULL : remark);

                    r.put("printed", c.getInt(9));
                    String printedAt = nvl(c.getString(10));
                    // 云端列名为 print_last_at（timestamp），与本地 printed_at 对应
                    r.put("print_last_at", printedAt.isEmpty() ? JSONObject.NULL : printedAt);

                    String st = nvl(c.getString(11));
                    r.put("status", st.isEmpty() ? "CONFIRMED" : st);

                    boolean isDel = c.getInt(12) != 0;
                    r.put("is_deleted", isDel);

                    String delAt = nvl(c.getString(13));
                    r.put("deleted_at", delAt.isEmpty() ? JSONObject.NULL : delAt);

                    // voided_at 云端也有列（你之前表结构里有），这里同样保持键一致
                    String voidAt = nvl(c.getString(14));
                    r.put("voided_at", voidAt.isEmpty() ? JSONObject.NULL : voidAt);

                    r.put("total_quantity", c.getInt(15));
                    r.put("total_amount", c.getDouble(16));

                    String ua = nvl(c.getString(17));
                    r.put("updated_at", ua.isEmpty() ? JSONObject.NULL : ua);

                    String ca = nvl(c.getString(18));
                    r.put("created_at", ca.isEmpty() ? JSONObject.NULL : ca);

                    // 兼容云端列：tenant（你表结构里叫 tenant）
                    // 本地 orders 表没有 tenant 列，统一写 NULL 以满足键集合一致（存在该列时）
                    // 注意：PostgREST 允许插入/更新时包含该列；若云端无该列，会被忽略/或报错。
                    // 由于你的 orders 表确实有 tenant(text)，这里保留。
                    r.put("tenant", JSONObject.NULL);

                } catch (Exception ignored) {
                }
                out.put(r);
            }
        } catch (Exception ignored) {}
        return out;
    }

    // =========================
    // v15：财务/对账（AR）云端同步
    // - 先保证“新增/修改 -> push、卸载重装 -> pull 恢复”
    // - 删除/冲突处理后续再增强
    // =========================

    public JSONArray exportArInvoicesPendingForCloud(String uid, int limit) {
        JSONArray out = new JSONArray();
        backfillCloudIdIfMissing("ar_invoices");
        int lim = Math.max(1, Math.min(2000, limit));
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery(
                "SELECT cloud_id,site_name,customer_name,period_ym,amount,status,note FROM ar_invoices WHERE synced=0 ORDER BY id ASC LIMIT " + lim,
                null)) {
            while (c.moveToNext()) {
                JSONObject r = new JSONObject();
                try {
                    // 不传 created_by，让云端默认 auth.uid()
                    String cloudId = nvl(c.getString(0));
                    r.put("cloud_id", cloudId.isEmpty() ? JSONObject.NULL : cloudId);
                    r.put("site_name", nvl(c.getString(1)));
                    r.put("customer_name", nvl(c.getString(2)));
                    r.put("period_ym", nvl(c.getString(3)));
                    r.put("amount", c.getDouble(4));
                    String st = nvl(c.getString(5));
                    r.put("status", st.isEmpty() ? "OPEN" : st);
                    String note = nvl(c.getString(6));
                    r.put("note", note.isEmpty() ? JSONObject.NULL : note);
                } catch (Exception ignored) {}
                out.put(r);
            }
        } catch (Exception ignored) {}
        return out;
    }

    public void markArInvoicesSyncedByCloudIds(JSONArray rows) {
        if (rows == null || rows.length() == 0) return;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            for (int i = 0; i < rows.length(); i++) {
                JSONObject r = rows.optJSONObject(i);
                if (r == null) continue;
                String cid = nvl(r.optString("cloud_id"));
                if (cid.isEmpty()) continue;
                ContentValues cv = new ContentValues();
                cv.put("synced", 1);
                cv.put("updated_at", System.currentTimeMillis());
                db.update("ar_invoices", cv, "cloud_id=?", new String[]{cid});
            }
            db.setTransactionSuccessful();
        } catch (Exception ignored) {
        } finally {
            try { db.endTransaction(); } catch (Exception ignored) {}
        }
    }

    public JSONArray exportArPaymentsPendingForCloud(String uid, int limit) {
        JSONArray out = new JSONArray();
        backfillCloudIdIfMissing("ar_payments");
        int lim = Math.max(1, Math.min(2000, limit));
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery(
                "SELECT cloud_id,site_name,customer_name,amount,pay_date,method,note FROM ar_payments WHERE synced=0 ORDER BY id ASC LIMIT " + lim,
                null)) {
            while (c.moveToNext()) {
                JSONObject r = new JSONObject();
                try {
                    String cloudId = nvl(c.getString(0));
                    r.put("cloud_id", cloudId.isEmpty() ? JSONObject.NULL : cloudId);
                    r.put("site_name", nvl(c.getString(1)));
                    r.put("customer_name", nvl(c.getString(2)));
                    r.put("amount", c.getDouble(3));
                    r.put("pay_date", nvl(c.getString(4)));
                    String method = nvl(c.getString(5));
                    r.put("method", method.isEmpty() ? JSONObject.NULL : method);
                    String note = nvl(c.getString(6));
                    r.put("note", note.isEmpty() ? JSONObject.NULL : note);
                } catch (Exception ignored) {}
                out.put(r);
            }
        } catch (Exception ignored) {}
        return out;
    }

    public void markArPaymentsSyncedByCloudIds(JSONArray rows) {
        if (rows == null || rows.length() == 0) return;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            for (int i = 0; i < rows.length(); i++) {
                JSONObject r = rows.optJSONObject(i);
                if (r == null) continue;
                String cid = nvl(r.optString("cloud_id"));
                if (cid.isEmpty()) continue;
                ContentValues cv = new ContentValues();
                cv.put("synced", 1);
                cv.put("updated_at", System.currentTimeMillis());
                db.update("ar_payments", cv, "cloud_id=?", new String[]{cid});
            }
            db.setTransactionSuccessful();
        } catch (Exception ignored) {
        } finally {
            try { db.endTransaction(); } catch (Exception ignored) {}
        }
    }

    public JSONArray exportArAllocationsPendingForCloud(String uid, int limit) {
        JSONArray out = new JSONArray();
        backfillCloudIdIfMissing("ar_allocations");
        int lim = Math.max(1, Math.min(2000, limit));
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery(
                "SELECT cloud_id,site_name,invoice_cloud_id,payment_cloud_id,amount,note FROM ar_allocations WHERE synced=0 ORDER BY id ASC LIMIT " + lim,
                null)) {
            while (c.moveToNext()) {
                JSONObject r = new JSONObject();
                try {
                    String cloudId = nvl(c.getString(0));
                    r.put("cloud_id", cloudId.isEmpty() ? JSONObject.NULL : cloudId);
                    r.put("site_name", nvl(c.getString(1)));
                    r.put("invoice_cloud_id", nvl(c.getString(2)));
                    r.put("payment_cloud_id", nvl(c.getString(3)));
                    r.put("amount", c.getDouble(4));
                    String note = nvl(c.getString(5));
                    r.put("note", note.isEmpty() ? JSONObject.NULL : note);
                } catch (Exception ignored) {}
                out.put(r);
            }
        } catch (Exception ignored) {}
        return out;
    }

    public void markArAllocationsSyncedByCloudIds(JSONArray rows) {
        if (rows == null || rows.length() == 0) return;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            for (int i = 0; i < rows.length(); i++) {
                JSONObject r = rows.optJSONObject(i);
                if (r == null) continue;
                String cid = nvl(r.optString("cloud_id"));
                if (cid.isEmpty()) continue;
                ContentValues cv = new ContentValues();
                cv.put("synced", 1);
                cv.put("updated_at", System.currentTimeMillis());
                db.update("ar_allocations", cv, "cloud_id=?", new String[]{cid});
            }
            db.setTransactionSuccessful();
        } catch (Exception ignored) {
        } finally {
            try { db.endTransaction(); } catch (Exception ignored) {}
        }
    }

    // ---------- cloud delete queue ----------

/** 删除队列条目（本地删了以后，下一次 push 时对 Supabase 执行 DELETE）。 */
public static class CloudDeleteItem {
    public long id;
    public String tableName;
    public JSONObject where;
    public long createdAt;
}

/** 入队：记录一次需要在云端执行的 DELETE（whereJson 为等值过滤条件）。 */
public void enqueueCloudDelete(String tableName, JSONObject whereJson) {
    if (tableName == null || tableName.trim().isEmpty() || whereJson == null) return;
    SQLiteDatabase db = getWritableDatabase();
    ContentValues cv = new ContentValues();
    cv.put("table_name", tableName.trim());
    cv.put("where_json", whereJson.toString());
    cv.put("created_at", System.currentTimeMillis());
    try { db.insert("cloud_delete_queue", null, cv); } catch (Exception ignored) {}
}

/**
 * 修复历史遗留：旧版本可能已经把订单在本地标记为 VOID/is_deleted=1，但没有入队 cloud_delete_queue，
 * 导致云端 orders / order_items 残留。
 *
 * 该方法会扫描本地已删除的订单（必须有 cloud_id），若 cloud_delete_queue 中缺少对应 DELETE 任务，
 * 则自动补齐：
 *  - orders: cloud_id=eq.<orderCloudId>
 *  - order_items: order_cloud_id=eq.<orderCloudId>
 *
 * 返回：本次新入队的任务数量（orders+order_items 计为 2）。
 */
public int enqueueCloudDeletesForLocallyDeletedOrders() {
    int enq = 0;
    SQLiteDatabase db = getWritableDatabase();
    Cursor c = null;
    try {
        c = db.rawQuery(
                "SELECT cloud_id FROM orders " +
                        "WHERE (IFNULL(is_deleted,0)=1 OR status=?) " +
                        "AND IFNULL(cloud_delete_tracked,0)=0 " +
                        "AND cloud_id IS NOT NULL AND TRIM(cloud_id)<>''",
                new String[]{ORDER_STATUS_VOID});

        while (c.moveToNext()) {
            String cid = nvl(c.getString(0)).trim();
            if (cid.isEmpty()) continue;

            // 1) orders delete task exists?
            if (!cloudDeleteTaskExistsLocked(db, "orders", "\"cloud_id\":\"" + cid + "\"")) {
                try {
                    JSONObject w1 = new JSONObject();
                    w1.put("cloud_id", cid);
                    enqueueCloudDelete("orders", w1);
                    enq++;
                } catch (Exception ignored) {}
            }

            // 2) order_items delete task exists?
            if (!cloudDeleteTaskExistsLocked(db, "order_items", "\"order_cloud_id\":\"" + cid + "\"")) {
                try {
                    JSONObject w2 = new JSONObject();
                    w2.put("order_cloud_id", cid);
                    enqueueCloudDelete("order_items", w2);
                    enq++;
                } catch (Exception ignored) {}
            }
            try {
                ContentValues mark = new ContentValues();
                mark.put("cloud_delete_tracked", 1);
                db.update("orders", mark, "cloud_id=?", new String[]{cid});
            } catch (Exception ignored) {}
        }
    } catch (Exception ignored) {
    } finally {
        if (c != null) try { c.close(); } catch (Exception ignored) {}
    }
    return enq;
}

/** 标记某个订单 cloud_id 已经纳入过云端删除跟踪，避免 backfill 反复重新入队。 */
public void markOrderCloudDeleteTrackedByCloudId(String orderCloudId) {
    if (orderCloudId == null) return;
    String cid = orderCloudId.trim();
    if (cid.isEmpty()) return;
    SQLiteDatabase db = getWritableDatabase();
    try {
        ContentValues cv = new ContentValues();
        cv.put("cloud_delete_tracked", 1);
        db.update("orders", cv, "cloud_id=?", new String[]{cid});
    } catch (Exception ignored) {}
}

/**
 * 判断 cloud_delete_queue 是否已经存在某个任务（通过 where_json 的关键片段匹配）。
 * 注意：where_json 是 JSON 字符串，SQLite 里没有 JSON 索引，使用 LIKE 做轻量去重。
 */
private boolean cloudDeleteTaskExistsLocked(SQLiteDatabase db, String tableName, String whereSnippet) {
    if (db == null || tableName == null || whereSnippet == null) return false;
    Cursor x = null;
    try {
        x = db.rawQuery(
                "SELECT 1 FROM cloud_delete_queue WHERE table_name=? AND where_json LIKE ? LIMIT 1",
                new String[]{tableName, "%" + whereSnippet + "%"});
        return x.moveToFirst();
    } catch (Exception ignored) {
        return false;
    } finally {
        if (x != null) try { x.close(); } catch (Exception ignored) {}
    }
}

/** 取待处理的删除队列（按时间顺序）。 */
public List<CloudDeleteItem> getPendingCloudDeletes(int limit) {
    List<CloudDeleteItem> list = new ArrayList<>();
    SQLiteDatabase db = getReadableDatabase();
    int l = Math.max(1, Math.min(200, limit));
    Cursor c = null;
    try {
        c = db.rawQuery("SELECT id, table_name, where_json, created_at FROM cloud_delete_queue ORDER BY id ASC LIMIT " + l, null);
        while (c.moveToNext()) {
            CloudDeleteItem it = new CloudDeleteItem();
            it.id = c.getLong(0);
            it.tableName = nvl(c.getString(1));
            String w = nvl(c.getString(2));
            it.createdAt = c.getLong(3);
            try { it.where = new JSONObject(w); } catch (Exception e) { it.where = new JSONObject(); }
            list.add(it);
        }
    } catch (Exception ignored) {
    } finally {
        if (c != null) try { c.close(); } catch (Exception ignore) {}
    }
    return list;
}

/** 标记删除队列已完成（本地删除该队列项）。 */
public void markCloudDeleteDone(long id) {
    if (id <= 0) return;
    SQLiteDatabase db = getWritableDatabase();
    try { db.delete("cloud_delete_queue", "id=?", new String[]{String.valueOf(id)}); } catch (Exception ignored) {}
}

/** 订单删除 where 条件（云端 orders 多数没有 id，因此用字段组合匹配）。 */
private JSONObject buildWhereJsonForOrderDelete(String date, String customer, String product, String location, double price) {
    JSONObject w = new JSONObject();
    try {
        // orders RLS uses owner_uid = auth.uid(), so delete filters must include owner_uid.
        String uid = AuthManager.getUserId(ctx);
        if (uid != null && !uid.trim().isEmpty()) w.put("owner_uid", uid.trim());

        // Use the same column names as local orders table and most Supabase schemas in this app.
        // (customer_name/product_name) matches your DELETE log and avoids 400 due to wrong column names.
        w.put("date", safeTrim(date));
        w.put("customer_name", safeTrim(customer));
        w.put("product_name", safeTrim(product));

        String loc = location == null ? "" : location.trim();
        w.put("location", loc);
        if (loc.isEmpty()) w.put("__location_allow_null", true);

        w.put("price", price);
    } catch (Exception ignored) {}
    return w;
}

/**
 * 物流单删除 where。
 * ✅ 重要：云端 logistics_forms 的主键 id 是 uuid。
 *   之前用 uuid(uid|localId) 生成“稳定 id”，但卸载重装后 localId 会变，导致：
 *   - push 重复插入
 *   - delete 找不到正确的云端行
 * 现在统一使用本地表保存的 cloud_id 作为云端主键。
 */
private JSONObject buildWhereJsonForLogisticsDelete(String uid, String cloudId) {
    JSONObject w = new JSONObject();
    try {
        if (cloudId != null && !cloudId.trim().isEmpty()) {
            w.put("id", cloudId.trim());
        }
        w.put("tenant_id", uid);
    } catch (Exception ignored) {}
    return w;
}

/** 物流明细删除 where：按 tenant_id + form_id 删除该单所有尺寸行。 */
private JSONObject buildWhereJsonForLogisticsSizesDelete(String uid, String formCloudId) {
    JSONObject w = new JSONObject();
    try {
        w.put("tenant_id", uid);
        if (formCloudId != null && !formCloudId.trim().isEmpty()) {
            w.put("form_id", formCloudId.trim());
        }
    } catch (Exception ignored) {}
    return w;
}


        // ---------- utils ----------

    private static String safeTrim(String s) {
        return s == null ? "" : s.trim();
    }

    /**
     * ✅ P0：回填 cloud_id（本地可能已有旧数据 cloud_id 为空；但云端已设 NOT NULL）
     * 只会填充 cloud_id 为 NULL/空字符串 的行，不会改动已有 cloud_id。
     */
    private void backfillCloudIdIfMissing(String table) {
        if (table == null || table.trim().isEmpty()) return;
        SQLiteDatabase db = null;
        Cursor c = null;
        try {
            db = getWritableDatabase();
            // 仅选择 cloud_id 为空的行
            c = db.rawQuery("SELECT id FROM " + table + " WHERE cloud_id IS NULL OR TRIM(cloud_id)='' ", null);
            while (c.moveToNext()) {
                long id = c.getLong(0);
                ContentValues cv = new ContentValues();
                cv.put("cloud_id", java.util.UUID.randomUUID().toString());
                cv.put("synced", 0);
                db.update(table, cv, "id=?", new String[]{String.valueOf(id)});
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) try { c.close(); } catch (Exception ignore) {}
        }
    }



    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        try { ensureSharedMasterSyncColumns(db); } catch (Exception ignored) {}
        try { ensureInventorySyncColumns(db); } catch (Exception ignored) {}
    }

    private void ensureSharedMasterSyncColumns(SQLiteDatabase db) {
        if (db == null) return;
        try { db.execSQL("ALTER TABLE customers ADD COLUMN cloud_id TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE customers ADD COLUMN updated_at TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE products ADD COLUMN cloud_id TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE products ADD COLUMN updated_at TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_customers_cloud_id ON customers(cloud_id)"); } catch (Exception ignored) {}
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_products_cloud_id ON products(cloud_id)"); } catch (Exception ignored) {}
        try { db.execSQL("UPDATE customers SET updated_at = COALESCE(NULLIF(updated_at,''), datetime('now'))"); } catch (Exception ignored) {}
        try { db.execSQL("UPDATE products SET updated_at = COALESCE(NULLIF(updated_at,''), datetime('now'))"); } catch (Exception ignored) {}
    }

    private void ensureInventorySyncColumns(SQLiteDatabase db) {
        if (db == null) return;
        try { db.execSQL("ALTER TABLE inventory_items ADD COLUMN updated_at TEXT"); } catch (Exception ignored) {}
        try { db.execSQL("UPDATE inventory_items SET updated_at = COALESCE(NULLIF(updated_at,''), datetime('now'))"); } catch (Exception ignored) {}
    }

    private static String nvl(String s) {
        return s == null ? "" : s;
    }

    private static String sha1(String s) {
        if (s == null) return "";
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-1");
            byte[] dig = md.digest(s.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : dig) sb.append(String.format(java.util.Locale.US, "%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * P1：导出待同步订单明细（order_items.synced=0），用于云端 upsert。
     */
    public JSONArray exportOrderItemsPendingForCloud(String uid, int limit) {
        JSONArray out = new JSONArray();

        // ✅ Step3兜底：如果本地 order_items 仍为空，则从旧 orders 表补偿生成明细
        // 目的：避免出现“UPSERT skip (empty): order_items”导致云端明细长期为0
        try { compensateOrderItemsFromOrdersIfEmpty(); } catch (Exception ignored) {}

        backfillCloudIdIfMissing("order_items");
        int lim = Math.max(1, Math.min(5000, limit));
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery(
                "SELECT cloud_id,order_cloud_id,product_name,pieces,quantity,price,remark,is_deleted,deleted_at " +
                        "FROM order_items WHERE synced=0 ORDER BY id ASC LIMIT " + lim,
                null)) {
            while (c.moveToNext()) {
                JSONObject r = new JSONObject();
                try {
                    r.put("owner_uid", uid);
                    r.put("id", nvl(c.getString(0)));
r.put("order_cloud_id", nvl(c.getString(1)));
                    r.put("product", nvl(c.getString(2)));
                    r.put("pieces", c.getInt(3));
                    r.put("quantity", c.getInt(4));
                    r.put("price", c.getDouble(5));
                    String remark = nvl(c.getString(6));
                    if (!remark.isEmpty()) r.put("remark", remark);
                    r.put("is_deleted", c.getInt(7)!=0);
String delAt = nvl(c.getString(8));
                    if (!delAt.isEmpty()) r.put("deleted_at", delAt);
                    out.put(r);
                } catch (Exception ignored) {}
            }
        } catch (Exception e) {
            Log.e("DB", "exportOrderItemsPendingForCloud error", e);
        }
        return out;
    }
    /**
     * ✅ 兜底补偿：当 order_items 表为空时，从旧版 orders（单品订单）自动生成 order_items 明细。
     * 仅在 order_items 总数为0时触发，避免重复生成。
     */
    private void compensateOrderItemsFromOrdersIfEmpty() {
        SQLiteDatabase db = null;
        Cursor c = null;
        try {
            db = getWritableDatabase();
            // 如果已有明细，则不补偿
            long cnt = 0;
            try (Cursor cc = db.rawQuery("SELECT COUNT(1) FROM order_items", null)) {
                if (cc.moveToFirst()) cnt = cc.getLong(0);
            }
            if (cnt > 0) return;

            // 确保 orders.cloud_id 不为空（云端 orders/cloud_id NOT NULL & order_items.order_cloud_id 依赖它）
            backfillCloudIdIfMissing("orders");

            db.beginTransaction();

            c = db.rawQuery(
                    "SELECT cloud_id, product_name, pieces, quantity, price, remark, created_at, updated_at " +
                            "FROM orders ORDER BY id ASC",
                    null
            );

            while (c.moveToNext()) {
                String orderCloudId = nvl(c.getString(0));
                if (orderCloudId.isEmpty()) continue;

                String productName = nvl(c.getString(1));
                int pieces = c.getInt(2);
                int qty = c.getInt(3);
                double price = c.getDouble(4);
                String remark = nvl(c.getString(5));
                String createdAt = nvl(c.getString(6));
                String updatedAt = nvl(c.getString(7));

                android.content.ContentValues cv = new android.content.ContentValues();
                cv.put("order_cloud_id", orderCloudId);
                cv.put("product_name", productName.isEmpty() ? "-" : productName);
                cv.put("pieces", Math.max(0, pieces));
                cv.put("quantity", Math.max(0, qty));
                cv.put("price", price);
                if (!remark.isEmpty()) cv.put("remark", remark);

                // 生成明细云端幂等ID（on_conflict=cloud_id）
                cv.put("cloud_id", java.util.UUID.randomUUID().toString());

                String now = nowIso8601();
                cv.put("created_at", createdAt.isEmpty() ? now : createdAt);
                cv.put("updated_at", updatedAt.isEmpty() ? now : updatedAt);

                cv.put("synced", 0);
                cv.put("is_deleted", 0);

                db.insert("order_items", null, cv);
            }

            db.setTransactionSuccessful();
        } finally {
            if (c != null) try { c.close(); } catch (Exception ignored) {}
            if (db != null) {
                try { if (db.inTransaction()) db.endTransaction(); } catch (Exception ignored) {}
            }
        }

        try { android.util.Log.d("DB", "COMPENSATE order_items from orders done"); } catch (Exception ignored) {}
    }



    /**
     * P1：标记 order_items 已同步（按 cloud_id）
     */
    public void markOrderItemsSyncedByCloudIds(JSONArray rows) {
        if (rows == null || rows.length() == 0) return;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            for (int i = 0; i < rows.length(); i++) {
                JSONObject r = rows.optJSONObject(i);
                if (r == null) continue;
                String cid = nvl(r.optString("cloud_id"));
                if (cid.isEmpty()) continue;
                ContentValues cv = new ContentValues();
                cv.put("synced", 1);
                db.update("order_items", cv, "cloud_id=?", new String[]{cid});
            }
            db.setTransactionSuccessful();
        } catch (Exception ignored) {
        } finally {
            try { db.endTransaction(); } catch (Exception ignored) {}
        }
    }


    private static String nowIso8601() {
        try {
            return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).format(new Date());
        } catch (Exception e) {
            return new Date().toString();
        }
    }

        private static long parseIsoToMillis(String iso) {
            if (iso == null) return 0L;
            String s = iso.trim();
            if (s.length() == 0) return 0L;

            // numeric epoch? (10 digits seconds, 13 digits millis; other digit-length treat as millis)
            boolean allDigits = true;
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                if (c < '0' || c > '9') { allDigits = false; break; }
            }
            if (allDigits) {
                try {
                    long v = Long.parseLong(s);
                    if (s.length() == 10) return v * 1000L;
                    return v;
                } catch (Throwable ignore) {}
            }

            // Normalize: replace space with 'T' to ease parsing
            s = s.replace(' ', 'T');

            // Extract timezone offset if present: Z / +hh[:mm] / -hh[:mm] / +hhmm / -hhmm / +hh / -hh
            int offsetMinutes = 0;
            boolean hasTz = false;

            if (s.endsWith("Z") || s.endsWith("z")) {
                hasTz = true;
                s = s.substring(0, s.length() - 1);
            } else {
                // find last '+' or '-' after date part
                int plus = s.lastIndexOf('+');
                int minus = s.lastIndexOf('-');
                int tzPos = Math.max(plus, minus);

                // If '-' belongs to date (yyyy-MM-dd), ignore it by requiring position > 10
                if (tzPos > 10) {
                    hasTz = true;
                    String tz = s.substring(tzPos);
                    s = s.substring(0, tzPos);

                    // tz formats: +08:00 / +0800 / +08
                    try {
                        int sign = tz.startsWith("-") ? -1 : 1;
                        String t = tz.substring(1);
                        int hh = 0, mm = 0;

                        if (t.contains(":")) {
                            String[] parts = t.split(":");
                            if (parts.length >= 1) hh = Integer.parseInt(parts[0]);
                            if (parts.length >= 2) mm = Integer.parseInt(parts[1]);
                        } else if (t.length() >= 4) {
                            hh = Integer.parseInt(t.substring(0, 2));
                            mm = Integer.parseInt(t.substring(2, 4));
                        } else if (t.length() >= 2) {
                            hh = Integer.parseInt(t.substring(0, 2));
                            mm = 0;
                        }
                        offsetMinutes = sign * (hh * 60 + mm);
                    } catch (Throwable ignore) {
                        offsetMinutes = 0;
                    }
                }
            }

            // Trim or pad fractional seconds to millis (3 digits) for stable parsing
            int dot = s.indexOf('.');
            if (dot >= 0) {
                int end = dot + 1;
                while (end < s.length() && Character.isDigit(s.charAt(end))) end++;
                String frac = s.substring(dot + 1, end);
                if (frac.length() > 3) frac = frac.substring(0, 3);
                while (frac.length() < 3) frac = frac + "0";
                s = s.substring(0, dot + 1) + frac + s.substring(end);
            }

            // Parse as UTC, then subtract offset to get real UTC instant
            java.util.TimeZone utc = java.util.TimeZone.getTimeZone("UTC");

            String[] patterns = new String[] {
                    "yyyy-MM-dd'T'HH:mm:ss.SSS",
                    "yyyy-MM-dd'T'HH:mm:ss",
                    "yyyy-MM-dd'T'HH:mm",
                    "yyyy-MM-dd"
            };

            for (String p : patterns) {
                try {
                    java.text.SimpleDateFormat df = new java.text.SimpleDateFormat(p, java.util.Locale.US);
                    df.setLenient(true);
                    df.setTimeZone(utc);
                    java.util.Date d = df.parse(s);
                    if (d != null) {
                        long t = d.getTime();
                        if (hasTz) t -= (long) offsetMinutes * 60L * 1000L;
                        return t;
                    }
                } catch (Throwable ignore) {}
            }

            return 0L;
        }


    // ===================== Step3：财务（应收/对账/账期） =====================

    /** 订单简表（对账用） */
    public static class OrderBrief {
        public long id;
        public String date;
        public String orderNo;
        public double totalAmount;
        public String remark;
    }

    /** 安全获取客户名称列表（兜底，不抛异常） */
    public List<String> getAllCustomerNamesSafe() {
        try {
            return getAllCustomerNames();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    /** 保存客户账期/额度（本地） */
    public void upsertCustomerFinanceProfile(String customerName, int creditDays, double creditLimit) {
        if (customerName == null) return;
        customerName = customerName.trim();
        if (customerName.length() == 0) return;

        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("customer_name", customerName);
        cv.put("credit_days", Math.max(0, creditDays));
        cv.put("credit_limit", Math.max(0, creditLimit));
        cv.put("updated_at", System.currentTimeMillis());
        // customer_name UNIQUE -> replace
        db.insertWithOnConflict("customer_finance_profile", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    /** 获取所有客户账期（没有设置的客户也返回，默认 0/0） */
    public List<CustomerFinanceProfile> getAllCustomerFinanceProfiles() {
        SQLiteDatabase db = getReadableDatabase();
        List<CustomerFinanceProfile> list = new ArrayList<>();
        String sql = "SELECT c.name, IFNULL(p.credit_days,0), IFNULL(p.credit_limit,0) " +
                "FROM customers c LEFT JOIN customer_finance_profile p ON p.customer_name=c.name " +
                "ORDER BY c.name COLLATE NOCASE";
        try (Cursor c = db.rawQuery(sql, null)) {
            while (c.moveToNext()) {
                CustomerFinanceProfile p = new CustomerFinanceProfile();
                p.customerName = c.getString(0);
                p.creditDays = c.getInt(1);
                p.creditLimit = c.getDouble(2);
                list.add(p);
            }
        } catch (Exception ignored) {}
        return list;
    }

    /** 新增收款记录 */
    public long addPayment(String customerName, double amount, String payDate, String method, String remark) {
        if (customerName == null) return -1;
        customerName = customerName.trim();
        if (customerName.length() == 0) return -1;

        if (payDate == null || payDate.trim().length() == 0) {
            payDate = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(new java.util.Date());
        }

        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("customer_name", customerName);
        cv.put("amount", amount);
        cv.put("pay_date", payDate);
        cv.put("method", method);
        cv.put("remark", remark);
        cv.put("created_at", System.currentTimeMillis());
        long id = db.insert("payments", null, cv);

        // 可选：未来接入云端同步时再补
        scheduleCloudPushSafe();
        return id;
    }

    /** 软删除收款（对账误录时使用） */
    public void softDeletePayment(long paymentId) {
        if (paymentId <= 0) return;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("is_deleted", 1);
        db.update("payments", cv, "id=?", new String[]{String.valueOf(paymentId)});
        scheduleCloudPushSafe();
    }

    /** 查询收款（对账用） */
    public List<PaymentRecord> queryPayments(String customerName, String startDate, String endDate) {
        SQLiteDatabase db = getReadableDatabase();
        List<PaymentRecord> list = new ArrayList<>();
        if (customerName == null) return list;
        String s = startDate == null ? "0000-01-01" : startDate;
        String e = endDate == null ? "9999-12-31" : endDate;
        String sql = "SELECT id, customer_name, amount, pay_date, method, remark " +
                "FROM payments WHERE is_deleted=0 AND customer_name=? AND pay_date>=? AND pay_date<=? " +
                "ORDER BY pay_date ASC, id ASC";
        try (Cursor c = db.rawQuery(sql, new String[]{customerName, s, e, getDefaultSiteForReports()})) {
            while (c.moveToNext()) {
                PaymentRecord p = new PaymentRecord();
                p.id = c.getLong(0);
                p.customerName = c.getString(1);
                p.amount = c.getDouble(2);
                p.payDate = c.getString(3);
                p.method = c.getString(4);
                p.remark = c.getString(5);
                list.add(p);
            }
        } catch (Exception ignored) {}
        return list;
    }

    /** 查询出货订单简表（对账用，默认只取已打印=出货） */
    
    /**
     * Step2-1：根据“对账范围”的收款/出货，自动维护订单是否结清（SETTLED）。
     * 规则：
     * - 仅影响 printed=1 且未作废/未删除的订单
     * - 若余额<=0：将范围内订单标记为 SETTLED，并写入 settled_at
     * - 若余额>0：将范围内已 SETTLED 的订单回退为 PRINTED（避免删收款后订单仍显示已结清）
     */
    public void recomputeSettlementForRange(String customerName, String startDate, String endDate) {
        if (customerName == null) return;
        String cust = customerName.trim();
        if (cust.isEmpty()) return;

        String s = (startDate == null || startDate.trim().isEmpty()) ? "0000-01-01" : startDate.trim();
        String e = (endDate == null || endDate.trim().isEmpty()) ? "9999-12-31" : endDate.trim();

        SQLiteDatabase db = getWritableDatabase();

        double shipSum = 0;
        double paySum = 0;

        try (Cursor c = db.rawQuery(
                "SELECT IFNULL(SUM(CASE WHEN IFNULL(total_amount,0)!=0 THEN total_amount ELSE (quantity*price) END),0) FROM orders " +
                        "WHERE customer_name=? AND date>=? AND date<=? " +
                        "AND COALESCE(printed,0)=1 " +
                        "AND IFNULL(is_deleted,0)=0 " +
                        "AND UPPER(COALESCE(status,'" + ORDER_STATUS_CONFIRMED + "'))!='" + ORDER_STATUS_VOID + "' " +
                        "AND (IFNULL(location,'')=? OR IFNULL(location,'')='')",
                new String[]{cust, s, e, getDefaultSiteForReports()}
        )) {
            if (c.moveToFirst()) shipSum = c.getDouble(0);
        } catch (Exception ignored) { }

        try (Cursor c = db.rawQuery(
                "SELECT IFNULL(SUM(amount),0) FROM payments " +
                        "WHERE customer_name=? AND pay_date>=? AND pay_date<=? " +
                        "AND IFNULL(is_deleted,0)=0",
                new String[]{cust, s, e, getDefaultSiteForReports()}
        )) {
            if (c.moveToFirst()) paySum = c.getDouble(0);
        } catch (Exception ignored) { }

        double balance = shipSum - paySum;
        String now = nowIso8601();

        db.beginTransaction();
        try {
            if (balance <= 0.000001d) {
                // 标记结清
                db.execSQL(
                        "UPDATE orders SET " +
                                "status=CASE WHEN UPPER(COALESCE(status,''))='" + ORDER_STATUS_VOID + "' THEN status ELSE '" + ORDER_STATUS_SETTLED + "' END, " +
                                "settled_at=CASE WHEN settled_at IS NULL OR settled_at='' THEN ? ELSE settled_at END, " +
                                "updated_at=?, synced=0 " +
                                "WHERE customer_name=? AND date>=? AND date<=? " +
                                "AND COALESCE(printed,0)=1 AND IFNULL(is_deleted,0)=0 " +
                                "AND UPPER(COALESCE(status,'" + ORDER_STATUS_CONFIRMED + "'))!='" + ORDER_STATUS_VOID + "'",
                        new Object[]{now, now, cust, s, e}
                );
            } else {
                // 回退（比如删了收款）
                db.execSQL(
                        "UPDATE orders SET " +
                                "status='" + ORDER_STATUS_PRINTED + "', " +
                                "settled_at=NULL, " +
                                "updated_at=?, synced=0 " +
                                "WHERE customer_name=? AND date>=? AND date<=? " +
                                "AND COALESCE(printed,0)=1 AND IFNULL(is_deleted,0)=0 " +
                                "AND UPPER(COALESCE(status,''))='" + ORDER_STATUS_SETTLED + "'",
                        new Object[]{now, cust, s, e}
                );
            }
            db.setTransactionSuccessful();
        } catch (Exception ignored) {
        } finally {
            try { db.endTransaction(); } catch (Exception ignored) { }
        }

        scheduleCloudPushSafe();
    }

public List<OrderBrief> queryOrdersBrief(String customerName, String startDate, String endDate) {
        SQLiteDatabase db = getReadableDatabase();
        List<OrderBrief> list = new ArrayList<>();
        if (customerName == null) return list;
        String s = startDate == null ? "0000-01-01" : startDate;
        String e = endDate == null ? "9999-12-31" : endDate;

        String sql = "SELECT id, date, cloud_id, IFNULL(total_amount,0), remark " +
                "FROM orders WHERE customer_name=? AND date>=? AND date<=? " +
                "AND IFNULL(is_deleted,0)=0 AND UPPER(COALESCE(status,'CONFIRMED'))!='VOID' " +
                "AND printed=1 " +
                "AND (IFNULL(location,'')=? OR IFNULL(location,'')='') " +
                "ORDER BY date ASC, id ASC";
        try (Cursor c = db.rawQuery(sql, new String[]{customerName, s, e, getDefaultSiteForReports()})) {
            while (c.moveToNext()) {
                OrderBrief o = new OrderBrief();
                o.id = c.getLong(0);
                o.date = c.getString(1);
                String cloud = c.getString(2);
                o.orderNo = (cloud != null && cloud.trim().length() > 0) ? cloud : String.valueOf(o.id);
                o.totalAmount = c.getDouble(3);
                o.remark = c.getString(4);
                list.add(o);
            }
        } catch (Exception ignored) {}
        return list;
    }

    /** 应收汇总（每客户） */
    public List<ReceivableRow> getReceivablesSummary() {
        SQLiteDatabase db = getReadableDatabase();

        java.util.HashMap<String, Double> shipMap = new java.util.HashMap<>();
        java.util.HashMap<String, Double> payMap = new java.util.HashMap<>();
        java.util.HashMap<String, CustomerFinanceProfile> profMap = new java.util.HashMap<>();

        // 出货累计（默认已打印）
        try (Cursor c = db.rawQuery(
                "SELECT customer_name, " +
                        "IFNULL(SUM(CASE WHEN IFNULL(total_amount,0)!=0 THEN total_amount ELSE (quantity*price) END),0) " +
                        "FROM orders " +
                        "WHERE printed=1 AND IFNULL(is_deleted,0)=0 AND UPPER(COALESCE(status,'CONFIRMED'))!='VOID' " +
                        "AND (IFNULL(location,'')=? OR IFNULL(location,'')='') " +
                        "GROUP BY customer_name",
                new String[]{getDefaultSiteForReports()})) {
            while (c.moveToNext()) {
                shipMap.put(c.getString(0), c.getDouble(1));
            }
        } catch (Exception ignored) {}


// 收款累计
        try (Cursor c = db.rawQuery(
                "SELECT customer_name, IFNULL(SUM(amount),0) FROM payments WHERE is_deleted=0 GROUP BY customer_name", new String[]{getDefaultSiteForReports()})) {
            while (c.moveToNext()) {
                payMap.put(c.getString(0), c.getDouble(1));
            }
        } catch (Exception ignored) {}

        // 账期/额度
        try (Cursor c = db.rawQuery(
                "SELECT customer_name, IFNULL(credit_days,0), IFNULL(credit_limit,0) FROM customer_finance_profile", null)) {
            while (c.moveToNext()) {
                CustomerFinanceProfile p = new CustomerFinanceProfile();
                p.customerName = c.getString(0);
                p.creditDays = c.getInt(1);
                p.creditLimit = c.getDouble(2);
                profMap.put(p.customerName, p);
            }
        } catch (Exception ignored) {}

        // 合并客户名单
        java.util.HashSet<String> names = new java.util.HashSet<>();
        try (Cursor c = db.rawQuery("SELECT name FROM customers", null)) {
            while (c.moveToNext()) names.add(c.getString(0));
        } catch (Exception ignored) {}
        names.addAll(shipMap.keySet());
        names.addAll(payMap.keySet());

        List<ReceivableRow> list = new ArrayList<>();
        for (String name : names) {
            if (name == null || name.trim().length() == 0) continue;
            double ship = shipMap.containsKey(name) ? shipMap.get(name) : 0;
            double paid = payMap.containsKey(name) ? payMap.get(name) : 0;
            CustomerFinanceProfile p = profMap.get(name);

            ReceivableRow r = new ReceivableRow();
            r.customerName = name;
            r.totalShip = ship;
            r.totalPaid = paid;
            r.balance = ship - paid;
            r.creditDays = p == null ? 0 : p.creditDays;
            r.creditLimit = p == null ? 0 : p.creditLimit;
            list.add(r);
        }

        // 默认按应收余额降序
        list.sort((a,b)-> Double.compare(b.balance, a.balance));
        return list;
    }




// ==== Added for SupabaseSyncManager compatibility (do not remove existing behavior) ====
/**
 * Mark orders as synced by their cloud_id list returned/used in cloud upsert.
 * This is a safe best-effort implementation; if schema differs it will no-op.
 */
public void markOrdersSyncedByCloudIds(org.json.JSONArray cloudIds) {
    if (cloudIds == null) return;
    android.database.sqlite.SQLiteDatabase db = null;
    try {
        db = getWritableDatabase();
        db.beginTransaction();
        for (int i = 0; i < cloudIds.length(); i++) {
            String cid = cloudIds.optString(i, null);
            if (cid == null || cid.trim().isEmpty()) continue;
            android.content.ContentValues cv = new android.content.ContentValues();
            cv.put("synced", 1);
            cv.put("updated_at", System.currentTimeMillis());
            try {
                db.update("orders", cv, "cloud_id=?", new String[]{cid});
            } catch (Exception ignored) {
                // ignore schema mismatch
            }
        }
        db.setTransactionSuccessful();
    } catch (Exception ignored) {
    } finally {
        try { if (db != null) db.endTransaction(); } catch (Exception ignored) {}
    }
}

/**
 * Export logistics forms incrementally for cloud push. If your current project doesn't use
 * incremental logistics push, this returns empty safely.
 */
public org.json.JSONArray exportLogisticsFormsForCloudSince(String ownerUid, int lastPushedId) {
    org.json.JSONArray out = new org.json.JSONArray();

    // ✅ 确保 cloud_id 不为空（云端 logistics_forms 主键 id=uuid）
    try { backfillCloudIdIfMissing("logistics_forms"); } catch (Exception ignored) {}

    android.database.sqlite.SQLiteDatabase db = getReadableDatabase();
    android.database.Cursor c = null;
    try {
        // 优先上传未同步（synced=0），同时兼容按 lastPushedId 增量
        String where = "(synced=0 OR id>?)";
        c = db.rawQuery(
                "SELECT id,cloud_id,date,location,total_pieces,total_cbm,remark " +
                        "FROM logistics_forms WHERE " + where + " ORDER BY id ASC",
                new String[]{String.valueOf(Math.max(0, lastPushedId))}
        );

        while (c != null && c.moveToNext()) {
            org.json.JSONObject r = new org.json.JSONObject();
            try {
                String cloudId = nvl(c.getString(1));
                // 云端主键字段名是 id（uuid）
                r.put("id", cloudId.isEmpty() ? org.json.JSONObject.NULL : cloudId);
                // 云端私有隔离字段：tenant_id
                r.put("tenant_id", ownerUid);

                r.put("date", nvl(c.getString(2)));

                String location = nvl(c.getString(3));
                r.put("location", location.isEmpty() ? org.json.JSONObject.NULL : location);

                r.put("total_pieces", c.getInt(4));
                r.put("total_cbm", c.getDouble(5));

                String remark = nvl(c.getString(6));
                r.put("remark", remark.isEmpty() ? org.json.JSONObject.NULL : remark);
            } catch (Exception ignored) {}

            out.put(r);
        }
    } catch (Exception ignored) {
    } finally {
        try { if (c != null) c.close(); } catch (Exception ignored) {}
    }
    return out;
}

/**
 * Export logistics sizes incrementally for cloud push. If your current project doesn't use
 * incremental logistics push, this returns empty safely.
 */
public org.json.JSONArray exportLogisticsSizesForCloudSince(String ownerUid, int lastPushedId) {
    org.json.JSONArray out = new org.json.JSONArray();

    // ✅ 确保 logistics_forms.cloud_id 不为空，后续才能拼 form_id
    try { backfillCloudIdIfMissing("logistics_forms"); } catch (Exception ignored) {}

    android.database.sqlite.SQLiteDatabase db = getReadableDatabase();
    android.database.Cursor c = null;
    try {
        // 仅导出“关联到待同步物流单”的尺寸行，避免重复上传
        // - logistics_forms.synced=0 或 id>lastPushedId 的单
        c = db.rawQuery(
                "SELECT s.id, f.cloud_id, s.len, s.wid, s.hei, s.pieces, s.cbm " +
                        "FROM logistics_sizes s JOIN logistics_forms f ON s.logistics_id=f.id " +
                        "WHERE (f.synced=0 OR f.id>?) ORDER BY f.cloud_id ASC, s.id ASC",
                new String[]{String.valueOf(Math.max(0, lastPushedId))}
        );

        String __lastFormCloudId = null;
        int __idx = 0;

        while (c != null && c.moveToNext()) {
            long localSizeId = c.getLong(0);
            String formCloudId = nvl(c.getString(1));
            if (formCloudId.isEmpty()) continue; // 没有 form cloud_id 无法同步

            org.json.JSONObject r = new org.json.JSONObject();
            try {
                // ✅ 云端 logistics_sizes 也用 uuid 主键 id，生成稳定 id，避免重复插入
                if (!formCloudId.equals(__lastFormCloudId)) {
                    __lastFormCloudId = formCloudId;
                    __idx = 1;
                } else {
                    __idx++;
                }

                // ✅ 用(tenant + form_id + 行序号)生成稳定 id：编辑物流单(删旧再插新)也不会不断产生新 id
                String stable = java.util.UUID.nameUUIDFromBytes(
                        (ownerUid + "|lsz|" + formCloudId + "|" + __idx).getBytes("UTF-8")
                ).toString();
                r.put("id", stable);
                r.put("tenant_id", ownerUid);
                r.put("form_id", formCloudId);

                r.put("len", c.getDouble(2));
                r.put("wid", c.getDouble(3));
                r.put("hei", c.getDouble(4));
                r.put("pieces", c.getInt(5));
                r.put("cbm", c.getDouble(6));
            } catch (Exception ignored) {}

            out.put(r);
        }
    } catch (Exception ignored) {
    } finally {
        try { if (c != null) c.close(); } catch (Exception ignored) {}
    }
    return out;
}

/**
 * Get max local logistics form id. Best-effort; returns 0 if table missing.
 */
public int getMaxLogisticsFormId() {
    android.database.sqlite.SQLiteDatabase db = null;
    android.database.Cursor c = null;
    try {
        db = getReadableDatabase();
        c = db.rawQuery("SELECT MAX(id) FROM logistics_forms", null);
        if (c != null && c.moveToFirst()) return c.isNull(0) ? 0 : c.getInt(0);
    } catch (Exception ignored) {
    } finally {
        try { if (c != null) c.close(); } catch (Exception ignored) {}
    }
    return 0;
}

/**
 * Mark logistics synced up to a given id. Best-effort; will no-op if schema missing.
 */
public void markLogisticsSyncedUpTo(int maxId) {
    android.database.sqlite.SQLiteDatabase db = null;
    try {
        db = getWritableDatabase();
        android.content.ContentValues cv = new android.content.ContentValues();
        cv.put("synced", 1);
        try { db.update("logistics_forms", cv, "id<=?", new String[]{String.valueOf(maxId)}); } catch (Exception ignored) {}
        try { db.update("logistics_sizes", cv, "form_id<=?", new String[]{String.valueOf(maxId)}); } catch (Exception ignored) {}
    } catch (Exception ignored) {
    }
}
// ==== End SupabaseSyncManager compatibility ====

    // =============================================================
    // ✅ 账号切换隔离：清理私有数据
    // =============================================================
    /**
     * 账号切换时调用：清空所有“私有表”数据。
     *
     * 不清空：customers/products/print_templates/locations（这些是共享/基础数据）。
     */
    public void clearPrivateDataForAccountSwitch() {
        SQLiteDatabase db = null;
        try {
            db = getWritableDatabase();
            db.beginTransaction();

            // ✅ 私有：订单/明细
            try { db.delete("order_items", null, null); } catch (Exception ignored) {}
            try { db.delete("orders", null, null); } catch (Exception ignored) {}

            // ✅ 私有：库存（你当前模型中 inventory_items 为私有）
            try { db.delete("inventory_items", null, null); } catch (Exception ignored) {}
            try { db.delete("inventory_movements", null, null); } catch (Exception ignored) {}

            // ✅ 私有：物流单
            try { db.delete("logistics_sizes", null, null); } catch (Exception ignored) {}
            try { db.delete("logistics_forms", null, null); } catch (Exception ignored) {}

            // ✅ 私有：财务/对账相关（若表存在）
            try { db.delete("payments", null, null); } catch (Exception ignored) {}
            try { db.delete("receivables", null, null); } catch (Exception ignored) {}
            try { db.delete("reconciliations", null, null); } catch (Exception ignored) {}

            // ✅ 私有：云端删除队列（避免 A 账号的 delete 操作影响 B 账号）
            try { db.delete("cloud_delete_queue", null, null); } catch (Exception ignored) {}

            db.setTransactionSuccessful();
        } catch (Exception ignored) {
        } finally {
            try { if (db != null) db.endTransaction(); } catch (Exception ignored) {}
        }
    }

    // =============================================================
    // 云端财务（AR）UI 用：本地增删改查（同步由 SupabaseSyncManager 负责）
    // =============================================================

    public List<ArInvoiceRow> getArInvoices() {
        List<ArInvoiceRow> list = new java.util.ArrayList<>();
        SQLiteDatabase db = null;
        Cursor c = null;
        try {
            db = getReadableDatabase();
            c = db.rawQuery("SELECT cloud_id,site_name,customer_name,period_ym,amount,status,note FROM ar_invoices WHERE is_deleted=0 AND site_name=? ORDER BY period_ym DESC, customer_name ASC", new String[]{getDefaultSiteForReports()});
            while (c.moveToNext()) {
                ArInvoiceRow r = new ArInvoiceRow();
                r.cloudId = nvl(c.getString(0));
                r.siteName = nvl(c.getString(1));
                r.customerName = nvl(c.getString(2));
                r.periodYm = nvl(c.getString(3));
                r.amount = c.getDouble(4);
                r.status = nvl(c.getString(5));
                r.note = nvl(c.getString(6));
                list.add(r);
            }
        } catch (Exception ignored) {
        } finally {
            try { if (c != null) c.close(); } catch (Exception ignored) {}
        }
        return list;
    }

    public void upsertArInvoice(String cloudId, String siteName, String customerName, String periodYm,
                               double amount, String status, String note) {
        SQLiteDatabase db = null;
        try {
            db = getWritableDatabase();
            ContentValues cv = new ContentValues();
            String cid = (cloudId == null || cloudId.trim().isEmpty()) ? java.util.UUID.randomUUID().toString() : cloudId;
            cv.put("cloud_id", cid);
            cv.put("site_name", nvl(siteName));
            cv.put("customer_name", nvl(customerName));
            cv.put("period_ym", nvl(periodYm));
            cv.put("amount", amount);
            cv.put("status", nvl(status));
            cv.put("note", nvl(note));
            long now = System.currentTimeMillis();
            cv.put("updated_at", now);
            if (cloudId == null || cloudId.trim().isEmpty()) {
                cv.put("created_at", now);
            }
            cv.put("synced", 0);
            db.insertWithOnConflict("ar_invoices", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
        } catch (Exception ignored) {
        }
    }

    /**
     * 从 orders 表按“月份(YYYY-MM) + 场地 + 客户”汇总金额，用于生成应收账单（AR）。
     *
     * 规则：
     * - 仅统计 is_deleted=0 的订单
     * - 优先使用 total_amount（如果为 0，则回退用 quantity*price）
     */
    public java.util.List<OrderArAggRow> getOrderArAggForPeriod(String periodYm) {
        java.util.List<OrderArAggRow> out = new java.util.ArrayList<>();
        if (periodYm == null) return out;
        periodYm = periodYm.trim();
        if (periodYm.isEmpty()) return out;

        SQLiteDatabase db = null;
        Cursor c = null;
        try {
            db = getReadableDatabase();
            // date 格式通常为 YYYY-MM-DD，这里用 substr(date,1,7)=YYYY-MM
            String sql = "SELECT IFNULL(location,''), customer_name, " +
                    "SUM(CASE WHEN IFNULL(total_amount,0) != 0 THEN total_amount ELSE (quantity*price) END) " +
                    "FROM orders WHERE is_deleted=0 AND substr(date,1,7)=? " +
                    "AND (IFNULL(location,'')=? OR IFNULL(location,'')='') " +
                    "GROUP BY IFNULL(location,''), customer_name " +
                    "ORDER BY IFNULL(location,''), customer_name";
            c = db.rawQuery(sql, new String[]{periodYm, getDefaultSiteForReports()});
            while (c.moveToNext()) {
                OrderArAggRow r = new OrderArAggRow();
                r.siteName = nvl(c.getString(0));
                r.customerName = nvl(c.getString(1));
                r.amount = c.getDouble(2);
                out.add(r);
            }
        } catch (Exception ignored) {
        } finally {
            try { if (c != null) c.close(); } catch (Exception ignored) {}
        }
        return out;
    }

    public static class OrderArAggRow {
        public String siteName;
        public String customerName;
        public double amount;
    }

    public List<ArPaymentRow> getArPayments() {
        List<ArPaymentRow> list = new java.util.ArrayList<>();
        SQLiteDatabase db = null;
        Cursor c = null;
        try {
            db = getReadableDatabase();
            c = db.rawQuery("SELECT cloud_id,site_name,customer_name,pay_date,amount,method,note FROM ar_payments WHERE is_deleted=0 AND site_name=? ORDER BY pay_date DESC, customer_name ASC", new String[]{getDefaultSiteForReports()});
            while (c.moveToNext()) {
                ArPaymentRow r = new ArPaymentRow();
                r.cloudId = nvl(c.getString(0));
                r.siteName = nvl(c.getString(1));
                r.customerName = nvl(c.getString(2));
                r.payDate = nvl(c.getString(3));
                r.amount = c.getDouble(4);
                r.method = nvl(c.getString(5));
                r.note = nvl(c.getString(6));
                list.add(r);
            }
        } catch (Exception ignored) {
        } finally {
            try { if (c != null) c.close(); } catch (Exception ignored) {}
        }
        return list;
    }

    public void upsertArPayment(String cloudId, String siteName, String customerName,
                               double amount, String payDate, String method, String note) {
        SQLiteDatabase db = null;
        try {
            db = getWritableDatabase();
            ContentValues cv = new ContentValues();
            String cid = (cloudId == null || cloudId.trim().isEmpty()) ? java.util.UUID.randomUUID().toString() : cloudId;
            cv.put("cloud_id", cid);
            cv.put("site_name", nvl(siteName));
            cv.put("customer_name", nvl(customerName));
            cv.put("amount", amount);
            cv.put("pay_date", nvl(payDate));
            cv.put("method", nvl(method));
            cv.put("note", nvl(note));
            long now = System.currentTimeMillis();
            cv.put("updated_at", now);
            if (cloudId == null || cloudId.trim().isEmpty()) {
                cv.put("created_at", now);
            }
            cv.put("synced", 0);
            db.insertWithOnConflict("ar_payments", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
        } catch (Exception ignored) {
        }
    }

    public List<ArAllocationRow> getArAllocations() {
        List<ArAllocationRow> list = new java.util.ArrayList<>();
        SQLiteDatabase db = null;
        Cursor c = null;
        try {
            db = getReadableDatabase();
            c = db.rawQuery("SELECT cloud_id,site_name,invoice_cloud_id,payment_cloud_id,amount,note FROM ar_allocations WHERE is_deleted=0 AND site_name=? ORDER BY id DESC", new String[]{getDefaultSiteForReports()});
            while (c.moveToNext()) {
                ArAllocationRow r = new ArAllocationRow();
                r.cloudId = nvl(c.getString(0));
                r.siteName = nvl(c.getString(1));
                r.invoiceCloudId = nvl(c.getString(2));
                r.paymentCloudId = nvl(c.getString(3));
                r.amount = c.getDouble(4);
                r.note = nvl(c.getString(5));
                list.add(r);
            }
        } catch (Exception ignored) {
        } finally {
            try { if (c != null) c.close(); } catch (Exception ignored) {}
        }
        return list;
    }

    public void upsertArAllocation(String cloudId, String siteName, String invoiceCloudId,
                                  String paymentCloudId, double amount, String note) {
        SQLiteDatabase db = null;
        try {
            db = getWritableDatabase();
            ContentValues cv = new ContentValues();
            String cid = (cloudId == null || cloudId.trim().isEmpty()) ? java.util.UUID.randomUUID().toString() : cloudId;
            cv.put("cloud_id", cid);
            cv.put("site_name", nvl(siteName));
            cv.put("invoice_cloud_id", nvl(invoiceCloudId));
            cv.put("payment_cloud_id", nvl(paymentCloudId));
            cv.put("amount", amount);
            cv.put("note", nvl(note));
            long now = System.currentTimeMillis();
            cv.put("updated_at", now);
            if (cloudId == null || cloudId.trim().isEmpty()) {
                cv.put("created_at", now);
            }
            cv.put("synced", 0);
            db.insertWithOnConflict("ar_allocations", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
        } catch (Exception ignored) {
        }
    }

    /**
     * 更新print_templates的cloud_id映射（用于409冲突修复）
     * @param localId 本地稳定ID（基于org_id+type+name计算）
     * @param cloudId 云端真实ID
     */
    public void updatePrintTemplateCloudId(String localId, String cloudId) {
        if (localId == null || localId.trim().isEmpty() || cloudId == null || cloudId.trim().isEmpty()) {
            return;
        }
        SQLiteDatabase db = null;
        try {
            db = getWritableDatabase();
            ContentValues cv = new ContentValues();
            cv.put("cloud_id", cloudId.trim());
            // 根据本地稳定ID更新cloud_id
            // 注意：这里假设localId是stableId（基于org_id+type+name计算），不是数据库自增id
            // 需要先找到对应的记录
            Cursor c = null;
            try {
                c = db.rawQuery("SELECT id FROM print_templates WHERE cloud_id=? OR (cloud_id IS NULL AND type||name||org_id LIKE ?)", 
                    new String[]{localId.trim(), "%" + localId.trim() + "%"});
                if (c.moveToFirst()) {
                    long dbId = c.getLong(0);
                    db.update("print_templates", cv, "id=?", new String[]{String.valueOf(dbId)});
                    Log.d("DatabaseHelper", "更新print_templates cloud_id映射：本地stableId=" + localId + " -> 云端id=" + cloudId);
                }
            } catch (Exception e) {
                Log.e("DatabaseHelper", "查找print_templates记录失败", e);
            } finally {
                if (c != null) c.close();
            }
        } catch (Exception e) {
            Log.e("DatabaseHelper", "更新print_templates cloud_id失败", e);
        }
    }

    // =========================
    // 2年热数据：本地清理方法
    // =========================

    /**
     * 获取2年前的日期字符串（格式：yyyy-MM-dd）
     */
    public static String getDateTwoYearsAgo() {
        try {
            java.util.Calendar cal = java.util.Calendar.getInstance();
            cal.add(java.util.Calendar.MONTH, -24); // 2年前
            cal.set(java.util.Calendar.DAY_OF_MONTH, 1); // 从当月1号开始
            cal.set(java.util.Calendar.HOUR_OF_DAY, 0);
            cal.set(java.util.Calendar.MINUTE, 0);
            cal.set(java.util.Calendar.SECOND, 0);
            cal.set(java.util.Calendar.MILLISECOND, 0);
            
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
            return sdf.format(cal.getTime());
        } catch (Exception e) {
            // 如果出错，返回一个保守的日期（3年前）
            java.util.Calendar cal = java.util.Calendar.getInstance();
            cal.add(java.util.Calendar.YEAR, -3);
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
            return sdf.format(cal.getTime());
        }
    }

    /**
     * 清理超过2年的订单数据（只清理订单流水数据，不清理主数据）
     * @return 删除的订单数量
     */
    public int cleanupOldOrders() {
        SQLiteDatabase db = null;
        int deletedCount = 0;
        try {
            db = getWritableDatabase();
            String twoYearsAgo = getDateTwoYearsAgo();
            
            // 开始事务
            db.beginTransaction();
            
            // 1. 先删除order_items（订单明细）
            // 当前表结构使用 order_cloud_id 关联 orders.cloud_id，而不是 order_id
            deletedCount = db.delete("order_items", 
                "order_cloud_id IN (SELECT cloud_id FROM orders WHERE date < ? AND is_deleted = 0 AND cloud_id IS NOT NULL AND TRIM(cloud_id) <> '')", 
                new String[]{twoYearsAgo});
            Log.d("DatabaseHelper", "清理超过2年的order_items: " + deletedCount + "条");
            
            // 2. 删除orders（订单）
            int ordersDeleted = db.delete("orders", 
                "date < ? AND is_deleted = 0", 
                new String[]{twoYearsAgo});
            Log.d("DatabaseHelper", "清理超过2年的orders: " + ordersDeleted + "条");
            deletedCount += ordersDeleted;
            
            // 3. 先删除旧 logistics_sizes（仅删除关联到2年前物流单的尺寸行，避免孤儿明细长期堆积）
            try {
                int logisticsSizesDeleted = db.delete("logistics_sizes",
                    "logistics_id IN (SELECT id FROM logistics_forms WHERE date < ?)",
                    new String[]{twoYearsAgo});
                Log.d("DatabaseHelper", "清理超过2年的logistics_sizes: " + logisticsSizesDeleted + "条");
                deletedCount += logisticsSizesDeleted;
            } catch (Exception e) {
                Log.w("DatabaseHelper", "清理logistics_sizes失败: " + e.getMessage());
            }

            // 4. 删除logistics_forms（物流单）
            try {
                int logisticsDeleted = db.delete("logistics_forms", 
                    "date < ?", 
                    new String[]{twoYearsAgo});
                Log.d("DatabaseHelper", "清理超过2年的logistics_forms: " + logisticsDeleted + "条");
                deletedCount += logisticsDeleted;
            } catch (Exception e) {
                Log.w("DatabaseHelper", "清理logistics_forms失败（可能表不存在或无date字段）: " + e.getMessage());
            }
            
            // 提交事务
            db.setTransactionSuccessful();
            
            Log.d("DatabaseHelper", "2年热数据清理完成，共删除" + deletedCount + "条记录");
            
        } catch (Exception e) {
            Log.e("DatabaseHelper", "清理旧订单数据失败", e);
            deletedCount = 0;
        } finally {
            if (db != null) {
                try {
                    db.endTransaction();
                } catch (Exception ignored) {}
                try {
                    db.close();
                } catch (Exception ignored) {}
            }
        }
        return deletedCount;
    }

    /**
     * 获取超过2年的订单数量（用于统计和显示）
     * @return 超过2年的订单数量
     */
    public int getOldOrdersCount() {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        int count = 0;
        try {
            db = getReadableDatabase();
            String twoYearsAgo = getDateTwoYearsAgo();
            
            cursor = db.rawQuery("SELECT COUNT(*) FROM orders WHERE date < ? AND is_deleted = 0", 
                new String[]{twoYearsAgo});
            if (cursor.moveToFirst()) {
                count = cursor.getInt(0);
            }
        } catch (Exception e) {
            Log.e("DatabaseHelper", "获取旧订单数量失败", e);
        } finally {
            if (cursor != null) cursor.close();
            if (db != null) {
                try {
                    db.close();
                } catch (Exception ignored) {}
            }
        }
        return count;
    }

}
