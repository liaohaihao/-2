package com.suzai.suzaiflowersystem;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

public class AuthManager {
    private static final String PREFS = "auth_prefs";
    private static final String KEY_TOKEN = "auth_token";
    private static final String KEY_TENANT = "tenant_id";
    private static final String KEY_USER = "user_id";
    private static final String KEY_EMAIL = "email";

    // ✅ 组织（共享数据）：customers/products/print_templates
    private static final String KEY_ORG_ID = "org_id";

    // 兼容：LoginActivity 将 access_token 存在 supabase_cfg 中
    private static final String SP_SUPABASE_CFG = "supabase_cfg";
    private static final String KEY_ACCESS_TOKEN_CFG = "access_token";
    private static final String KEY_REFRESH_TOKEN_CFG = "refresh_token";
    // 兼容：LoginActivity 把 user_id 也存到了 supabase_cfg
    private static final String KEY_USER_ID_CFG = "user_id";

    // ===== 场地默认值（按账号）=====
    private static final String KEY_DEFAULT_LOCATION = "default_location";

    // ===== 账号切换隔离（私有数据/同步状态按账号隔离） =====
    private static final String KEY_LAST_LOGIN_USER_ID = "last_login_user_id";

    public static void saveSession(Context ctx, String token, String tenantId, String userId, String email) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        // ✅ 账号切换隔离：若 userId 变化，则清空“私有表”与“拉取状态”，避免 A 账号的订单在 B 账号里看到
        try {
            String lastUid = sp.getString(KEY_LAST_LOGIN_USER_ID, null);
            String nowUid = (userId == null) ? null : userId.trim();
            if (nowUid != null && !nowUid.isEmpty() && lastUid != null && !lastUid.trim().isEmpty() && !nowUid.equals(lastUid.trim())) {
                // 1) 清理本地私有数据（orders/logistics/inventory/payments/cloud_delete_queue...）
                try { new DatabaseHelper(ctx).clearPrivateDataForAccountSwitch(); } catch (Exception ignored) {}

                // 2) 清理同步拉取/推送状态（否则会用上一个账号的 lastPull 做增量，导致新账号“拉不到历史订单”）
                // 修复：清理动态名称的SharedPreferences，避免清理错误的名称
                try { 
                    // 清理旧账号的同步状态
                    if (lastUid != null && !lastUid.trim().isEmpty()) {
                        ctx.getSharedPreferences("sync_pull_state_" + lastUid.trim(), Context.MODE_PRIVATE).edit().clear().apply();
                        ctx.getSharedPreferences("sync_state_" + lastUid.trim(), Context.MODE_PRIVATE).edit().clear().apply();
                        Log.d("AuthManager", "账号切换：清理旧账号 " + lastUid.trim() + " 的同步状态");
                    }
                } catch (Exception e) { Log.e("AuthManager", "清理旧账号同步状态失败", e); }
                
                // 3) 清理org_id缓存，避免跨组织串数据
                try {
                    ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_ORG_ID).apply();
                    Log.d("AuthManager", "账号切换：清理org_id缓存");
                } catch (Exception e) { Log.e("AuthManager", "清理org_id缓存失败", e); }
            }
        } catch (Exception ignored) {}
        // 用 commit() 确保写入立即落盘：避免用户刚登录成功就立刻退出/系统回收导致下次启动丢登录态
        sp.edit()
                .putString(KEY_TOKEN, token)
                .putString(KEY_TENANT, tenantId)
                .putString(KEY_USER, userId)
                .putString(KEY_EMAIL, email)
                .putString(KEY_LAST_LOGIN_USER_ID, userId)
                .commit();

        // ✅ 登录成功后：按账号规则补齐“默认场地/场地列表”（不会覆盖用户手动设置的默认场地）
        try {
            String em = email == null ? null : email.trim().toLowerCase();
            String mappedLoc = null;
            if ("suzai1@163.com".equals(em)) mappedLoc = "佛山";
            else if ("suzai2@163.com".equals(em)) mappedLoc = "广州";
            else if ("suzai3@163.com".equals(em)) mappedLoc = "鹤山";

            if (mappedLoc != null) {
                // ✅ 你的规则：一个账号对应一个场地 —— 强制写入默认场地（避免旧值导致下拉出现多个场地）
                sp.edit().putString(KEY_DEFAULT_LOCATION, mappedLoc).apply();

                // 关键：确保本地 locations 表里存在该场地
                //    这样“新增订单/筛选”等下拉会立刻出现（不依赖用户先手动新增）
                try {
                    new DatabaseHelper(ctx).addLocation(mappedLoc);
                } catch (Exception ignored) {
                }
            }
        } catch (Exception ignored) {}
    }

    public static void clear(Context ctx) {
        // ✅ 退出账号：必须清理登录态（auth_prefs + supabase_cfg 的 token），但保留 baseUrl/anonKey
        try {
            SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            sp.edit().clear().apply();
        } catch (Exception ignored) {}

        try {
            SharedPreferences cfg = ctx.getSharedPreferences(SP_SUPABASE_CFG, Context.MODE_PRIVATE);
            cfg.edit()
                    .remove(KEY_ACCESS_TOKEN_CFG)
                    .remove(KEY_REFRESH_TOKEN_CFG)
                    .remove(KEY_USER_ID_CFG)
                    .apply();
        } catch (Exception ignored) {}
    }

    /** 保存当前账号所属 org_id（用于共享 master-data：客户/产品/模板）。 */
    public static void setOrgId(Context ctx, String orgId) {
        try {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit()
                    .putString(KEY_ORG_ID, orgId == null ? "" : orgId)
                    .apply();
        } catch (Exception ignored) {}
    }

    /** 读取当前账号所属 org_id（若为空表示尚未建立共享组织/或未拉取到）。 */
    public static String getOrgId(Context ctx) {
        try {
            String v = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ORG_ID, null);
            if (v == null) return null;
            v = v.trim();
            return v.isEmpty() ? null : v;
        } catch (Exception ignored) {
            return null;
        }
    }

    public static String getToken(Context ctx) {
        // 1) 优先使用 auth_prefs 中的 token（旧版本）
        String t = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TOKEN, null);
        if (t != null && !t.trim().isEmpty()) return t;

        // 2) 兼容：LoginActivity 将 access_token 存在 supabase_cfg 中（新版本）
        String t2 = ctx.getSharedPreferences(SP_SUPABASE_CFG, Context.MODE_PRIVATE).getString(KEY_ACCESS_TOKEN_CFG, null);
        return (t2 == null || t2.trim().isEmpty()) ? null : t2.trim();
    }

    public static String getTenantId(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TENANT, null);
    }

    public static String getUserId(Context ctx) {
        // 1) 优先 auth_prefs（旧版本/统一登录态）
        String u = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_USER, null);
        if (u != null && !u.trim().isEmpty()) return u;

        // 2) 兼容：supabase_cfg（新版本 LoginActivity 保存）
        String u2 = ctx.getSharedPreferences(SP_SUPABASE_CFG, Context.MODE_PRIVATE).getString(KEY_USER_ID_CFG, null);
        return (u2 == null || u2.trim().isEmpty()) ? null : u2.trim();
    }

    public static String getEmail(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_EMAIL, null);
    }

    public static boolean isLoggedIn(Context ctx) {
        String t = getToken(ctx);
        return t != null && !t.trim().isEmpty();
    }

    public static String getRefreshToken(Context ctx) {
        String r = ctx.getSharedPreferences(SP_SUPABASE_CFG, Context.MODE_PRIVATE).getString(KEY_REFRESH_TOKEN_CFG, null);
        return (r == null || r.trim().isEmpty()) ? null : r.trim();
    }

    public static void saveTokensToSupabaseCfg(Context ctx, String accessToken, String refreshToken) {
        ctx.getSharedPreferences(SP_SUPABASE_CFG, Context.MODE_PRIVATE).edit()
                .putString(KEY_ACCESS_TOKEN_CFG, accessToken == null ? "" : accessToken)
                .putString(KEY_REFRESH_TOKEN_CFG, refreshToken == null ? "" : refreshToken)
                .apply();
    }

    /** 获取账号默认场地：优先读本地保存，其次按邮箱映射。 */
    public static String getDefaultLocation(Context ctx) {
        try {
            String saved = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_DEFAULT_LOCATION, null);
            if (saved != null && !saved.trim().isEmpty()) return saved.trim();
        } catch (Exception ignored) {}

        String email = getEmail(ctx);
        if (email == null) return null;
        email = email.trim().toLowerCase();
        // ✅ 你的规则：suzai1@163.com -> 佛山
        if ("suzai1@163.com".equals(email)) return "佛山";
        if ("suzai2@163.com".equals(email)) return "广州";
        if ("suzai3@163.com".equals(email)) return "鹤山";
        return null;
    }

    /** 保存默认场地（写入 auth_prefs，供 UI 直接读取）。 */
    public static void setDefaultLocation(Context ctx, String location) {
        try {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putString(KEY_DEFAULT_LOCATION, location == null ? "" : location)
                    .apply();
        } catch (Exception ignored) {}
    }

    // Compatibility helper (older code expects this name)
    public static String getDefaultLocationForCurrentUser(android.content.Context ctx) {
        return getDefaultLocation(ctx);
    }

}