package com.suzai.suzaiflowersystem;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.Editable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * 库存管理
 * - 纸箱：逻辑保持原样（物流单尺寸扣减）
 * - 产品/花盆/套袋：在“订单打印出货”后由 DatabaseHelper.deductInventoryForUnprintedOrders(...) 扣减
 * - 套袋：支持绑定多个产品名（inventory_items.sku 里存逗号分隔的产品名列表）
 * - 安全库存：可在“调整”里修改 safety；qty 盘点/增减会产生流水
 */
public class InventoryManagementActivity extends BaseDrawerActivity implements InventoryAdapter.Listener {

    private Spinner typeSpinner;
    private Button addButton;
    private EditText searchEditText;
    private CheckBox lowStockOnlyCheckBox;
    private TextView summaryTextView;
    private RecyclerView recyclerView;
    private TextView hintText;

    private DatabaseHelper db;
    private InventoryAdapter adapter;

    // 全量数据（用于搜索/筛选，不直接喂给 adapter）
    private final List<InventoryItem> allItems = new ArrayList<>();

    // 类型展示
    private static class TypeItem {
        final String label;
        final String type;
        TypeItem(String label, String type) { this.label = label; this.type = type; }
        @Override public String toString() { return label; }
    }

    private final List<TypeItem> types = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentLayout(R.layout.activity_inventory_management);
        if (toolbar != null) toolbar.setTitle("库存管理");
        android.view.View lite = findViewById(R.id.toolbarLite);
        if (lite != null) lite.setVisibility(android.view.View.GONE);

        db = new DatabaseHelper(this);

        typeSpinner = findViewById(R.id.typeSpinner);
        addButton = findViewById(R.id.addItemButton);
        searchEditText = findViewById(R.id.searchEditText);
        lowStockOnlyCheckBox = findViewById(R.id.lowStockOnlyCheckBox);
        summaryTextView = findViewById(R.id.summaryTextView);
        recyclerView = findViewById(R.id.inventoryRecyclerView);
        hintText = findViewById(R.id.lowStockHintTextView);

        types.clear();
        types.add(new TypeItem("纸箱库存", DatabaseHelper.INV_TYPE_CARTON));
        types.add(new TypeItem("花盆库存", DatabaseHelper.INV_TYPE_POT));
        types.add(new TypeItem("套袋库存", DatabaseHelper.INV_TYPE_BAG));
        types.add(new TypeItem("产品库存", DatabaseHelper.INV_TYPE_PRODUCT));

        ArrayAdapter<TypeItem> spinAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, types);
        spinAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        typeSpinner.setAdapter(spinAdapter);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new InventoryAdapter(new ArrayList<>(), this);
        recyclerView.setAdapter(adapter);

        addButton.setOnClickListener(v -> showAddDialog());

        // 搜索/筛选：库存条目多时，商用必须具备
        if (searchEditText != null) {
            searchEditText.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
                @Override public void afterTextChanged(Editable s) { applyFilterAndRender(); }
            });
        }
        if (lowStockOnlyCheckBox != null) {
            lowStockOnlyCheckBox.setOnCheckedChangeListener((btn, checked) -> applyFilterAndRender());
        }

        // 切换类型刷新列表
        typeSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                refreshList();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });

        refreshList();
        refreshLowStockHint();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshList();
        refreshLowStockHint();
    }

    private String currentType() {
        Object obj = typeSpinner.getSelectedItem();
        if (obj instanceof TypeItem) return ((TypeItem) obj).type;
        return DatabaseHelper.INV_TYPE_CARTON;
    }

    private void refreshList() {
        String type = currentType();
        List<InventoryItem> list = db.getInventoryItemsByType(type);
        allItems.clear();
        if (list != null) allItems.addAll(list);
        applyFilterAndRender();
    }

    /**
     * 根据搜索关键字 + “仅看低库存” 勾选，过滤并刷新列表，同时更新统计。
     */
    private void applyFilterAndRender() {
        String q = "";
        if (searchEditText != null) q = safeTrim(searchEditText.getText().toString()).toLowerCase();
        boolean lowOnly = lowStockOnlyCheckBox != null && lowStockOnlyCheckBox.isChecked();

        List<InventoryItem> filtered = new ArrayList<>();
        int sumQty = 0;
        int lowCount = 0;

        for (InventoryItem it : allItems) {
            if (it == null) continue;
            boolean isLow = it.getSafetyStock() > 0 && it.getQuantity() <= it.getSafetyStock();
            if (isLow) lowCount++;

            if (lowOnly && !isLow) continue;

            if (!q.isEmpty()) {
                String name = safeLower(it.getName());
                String sku = safeLower(it.getSku());
                String spec = safeLower(it.getSpec());
                if (!name.contains(q) && !sku.contains(q) && !spec.contains(q)) continue;
            }

            filtered.add(it);
            sumQty += Math.max(0, it.getQuantity());
        }

        adapter.setItems(filtered);

        if (summaryTextView != null) {
            // 统计：当前列表条目数/合计库存/低库存条目数
            summaryTextView.setText("共" + filtered.size() + "项  |  合计" + sumQty + "  |  低库存" + lowCount);
        }
    }

    private void refreshLowStockHint() {
        try {
            String[] watchTypes = new String[]{ DatabaseHelper.INV_TYPE_POT, DatabaseHelper.INV_TYPE_BAG, DatabaseHelper.INV_TYPE_PRODUCT };
            List<InventoryItem> lows = db.getLowStockItems(watchTypes);
            if (lows == null || lows.isEmpty()) {
                hintText.setVisibility(View.GONE);
            } else {
                hintText.setVisibility(View.VISIBLE);
                hintText.setText("⚠ 低库存提醒：有 " + lows.size() + " 个条目低于安全库存（出货后会弹窗提示）。");
            }
        } catch (Exception e) {
            hintText.setVisibility(View.GONE);
        }
    }

    private void showAddDialog() {
        final String type = currentType();

        LinearLayout root = dialogRoot();

        final EditText nameEt = buildEdit(root, "名称（必填）", InputType.TYPE_CLASS_TEXT, 40);
        final EditText skuEt  = buildEdit(root, "SKU/绑定产品（可选）", InputType.TYPE_CLASS_TEXT, 200);
        final EditText specEt = buildEdit(root, "规格（可选）", InputType.TYPE_CLASS_TEXT, 200);
        final EditText qtyEt  = buildEdit(root, "数量 qty（默认0）", InputType.TYPE_CLASS_NUMBER, 10);
        final EditText safEt  = buildEdit(root, "安全库存 safety（默认0）", InputType.TYPE_CLASS_NUMBER, 10);

        boolean bindType = DatabaseHelper.INV_TYPE_BAG.equals(type)
                || DatabaseHelper.INV_TYPE_POT.equals(type)
                || DatabaseHelper.INV_TYPE_PRODUCT.equals(type);
        if (!bindType) {
            skuEt.setHint("SKU（可选）");
        } else {
            skuEt.setHint("对应产品列表：可多选后自动填入");
            Button pick = buildButton(root, "选择对应产品（可多选）");
            pick.setOnClickListener(v -> showPickProductsDialog(skuEt.getText().toString(), (selectedCsv) -> skuEt.setText(selectedCsv)));
        }

        new AlertDialog.Builder(this)
                .setTitle("新增库存：" + typeLabel(type))
                .setView(root)
                .setPositiveButton("保存", (dialog, which) -> {
                    String name = safeTrim(nameEt.getText().toString());
                    if (TextUtils.isEmpty(name)) {
                        toast("名称不能为空");
                        return;
                    }
                    String sku = safeTrim(skuEt.getText().toString());
                    String spec = safeTrim(specEt.getText().toString());
                    int qty = parseInt(qtyEt.getText().toString(), 0);
                    int safety = parseInt(safEt.getText().toString(), 0);

                    db.addInventoryItem(type, name, sku, spec, qty, safety);
                    refreshList();
                    refreshLowStockHint();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    // InventoryAdapter callbacks

    @Override
    public void onEdit(InventoryItem item) {
        showEditItemDialog(item);
    }

    @Override
    public void onInbound(InventoryItem item) {
        showDeltaDialog(item, true);
    }

    @Override
    public void onAdjust(InventoryItem item) {
        showAdjustDialog(item);
    }

    @Override
    public void onStocktake(InventoryItem item) {
        showStocktakeDialog(item);
    }

    @Override
    public void onDelete(InventoryItem item) {
        new AlertDialog.Builder(this)
                .setTitle("删除库存")
                .setMessage("确认删除：" + item.getName() + " ?\n删除后对应流水也会清理。")
                .setPositiveButton("删除", (d, w) -> {
                    db.deleteInventoryItem(item.getId());
                    refreshList();
                    refreshLowStockHint();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showDeltaDialog(InventoryItem item, boolean inbound) {
        LinearLayout root = dialogRoot();

        String title = inbound ? "入库增加" : "出库减少";
        final EditText deltaEt = buildEdit(root, inbound ? "增加数量（正整数）" : "减少数量（正整数）", InputType.TYPE_CLASS_NUMBER, 10);
        final EditText noteEt = buildEdit(root, "备注（可选）", InputType.TYPE_CLASS_TEXT, 200);

        new AlertDialog.Builder(this)
                .setTitle(title + "：" + item.getName())
                .setView(root)
                .setPositiveButton("确定", (d, w) -> {
                    int delta = parseInt(deltaEt.getText().toString(), 0);
                    if (delta <= 0) {
                        toast("数量必须 > 0");
                        return;
                    }
                    if (!inbound) delta = -delta;
                    String note = safeTrim(noteEt.getText().toString());
                    String reason = inbound ? "手动入库" : "手动出库";
                    if (!TextUtils.isEmpty(note)) reason = reason + "：" + note;

                    db.adjustInventory(item.getId(), delta, reason, inbound ? "INBOUND" : "OUTBOUND", 0);
                    refreshList();
                    refreshLowStockHint();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /**
     * 调整：修改 qty（产生流水） + 修改 safety（不产生流水） + 套袋绑定产品列表
     */
    private void showAdjustDialog(InventoryItem item) {
        LinearLayout root = dialogRoot();

        TextView cur = new TextView(this);
        cur.setText("当前 qty=" + item.getQuantity() + "，安全库存 safety=" + item.getSafetyStock());
        cur.setPadding(0, 0, 0, dp(8));
        root.addView(cur, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final EditText qtyEt = buildEdit(root, "修改 qty（留空=不改）", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED, 12);
        final EditText safEt = buildEdit(root, "修改 safety（留空=不改）", InputType.TYPE_CLASS_NUMBER, 12);

        final EditText skuEt;
        boolean bindType = DatabaseHelper.INV_TYPE_BAG.equals(item.getType())
                || DatabaseHelper.INV_TYPE_POT.equals(item.getType())
                || DatabaseHelper.INV_TYPE_PRODUCT.equals(item.getType());
        if (bindType) {
            skuEt = buildEdit(root, "对应产品列表（逗号分隔，可多选）", InputType.TYPE_CLASS_TEXT, 400);
            skuEt.setText(safeTrim(item.getSku()));
            Button pick = buildButton(root, "选择对应产品（可多选）");
            pick.setOnClickListener(v -> showPickProductsDialog(skuEt.getText().toString(), (selectedCsv) -> skuEt.setText(selectedCsv)));
        } else {
            skuEt = null;
        }

        final EditText noteEt = buildEdit(root, "调整备注（可选，写入流水）", InputType.TYPE_CLASS_TEXT, 200);

        new AlertDialog.Builder(this)
                .setTitle("调整：" + item.getName())
                .setView(root)
                .setPositiveButton("保存", (d, w) -> {
                    String note = safeTrim(noteEt.getText().toString());
                    String reason = TextUtils.isEmpty(note) ? "手动调整" : ("手动调整：" + note);

                    // 1) qty
                    String qtyStr = safeTrim(qtyEt.getText().toString());
                    if (!TextUtils.isEmpty(qtyStr)) {
                        int newQty = parseInt(qtyStr, item.getQuantity());
                        db.setInventoryQuantityWithLog(item.getId(), newQty, reason);
                    }

                    // 2) safety
                    String safStr = safeTrim(safEt.getText().toString());
                    if (!TextUtils.isEmpty(safStr)) {
                        int newSaf = parseInt(safStr, item.getSafetyStock());
                        db.setInventorySafetyStock(item.getId(), newSaf, "修改安全库存");
                    }

                    // 3) bound products
                    if (skuEt != null) {
                        db.setInventorySku(item.getId(), safeTrim(skuEt.getText().toString()));
                    }

                    refreshList();
                    refreshLowStockHint();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showEditItemDialog(InventoryItem item) {
        LinearLayout root = dialogRoot();

        final EditText nameEt = buildEdit(root, "库存名称（必填）", InputType.TYPE_CLASS_TEXT, 80);
        nameEt.setText(safeTrim(item.getName()));

        final EditText skuEt = buildEdit(root, "SKU/对应产品（可选）", InputType.TYPE_CLASS_TEXT, 400);
        skuEt.setText(safeTrim(item.getSku()));

        final EditText specEt = buildEdit(root, "规格（可选）", InputType.TYPE_CLASS_TEXT, 200);
        specEt.setText(safeTrim(item.getSpec()));

        final EditText safEt = buildEdit(root, "安全库存（留空=不改）", InputType.TYPE_CLASS_NUMBER, 12);
        safEt.setText(String.valueOf(Math.max(0, item.getSafetyStock())));

        boolean bindType = DatabaseHelper.INV_TYPE_BAG.equals(item.getType())
                || DatabaseHelper.INV_TYPE_POT.equals(item.getType())
                || DatabaseHelper.INV_TYPE_PRODUCT.equals(item.getType());
        if (bindType) {
            skuEt.setHint("对应产品列表：可多选后自动填入");
            Button pick = buildButton(root, "选择对应产品（可多选）");
            pick.setOnClickListener(v -> showPickProductsDialog(skuEt.getText().toString(), (selectedCsv) -> skuEt.setText(selectedCsv)));
        } else {
            skuEt.setHint("SKU（可选）");
        }

        new AlertDialog.Builder(this)
                .setTitle("编辑库存：" + item.getName())
                .setView(root)
                .setPositiveButton("保存", (d, w) -> {
                    String name = safeTrim(nameEt.getText().toString());
                    if (TextUtils.isEmpty(name)) {
                        toast("库存名称不能为空");
                        return;
                    }
                    String sku = safeTrim(skuEt.getText().toString());
                    String spec = safeTrim(specEt.getText().toString());
                    Integer safety = null;
                    String safStr = safeTrim(safEt.getText().toString());
                    if (!TextUtils.isEmpty(safStr)) {
                        safety = parseInt(safStr, item.getSafetyStock());
                    }
                    db.updateInventoryItemBasic(item.getId(), name, sku, spec, safety);
                    refreshList();
                    refreshLowStockHint();
                    toast("库存已更新");
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showStocktakeDialog(InventoryItem item) {
        LinearLayout root = dialogRoot();

        final EditText qtyEt = buildEdit(root, "盘点数量（必须填）", InputType.TYPE_CLASS_NUMBER, 12);
        qtyEt.setText(String.valueOf(Math.max(0, item.getQuantity())));
        final EditText noteEt = buildEdit(root, "盘点备注（可选）", InputType.TYPE_CLASS_TEXT, 200);

        new AlertDialog.Builder(this)
                .setTitle("盘点：" + item.getName())
                .setView(root)
                .setPositiveButton("确定", (d, w) -> {
                    int newQty = parseInt(qtyEt.getText().toString(), item.getQuantity());
                    String note = safeTrim(noteEt.getText().toString());
                    db.stocktakeSingleItem(item.getId(), newQty, TextUtils.isEmpty(note) ? "盘点调整" : note);
                    refreshList();
                    refreshLowStockHint();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    // ---------- 套袋：选择产品多选 ----------

    private interface PickCallback {
        void onPicked(String csv);
    }

    private void showPickProductsDialog(String curSku, PickCallback cb) {
        // 注意：在 lambda/匿名内部类中引用的本地变量必须是 final 或“实际上 final”。
        // 这里不要对 products 重新赋值... , instead fill list.
        final List<String> products = new ArrayList<>();
        try {
            List<String> tmp = db.getAllProductNames();
            if (tmp != null) products.addAll(tmp);
        } catch (Exception ignored) {
        }

        if (products.isEmpty()) {
            toast("产品列表为空，请先在“产品管理”添加产品。");
            return;
        }

        final boolean[] checked = new boolean[products.size()];
        for (int i = 0; i < products.size(); i++) {
            String p = products.get(i);
            checked[i] = skuListContains(curSku, p);
        }

        String[] items = products.toArray(new String[0]);

        new AlertDialog.Builder(this)
                .setTitle("选择对应产品（可多选）")
                .setMultiChoiceItems(items, checked, (dialog, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton("确定", (dialog, which) -> {
                    List<String> sel = new ArrayList<>();
                    for (int i = 0; i < checked.length; i++) {
                        if (checked[i]) sel.add(products.get(i));
                    }
                    cb.onPicked(TextUtils.join(",", sel));
                })
                .setNegativeButton("取消", null)
                .setNeutralButton("全不选", (dialog, which) -> {
                    for (int i = 0; i < checked.length; i++) checked[i] = false;
                    // 重新打开一遍，给用户直观看到清空（简单处理：直接回调空）
                    cb.onPicked("");
                })
                .show();
    }

    /**
     * 判断 sku 列表里是否包含某个产品名。\n
     * 兼容：中文逗号、空格、换行、分号、竖线。\n
     * 注意：这里是“精确匹配”，避免“110钻石水培”被“110钻石水培A”误命中。\n
     */
    private boolean skuListContains(String skuList, String productName) {
        if (skuList == null || productName == null) return false;
        String sku = skuList.replace('，', ',')
                .replace(';', ',')
                .replace('|', ',')
                .replace('\n', ',')
                .replace('\r', ',')
                .trim();
        if (sku.isEmpty()) return false;

        // 允许用空格分隔
        sku = sku.replace(" ", ",");

        String target = productName.trim();
        if (target.isEmpty()) return false;

        String[] parts = sku.split(",");
        for (String p : parts) {
            if (p == null) continue;
            String t = p.trim();
            if (t.isEmpty()) continue;
            if (t.equals(target)) return true;
        }
        return false;
    }

    // ---------- small helpers ----------

    private LinearLayout dialogRoot() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        root.setPadding(pad, pad, pad, pad);
        return root;
    }

    private Button buildButton(LinearLayout root, String text) {
        Button b = new Button(this);
        b.setText(text);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        root.addView(b, lp);
        return b;
    }

    private EditText buildEdit(LinearLayout root, String hint, int inputType, int maxLen) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setInputType(inputType);
        et.setFilters(new InputFilter[]{ new InputFilter.LengthFilter(maxLen) });
        et.setGravity(Gravity.START);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        root.addView(et, lp);
        return et;
    }

    private int dp(int v) {
        float d = getResources().getDisplayMetrics().density;
        return (int) (v * d + 0.5f);
    }

    private String typeLabel(String type) {
        if (DatabaseHelper.INV_TYPE_CARTON.equals(type)) return "纸箱";
        if (DatabaseHelper.INV_TYPE_POT.equals(type)) return "花盆";
        if (DatabaseHelper.INV_TYPE_BAG.equals(type)) return "套袋";
        if (DatabaseHelper.INV_TYPE_PRODUCT.equals(type)) return "产品";
        return type;
    }

    private String safeTrim(String s) {
        return s == null ? "" : s.trim();
    }

    private String safeLower(String s) {
        if (s == null) return "";
        return s.trim().toLowerCase();
    }

    private int parseInt(String s, int def) {
        try {
            if (s == null) return def;
            s = s.trim();
            if (s.isEmpty()) return def;
            return Integer.parseInt(s);
        } catch (Exception e) {
            return def;
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
