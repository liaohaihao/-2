package com.suzai.suzaiflowersystem;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

/**
 * ✅ 完全可覆盖版
 * - 支持 template_id<=0 的“新增模板”流程：先插入一条模板，再进入编辑
 * - LABEL 模板跳转拖拽编辑器（避免旧界面）
 * - DatabaseHelper.updateTemplate(...) 返回 void 的兼容
 */
public class TemplateEditActivity extends AppCompatActivity {

    public static final String EXTRA_TEMPLATE_ID = "template_id";

    private DatabaseHelper db;

    private long templateId = -1;
    private String type; // 来自 TemplateCenterActivity.currentType()

    private PrintTemplate template;

    private EditText etName;
    private EditText etContent;
    private Button btnSave;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setTitle("编辑模板");
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        setContentView(R.layout.activity_template_edit);

        db = new DatabaseHelper(this);

        etName = findViewById(R.id.etTemplateName);
        etContent = findViewById(R.id.etTemplateContent);
        btnSave = findViewById(R.id.btnSaveTemplate);

        type = getIntent().getStringExtra("type");
        if (TextUtils.isEmpty(type)) {
            // 兜底：默认标签
            type = TemplateCenterActivity.TYPE_LABEL;
        }

        templateId = getIntent().getLongExtra(EXTRA_TEMPLATE_ID, -1);

        // ✅ 新增模板：templateId<=0 时先插入一条默认模板，再编辑
        if (templateId <= 0) {
            String defaultName = defaultNameForType(type);
            String defaultContent = safe(db.getDefaultTemplateContent(type));
            long now = System.currentTimeMillis();
            try {
                templateId = db.insertTemplate(type, defaultName, defaultContent, now, 0);
            } catch (Exception e) {
                Toast.makeText(this, "新增模板失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
        }

        template = db.getTemplateById(templateId);
        if (template == null) {
            Toast.makeText(this, "未找到模板", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }


        // ✅ LABEL 模板：跳转拖拽编辑器
        if (TemplateCenterActivity.TYPE_LABEL.equalsIgnoreCase(safe(template.getType()))) {
            Intent it = new Intent(this, DraggableLabelTemplateEditActivity.class);
            it.putExtra(EXTRA_TEMPLATE_ID, templateId);
            it.putExtra("type", template.getType());
            startActivity(it);
            finish();
            return;
        }

        // ✅ 送货单/物流单：打开“小票模板设计器”（带实时预览 + 字段插入）
        if (TemplateCenterActivity.TYPE_DELIVERY.equalsIgnoreCase(safe(template.getType()))
                || TemplateCenterActivity.TYPE_LOGISTICS.equalsIgnoreCase(safe(template.getType()))) {
            Intent it = new Intent(this, ReceiptTemplateDesignerActivity.class);
            it.putExtra(ReceiptTemplateDesignerActivity.EXTRA_TEMPLATE_ID, templateId);
            it.putExtra(ReceiptTemplateDesignerActivity.EXTRA_TYPE, template.getType());
            startActivity(it);
            finish();
            return;
        }

        // 其它模板：文本编辑

        etName.setText(safe(template.getName()));
        etContent.setText(safe(template.getContent()));

        btnSave.setOnClickListener(v -> {
            String name = etName.getText() == null ? "" : etName.getText().toString().trim();
            String content = etContent.getText() == null ? "" : etContent.getText().toString();

            if (TextUtils.isEmpty(name)) {
                Toast.makeText(this, "请输入模板名称", Toast.LENGTH_SHORT).show();
                return;
            }
            if (TextUtils.isEmpty(content)) {
                Toast.makeText(this, "请输入模板内容", Toast.LENGTH_SHORT).show();
                return;
            }

            long updatedAt = System.currentTimeMillis();

            try {
                db.updateTemplate(templateId, name, content, updatedAt);

                // 再读一次确认
                PrintTemplate after = db.getTemplateById(templateId);
                boolean saved = after != null
                        && name.equals(safe(after.getName()))
                        && content.equals(safe(after.getContent()));

                if (saved) {
                    Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                } else {
                    Toast.makeText(this, "保存可能失败：请重试", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "保存失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private String defaultNameForType(String type) {
        if (TemplateCenterActivity.TYPE_LABEL.equalsIgnoreCase(type)) return "客户标签模板";
        if (TemplateCenterActivity.TYPE_DELIVERY.equalsIgnoreCase(type)) return "出货单模板";
        if (TemplateCenterActivity.TYPE_LOGISTICS.equalsIgnoreCase(type)) return "物流单模板";
        return "新模板";
    }

    private String safe(String s) {
        return s == null ? "" : s;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
