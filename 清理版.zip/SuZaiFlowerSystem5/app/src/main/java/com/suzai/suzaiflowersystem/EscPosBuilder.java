package com.suzai.suzaiflowersystem;

import java.io.ByteArrayOutputStream;
import java.nio.charset.Charset;

public class EscPosBuilder {

    private final ByteArrayOutputStream out = new ByteArrayOutputStream();
    private final Charset charset;

    public EscPosBuilder(Charset charset){
        this.charset = charset;
        // init
        cmd(new byte[]{0x1B, 0x40});
    }

    public EscPosBuilder text(String s){
        if (s == null) return this;
        try {
            out.write(s.getBytes(charset));
        } catch (Exception ignore) {}
        return this;
    }

    public EscPosBuilder ln(){
        return cmd(new byte[]{0x0A});
    }

    public EscPosBuilder feed(int n){
        for(int i=0;i<n;i++) ln();
        return this;
    }

    public EscPosBuilder bigOn(){
        // GS ! n  (double width + double height)
        return cmd(new byte[]{0x1D, 0x21, 0x11});
    }

    public EscPosBuilder bigOff(){
        return cmd(new byte[]{0x1D, 0x21, 0x00});
    }

    public EscPosBuilder boldOn(){
        return cmd(new byte[]{0x1B, 0x45, 0x01});
    }

    public EscPosBuilder boldOff(){
        return cmd(new byte[]{0x1B, 0x45, 0x00});
    }

    public EscPosBuilder center(){
        return cmd(new byte[]{0x1B, 0x61, 0x01});
    }

    public EscPosBuilder left(){
        return cmd(new byte[]{0x1B, 0x61, 0x00});
    }

    public EscPosBuilder cmd(byte[] b){
        try { out.write(b); } catch (Exception ignore) {}
        return this;
    }

    public byte[] build(){
        return out.toByteArray();
    }
}