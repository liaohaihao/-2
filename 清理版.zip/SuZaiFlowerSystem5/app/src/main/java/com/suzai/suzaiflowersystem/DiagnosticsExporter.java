package com.suzai.suzaiflowersystem;

import android.content.Context;

import java.io.File;

public class DiagnosticsExporter {
    public static File exportZip(Context ctx) {
        throw new UnsupportedOperationException("正式版已关闭诊断包导出功能");
    }
}
