package com.suzai.suzaiflowersystem;

import android.app.AlertDialog;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 云端财务：核销明细（ar_allocations）
 * - 选择“应收账单 + 收款记录”进行核销
 */
public class ArAllocationsActivity extends BaseDrawerActivity {

    private DatabaseHelper db;
    private ArAllocationAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("核销明细（云）");
        setContentLayout(R.layout.activity_ar_allocations);

        db = new DatabaseHelper(this);

        Button btnAdd = findViewById(R.id.btn_add);
        Button btnRefresh = findViewById(R.id.btn_refresh);
        Button btnExport = findViewById(R.id.btn_export);

        RecyclerView rv = findViewById(R.id.recycler);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ArAllocationAdapter(row -> showEditDialog(row));
        rv.setAdapter(adapter);

        btnAdd.setOnClickListener(v -> showEditDialog(null));
        btnRefresh.setOnClickListener(v -> refresh());
        btnExport.setOnClickListener(v -> exportExcel());

        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        adapter.setData(db.getArAllocations());
    }

    private void showEditDialog(ArAllocationRow row) {
        boolean isNew = (row == null);
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_ar_allocation, null);
        Spinner spInvoice = view.findViewById(R.id.sp_invoice);
        Spinner spPayment = view.findViewById(R.id.sp_payment);
        EditText etAmount = view.findViewById(R.id.et_amount);
        EditText etNote = view.findViewById(R.id.et_note);

        List<ArInvoiceRow> invoices = db.getArInvoices();
        List<ArPaymentRow> payments = db.getArPayments();

        List<String> invoiceLabels = new ArrayList<>();
        for (ArInvoiceRow i : invoices) {
            invoiceLabels.add(nvl(i.periodYm) + " " + nvl(i.customerName) + "(" + fmt2(i.amount) + ")");
        }
        List<String> paymentLabels = new ArrayList<>();
        for (ArPaymentRow p : payments) {
            paymentLabels.add(nvl(p.payDate) + " " + nvl(p.customerName) + "(" + fmt2(p.amount) + ")");
        }

        spInvoice.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                invoiceLabels.isEmpty() ? new String[]{"(没有应收账单)"} : invoiceLabels.toArray(new String[0])));
        spPayment.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                paymentLabels.isEmpty() ? new String[]{"(没有收款记录)"} : paymentLabels.toArray(new String[0])));

        if (!isNew) {
            etAmount.setText(fmt2(row.amount));
            etNote.setText(nvl(row.note));
            // 尝试定位 spinner
            int invIdx = 0;
            for (int k = 0; k < invoices.size(); k++) {
                if (TextUtils.equals(invoices.get(k).cloudId, row.invoiceCloudId)) { invIdx = k; break; }
            }
            int payIdx = 0;
            for (int k = 0; k < payments.size(); k++) {
                if (TextUtils.equals(payments.get(k).cloudId, row.paymentCloudId)) { payIdx = k; break; }
            }
            if (invoices.size() > 0) spInvoice.setSelection(invIdx);
            if (payments.size() > 0) spPayment.setSelection(payIdx);
        }

        new AlertDialog.Builder(this)
                .setTitle(isNew ? "新增核销" : "编辑核销")
                .setView(view)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", (d, w) -> {
                    if (invoices.isEmpty() || payments.isEmpty()) {
                        Toast.makeText(this, "需要先有应收账单与收款记录", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    int invPos = spInvoice.getSelectedItemPosition();
                    int payPos = spPayment.getSelectedItemPosition();
                    if (invPos < 0 || invPos >= invoices.size() || payPos < 0 || payPos >= payments.size()) {
                        Toast.makeText(this, "请选择有效账单/收款", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    String amountStr = etAmount.getText().toString().trim();
                    if (TextUtils.isEmpty(amountStr)) amountStr = "0";
                    double amount;
                    try { amount = Double.parseDouble(amountStr); } catch (Exception e) { amount = 0; }
                    String note = etNote.getText().toString().trim();

                    String site = nvl(AuthManager.getDefaultLocation(this));
                    db.upsertArAllocation(row == null ? null : row.cloudId,
                            site,
                            invoices.get(invPos).cloudId,
                            payments.get(payPos).cloudId,
                            amount,
                            note);
                    refresh();
                    Toast.makeText(this, "已保存（记得点同步上传）", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void exportExcel() {
        try {
            List<ArAllocationRow> rows = db.getArAllocations();
            String[] headers = new String[]{"场地", "账单ID", "收款ID", "核销金额", "备注"};
            List<List<String>> data = new ArrayList<>();
            for (ArAllocationRow r : rows) {
                List<String> line = new ArrayList<>();
                line.add(nvl(r.siteName));
                line.add(nvl(r.invoiceCloudId));
                line.add(nvl(r.paymentCloudId));
                line.add(fmt2(r.amount));
                line.add(nvl(r.note));
                data.add(line);
            }
            String xml = SpreadsheetXml.buildWorkbookSingle("核销明细(云)", "ar_allocations", headers, data);
            String month = new SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(new Date());
            String fileName = "核销明细_云_" + month + ".xls";
            Uri uri = ExportUtils.saveTextToDownloads(this, "SuZaiExports/Finance/" + month, fileName,
                    "application/vnd.ms-excel", xml);
            Toast.makeText(this, uri == null ? "导出失败" : "已导出：" + fileName, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "导出失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private static String nvl(String s) { return s == null ? "" : s; }
    private static String fmt2(double v) { return String.format(Locale.getDefault(), "%.2f", v); }
}
