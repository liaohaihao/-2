package com.suzai.suzaiflowersystem;

import android.app.AlertDialog;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 云端财务：收款记录（ar_payments）
 */
public class ArPaymentsActivity extends BaseDrawerActivity {

    private DatabaseHelper db;
    private ArPaymentAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("收款记录（云）");
        setContentLayout(R.layout.activity_ar_payments);

        db = new DatabaseHelper(this);

        Button btnAdd = findViewById(R.id.btn_add);
        Button btnRefresh = findViewById(R.id.btn_refresh);
        Button btnExport = findViewById(R.id.btn_export);

        RecyclerView rv = findViewById(R.id.recycler);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ArPaymentAdapter(row -> showEditDialog(row));
        rv.setAdapter(adapter);

        btnAdd.setOnClickListener(v -> showEditDialog(null));
        btnRefresh.setOnClickListener(v -> refresh());
        btnExport.setOnClickListener(v -> exportExcel());

        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        adapter.setData(db.getArPayments());
    }

    private void showEditDialog(ArPaymentRow row) {
        boolean isNew = (row == null);
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_ar_payment, null);
        EditText etCustomer = view.findViewById(R.id.et_customer);
        EditText etAmount = view.findViewById(R.id.et_amount);
        EditText etDate = view.findViewById(R.id.et_date);
        EditText etMethod = view.findViewById(R.id.et_method);
        EditText etNote = view.findViewById(R.id.et_note);

        String defaultSite = nvl(AuthManager.getDefaultLocation(this));
        if (isNew) {
            etDate.setText(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()));
        } else {
            etCustomer.setText(nvl(row.customerName));
            etAmount.setText(fmt2(row.amount));
            etDate.setText(nvl(row.payDate));
            etMethod.setText(nvl(row.method));
            etNote.setText(nvl(row.note));
        }

        new AlertDialog.Builder(this)
                .setTitle(isNew ? "新增收款" : "编辑收款")
                .setView(view)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", (d, w) -> {
                    String customer = etCustomer.getText().toString().trim();
                    String amountStr = etAmount.getText().toString().trim();
                    String payDate = etDate.getText().toString().trim();
                    String method = etMethod.getText().toString().trim();
                    String note = etNote.getText().toString().trim();

                    if (TextUtils.isEmpty(customer)) {
                        Toast.makeText(this, "请输入客户", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (TextUtils.isEmpty(amountStr)) amountStr = "0";
                    double amount;
                    try { amount = Double.parseDouble(amountStr); } catch (Exception e) { amount = 0; }
                    if (TextUtils.isEmpty(payDate)) {
                        payDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                    }

                    db.upsertArPayment(row == null ? null : row.cloudId,
                            defaultSite,
                            customer,
                            amount,
                            payDate,
                            method,
                            note);
                    refresh();
                    Toast.makeText(this, "已保存（记得点同步上传）", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void exportExcel() {
        try {
            List<ArPaymentRow> rows = db.getArPayments();
            String[] headers = new String[]{"场地", "客户", "日期", "金额", "方式", "备注"};
            List<List<String>> data = new ArrayList<>();
            for (ArPaymentRow r : rows) {
                List<String> line = new ArrayList<>();
                line.add(nvl(r.siteName));
                line.add(nvl(r.customerName));
                line.add(nvl(r.payDate));
                line.add(fmt2(r.amount));
                line.add(nvl(r.method));
                line.add(nvl(r.note));
                data.add(line);
            }
            String xml = SpreadsheetXml.buildWorkbookSingle("收款记录(云)", "ar_payments", headers, data);
            String month = new SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(new Date());
            String fileName = "收款记录_云_" + month + ".xls";
            Uri uri = ExportUtils.saveTextToDownloads(this, "SuZaiExports/Finance/" + month, fileName,
                    "application/vnd.ms-excel", xml);
            Toast.makeText(this, uri == null ? "导出失败" : "已导出：" + fileName, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "导出失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private static String nvl(String s) { return s == null ? "" : s; }
    private static String fmt2(double v) { return String.format(Locale.getDefault(), "%.2f", v); }
}
