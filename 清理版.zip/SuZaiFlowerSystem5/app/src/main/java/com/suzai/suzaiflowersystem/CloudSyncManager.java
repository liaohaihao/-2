package com.suzai.suzaiflowersystem;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * MVP 同步管理器：把本地 sync_queue 里的任务批量推送到服务器。
 * 为了避免引入 WorkManager 依赖（会增加构建复杂度），这里用单线程线程池。
 * 商用增强建议：切换为 WorkManager + 网络约束 + 指数退避。
 */
public class CloudSyncManager {

    private static CloudSyncManager instance;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public static synchronized CloudSyncManager getInstance() {
        if (instance == null) instance = new CloudSyncManager();
        return instance;
    }

    public void triggerSync(Context ctx) {
        executor.execute(() -> {
            try {
                if (!AuthManager.isLoggedIn(ctx)) return;
                String token = AuthManager.getToken(ctx);

                DatabaseHelper db = new DatabaseHelper(ctx);

                // 1) 先拉取云端主数据/模板（增量）
                try {
                    String baseUrl = CloudSettings.getBaseUrl(ctx);
                    CloudApiClient api = new CloudApiClient(baseUrl);

                    long sinceMaster = CloudSyncPrefs.getMasterLastPull(ctx);
                    JSONObject md = api.pullMasterData(token, sinceMaster);
                    db.applyMasterDataFromCloud(md);
                    long serverTime = md.optLong("server_time", System.currentTimeMillis());
                    CloudSyncPrefs.setMasterLastPull(ctx, serverTime);

                    long sinceTpl = CloudSyncPrefs.getTplLastPull(ctx);
                    JSONObject tpls = api.pullTemplates(token, sinceTpl);
                    db.applyTemplatesFromCloud(tpls);
                    long serverTime2 = tpls.optLong("server_time", System.currentTimeMillis());
                    CloudSyncPrefs.setTplLastPull(ctx, serverTime2);
                } catch (Exception ignored) {}

                // 2) 再推送本地待同步队列（幂等 movement 等）

                List<SyncQueueItem> pending = db.getPendingSyncQueue(50);
                if (pending == null || pending.isEmpty()) return;

                JSONArray arr = new JSONArray();
                for (SyncQueueItem item : pending) {
                    JSONObject o = new JSONObject();
                    o.put("id", item.getId());
                    o.put("type", item.getType());
                    o.put("payload", new JSONObject(item.getPayload()));
                    o.put("created_at", item.getCreatedAt());
                    arr.put(o);
                }

                String baseUrl2 = CloudSettings.getBaseUrl(ctx);
                CloudApiClient api2 = new CloudApiClient(baseUrl2);
                api2.pushSyncBatch(token, arr);

                // 成功后标记已同步
                for (SyncQueueItem item : pending) {
                    db.markSyncQueueDone(item.getId());
                }
            } catch (Exception ignored) {
                // MVP：静默失败，下次再试
            }
        });
    }
}
