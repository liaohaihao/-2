package com.suzai.suzaiflowersystem;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.Date;

/**
 * OrderPrintActivity - 最终可覆盖版（飞鹅云小票：商品明细“可调节输出口”）
 *
 * 你提到的问题：
 * - “加粗会导致字体变大 -> 超行自动换行”：这是因为你之前用的是“字号变大”来达到加粗效果。
 *
 * 本版提供的解决方案（不再靠字号变大）：
 * 1) 在程序里提供 2 个商品明细输出口：
 *    - {{items_lines}}         : 普通（不加粗）
 *    - {{items_lines_bold}}    : 使用飞鹅云 <B> 包裹（不改变字号，只加粗）
 *    模板中心里你想加粗商品明细，就把模板里的 {{items_lines}} 改成 {{items_lines_bold}} 即可。
 *
 * 2) 为避免加粗导致“同等字符更宽 -> 换行”，本版对“商品名”做了可控截断：
 *    - 普通输出口：默认最大宽度 UNITS_NAME_MAX_NORMAL
 *    - 加粗输出口：默认最大宽度 UNITS_NAME_MAX_BOLD（略小）
 *
 * 3) 商品与商品之间：自动插入 1 个空行（可在常量里调整）
 *
 * 仅修改送货单打印相关逻辑；其它功能保持原样。
 */
public class OrderPrintActivity extends BaseDrawerActivity {
    private static final String LABEL_PRINT_PREF = "label_print_pref";
    private static final String KEY_LABEL_PRINTED_MAXID_PREFIX = "label_printed_maxid_";


    public static final String EXTRA_DATE = "extra_date";
    public static final String EXTRA_CUSTOMER = "extra_customer";
    public static final String EXTRA_ORDER_ID = "extra_order_id"; // ✅ 兼容外部跳转

    private static final int REQ_BT_PERMS = 2201;

    // ====== 商品明细排版“可调节区”（你以后想微调，只改这里） ======
    // 说明：这里的“单位宽度”是为了兼容中英文混排：中文约 2 单位，英文/数字约 1 单位
    private static final int UNITS_NAME_MAX_NORMAL = 26; // 普通：商品名最大宽度（单位）
    private static final int UNITS_NAME_MAX_BOLD = 24;   // 加粗：商品名最大宽度（单位）——略小，避免粗体更宽导致换行

    // 数值列宽（80mm 小票推荐；如果你发现列仍不齐，只改这里）
    private static final int W_PRICE = 8;
    private static final int W_PACK = 6;
    private static final int W_QTY = 6;
    private static final int W_AMOUNT = 10;
    private static final int W_PIECES = 4;

    // 商品之间空行数（1 = 插入一个空行；2 = 两个空行）
    private static final int GAP_BLANK_LINES_BETWEEN_ITEMS = 1;
    // ============================================================

    private TextView customerTitleTextView;
    private TextView dateTextView;
    private TextView locationTextView;
    private TextView orderTotalsTextView;

    private Button deleteCheckedOrdersButton;
    private Button cancelOrderButton;
    private Button editOrderButton;
    private Button appendOrderButton;
    private Button printCheckedLabelsButton;
    private Button printAllLabelsButton;
    private Button printDeliveryNoteButton;

    private RecyclerView itemsRecyclerView;
    private OrderPrintItemAdapter adapter;

    private DatabaseHelper db;
    private String date;
    private String customer;
    private String currentLocation = "";
    private List<Order> orderItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("订单打印");
        setContentLayout(R.layout.activity_order_print);

        db = new DatabaseHelper(this);

        Intent it = getIntent();
        date = it.getStringExtra(EXTRA_DATE);
        if (date == null) date = it.getStringExtra("date");
        customer = it.getStringExtra(EXTRA_CUSTOMER);
        if (customer == null) customer = it.getStringExtra("customer");

        initViews();
        loadData();
        setupButtons();
    }

    /* =========================================================
       ✅ 关键：动态查找 View id，彻底避免 R.id.xxx 缺失导致编译失败
       ========================================================= */
    private int id(String name) {
        return getResources().getIdentifier(name, "id", getPackageName());
    }

    @SuppressWarnings("unchecked")
    private <T> T fv(String idName) {
        int resId = id(idName);
        if (resId == 0) return null;
        return (T) findViewById(resId);
    }

    private void initViews() {
        customerTitleTextView = fv("customerTitleTextView");
        dateTextView = fv("orderDateTextView");
        locationTextView = fv("orderLocationTextView");
        orderTotalsTextView = fv("orderTotalsTextView");

        deleteCheckedOrdersButton = fv("deleteCheckedOrdersButton");
        cancelOrderButton = fv("cancelOrderButton");
        editOrderButton = fv("editOrderButton");
        appendOrderButton = fv("appendOrderButton");
        printCheckedLabelsButton = fv("printCheckedLabelsButton");
        printAllLabelsButton = fv("printAllLabelsButton");
        printDeliveryNoteButton = fv("printDeliveryNoteButton");

        itemsRecyclerView = fv("itemsRecyclerView");
        if (itemsRecyclerView != null) {
            itemsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        }

        adapter = new OrderPrintItemAdapter(orderItems);
        if (itemsRecyclerView != null) {
            itemsRecyclerView.setAdapter(adapter);
        }
    }

    private void loadData() {
        if (date == null) date = "";
        if (customer == null) customer = "";

        orderItems = db.getOrdersByDateAndCustomer(date, customer);
        if (orderItems == null) orderItems = new ArrayList<>();
        adapter.updateItems(orderItems);

        int totalPieces = 0;
        double totalAmount = 0.0;
        for (Order o : orderItems) {
            totalPieces += Math.max(0, o.getPieces());
            totalAmount += o.getTotalPrice();
        }

        if (orderTotalsTextView != null) {
            orderTotalsTextView.setText(String.format(Locale.getDefault(),
                    "合计：总件数 %d    总金额 %.2f", totalPieces, totalAmount));
        }

        if (customerTitleTextView != null) customerTitleTextView.setText("客户：" + customer);
        if (dateTextView != null) dateTextView.setText("日期：" + date);

        // 场地：若多条不一致，显示“多场地”
        String loc = "";
        for (Order o : orderItems) {
            String l = safeStr(o.getLocation());
            if (loc.isEmpty()) loc = l;
            else if (!loc.equals(l)) { loc = "多场地"; break; }
        }
        currentLocation = loc;
        if (locationTextView != null) {
            locationTextView.setText("场地：" + (loc.isEmpty() ? "-" : loc));
        }
    }

    private void setupButtons() {
        // ✅ 删除勾选订单（如果布局里没有这个按钮id，也不会崩）
        if (deleteCheckedOrdersButton != null) {
            deleteCheckedOrdersButton.setOnClickListener(v -> {
                List<Order> checked = adapter.getCheckedItems();
                if (checked == null || checked.isEmpty()) {
                    toast("请先勾选要删除的订单");
                    return;
                }

                new AlertDialog.Builder(this)
                        .setTitle("确认删除")
                        .setMessage(String.format(Locale.getDefault(),
                                "确定删除已勾选的 %d 条订单吗？\n此操作不可恢复。", checked.size()))
                        .setNegativeButton("取消", null)
                        .setPositiveButton("删除", (d, w) -> {
                            int deleted = 0;
                            for (Order o : checked) {
                                if (o != null && o.getId() > 0) {
                                    deleted += db.deleteOrderById(o.getId());
                                }
                            }
                            toast("已删除 " + deleted + " 条");
                            loadData();
                        })
                        .show();
            });
        }

        // ✅ 取消该订单：删除当前页面的全部明细（同一天同客户的订单）
        if (cancelOrderButton != null) {
            cancelOrderButton.setOnClickListener(v -> {
                if (orderItems == null || orderItems.isEmpty()) {
                    toast("没有可取消的订单");
                    return;
                }

                new AlertDialog.Builder(this)
                        .setTitle("取消该订单")
                        .setMessage("将删除该客户在当前日期的全部订单明细（不可恢复）。\n\n确定要取消吗？")
                        .setNegativeButton("不取消", null)
                        .setPositiveButton("确认取消", (d, w) -> {
                            int deleted = 0;
                            for (Order o : new ArrayList<>(orderItems)) {
                                if (o != null && o.getId() > 0) {
                                    deleted += db.deleteOrderById(o.getId());
                                }
                            }
                            toast("已取消订单，删除 " + deleted + " 条");
                            finish();
                        })
                        .show();
            });
        }

        // ✅ 修改此订单：可修改每条明细的 件数/数量/单价（仅影响 orders 表，不回写 products 价格）
        if (editOrderButton != null) {
            editOrderButton.setOnClickListener(v -> {
                if (orderItems == null || orderItems.isEmpty()) {
                    toast("没有可修改的订单明细");
                    return;
                }
                showEditOrderItemPicker();
            });
        }

        // ✅ 追加订单：在本订单（同日期同客户）下新增一条产品明细
        if (appendOrderButton != null) {
            appendOrderButton.setOnClickListener(v -> {
                if (TextUtils.isEmpty(date) || TextUtils.isEmpty(customer)) {
                    toast("订单信息不完整");
                    return;
                }
                showAppendOrderDialog();
            });
        }

        // ✅ 打印勾选标签：标签张数 = 件数
        if (printCheckedLabelsButton != null) {
            printCheckedLabelsButton.setOnClickListener(v -> {
                if (!ensureBluetoothPermissions()) return;

                List<Order> checked = adapter.getCheckedItems();
                if (checked == null || checked.isEmpty()) {
                    toast("请先勾选要打印的标签");
                    return;
                }
                printLabelsByPieces(checked);
            });
        }

        // ✅ 打印全部标签：标签张数 = 件数
        if (printAllLabelsButton != null) {
            printAllLabelsButton.setOnClickListener(v -> {
                if (!ensureBluetoothPermissions()) return;

                if (orderItems == null || orderItems.isEmpty()) {
                    toast("没有可打印的订单明细");
                    return;
                }
                printLabelsByPieces(orderItems);
            });
        }

        // ✅ 打印送货单：同客户同产品（产品名+单价）自动合并
        if (printDeliveryNoteButton != null) {
            printDeliveryNoteButton.setOnClickListener(v -> {
                if (!ensureBluetoothPermissions()) return;

                if (orderItems == null || orderItems.isEmpty()) {
                    toast("没有可打印的订单明细");
                    return;
                }
                printDeliveryNoteMerged(orderItems);
            });
        }
    }

    /* =========================================================
       ✅ 订单编辑/追加
       ========================================================= */

    private void showEditOrderItemPicker() {
        // 更人性化：每条明细一行，右侧“编辑”按钮
        final List<Order> snapshot = new ArrayList<>(orderItems);
        if (snapshot.isEmpty()) {
            toast("没有可修改的明细");
            return;
        }

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(14);
        root.setPadding(pad, dp(10), pad, dp(2));
        sv.addView(root);

        for (Order o : snapshot) {
            if (o == null) continue;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, dp(8), 0, dp(8));

            TextView tv = new TextView(this);
            tv.setText(String.format(Locale.getDefault(), "%s\n件数:%d  数量:%d  单价:%.2f  金额:%.2f",
                    safeStr(o.getProductName()), o.getPieces(), o.getQuantity(), o.getPrice(), o.getTotalPrice()));
            tv.setTextSize(16f);
            tv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            Button btn = new Button(this);
            btn.setText("编辑");
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            blp.leftMargin = dp(10);
            btn.setLayoutParams(blp);
            btn.setOnClickListener(v -> {
                if (o.getId() <= 0) {
                    toast("订单条目无效");
                    return;
                }
                showEditOneItemDialog(o);
            });

            row.addView(tv);
            row.addView(btn);
            root.addView(row);

            View divider = new View(this);
            divider.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)));
            divider.setBackgroundColor(0x1F000000);
            root.addView(divider);
        }

        new AlertDialog.Builder(this)
                .setTitle("选择要修改的明细")
                .setView(sv)
                .setNegativeButton("关闭", null)
                .show();
    }

    private int dp(int v) {
        return Math.round(getResources().getDisplayMetrics().density * v);
    }

    private void showEditOneItemDialog(Order o) {
        View view = getLayoutInflater().inflate(R.layout.dialog_edit_order_item, null);
        TextView title = view.findViewById(R.id.itemTitleTextView);
        EditText piecesEt = view.findViewById(R.id.piecesEditText);
        EditText qtyEt = view.findViewById(R.id.quantityEditText);
        EditText priceEt = view.findViewById(R.id.priceEditText);
        EditText remarkEt = view.findViewById(R.id.remarkEditText);

        if (title != null) title.setText("产品：" + safeStr(o.getProductName()));
        if (piecesEt != null) piecesEt.setText(String.valueOf(Math.max(0, o.getPieces())));
        if (qtyEt != null) qtyEt.setText(String.valueOf(Math.max(0, o.getQuantity())));
        if (priceEt != null) priceEt.setText(String.format(Locale.getDefault(), "%.2f", o.getPrice()));
        if (remarkEt != null) remarkEt.setText(safeStr(o.getRemark()));

        final int oldPieces = Math.max(0, o.getPieces());
        final int oldQty = Math.max(0, o.getQuantity());
        int pack = 0;
        try { pack = db.getProductPackingUnitsByName(safeStr(o.getProductName())); } catch (Exception ignored) {}
        if (pack <= 0 && oldPieces > 0 && oldQty > 0) {
            pack = Math.max(1, oldQty / oldPieces);
        }
        if (pack <= 0) pack = 1;
        final int unitsPerPiece = pack;

        if (piecesEt != null && qtyEt != null) {
            final boolean[] updating = new boolean[]{false};
            final boolean[] qtyManuallyEdited = new boolean[]{false};

            piecesEt.addTextChangedListener(new android.text.TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
                @Override public void afterTextChanged(android.text.Editable s) {
                    if (updating[0] || qtyManuallyEdited[0]) return;
                    int pcs = parseIntSafe(s == null ? "" : s.toString(), oldPieces);
                    if (pcs < 0) pcs = 0;
                    int computedQty = pcs * unitsPerPiece;
                    updating[0] = true;
                    qtyEt.setText(String.valueOf(computedQty));
                    qtyEt.setSelection(qtyEt.getText().length());
                    updating[0] = false;
                }
            });

            qtyEt.addTextChangedListener(new android.text.TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
                @Override public void afterTextChanged(android.text.Editable s) {
                    if (updating[0]) return;
                    qtyManuallyEdited[0] = true;
                }
            });
        }

        new AlertDialog.Builder(this)
                .setTitle("修改订单明细")
                .setView(view)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", (d, w) -> {
                    int pieces = parseIntSafe(piecesEt != null ? piecesEt.getText().toString() : "", o.getPieces());
                    String qtyText = qtyEt != null && qtyEt.getText() != null ? qtyEt.getText().toString().trim() : "";
                    int qty = qtyText.isEmpty()
                            ? Math.max(0, pieces * unitsPerPiece)
                            : Math.max(0, parseIntSafe(qtyText, o.getQuantity()));
                    double price = parseDoubleSafe(priceEt != null ? priceEt.getText().toString() : "", o.getPrice());
                    String remark = remarkEt != null ? remarkEt.getText().toString().trim() : safeStr(o.getRemark());

                    int n = db.updateOrderById(o.getId(), pieces, qty, safeStr(o.getLocation()), price, remark);
                    if (n > 0) {
                        toast("已更新");
                        loadData();
                    } else {
                        toast("更新失败");
                    }
                })
                .show();
    }

    private void showAppendOrderDialog() {
        // 1) 先选产品（包含匹配搜索）
        List<String> products = db.getAllProductNames();
        if (products == null || products.isEmpty()) {
            toast("暂无产品，请先在产品管理中添加");
            return;
        }
        showSearchablePickDialog("选择要追加的产品", products, productName -> {
            if (TextUtils.isEmpty(productName)) return;

            // 2) 输入件数/数量/单价
            View view = getLayoutInflater().inflate(R.layout.dialog_append_order_item, null);
            TextView title = view.findViewById(R.id.itemTitleTextView);
            EditText piecesEt = view.findViewById(R.id.piecesEditText);
            EditText qtyEt = view.findViewById(R.id.quantityEditText);
            EditText priceEt = view.findViewById(R.id.priceEditText);

            if (title != null) title.setText("产品：" + productName);

            int packing = db.getProductPackingUnitsByName(productName);
            double defPrice = db.getProductPriceByName(productName);

            if (priceEt != null) priceEt.setText(String.format(Locale.getDefault(), "%.2f", defPrice));
            if (piecesEt != null) piecesEt.setText("1");
            if (qtyEt != null) {
                int defQty = Math.max(1, packing);
                qtyEt.setText(String.valueOf(defQty));
            }

            if (piecesEt != null && qtyEt != null) {
                final boolean[] program = new boolean[]{false};
                android.text.TextWatcher watcher = new android.text.TextWatcher() {
                    @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                    @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
                    @Override public void afterTextChanged(android.text.Editable s) {
                        if (program[0]) return;
                        int pcs = parseIntSafe(piecesEt.getText().toString(), 1);
                        if (pcs <= 0) pcs = 1;
                        int computedQty = Math.max(1, packing) * pcs;
                        program[0] = true;
                        qtyEt.setText(String.valueOf(computedQty));
                        qtyEt.setSelection(qtyEt.getText().length());
                        program[0] = false;
                    }
                };
                piecesEt.addTextChangedListener(watcher);
            }

            new AlertDialog.Builder(this)
                    .setTitle("追加订单")
                    .setView(view)
                    .setNegativeButton("取消", null)
                    .setPositiveButton("追加", (d, w) -> {
                        int pieces = parseIntSafe(piecesEt != null ? piecesEt.getText().toString() : "", 1);
                        int qty = parseIntSafe(qtyEt != null ? qtyEt.getText().toString() : "", Math.max(1, packing));
                        double price = parseDoubleSafe(priceEt != null ? priceEt.getText().toString() : "", defPrice);

                        // 场地：尽量沿用当前订单；若为“多场地”则留空
                        String loc = "";
                        if (!TextUtils.isEmpty(currentLocation) && !"多场地".equals(currentLocation)) {
                            loc = currentLocation;
                        }

                        Order newO = new Order(date, customer, productName, pieces, qty, price, loc, "");
                        long r = db.addOrder(newO);
                        if (r != -1) {
                            toast("已追加");
                            loadData();
                        } else {
                            toast("追加失败");
                        }
                    })
                    .show();
        });
    }

    /**
     * ✅ 可搜索选择器（包含匹配）：输入任意 1 个字也能搜到。
     */
    private interface PickListener {
        void onPick(String name);
    }

    /**
     * ✅ 可搜索选择器（包含匹配）：输入任意 1 个字也能搜到。
     */
    private void showSearchablePickDialog(String title, List<String> data, PickListener onPick) {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_search_select, null);
        SearchView searchView = dialogView.findViewById(R.id.searchView);
        ListView listView = dialogView.findViewById(R.id.listView);

        ArrayAdapter<String> adapter = new ContainsFilterArrayAdapter(this, new ArrayList<>(data));
        listView.setAdapter(adapter);
        searchView.setIconifiedByDefault(false);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override public boolean onQueryTextSubmit(String query) { return false; }
            @Override public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return true;
            }
        });

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(dialogView)
                .setNegativeButton("取消", null)
                .create();

        listView.setOnItemClickListener((parent, view, position, id) -> {
            String name = adapter.getItem(position);
            if (onPick != null) onPick.onPick(name);
            dialog.dismiss();
        });

        dialog.show();
    }

    /**
     * ✅ “包含匹配”搜索适配器：输入任意字符即可命中（而非前缀）。
     */
    private static class ContainsFilterArrayAdapter extends ArrayAdapter<String> {
        private final List<String> original;
        private final List<String> filtered;

        ContainsFilterArrayAdapter(android.content.Context ctx, List<String> data) {
            super(ctx, android.R.layout.simple_list_item_1, data);
            this.filtered = data;
            this.original = new ArrayList<>(data);
        }

        @Override
        public Filter getFilter() {
            return new Filter() {
                @Override
                protected FilterResults performFiltering(CharSequence constraint) {
                    String q = constraint == null ? "" : constraint.toString().trim();
                    String qLower = q.toLowerCase(Locale.getDefault());

                    List<String> out = new ArrayList<>();
                    if (qLower.isEmpty()) {
                        out.addAll(original);
                    } else {
                        for (String s : original) {
                            if (s == null) continue;
                            String sLower = s.toLowerCase(Locale.getDefault());
                            if (sLower.contains(qLower)) out.add(s);
                        }
                    }

                    FilterResults fr = new FilterResults();
                    fr.values = out;
                    fr.count = out.size();
                    return fr;
                }

                @Override
                protected void publishResults(CharSequence constraint, FilterResults results) {
                    filtered.clear();
                    if (results != null && results.values instanceof List) {
                        //noinspection unchecked
                        filtered.addAll((List<String>) results.values);
                    }
                    notifyDataSetChanged();
                }
            };
        }
    }

    private int parseIntSafe(String s, int def) {
        try {
            if (s == null) return def;
            String t = s.trim();
            if (t.isEmpty()) return def;
            return Integer.parseInt(t);
        } catch (Exception e) {
            return def;
        }
    }

    private double parseDoubleSafe(String s, double def) {
        try {
            if (s == null) return def;
            String t = s.trim();
            if (t.isEmpty()) return def;
            return Double.parseDouble(t);
        } catch (Exception e) {
            return def;
        }
    }

    /* =========================
       权限
       ========================= */
    private boolean ensureBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
                    || ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN},
                        REQ_BT_PERMS);
                return false;
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT_PERMS) {
            boolean ok = true;
            if (grantResults != null) {
                for (int g : grantResults) {
                    if (g != PackageManager.PERMISSION_GRANTED) { ok = false; break; }
                }
            } else ok = false;

            if (!ok) toast("缺少蓝牙权限，无法打印/搜索");
        }
    }

    /* =====================================================
       ✅ 功能1：标签打印张数 = 件数，并支持 page/pages
       ===================================================== */
    private void printLabelsByPieces(List<Order> items) {
        try {
            String tpl = db.getDefaultTemplateContent(TemplateCenterActivity.TYPE_LABEL);
            if (tpl == null) tpl = "";

            int total = 0;

            for (Order o : items) {
                String c = safeStr(o.getCustomerName());
                String p = safeStr(o.getProductName());

                int pieces = Math.max(0, o.getPieces());
                if (pieces <= 0) pieces = Math.max(1, o.getQuantity()); // 兜底

                // 备注：只显示用户填写内容；场地单独用 {{site}} 输出，避免备注被场地覆盖
                String remark = safeStr(o.getRemark()).trim();
                String site = safeStr(o.getLocation()).trim();

                for (int i = 1; i <= pieces; i++) {
                    Map<String, String> vars = new HashMap<>();
                    vars.put("customer", c);
                    vars.put("product", p);
                    vars.put("quantity", String.valueOf(pieces));
                    vars.put("pieces", String.valueOf(pieces));
                    vars.put("remark", remark);
                    vars.put("location", safeStr(o.getLocation())); // 兼容旧模板字段
                    vars.put("site", site); // 新字段：基地/场地
                    int packingUnits = 1;
                    try { packingUnits = db.getProductPackingUnitsByName(p); } catch (Exception ignored) {}
                    vars.put("spec", String.valueOf(packingUnits));
                    vars.put("packing_units", String.valueOf(packingUnits));

                    vars.put("page", String.valueOf(i));
                    vars.put("pages", String.valueOf(pieces));
                    // ✅ 兼容模板字段：{{index}}/{{total}}（等价于 page/pages）
                    vars.put("index", String.valueOf(i));
                    vars.put("total", String.valueOf(pieces));
                    vars.put("date", PrinterManager.normalizeLabelDate(o.getDate()));

                    String rendered = TemplateEngine.render(tpl, vars);

                    // ✅ 每件一张：直接逐张发起打印
                    PrinterManager.printLabel(this, rendered);
                    total++;
                }
            }

            try {
                long maxId = 0L;
                String dateKey = "";
                java.util.ArrayList<Long> printedIds = new java.util.ArrayList<>();
                for (Order o : items) {
                    if (o == null) continue;
                    if (o.getId() > maxId) maxId = o.getId();
                    if (o.getId() > 0) printedIds.add((long) o.getId());
                    if (dateKey.isEmpty()) dateKey = safeStr(o.getDate());
                }
                if (!printedIds.isEmpty()) {
                    db.markOrdersPrintedByIds(printedIds);
                }
                if (maxId > 0 && !dateKey.isEmpty()) {
                    android.content.SharedPreferences sp = getSharedPreferences(LABEL_PRINT_PREF, MODE_PRIVATE);
                    long oldMax = sp.getLong(KEY_LABEL_PRINTED_MAXID_PREFIX + dateKey, 0L);
                    if (maxId > oldMax) {
                        sp.edit().putLong(KEY_LABEL_PRINTED_MAXID_PREFIX + dateKey, maxId).apply();
                    }
                }
            } catch (Exception ignored) {}

            try { loadData(); } catch (Exception ignored) {}
            toast("标签已提交打印：" + total + "张");
            // ✅ 2026-04：库存统一改为“打印送货单时扣减”。
            // 这里打印箱唛/标签只负责出签，不再扣减花盆/套袋/产品库存。
} catch (Exception e) {
            Toast.makeText(this, "打印失败：" + e.getMessage() + "（请到“打印机设置”配置标签打印机）", Toast.LENGTH_LONG).show();
        }
    }

    /* =====================================================
       ✅ 功能2：送货单合并同客户同产品（产品名+单价）
       ===================================================== */
    private void printDeliveryNoteMerged(List<Order> items) {
        if (items == null || items.isEmpty()) {
            toast("没有可打印的商品明细");
            return;
        }

        // ✅ 合并同产品 + 同单价
        List<Order> merged = mergeSameProduct(items);

        String tpl = db.getDefaultTemplateContent(TemplateCenterActivity.TYPE_DELIVERY);
        if (tpl == null) tpl = "";

        // ✅ 两个输出口：普通 / 加粗（模板中心选择用哪个占位符）
        String itemsLinesNormal = buildDeliveryItemsLines(db, merged, false);
        String itemsLinesBold = buildDeliveryItemsLines(db, merged, true);

        // ✅ 飞鹅云小票标记语言：需要用 <BR> 换行
        boolean isFeieyunMarkup = false;
        try {
            String t0 = tpl == null ? "" : tpl;
            isFeieyunMarkup = t0.contains("<BR>") || t0.contains("<CB>") || t0.contains("<C>") || t0.contains("<B>");
        } catch (Exception ignore) { }

        if (isFeieyunMarkup) {
            itemsLinesNormal = toFeieyunBR(itemsLinesNormal);
            itemsLinesBold = toFeieyunBR(itemsLinesBold);
        }

        int totalPieces = 0;
        double totalAmount = 0.0;
        for (Order o : merged) {
            totalPieces += Math.max(0, o.getPieces());
            totalAmount += (o.getPrice() * o.getQuantity());
        }

        HashMap<String, String> vars = new HashMap<>();
        vars.put("customer", safeStr(customer));
        vars.put("date", safeStr(date));
        vars.put("location", safeStr(currentLocation));

        // ✅ 兼容：旧模板用 {{items}} 或 {{items_lines}}
        vars.put("items", safeStr(itemsLinesNormal));
        vars.put("items_lines", safeStr(itemsLinesNormal));

        // ✅ 新输出口：模板里写 {{items_lines_bold}} 即可加粗（不变字号）
        vars.put("items_lines_bold", safeStr(itemsLinesBold));

        vars.put("total_pieces", String.valueOf(totalPieces));
        vars.put("total_amount", String.format(Locale.getDefault(), "%.2f", totalAmount));
        vars.put("order_no", safeStr(date) + "-" + safeStr(customer));
        vars.put("remark", buildDeliveryRemark(items)); // 备注汇总（不影响合并）
        vars.put("contact", "");
        vars.put("phone", "");

        String rendered = TemplateEngine.render(tpl, vars);

        // ✅ 若模板为 JSON(canvas_receipt_v1)，则包装 tpl + payload 交由 PrinterManager 走“图片渲染打印”
        String sendContent = rendered;
        try {
            String tt = tpl == null ? "" : tpl.trim();
            if (tt.startsWith("{") && (tt.contains("\"renderer\"") || tt.contains("\"els\""))) {
                org.json.JSONObject wrap = new org.json.JSONObject();
                wrap.put("__suzai_print", "v1");
                wrap.put("tpl", new org.json.JSONObject(rendered));

                org.json.JSONObject payload = new org.json.JSONObject();
                org.json.JSONArray arr = new org.json.JSONArray();
                for (Order o : items) {
                    if (o == null) continue;
                    int qty = Math.max(0, o.getQuantity());
                    int pcs = Math.max(0, o.getPieces());
                    double price = o.getPrice();
                    double amount = price * qty;
                    int pack = (pcs > 0) ? (int) Math.round((double) qty / (double) pcs) : 0;

                    org.json.JSONObject row = new org.json.JSONObject();
                    row.put("name", safeStr(o.getProductName()));
                    row.put("price", String.format(Locale.getDefault(), "%.2f", price));
                    row.put("pack", String.valueOf(pack));
                    row.put("qty", String.valueOf(qty));
                    row.put("amount", String.format(Locale.getDefault(), "%.2f", amount));
                    row.put("pieces", String.valueOf(pcs));
                    arr.put(row);
                }
                payload.put("items", arr);
                wrap.put("payload", payload);

                sendContent = wrap.toString();
            }
        } catch (Exception ignore) { }

        try {
            PrinterManager.printDocText(this, sendContent, new PrinterManager.PrintCallback() {
                @Override public void onSuccess() {
                    toast("送货单已提交打印");
                    // ✅ 商业化逻辑：仅在“成功提交打印流程/配置正确”后扣库存
                    runInventoryDeductionAfterPrint(items, true);
                }

                @Override public void onError(Exception e) {
                    try { android.util.Log.e("OrderPrint", "print delivery failed: " + (e==null?"":e.getMessage()), e); } catch (Exception ignored) {}
                    toast("送货单提交失败：" + (e==null?"":e.getMessage()));
                    // ❌ 打印失败/取消：不扣库存
                }
            });
        } catch (Exception e) {
            // 极端兜底：例如 ctx 为空等
            try { android.util.Log.e("OrderPrint", "print delivery failed(outer): " + e.getMessage(), e); } catch (Exception ignored) {}
            toast("送货单提交失败：" + e.getMessage());
            // ❌ 不扣库存
        }
}

    private static String toFeieyunBR(String s) {
        if (s == null) return "";
        String t = s.replace("\r\n", "\n").replace("\r", "\n");
        return t.replace("\n", "<BR>");
    }

    /** 合并：同产品名 + 同单价 */
    private List<Order> mergeSameProduct(List<Order> items) {
        LinkedHashMap<String, Order> map = new LinkedHashMap<>();

        for (Order o : items) {
            String key = safeStr(o.getProductName()) + "||" + o.getPrice();
            Order exist = map.get(key);

            if (exist == null) {
                Order neo = new Order();
                neo.setDate(o.getDate());
                neo.setCustomerName(o.getCustomerName());
                neo.setProductName(o.getProductName());
                neo.setPrice(o.getPrice());
                neo.setQuantity(Math.max(0, o.getQuantity()));
                neo.setPieces(Math.max(0, o.getPieces()));
                neo.setLocation(o.getLocation());
                neo.setRemark(o.getRemark());
                map.put(key, neo);
            } else {
                exist.setQuantity(exist.getQuantity() + Math.max(0, o.getQuantity()));
                exist.setPieces(exist.getPieces() + Math.max(0, o.getPieces()));
            }
        }

        List<Order> out = new ArrayList<>(map.values());
        Collections.sort(out, (a, b) -> safeStr(a.getProductName()).compareTo(safeStr(b.getProductName())));
        return out;
    }

    /* =========================
       送货单明细渲染（两行 + 可选加粗 + 空行）
       ========================= */
    private String buildDeliveryItemsLines(DatabaseHelper db, List<Order> items, boolean bold) {
        StringBuilder sb = new StringBuilder();

        for (Order o : items) {
            String name = safeStr(o.getProductName());
            double price = o.getPrice();
            int qty = Math.max(0, o.getQuantity());
            int pieces = Math.max(0, o.getPieces());

            int packingUnits = 1;
            try {
                packingUnits = db.getProductPackingUnitsByName(name);
            } catch (Exception ignore) {}
            if (packingUnits <= 0) packingUnits = 1;

            double amount = price * qty;

            // 1) 名称行：按“单位宽度”截断，避免粗体更宽导致换行
            int maxUnits = bold ? UNITS_NAME_MAX_BOLD : UNITS_NAME_MAX_NORMAL;
            String name1 = truncateByUnits(name, maxUnits);
            if (bold) {
                // ✅ 更醒目：加粗 + 放大（飞鹅云：<B> 放大一倍；<BOLD> 加粗）
                sb.append("<B><BOLD>").append(name1).append("</BOLD></B>").append("\n");
            } else {
                // ✅ 默认也要“稍大 + 加粗”：字体变高一倍（<L>）+ 加粗（<BOLD>）
                // 说明：<L> 不改变宽度，对齐更稳；更接近“稍大”。
                sb.append("<L><BOLD>").append(name1).append("</BOLD></L>").append("\n");
            }

            // 2) 数值行：固定列宽，靠空格对齐（不插多余空格，最稳）
            String priceStr = String.format(Locale.getDefault(), "%.2f", price);
            String amountStr = String.format(Locale.getDefault(), "%.2f", amount);

            String line2 = formatCols(priceStr,
                    String.valueOf(packingUnits),
                    String.valueOf(qty),
                    amountStr,
                    String.valueOf(pieces));

            if (bold) {
                sb.append("<B><BOLD>").append(line2).append("</BOLD></B>").append("\n");
            } else {
                sb.append("<L><BOLD>").append(line2).append("</BOLD></L>").append("\n");
            }

            // 3) 商品之间空行
            for (int i = 0; i < GAP_BLANK_LINES_BETWEEN_ITEMS; i++) {
                sb.append("\n");
            }
        }

        return sb.toString();
    }

    private static String formatCols(String price, String pack, String qty, String amount, String pieces) {
        // 这里用 String.format 固定列宽
        return String.format(Locale.getDefault(),
                "%" + W_PRICE + "s%" + W_PACK + "s%" + W_QTY + "s%" + W_AMOUNT + "s%" + W_PIECES + "s",
                safe(price), safe(pack), safe(qty), safe(amount), safe(pieces));
    }

    // “单位宽度”计算：中文约 2，ASCII 约 1
    private static int unitWidthOfChar(char ch) {
        // 粗略但好用：ASCII <= 127 认为 1，其它认为 2
        return (ch <= 127) ? 1 : 2;
    }

    private static String truncateByUnits(String s, int maxUnits) {
        if (s == null) return "";
        String t = s.trim();
        if (t.isEmpty()) return "";

        int units = 0;
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < t.length(); i++) {
            char ch = t.charAt(i);
            int w = unitWidthOfChar(ch);
            if (units + w > maxUnits) {
                out.append("…");
                break;
            }
            out.append(ch);
            units += w;
        }
        return out.toString();
    }

    private String buildDeliveryRemark(List<Order> items) {
        LinkedHashSet<String> set = new LinkedHashSet<>();
        for (Order o : items) {
            try {
                String r = o.getRemark();
                if (!TextUtils.isEmpty(r)) set.add(r.trim());
            } catch (Exception ignore) {}
        }
        if (set.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (String r : set) {
            if (sb.length() > 0) sb.append("；");
            sb.append(r);
        }
        return sb.toString();
    }

    private static String safeStr(String s) {
        if (s == null) return "";
        String t = s.trim();
        return "null".equalsIgnoreCase(t) ? "" : t;
    }

    private static String safe(String s) {
        return s == null ? "" : s;
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // ============================
    // 低库存提醒（仅送货单打印成功后触发）
    // - 忽略：将当前低于安全值的条目加入忽略列表（补货到>=安全值后自动解除忽略）
    // - 下次提醒：本次不记录，下次仍提示
    // ============================
    private void checkAndPromptLowStockAfterDeliveryPrint() {
        if (db == null) return;
        List<InventoryItem> lows;
        try {
            lows = db.getLowStockItems();
        } catch (Exception e) {
            try { android.util.Log.e("OrderPrint", "lowStock query failed: " + e.getMessage(), e); } catch (Exception ignored) {}
            return;
        }
        if (lows == null || lows.isEmpty()) {
            // 顺便清理忽略状态（如果之前忽略过，但现在没有任何低库存）
            clearAllIgnoredLowStockIfNoLowStock();
            return;
        }

        final LinkedHashSet<String> currentLowKeys = new LinkedHashSet<>();
        for (InventoryItem it : lows) {
            currentLowKeys.add(buildInvIgnoreKey(it));
        }

        // 清理：已忽略但已补货到>=安全值的条目，自动解除忽略
        LinkedHashSet<String> ignored = loadIgnoredLowStockKeys();
        if (!ignored.isEmpty()) {
            LinkedHashSet<String> stillIgnored = new LinkedHashSet<>();
            for (String k : ignored) {
                if (currentLowKeys.contains(k)) stillIgnored.add(k);
            }
            if (stillIgnored.size() != ignored.size()) {
                saveIgnoredLowStockKeys(stillIgnored);
                ignored = stillIgnored;
            }
        }

        final List<InventoryItem> toShow = new ArrayList<>();
        for (InventoryItem it : lows) {
            String k = buildInvIgnoreKey(it);
            if (!ignored.contains(k)) toShow.add(it);
        }
        if (toShow.isEmpty()) return; // 全被忽略，不弹窗

        StringBuilder sb = new StringBuilder();
        sb.append("以下库存已低于安全值：\n\n");
        for (InventoryItem it : toShow) {
            String type = safeStr(it.getType());
            String name = safeStr(it.getName());
            String spec = safeStr(it.getSpec());
            String sku = safeStr(it.getSku());
            int qty = it.getQuantity();
            int safety = it.getSafetyStock();
            sb.append("• ");
            if (!type.isEmpty()) sb.append("[").append(type).append("] ");
            sb.append(name);
            if (!spec.isEmpty()) sb.append(" ").append(spec);
            if (!sku.isEmpty()) sb.append(" (SKU:").append(sku).append(")");
            sb.append("  ").append(qty).append("/").append(safety).append("\n");
        }
        sb.append("\n可选择忽略本次这些条目（补货到>=安全值后会自动恢复提醒）。");

        runOnUiThread(() -> {
            try {
                if (isFinishing()) return;
            } catch (Exception ignored2) {}
            new AlertDialog.Builder(OrderPrintActivity.this)
                    .setTitle("低库存提醒")
                    .setMessage(sb.toString())
                    .setCancelable(true)
                    .setNegativeButton("下次提醒", (d, w) -> { /* do nothing */ })
                    .setPositiveButton("忽略", (d, w) -> {
                        LinkedHashSet<String> ig = loadIgnoredLowStockKeys();
                        for (InventoryItem it : toShow) {
                            ig.add(buildInvIgnoreKey(it));
                        }
                        saveIgnoredLowStockKeys(ig);
                        toast("已忽略低库存提醒");
                    })
                    .show();
        });
    }

    private void clearAllIgnoredLowStockIfNoLowStock() {
        try {
            LinkedHashSet<String> ignored = loadIgnoredLowStockKeys();
            if (!ignored.isEmpty()) saveIgnoredLowStockKeys(new LinkedHashSet<>());
        } catch (Exception ignored) {}
    }

    private String buildInvIgnoreKey(InventoryItem it) {
        if (it == null) return "";
        // 采用逻辑唯一键：type+name+spec+sku（云端同步也以 type/name/spec 保证唯一）
        return safeStr(it.getType()) + "|" + safeStr(it.getName()) + "|" + safeStr(it.getSpec()) + "|" + safeStr(it.getSku());
    }

    private LinkedHashSet<String> loadIgnoredLowStockKeys() {
        try {
            SharedPreferences sp = getSharedPreferences("low_stock_prefs", MODE_PRIVATE);
            java.util.Set<String> s = sp.getStringSet("ignored_keys", null);
            if (s == null) return new LinkedHashSet<>();
            return new LinkedHashSet<>(s);
        } catch (Exception e) {
            return new LinkedHashSet<>();
        }
    }

    private void saveIgnoredLowStockKeys(LinkedHashSet<String> keys) {
        try {
            SharedPreferences sp = getSharedPreferences("low_stock_prefs", MODE_PRIVATE);
            sp.edit().putStringSet("ignored_keys", (keys==null)?new LinkedHashSet<>():keys).apply();
        } catch (Exception ignored) {}
    }

    // ============================
    // 库存扣减（花盆/套袋/产品）
    // 说明：当前版本“订单出库扣减”依赖打印动作触发。
    // 为避免不同入口（打印送货单/打印标签）导致未扣减，这里统一在提交打印后尝试扣减。
    // ============================
    private void runInventoryDeductionAfterPrint(List<Order> items, boolean checkLowStockAfter) {
        if (db == null || items == null || items.isEmpty()) return;
        try {
            java.util.LinkedHashSet<Integer> ids = new java.util.LinkedHashSet<>();
            for (Order o : items) {
                if (o != null && o.getId() > 0) ids.add(o.getId());
            }
            if (!ids.isEmpty()) {
                db.deductInventoryForOrderIds(new java.util.ArrayList<>(ids), true);
            }
            if (checkLowStockAfter) {
                checkAndPromptLowStockAfterDeliveryPrint();
            }
        } catch (Exception ex) {
            try { android.util.Log.e("OrderPrint", "deductInventoryForOrderIds failed: " + ex.getMessage(), ex); } catch (Exception ignored) {}
            toast("扣减库存失败：" + ex.getMessage());
        }
    }

}