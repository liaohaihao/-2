package com.suzai.suzaiflowersystem;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ProductSummaryAdapter extends RecyclerView.Adapter<ProductSummaryAdapter.VH> {

    private List<ProductSummary> list;

    public ProductSummaryAdapter(List<ProductSummary> list) {
        this.list = list;
    }

    public void update(List<ProductSummary> newList) {
        this.list = newList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product_summary, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        ProductSummary item = list.get(position);
        holder.productName.setText(item.getProductName());
        holder.pieces.setText(item.getPieces() + " 件");
    }

    @Override
    public int getItemCount() {
        return list == null ? 0 : list.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView productName;
        TextView pieces;

        VH(@NonNull View itemView) {
            super(itemView);
            productName = itemView.findViewById(R.id.productNameTextView);
            pieces = itemView.findViewById(R.id.piecesTextView);
        }
    }
}
