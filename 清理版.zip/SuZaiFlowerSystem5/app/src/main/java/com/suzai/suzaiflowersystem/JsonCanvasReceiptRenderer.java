package com.suzai.suzaiflowersystem;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 将“JSON模板（canvas_receipt_v1）”渲染成图片（PNG），用于小票机/单据机走“图片打印”。
 *
 * 说明：
 * - 坐标单位：dots（点），与模板 meta.dpm（dot per mm）对应。80mm * 8dpm = 640 dots。
 * - 目前支持元素：
 *   - text / line / items
 * - items 的数据来自 payload.items（由业务侧构造；只影响打印，不改其它逻辑）
 */
public class JsonCanvasReceiptRenderer {

    private JsonCanvasReceiptRenderer() {}

    public static byte[] renderToPng(Context ctx, JSONObject tplObj, JSONObject payloadObj) throws Exception {
        if (tplObj == null) throw new IllegalArgumentException("模板为空");
        JSONObject meta = tplObj.optJSONObject("meta");
        double mmW = meta != null ? meta.optDouble("mmW", 80) : 80;
        double dpm = meta != null ? meta.optDouble("dpm", 8) : 8;
        double zoom = meta != null ? meta.optDouble("zoom", 1) : 1;

        int width = (int) Math.round(mmW * dpm * zoom);
        if (width <= 0) width = 640;

        JSONArray els = tplObj.optJSONArray("els");
        if (els == null) els = new JSONArray();

        // 先估算高度（根据 y + 文字大小/ items 行数）
        int estH = estimateHeight(els, payloadObj, zoom);
        if (estH < 200) estH = 900; // 默认给足高度

        Bitmap bmp = Bitmap.createBitmap(width, estH, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        canvas.drawColor(Color.WHITE);

        Paint pText = new Paint(Paint.ANTI_ALIAS_FLAG);
        pText.setColor(Color.BLACK);
        pText.setStyle(Paint.Style.FILL);

        Paint pLine = new Paint(Paint.ANTI_ALIAS_FLAG);
        pLine.setColor(Color.BLACK);
        pLine.setStyle(Paint.Style.FILL);

        int maxY = 0;

        for (int i = 0; i < els.length(); i++) {
            JSONObject el = els.optJSONObject(i);
            if (el == null) continue;
            String type = el.optString("type", "");
            if ("text".equalsIgnoreCase(type)) {
                int x = (int) Math.round(el.optDouble("x", 0) * zoom);
                int y = (int) Math.round(el.optDouble("y", 0) * zoom);
                int size = (int) Math.round(el.optDouble("size", 24) * zoom);
                boolean bold = el.optBoolean("bold", false);
                String align = el.optString("align", "left");

                String text = el.optString("text", "");
                text = stripInlineTags(text);

                drawText(canvas, pText, text, x, y, size, bold, align, width);
                maxY = Math.max(maxY, y + size + 10);
            } else if ("line".equalsIgnoreCase(type)) {
                int x = (int) Math.round(el.optDouble("x", 0) * zoom);
                int y = (int) Math.round(el.optDouble("y", 0) * zoom);
                int w = (int) Math.round(el.optDouble("w", 0) * zoom);
                int h = (int) Math.round(el.optDouble("h", 1) * zoom);
                if (h <= 0) h = 1;
                canvas.drawRect(x, y, x + w, y + h, pLine);
                maxY = Math.max(maxY, y + h + 5);
            } else if ("items".equalsIgnoreCase(type)) {
                ItemsCfg cfg = ItemsCfg.from(el, zoom);
                List<ItemRow> rows = buildItemRows(payloadObj);
                int endY = drawItems(canvas, pText, cfg, rows, width);
                maxY = Math.max(maxY, endY);
            }
        }

        // 裁剪到实际高度（留一点底部边距）
        int finalH = Math.min(estH, Math.max(maxY + 40, 200));
        if (finalH < bmp.getHeight()) {
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), finalH);
        }

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, bos);
        return bos.toByteArray();
    }

    private static String stripInlineTags(String s) {
        if (s == null) return "";
        // 目前只处理 [bigb] [/bigb] 这类简易标记：直接去掉标签
        return s.replace("[bigb]", "").replace("[/bigb]", "");
    }

    private static void drawText(Canvas canvas, Paint p, String text, int x, int y, int size, boolean bold, String align, int width) {
        if (TextUtils.isEmpty(text)) return;
        p.setTextSize(size);
        p.setTypeface(bold ? Typeface.create(Typeface.DEFAULT, Typeface.BOLD) : Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));

        float drawX = x;
        if ("center".equalsIgnoreCase(align)) {
            float w = p.measureText(text);
            drawX = x - w / 2f;
        } else if ("right".equalsIgnoreCase(align)) {
            float w = p.measureText(text);
            drawX = x - w;
        }
        // y 认为是“文字基线偏上”的坐标；这里用 baseline = y + size
        float baseline = y + size;
        canvas.drawText(text, drawX, baseline, p);
    }

    private static int estimateHeight(JSONArray els, JSONObject payloadObj, double zoom) {
        int max = 0;
        for (int i = 0; i < els.length(); i++) {
            JSONObject el = els.optJSONObject(i);
            if (el == null) continue;
            String type = el.optString("type", "");
            if ("text".equalsIgnoreCase(type)) {
                int y = (int) Math.round(el.optDouble("y", 0) * zoom);
                int size = (int) Math.round(el.optDouble("size", 24) * zoom);
                max = Math.max(max, y + size + 40);
            } else if ("line".equalsIgnoreCase(type) || "items".equalsIgnoreCase(type)) {
                int y = (int) Math.round(el.optDouble("y", 0) * zoom);
                max = Math.max(max, y + 600);
            }
        }
        // items 行数影响高度
        int itemCount = 0;
        if (payloadObj != null) {
            JSONArray items = payloadObj.optJSONArray("items");
            if (items != null) itemCount = items.length();
        }
        if (itemCount > 0) {
            max += itemCount * 60;
        }
        return Math.max(max, 900);
    }

    private static class ItemsCfg {
        int x, y;
        int nameSize, numSize;
        int gap, leading;
        int colPrice, colPack, colQty, colAmount, colPieces;
        double nameScale, numScale;

        static ItemsCfg from(JSONObject el, double zoom) {
            ItemsCfg c = new ItemsCfg();
            c.x = (int) Math.round(el.optDouble("x", 0) * zoom);
            c.y = (int) Math.round(el.optDouble("y", 0) * zoom);
            c.nameSize = (int) Math.round(el.optDouble("nameSize", 22) * zoom);
            c.numSize = (int) Math.round(el.optDouble("numSize", 18) * zoom);
            c.nameScale = el.optDouble("nameScale", 1) * zoom;
            c.numScale = el.optDouble("numScale", 1) * zoom;
            c.gap = (int) Math.round(el.optDouble("gap", 4) * zoom);
            c.leading = (int) Math.round(el.optDouble("leading", 10) * zoom);
            c.colPrice = (int) Math.round(el.optDouble("col_price", 0) * zoom);
            c.colPack = (int) Math.round(el.optDouble("col_pack", 140) * zoom);
            c.colQty = (int) Math.round(el.optDouble("col_qty", 250) * zoom);
            c.colAmount = (int) Math.round(el.optDouble("col_amount", 360) * zoom);
            c.colPieces = (int) Math.round(el.optDouble("col_pieces", 500) * zoom);
            return c;
        }
    }

    private static class ItemRow {
        String name;
        String price;
        String pack;
        String qty;
        String amount;
        String pieces;
    }

    private static List<ItemRow> buildItemRows(JSONObject payloadObj) {
        List<ItemRow> out = new ArrayList<>();
        if (payloadObj == null) return out;
        JSONArray arr = payloadObj.optJSONArray("items");
        if (arr == null) return out;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            ItemRow r = new ItemRow();
            r.name = o.optString("name", "");
            r.price = o.optString("price", "");
            r.pack = o.optString("pack", "");
            r.qty = o.optString("qty", "");
            r.amount = o.optString("amount", "");
            r.pieces = o.optString("pieces", "");
            out.add(r);
        }
        return out;
    }

    private static int drawItems(Canvas canvas, Paint p, ItemsCfg cfg, List<ItemRow> rows, int width) {
        if (rows == null) rows = new ArrayList<>();

        int y = cfg.y;
        for (ItemRow r : rows) {
            // 1) 名称行
            p.setTextSize((float) (cfg.nameSize * cfg.nameScale));
            p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            canvas.drawText(n(r.name), cfg.x, y + p.getTextSize(), p);

            // 2) 数字行
            y += (int) (cfg.nameSize * cfg.nameScale) + cfg.leading;
            p.setTextSize((float) (cfg.numSize * cfg.numScale));
            p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL));

            int baseY = (int) (y + p.getTextSize());

            // price col
            canvas.drawText(n(r.price), cfg.x + cfg.colPrice, baseY, p);
            canvas.drawText(n(r.pack), cfg.x + cfg.colPack, baseY, p);
            canvas.drawText(n(r.qty), cfg.x + cfg.colQty, baseY, p);
            canvas.drawText(n(r.amount), cfg.x + cfg.colAmount, baseY, p);
            canvas.drawText(n(r.pieces), cfg.x + cfg.colPieces, baseY, p);

            // 下一行
            y += (int) p.getTextSize() + cfg.gap + cfg.leading;
        }
        return y;
    }

    private static String n(String s) { return s == null ? "" : s; }
}
