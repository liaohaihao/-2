package com.suzai.suzaiflowersystem;

public class ArPaymentRow {
    public String cloudId;
    public String siteName;
    public String customerName;
    public String payDate;
    public double amount;
    public String method;
    public String note;
}
