package com.suzai.suzaiflowersystem;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 标签模板拖拽编辑器（飞鹅云排版控制标签）。
 * - 画布按 50x80mm 竖版比例显示
 * - 文本块可拖拽
 * - 保存时生成 <SIZE>/<DIRECTION>/<TEXT ...> 的模板字符串，直接可用于打印
 */
public class DraggableLabelTemplateEditActivity extends AppCompatActivity {

    private static final String TAG = "DragTpl";

    private boolean fallbackUsed = false;


    private DatabaseHelper db;
    private long templateId;
    private String type;

    private EditText etName;
    private FrameLayout canvas;

    // 画布像素尺寸（运行时测得）
    private int canvasW = 1;
    private int canvasH = 1;

    // 标签目标 dots
    private static final int DOT_W = 400; // 50mm * 8
    private static final int DOT_H = 640; // 80mm * 8

    private final List<DragTextItem> items = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("拖拽编辑标签模板");
        setContentView(R.layout.activity_drag_label_template_edit);

        db = new DatabaseHelper(this);
        type = getIntent().getStringExtra("type");
        templateId = getIntent().getLongExtra("template_id", 0);

        etName = findViewById(R.id.etTemplateName);
        canvas = findViewById(R.id.templateCanvas);

        Button btnAdd = findViewById(R.id.btnAddText);
        Button btnFields = findViewById(R.id.btnAddField);
        Button btnSave = findViewById(R.id.btnSave);

        btnAdd.setOnClickListener(v -> addTextBlock("文本"));
        btnFields.setOnClickListener(v -> showFieldPicker());
        btnSave.setOnClickListener(v -> save());

        // 先加载已有模板（或默认模板）
        String name = "标签模板";
        String content;
        if (templateId > 0) {
            PrintTemplate t = db.getTemplateById(templateId);
            if (t != null) {
                name = t.getName();
                content = t.getContent();
            } else {
                content = db.getDefaultTemplateContent(type);
            }
        } else {
            content = db.getDefaultTemplateContent(type);
        }
        etName.setText(name);

        // 画布尺寸测量后再解析渲染
        String finalContent = content;
        canvas.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                canvas.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                canvasW = Math.max(1, canvas.getWidth());
                canvasH = Math.max(1, canvas.getHeight());
                parseAndRender(finalContent);
            }
        });
    }

    private void showFieldPicker() {
        final String[] fields = new String[]{
                "客户：{{customer}}",
                "产品：{{product}}",
                "规格：{{spec}}",
                "数量：{{quantity}}装",
                "日期：{{date}}",
                "张数：{{page}}/{{pages}}",
                "备注：{{remark}}",
                "场地：{{site}}"
        };
        new AlertDialog.Builder(this)
                .setTitle("选择一个字段")
                .setItems(fields, (d, which) -> addTextBlock(fields[which]))
                .setNegativeButton("取消", null)
                .show();
    }

    private void addTextBlock(String text) {
        DragTextItem item = new DragTextItem(this);
        item.setText(text);
        // 默认放到左上角往下一点，避免重叠
        item.setX(20);
        item.setY(20 + items.size() * 50);
        canvas.addView(item);
        items.add(item);
    }

    private void parseAndRender(String tpl) {
        // 清空
        canvas.removeAllViews();
        items.clear();

        if (TextUtils.isEmpty(tpl)) {
            // 空模板：给一个默认字段
            addTextBlock("客户：{{customer}}...");
            return;
        }

        // 简易解析：找出 <TEXT x=".." y=".." font=".." w=".." h=".." r="..">...</TEXT>
        Pattern p = Pattern.compile("<TEXT\\s+[^>]*x=\\\"(\\d+)\\\"[^>]*y=\\\"(\\d+)\\\"[^>]*w=\\\"(\\d+)\\\"[^>]*h=\\\"(\\d+)\\\"[^>]*>(.*?)</TEXT>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
        Matcher m = p.matcher(tpl);
        int count = 0;
        while (m.find()) {
            try {
                int xDot = Integer.parseInt(m.group(1));
                int yDot = Integer.parseInt(m.group(2));
                int w = Integer.parseInt(m.group(3));
                int h = Integer.parseInt(m.group(4));
                String text = m.group(5);

                DragTextItem item = new DragTextItem(this);
                item.setText(text);
                item.setScale(w, h);

                // dots -> px（按比例）
                float xPx = (xDot * 1f / DOT_W) * canvasW;
                float yPx = (yDot * 1f / DOT_H) * canvasH;
                item.setX(xPx);
                item.setY(yPx);

                canvas.addView(item);
                items.add(item);
                count++;
            } catch (Exception e) {
                Log.w(TAG, "parse text tag failed", e);
            }
        }

        if (count == 0) {
            // 不是可解析的模板（例如旧的纯文本/HTML）。
            // 之前这里递归调用 parseAndRender(def) 容易在 def 也无法解析时造成 StackOverflow。
            if (fallbackUsed) {
                // 已经回退过一次，直接给一个最基础的可拖拽块，避免无限递归
                addTextBlock("客户：{{customer}}");
                addTextBlock("产品：{{product}}");
                addTextBlock("件数：{{pieces}} ({{index}}/{{total}})");
                return;
            }
            fallbackUsed = true;

            // 尝试用系统默认 LABEL 模板来生成拖拽块；如果仍解析不到，则走上面的基础块
            String def = null;
            try {
                def = db.getDefaultTemplateContent(TemplateCenterActivity.TYPE_LABEL);
            } catch (Exception e) {
                Log.w(TAG, "getDefaultTemplateContent failed", e);
            }
            if (TextUtils.isEmpty(def) || def.equals(tpl)) {
                addTextBlock("客户：{{customer}}");
                addTextBlock("产品：{{product}}");
                addTextBlock("件数：{{pieces}} ({{index}}/{{total}})");
                return;
            }
            parseAndRender(def);
        }
    }

    private void save() {
        String name = etName.getText().toString().trim();
        if (TextUtils.isEmpty(name)) {
            Toast.makeText(this, "请输入模板名称", Toast.LENGTH_SHORT).show();
            return;
        }

        String content = exportToFeieTemplate();
        long now = System.currentTimeMillis();

        if (templateId > 0) {
            db.updateTemplate(templateId, name, content, now);
        } else {
            templateId = db.insertTemplate(type, name, content, now, 0);
        }

        db.enqueueTemplateUpsert(templateId);
        try { CloudSyncManager.getInstance().triggerSync(this); } catch (Exception ignore) {}

        Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show();
        finish();
    }

    private String exportToFeieTemplate() {
        StringBuilder sb = new StringBuilder();
        sb.append("<SIZE>50,80</SIZE>\n");
        sb.append("<DIRECTION>1</DIRECTION>\n");

        for (DragTextItem it : items) {
            int xDot = Math.round((it.getX() / Math.max(1f, canvasW)) * DOT_W);
            int yDot = Math.round((it.getY() / Math.max(1f, canvasH)) * DOT_H);

            // 边界保护
            xDot = Math.max(0, Math.min(DOT_W, xDot));
            yDot = Math.max(0, Math.min(DOT_H, yDot));

            sb.append("<TEXT x=\"").append(xDot)
                    .append("\" y=\"").append(yDot)
                    .append("\" font=\"12\" w=\"").append(it.getW())
                    .append("\" h=\"").append(it.getH())
                    .append("\" r=\"0\">")
                    .append(it.getText())
                    .append("</TEXT>\n");
        }

        return sb.toString();
    }

    /**
     * 可拖拽文本块
     */
    static class DragTextItem extends androidx.appcompat.widget.AppCompatTextView {

        private float downRawX;
        private float downRawY;
        private float dX;
        private float dY;

        private int w = 1;
        private int h = 1;

        public DragTextItem(android.content.Context ctx) {
            super(ctx);
            setPadding(12, 8, 12, 8);
            setBackgroundResource(R.drawable.bg_drag_text_item);
            setTextSize(14);
            setGravity(Gravity.CENTER_VERTICAL);
            setSingleLine(false);
            setOnLongClickListener(v -> {
                showScalePicker();
                return true;
            });
            enableDrag();
        }

        public void setScale(int w, int h) {
            this.w = Math.max(1, Math.min(4, w));
            this.h = Math.max(1, Math.min(4, h));
            // UI 上用字号粗略体现
            float base = 12f;
            setTextSize(base + (this.w - 1) * 4f);
        }

        public int getW() { return w; }
        public int getH() { return h; }

        private void showScalePicker() {
            String[] opts = new String[]{"1x", "2x", "3x", "4x"};
            new AlertDialog.Builder(getContext())
                    .setTitle("字号缩放（长按调整）")
                    .setItems(opts, (d, which) -> setScale(which + 1, which + 1))
                    .setNegativeButton("取消", null)
                    .show();
        }

        @SuppressLint("ClickableViewAccessibility")
        private void enableDrag() {
            setOnTouchListener((v, event) -> {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        dX = v.getX() - event.getRawX();
                        dY = v.getY() - event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float newX = event.getRawX() + dX;
                        float newY = event.getRawY() + dY;

                        // 父容器边界
                        View parent = (View) v.getParent();
                        if (parent != null) {
                            newX = Math.max(0, Math.min(parent.getWidth() - v.getWidth(), newX));
                            newY = Math.max(0, Math.min(parent.getHeight() - v.getHeight(), newY));
                        }

                        v.setX(newX);
                        v.setY(newY);
                        return true;
                    case MotionEvent.ACTION_UP:
                        // 点击弹编辑
                        float upX = event.getRawX();
                        float upY = event.getRawY();
                        if (Math.abs(upX - downRawX) < 10 && Math.abs(upY - downRawY) < 10) {
                            showEditDialog();
                        }
                        return true;
                }
                return false;
            });
        }

        private void showEditDialog() {
            EditText et = new EditText(getContext());
            et.setText(getText());
            et.setMinLines(2);

            new AlertDialog.Builder(getContext())
                    .setTitle("编辑文本")
                    .setView(et)
                    .setPositiveButton("确定", (d, w) -> setText(et.getText().toString()))
                    .setNeutralButton("删除", (d, w) -> {
                        View p = (View) getParent();
                        if (p instanceof FrameLayout) {
                            ((FrameLayout) p).removeView(this);
                        }
                    })
                    .setNegativeButton("取消", null)
                    .show();
        }
    }
}
