package com.suzai.suzaiflowersystem;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Map;

public class TemplateEngine {
    /**
     * 模板渲染（兼容多种占位符写法）：
     * 1) {{key}} / {{ key }}
     * 2) ${key}
     * 3) {key}
     *
     * 说明：用户导入模板时，经常会混用不同格式；这里统一兼容，避免出现“只打印模板不替换变量”。
     */
    public static String render(String template, Map<String, String> data) {
        if (template == null) return "";
        String out = template;
        if (data == null || data.isEmpty()) return out;

        for (Map.Entry<String, String> e : data.entrySet()) {
            String k = e.getKey();
            if (k == null || k.trim().isEmpty()) continue;
            String v = e.getValue() == null ? "" : e.getValue();

            // 1) {{key}} / {{ key }}
            out = replaceAll(out, "\\{\\{\\s*" + Pattern.quote(k) + "\\s*\\}\\}", v);
            // 2) ${key}
            out = replaceAll(out, "\\$\\{\\s*" + Pattern.quote(k) + "\\s*\\}", v);
            // 3) {key}
            out = replaceAll(out, "\\{\\s*" + Pattern.quote(k) + "\\s*\\}", v);
        }
        return out;
    }

    private static String replaceAll(String src, String regex, String replacement) {
        try {
            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(src);
            return m.replaceAll(Matcher.quoteReplacement(replacement));
        } catch (Exception e) {
            // fallback：不让渲染崩
            return src;
        }
    }
}
